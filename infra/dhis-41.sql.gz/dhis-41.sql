--
-- PostgreSQL database dump
--

\restrict bariPagwfIa45BR4nvpqwP5XoTf6iysnCssZVFNXqGEEVaXHAG9ygRfrkdVWugI

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg11+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg11+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.potentialduplicate DROP CONSTRAINT IF EXISTS potentialduplicate_lastupdatedby_user;
ALTER TABLE IF EXISTS ONLY public.smscommandspecialcharacters DROP CONSTRAINT IF EXISTS fktl0s6blarqvbvjhnoa94drtb2;
ALTER TABLE IF EXISTS ONLY public.datasetnotificationtemplate_deliverychannel DROP CONSTRAINT IF EXISTS fkpmebskggkjfjfwxw7u43twmg2;
ALTER TABLE IF EXISTS ONLY public.pushanalysisrecipientusergroups DROP CONSTRAINT IF EXISTS fklllvhilfsouycft98q82ph66q;
ALTER TABLE IF EXISTS ONLY public.programmessage_deliverychannels DROP CONSTRAINT IF EXISTS fkljv6vp4ro5l6stx7dclnkenen;
ALTER TABLE IF EXISTS ONLY public.outbound_sms_recipients DROP CONSTRAINT IF EXISTS fkktmkxjuo5b3v1q2jqk7lymh0p;
ALTER TABLE IF EXISTS ONLY public.programindicatorlegendsets DROP CONSTRAINT IF EXISTS fkkbd9rqv83w4nwogj5fchtxj9y;
ALTER TABLE IF EXISTS ONLY public.pushanalysis DROP CONSTRAINT IF EXISTS fkibpy72i2p9nfkdtqqe6my34nr;
ALTER TABLE IF EXISTS ONLY public.program_userroles DROP CONSTRAINT IF EXISTS fkgb55kdvtf92qykh2840inyhst;
ALTER TABLE IF EXISTS ONLY public.previouspasswords DROP CONSTRAINT IF EXISTS fkg6n5kwuhypwdvkn15ke824kpb;
ALTER TABLE IF EXISTS ONLY public.datasetnotification_datasets DROP CONSTRAINT IF EXISTS fken6g44y648k1fembweltcao3e;
ALTER TABLE IF EXISTS ONLY public.smscommandcodes DROP CONSTRAINT IF EXISTS fke1eymlpayuhawlo8pfuwue654;
ALTER TABLE IF EXISTS ONLY public.smscommandspecialcharacters DROP CONSTRAINT IF EXISTS fkch98ncn24f71dft102f7of537;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributelegendsets DROP CONSTRAINT IF EXISTS fkcdkajbb0rpnpwuo57i894s0dg;
ALTER TABLE IF EXISTS ONLY public.smscommandcodes DROP CONSTRAINT IF EXISTS fkc6ibwny8jp0hq6l6w0w2untt4;
ALTER TABLE IF EXISTS ONLY public.programmessage_emailaddresses DROP CONSTRAINT IF EXISTS fkbyaw75hj8du8w14hpuhxj762w;
ALTER TABLE IF EXISTS ONLY public.dataelementlegendsets DROP CONSTRAINT IF EXISTS fkbrsplevygf9yr4hvydhix39ug;
ALTER TABLE IF EXISTS ONLY public.visualization_yearlyseries DROP CONSTRAINT IF EXISTS fk_visualization_yearlyseries_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization DROP CONSTRAINT IF EXISTS fk_visualization_userid;
ALTER TABLE IF EXISTS ONLY public.visualization_rows DROP CONSTRAINT IF EXISTS fk_visualization_rows_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization DROP CONSTRAINT IF EXISTS fk_visualization_relativeperiodsid;
ALTER TABLE IF EXISTS ONLY public.visualization_periods DROP CONSTRAINT IF EXISTS fk_visualization_periods_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_periods DROP CONSTRAINT IF EXISTS fk_visualization_periods_periodid;
ALTER TABLE IF EXISTS ONLY public.visualization_orgunitlevels DROP CONSTRAINT IF EXISTS fk_visualization_orgunitlevels_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS fk_visualization_orgunitgroupsetdimensions_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_organisationunits DROP CONSTRAINT IF EXISTS fk_visualization_organisationunits_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_organisationunits DROP CONSTRAINT IF EXISTS fk_visualization_organisationunits_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.visualization DROP CONSTRAINT IF EXISTS fk_visualization_legendsetid;
ALTER TABLE IF EXISTS ONLY public.visualization DROP CONSTRAINT IF EXISTS fk_visualization_lastupdateby;
ALTER TABLE IF EXISTS ONLY public.visualization_itemorgunitgroups DROP CONSTRAINT IF EXISTS fk_visualization_itemorgunitunitgroups_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_itemorgunitgroups DROP CONSTRAINT IF EXISTS fk_visualization_itemorgunitgroups_orgunitgroupid;
ALTER TABLE IF EXISTS ONLY public.visualization_filters DROP CONSTRAINT IF EXISTS fk_visualization_filters_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS fk_visualization_dimensions_orgunitgroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.visualization_dataelementgroupsetdimensions DROP CONSTRAINT IF EXISTS fk_visualization_dimensions_dataelementgroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.visualization_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS fk_visualization_dimensions_catoptiongroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.visualization_dataelementgroupsetdimensions DROP CONSTRAINT IF EXISTS fk_visualization_dataelementgroupsetdimensions_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_datadimensionitems DROP CONSTRAINT IF EXISTS fk_visualization_datadimensionitems_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_datadimensionitems DROP CONSTRAINT IF EXISTS fk_visualization_datadimensionitems_datadimensionitemid;
ALTER TABLE IF EXISTS ONLY public.visualization_columns DROP CONSTRAINT IF EXISTS fk_visualization_columns_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS fk_visualization_catoptiongroupsetdimensions_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_categorydimensions DROP CONSTRAINT IF EXISTS fk_visualization_categorydimensions_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_categorydimensions DROP CONSTRAINT IF EXISTS fk_visualization_categorydimensions_categorydimensionid;
ALTER TABLE IF EXISTS ONLY public.visualization_axis DROP CONSTRAINT IF EXISTS fk_visualization_axis_visualizationid;
ALTER TABLE IF EXISTS ONLY public.visualization_axis DROP CONSTRAINT IF EXISTS fk_visualization_axis_axisid;
ALTER TABLE IF EXISTS ONLY public.validationrulegroupmembers DROP CONSTRAINT IF EXISTS fk_validationrulegroupmembers_validationrulegroupid;
ALTER TABLE IF EXISTS ONLY public.validationrulegroupmembers DROP CONSTRAINT IF EXISTS fk_validationrulegroup_validationruleid;
ALTER TABLE IF EXISTS ONLY public.validationrulegroup DROP CONSTRAINT IF EXISTS fk_validationrulegroup_userid;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplatevalidationrules DROP CONSTRAINT IF EXISTS fk_validationrule_validationnotificationtemplateid;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS fk_validationrule_userid;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS fk_validationrule_skiptestexpressionid;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS fk_validationrule_rightexpressionid;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS fk_validationrule_periodtypeid;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS fk_validationrule_periodtypeid;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS fk_validationrule_leftexpressionid;
ALTER TABLE IF EXISTS ONLY public.validationresult DROP CONSTRAINT IF EXISTS fk_validationresult_validationruleid;
ALTER TABLE IF EXISTS ONLY public.validationresult DROP CONSTRAINT IF EXISTS fk_validationresult_period;
ALTER TABLE IF EXISTS ONLY public.validationresult DROP CONSTRAINT IF EXISTS fk_validationresult_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.validationresult DROP CONSTRAINT IF EXISTS fk_validationresult_attributeoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplate_recipientusergroups DROP CONSTRAINT IF EXISTS fk_validationnotificationtemplate_usergroup;
ALTER TABLE IF EXISTS ONLY public.userteisearchorgunits DROP CONSTRAINT IF EXISTS fk_userteisearchorgunits_userinfoid;
ALTER TABLE IF EXISTS ONLY public.userteisearchorgunits DROP CONSTRAINT IF EXISTS fk_userteisearchorgunits_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.usersetting DROP CONSTRAINT IF EXISTS fk_usersetting_userinfoid;
ALTER TABLE IF EXISTS ONLY public.users_cogsdimensionconstraints DROP CONSTRAINT IF EXISTS fk_users_cogsconstraints_userid;
ALTER TABLE IF EXISTS ONLY public.users_catdimensionconstraints DROP CONSTRAINT IF EXISTS fk_users_catconstraints_userid;
ALTER TABLE IF EXISTS ONLY public.userrolerestrictions DROP CONSTRAINT IF EXISTS fk_userrolerestrictions_userroleid;
ALTER TABLE IF EXISTS ONLY public.userrolemembers DROP CONSTRAINT IF EXISTS fk_userrolemembers_userroleid;
ALTER TABLE IF EXISTS ONLY public.userrolemembers DROP CONSTRAINT IF EXISTS fk_userrolemembers_userid;
ALTER TABLE IF EXISTS ONLY public.userroleauthorities DROP CONSTRAINT IF EXISTS fk_userroleauthorities_userroleid;
ALTER TABLE IF EXISTS ONLY public.userrole DROP CONSTRAINT IF EXISTS fk_userrole_userid;
ALTER TABLE IF EXISTS ONLY public.usermessage DROP CONSTRAINT IF EXISTS fk_usermessage_user;
ALTER TABLE IF EXISTS ONLY public.usermembership DROP CONSTRAINT IF EXISTS fk_usermembership_userinfoid;
ALTER TABLE IF EXISTS ONLY public.userkeyjsonvalue DROP CONSTRAINT IF EXISTS fk_userkeyjsonvalue_user;
ALTER TABLE IF EXISTS ONLY public.usermembership DROP CONSTRAINT IF EXISTS fk_userinfo_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.usergroupmembers DROP CONSTRAINT IF EXISTS fk_usergroupmembers_userid;
ALTER TABLE IF EXISTS ONLY public.usergroupmembers DROP CONSTRAINT IF EXISTS fk_usergroupmembers_usergroupid;
ALTER TABLE IF EXISTS ONLY public.usergroupmanaged DROP CONSTRAINT IF EXISTS fk_usergroupmanaging_managedgroupid;
ALTER TABLE IF EXISTS ONLY public.usergroupmanaged DROP CONSTRAINT IF EXISTS fk_usergroupmanaging_managedbygroupid;
ALTER TABLE IF EXISTS ONLY public.usergroup DROP CONSTRAINT IF EXISTS fk_usergroup_userid;
ALTER TABLE IF EXISTS ONLY public.userdatavieworgunits DROP CONSTRAINT IF EXISTS fk_userdatavieworgunits_userinfoid;
ALTER TABLE IF EXISTS ONLY public.userdatavieworgunits DROP CONSTRAINT IF EXISTS fk_userdatavieworgunits_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.userapps DROP CONSTRAINT IF EXISTS fk_userapps_userinfoid;
ALTER TABLE IF EXISTS ONLY public.userinfo DROP CONSTRAINT IF EXISTS fk_user_fileresourceid;
ALTER TABLE IF EXISTS ONLY public.trackedentitytypeattribute DROP CONSTRAINT IF EXISTS fk_trackedentitytypeattribute_trackedentitytypeid;
ALTER TABLE IF EXISTS ONLY public.trackedentitytypeattribute DROP CONSTRAINT IF EXISTS fk_trackedentitytypeattribute_trackedentityattributeid;
ALTER TABLE IF EXISTS ONLY public.trackedentitytype DROP CONSTRAINT IF EXISTS fk_trackedentitytype_userid;
ALTER TABLE IF EXISTS ONLY public.trackedentityprogramowner DROP CONSTRAINT IF EXISTS fk_trackedentityprogramowner_trackedentityinstanceid;
ALTER TABLE IF EXISTS ONLY public.trackedentityprogramowner DROP CONSTRAINT IF EXISTS fk_trackedentityprogramowner_programid;
ALTER TABLE IF EXISTS ONLY public.trackedentityprogramowner DROP CONSTRAINT IF EXISTS fk_trackedentityprogramowner_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.trackedentityfilter DROP CONSTRAINT IF EXISTS fk_trackedentityinstancefilter_userid;
ALTER TABLE IF EXISTS ONLY public.trackedentityfilter DROP CONSTRAINT IF EXISTS fk_trackedentityinstancefilter_programid;
ALTER TABLE IF EXISTS ONLY public.trackedentity DROP CONSTRAINT IF EXISTS fk_trackedentityinstance_trackedentitytypeid;
ALTER TABLE IF EXISTS ONLY public.trackedentity DROP CONSTRAINT IF EXISTS fk_trackedentityinstance_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattribute DROP CONSTRAINT IF EXISTS fk_trackedentityattribute_userid;
ALTER TABLE IF EXISTS ONLY public.smscodes DROP CONSTRAINT IF EXISTS fk_trackedentityattribute_trackedentityattributeid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattribute DROP CONSTRAINT IF EXISTS fk_trackedentityattribute_optionsetid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributelegendsets DROP CONSTRAINT IF EXISTS fk_trackedentityattribute_legendsetid;
ALTER TABLE IF EXISTS ONLY public.trackedentityprogramindicatordimension DROP CONSTRAINT IF EXISTS fk_teprogramindicatordimension_programindicatorid;
ALTER TABLE IF EXISTS ONLY public.trackedentityprogramindicatordimension DROP CONSTRAINT IF EXISTS fk_teprogramindicatordimension_legendsetid;
ALTER TABLE IF EXISTS ONLY public.trackedentitydataelementdimension DROP CONSTRAINT IF EXISTS fk_tedataelementdimension_programstageid;
ALTER TABLE IF EXISTS ONLY public.trackedentitydataelementdimension DROP CONSTRAINT IF EXISTS fk_tedataelementdimension_legendsetid;
ALTER TABLE IF EXISTS ONLY public.trackedentitydataelementdimension DROP CONSTRAINT IF EXISTS fk_tedataelementdimension_dataelementid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributedimension DROP CONSTRAINT IF EXISTS fk_teattributedimension_legendsetid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributedimension DROP CONSTRAINT IF EXISTS fk_teattributedimension_attributeid;
ALTER TABLE IF EXISTS ONLY public.sqlview DROP CONSTRAINT IF EXISTS fk_sqlview_userid;
ALTER TABLE IF EXISTS ONLY public.smscommands DROP CONSTRAINT IF EXISTS fk_smscommand_usergroup;
ALTER TABLE IF EXISTS ONLY public.smscommands DROP CONSTRAINT IF EXISTS fk_smscommand_programstage;
ALTER TABLE IF EXISTS ONLY public.smscommands DROP CONSTRAINT IF EXISTS fk_smscommand_program;
ALTER TABLE IF EXISTS ONLY public.sectionindicators DROP CONSTRAINT IF EXISTS fk_sectionindicators_sectionid;
ALTER TABLE IF EXISTS ONLY public.sectiongreyedfields DROP CONSTRAINT IF EXISTS fk_sectiongreyedfields_sectionid;
ALTER TABLE IF EXISTS ONLY public.sectiondataelements DROP CONSTRAINT IF EXISTS fk_sectiondataelements_sectionid;
ALTER TABLE IF EXISTS ONLY public.sectionindicators DROP CONSTRAINT IF EXISTS fk_section_indicatorid;
ALTER TABLE IF EXISTS ONLY public.section DROP CONSTRAINT IF EXISTS fk_section_datasetid;
ALTER TABLE IF EXISTS ONLY public.sectiongreyedfields DROP CONSTRAINT IF EXISTS fk_section_dataelementoperandid;
ALTER TABLE IF EXISTS ONLY public.sectiondataelements DROP CONSTRAINT IF EXISTS fk_section_dataelementid;
ALTER TABLE IF EXISTS ONLY public.route DROP CONSTRAINT IF EXISTS fk_route_userid_userinfoid;
ALTER TABLE IF EXISTS ONLY public.route DROP CONSTRAINT IF EXISTS fk_route_lastupdateby_userinfoid;
ALTER TABLE IF EXISTS ONLY public.report DROP CONSTRAINT IF EXISTS fk_report_visualizationid;
ALTER TABLE IF EXISTS ONLY public.report DROP CONSTRAINT IF EXISTS fk_report_userid;
ALTER TABLE IF EXISTS ONLY public.report DROP CONSTRAINT IF EXISTS fk_report_relativeperiodsid;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS fk_relationshiptype_userid;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS fk_relationshiptype_to_relationshipconstraintid;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS fk_relationshiptype_from_relationshipconstraintid;
ALTER TABLE IF EXISTS ONLY public.relationshipitem DROP CONSTRAINT IF EXISTS fk_relationshipitem_trackedentityinstanceid;
ALTER TABLE IF EXISTS ONLY public.relationshipitem DROP CONSTRAINT IF EXISTS fk_relationshipitem_relationshipid;
ALTER TABLE IF EXISTS ONLY public.relationshipitem DROP CONSTRAINT IF EXISTS fk_relationshipitem_programstageinstanceid;
ALTER TABLE IF EXISTS ONLY public.relationshipitem DROP CONSTRAINT IF EXISTS fk_relationshipitem_programinstanceid;
ALTER TABLE IF EXISTS ONLY public.relationshipconstraint DROP CONSTRAINT IF EXISTS fk_relationshipconstraint_trackedentitytype_trackedentitytypeid;
ALTER TABLE IF EXISTS ONLY public.relationshipconstraint DROP CONSTRAINT IF EXISTS fk_relationshipconstraint_programstage_programstageid;
ALTER TABLE IF EXISTS ONLY public.relationshipconstraint DROP CONSTRAINT IF EXISTS fk_relationshipconstraint_program_programid;
ALTER TABLE IF EXISTS ONLY public.relationship DROP CONSTRAINT IF EXISTS fk_relationship_to_relationshipitemid;
ALTER TABLE IF EXISTS ONLY public.relationship DROP CONSTRAINT IF EXISTS fk_relationship_relationshiptypeid;
ALTER TABLE IF EXISTS ONLY public.relationship DROP CONSTRAINT IF EXISTS fk_relationship_from_relationshipitemid;
ALTER TABLE IF EXISTS ONLY public.pushanalysisrecipientusergroups DROP CONSTRAINT IF EXISTS fk_pushanalysis_recipientusergroups;
ALTER TABLE IF EXISTS ONLY public.program_attributes DROP CONSTRAINT IF EXISTS fk_programtrackedentityattribute_programid;
ALTER TABLE IF EXISTS ONLY public.programtempownershipaudit DROP CONSTRAINT IF EXISTS fk_programtempownershipaudit_trackedentityinstanceid;
ALTER TABLE IF EXISTS ONLY public.programtempownershipaudit DROP CONSTRAINT IF EXISTS fk_programtempownershipaudit_programid;
ALTER TABLE IF EXISTS ONLY public.programtempowner DROP CONSTRAINT IF EXISTS fk_programtempowner_userid;
ALTER TABLE IF EXISTS ONLY public.programtempowner DROP CONSTRAINT IF EXISTS fk_programtempowner_trackedentityinstanceid;
ALTER TABLE IF EXISTS ONLY public.programtempowner DROP CONSTRAINT IF EXISTS fk_programtempowner_programid;
ALTER TABLE IF EXISTS ONLY public.programstageworkinglist DROP CONSTRAINT IF EXISTS fk_programstageworkinglist_programstageid;
ALTER TABLE IF EXISTS ONLY public.programstageworkinglist DROP CONSTRAINT IF EXISTS fk_programstageworkinglist_programid;
ALTER TABLE IF EXISTS ONLY public.programstagesection_programindicators DROP CONSTRAINT IF EXISTS fk_programstagesection_programindicators_sectionid;
ALTER TABLE IF EXISTS ONLY public.programstagesection_programindicators DROP CONSTRAINT IF EXISTS fk_programstagesection_programindicators_indicatorid;
ALTER TABLE IF EXISTS ONLY public.programstagesection_dataelements DROP CONSTRAINT IF EXISTS fk_programstagesection_dataelements_programstagesectionid;
ALTER TABLE IF EXISTS ONLY public.programstagesection_dataelements DROP CONSTRAINT IF EXISTS fk_programstagesection_dataelements_dataelementid;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate DROP CONSTRAINT IF EXISTS fk_programstagenotification_usergroup;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate DROP CONSTRAINT IF EXISTS fk_programstagenotification_trackedentityattributeid;
ALTER TABLE IF EXISTS ONLY public.programnotificationinstance DROP CONSTRAINT IF EXISTS fk_programstagenotification_psi;
ALTER TABLE IF EXISTS ONLY public.programnotificationinstance DROP CONSTRAINT IF EXISTS fk_programstagenotification_pi;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate DROP CONSTRAINT IF EXISTS fk_programstagenotification_dataelementid;
ALTER TABLE IF EXISTS ONLY public.eventfilter DROP CONSTRAINT IF EXISTS fk_programstageinstancefilter_userid;
ALTER TABLE IF EXISTS ONLY public.event_notes DROP CONSTRAINT IF EXISTS fk_programstageinstancecomments_trackedentitycommentid;
ALTER TABLE IF EXISTS ONLY public.event_notes DROP CONSTRAINT IF EXISTS fk_programstageinstancecomments_programstageinstanceid;
ALTER TABLE IF EXISTS ONLY public.event DROP CONSTRAINT IF EXISTS fk_programstageinstance_programstageid;
ALTER TABLE IF EXISTS ONLY public.event DROP CONSTRAINT IF EXISTS fk_programstageinstance_programinstanceid;
ALTER TABLE IF EXISTS ONLY public.event DROP CONSTRAINT IF EXISTS fk_programstageinstance_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.event DROP CONSTRAINT IF EXISTS fk_programstageinstance_attributeoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.event DROP CONSTRAINT IF EXISTS fk_programstageinstance_assigneduserid;
ALTER TABLE IF EXISTS ONLY public.programstagedataelement DROP CONSTRAINT IF EXISTS fk_programstagedataelement_programstageid;
ALTER TABLE IF EXISTS ONLY public.programstagedataelement DROP CONSTRAINT IF EXISTS fk_programstagedataelement_dataelementid;
ALTER TABLE IF EXISTS ONLY public.programstage DROP CONSTRAINT IF EXISTS fk_programstage_userid;
ALTER TABLE IF EXISTS ONLY public.programstage DROP CONSTRAINT IF EXISTS fk_programstage_program;
ALTER TABLE IF EXISTS ONLY public.programstage DROP CONSTRAINT IF EXISTS fk_programstage_periodtypeid;
ALTER TABLE IF EXISTS ONLY public.programstage DROP CONSTRAINT IF EXISTS fk_programstage_nextscheduledateid;
ALTER TABLE IF EXISTS ONLY public.programstage DROP CONSTRAINT IF EXISTS fk_programstage_dataentryform;
ALTER TABLE IF EXISTS ONLY public.programsection_attributes DROP CONSTRAINT IF EXISTS fk_programsections_attributes_programsectionid;
ALTER TABLE IF EXISTS ONLY public.programsection_attributes DROP CONSTRAINT IF EXISTS fk_programsection_attributes_trackedentityattributeid;
ALTER TABLE IF EXISTS ONLY public.programrulevariable DROP CONSTRAINT IF EXISTS fk_programrulevariable_trackedentityattribute;
ALTER TABLE IF EXISTS ONLY public.programrulevariable DROP CONSTRAINT IF EXISTS fk_programrulevariable_programstage;
ALTER TABLE IF EXISTS ONLY public.programrulevariable DROP CONSTRAINT IF EXISTS fk_programrulevariable_program;
ALTER TABLE IF EXISTS ONLY public.programrulevariable DROP CONSTRAINT IF EXISTS fk_programrulevariable_dataelement;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS fk_programruleaction_trackedentityattribute;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS fk_programruleaction_programstagesection;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS fk_programruleaction_programstage;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS fk_programruleaction_programrule;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS fk_programruleaction_programindicator;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS fk_programruleaction_optiongroup;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS fk_programruleaction_option;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS fk_programruleaction_dataelement;
ALTER TABLE IF EXISTS ONLY public.programrule DROP CONSTRAINT IF EXISTS fk_programrule_programstage;
ALTER TABLE IF EXISTS ONLY public.programrule DROP CONSTRAINT IF EXISTS fk_programrule_program;
ALTER TABLE IF EXISTS ONLY public.programownershiphistory DROP CONSTRAINT IF EXISTS fk_programownershiphistory_trackedentityinstanceid;
ALTER TABLE IF EXISTS ONLY public.programownershiphistory DROP CONSTRAINT IF EXISTS fk_programownershiphistory_programid;
ALTER TABLE IF EXISTS ONLY public.programownershiphistory DROP CONSTRAINT IF EXISTS fk_programownershiphistory_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.programmessage DROP CONSTRAINT IF EXISTS fk_programmessage_trackedentityinstanceid;
ALTER TABLE IF EXISTS ONLY public.programmessage DROP CONSTRAINT IF EXISTS fk_programmessage_programstageinstanceid;
ALTER TABLE IF EXISTS ONLY public.programmessage DROP CONSTRAINT IF EXISTS fk_programmessage_programinstanceid;
ALTER TABLE IF EXISTS ONLY public.programmessage DROP CONSTRAINT IF EXISTS fk_programmessage_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.enrollment_notes DROP CONSTRAINT IF EXISTS fk_programinstancecomments_trackedentitycommentid;
ALTER TABLE IF EXISTS ONLY public.enrollment_notes DROP CONSTRAINT IF EXISTS fk_programinstancecomments_programinstanceid;
ALTER TABLE IF EXISTS ONLY public.enrollment DROP CONSTRAINT IF EXISTS fk_programinstance_trackedentityinstanceid;
ALTER TABLE IF EXISTS ONLY public.enrollment DROP CONSTRAINT IF EXISTS fk_programinstance_programid;
ALTER TABLE IF EXISTS ONLY public.enrollment DROP CONSTRAINT IF EXISTS fk_programinstance_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.programindicatorgroupmembers DROP CONSTRAINT IF EXISTS fk_programindicatorgroupmembers_programindicatorgroupid;
ALTER TABLE IF EXISTS ONLY public.programindicatorgroup DROP CONSTRAINT IF EXISTS fk_programindicatorgroup_userid;
ALTER TABLE IF EXISTS ONLY public.programindicatorgroupmembers DROP CONSTRAINT IF EXISTS fk_programindicatorgroup_programindicatorid;
ALTER TABLE IF EXISTS ONLY public.programindicator DROP CONSTRAINT IF EXISTS fk_programindicator_userid;
ALTER TABLE IF EXISTS ONLY public.programindicator DROP CONSTRAINT IF EXISTS fk_programindicator_program;
ALTER TABLE IF EXISTS ONLY public.programindicatorlegendsets DROP CONSTRAINT IF EXISTS fk_programindicator_legendsetid;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS fk_program_userid;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS fk_program_trackedentitytypeid;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS fk_program_relatedprogram;
ALTER TABLE IF EXISTS ONLY public.programstagesection DROP CONSTRAINT IF EXISTS fk_program_programstageid;
ALTER TABLE IF EXISTS ONLY public.programsection DROP CONSTRAINT IF EXISTS fk_program_programid;
ALTER TABLE IF EXISTS ONLY public.program_organisationunits DROP CONSTRAINT IF EXISTS fk_program_organisationunits_programid;
ALTER TABLE IF EXISTS ONLY public.program_organisationunits DROP CONSTRAINT IF EXISTS fk_program_organisationunits_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS fk_program_expiryperiodtypeid;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS fk_program_dataentryformid;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS fk_program_categorycomboid;
ALTER TABLE IF EXISTS ONLY public.program_attributes DROP CONSTRAINT IF EXISTS fk_program_attributeid;
ALTER TABLE IF EXISTS ONLY public.predictororgunitlevels DROP CONSTRAINT IF EXISTS fk_predictororgunitlevels_predictorid;
ALTER TABLE IF EXISTS ONLY public.predictororgunitlevels DROP CONSTRAINT IF EXISTS fk_predictororgunitlevels_orgunitlevelid;
ALTER TABLE IF EXISTS ONLY public.predictorgroupmembers DROP CONSTRAINT IF EXISTS fk_predictorgroupmembers_predictorgroupid;
ALTER TABLE IF EXISTS ONLY public.predictorgroup DROP CONSTRAINT IF EXISTS fk_predictorgroup_userid;
ALTER TABLE IF EXISTS ONLY public.predictorgroupmembers DROP CONSTRAINT IF EXISTS fk_predictorgroup_predictorid;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS fk_predictor_outputdataelementid;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS fk_predictor_outputcomboid;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS fk_predictor_generatorexpressionid;
ALTER TABLE IF EXISTS ONLY public.periodboundary DROP CONSTRAINT IF EXISTS fk_periodboundary_programindicator;
ALTER TABLE IF EXISTS ONLY public.periodboundary DROP CONSTRAINT IF EXISTS fk_periodboundary_periodtype;
ALTER TABLE IF EXISTS ONLY public.period DROP CONSTRAINT IF EXISTS fk_period_periodtypeid;
ALTER TABLE IF EXISTS ONLY public.organisationunit DROP CONSTRAINT IF EXISTS fk_parentid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupsetmembers DROP CONSTRAINT IF EXISTS fk_orgunitgroupsetmembers_orgunitgroupsetid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupset DROP CONSTRAINT IF EXISTS fk_orgunitgroupset_userid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupsetmembers DROP CONSTRAINT IF EXISTS fk_orgunitgroupset_orgunitgroupid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupmembers DROP CONSTRAINT IF EXISTS fk_orgunitgroupmembers_orgunitgroupid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroup DROP CONSTRAINT IF EXISTS fk_orgunitgroup_userid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupmembers DROP CONSTRAINT IF EXISTS fk_orgunitgroup_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.validationruleorganisationunitlevels DROP CONSTRAINT IF EXISTS fk_organisationunitlevel_validationtuleid;
ALTER TABLE IF EXISTS ONLY public.organisationunit DROP CONSTRAINT IF EXISTS fk_organisationunit_userid;
ALTER TABLE IF EXISTS ONLY public.organisationunit DROP CONSTRAINT IF EXISTS fk_organisationunit_fileresourceid;
ALTER TABLE IF EXISTS ONLY public.optionvalue DROP CONSTRAINT IF EXISTS fk_optionsetmembers_optionsetid;
ALTER TABLE IF EXISTS ONLY public.optionset DROP CONSTRAINT IF EXISTS fk_optionset_userid;
ALTER TABLE IF EXISTS ONLY public.optiongroupsetmembers DROP CONSTRAINT IF EXISTS fk_optiongroupsetmembers_optiongroupsetid;
ALTER TABLE IF EXISTS ONLY public.optiongroupsetmembers DROP CONSTRAINT IF EXISTS fk_optiongroupsetmembers_optiongroupid;
ALTER TABLE IF EXISTS ONLY public.optiongroupset DROP CONSTRAINT IF EXISTS fk_optiongroupset_userid;
ALTER TABLE IF EXISTS ONLY public.optiongroupset DROP CONSTRAINT IF EXISTS fk_optiongroupset_optionsetid;
ALTER TABLE IF EXISTS ONLY public.optiongroupmembers DROP CONSTRAINT IF EXISTS fk_optiongroupmembers_optionid;
ALTER TABLE IF EXISTS ONLY public.optiongroupmembers DROP CONSTRAINT IF EXISTS fk_optiongroupmembers_optiongroupid;
ALTER TABLE IF EXISTS ONLY public.optiongroup DROP CONSTRAINT IF EXISTS fk_optiongroup_userid;
ALTER TABLE IF EXISTS ONLY public.optiongroup DROP CONSTRAINT IF EXISTS fk_optiongroup_optionsetid;
ALTER TABLE IF EXISTS ONLY public.oauth2clientredirecturis DROP CONSTRAINT IF EXISTS fk_oauth2clientredirecturis_oauth2clientid;
ALTER TABLE IF EXISTS ONLY public.oauth2clientgranttypes DROP CONSTRAINT IF EXISTS fk_oauth2clientgranttypes_oauth2clientid;
ALTER TABLE IF EXISTS ONLY public.minmaxdataelement DROP CONSTRAINT IF EXISTS fk_minmaxdataelement_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.minmaxdataelement DROP CONSTRAINT IF EXISTS fk_minmaxdataelement_dataelementid;
ALTER TABLE IF EXISTS ONLY public.minmaxdataelement DROP CONSTRAINT IF EXISTS fk_minmaxdataelement_categoryoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.messageconversation_usermessages DROP CONSTRAINT IF EXISTS fk_messageconversation_usermessages_usermessageid;
ALTER TABLE IF EXISTS ONLY public.messageconversation_usermessages DROP CONSTRAINT IF EXISTS fk_messageconversation_usermessages_messageconversationid;
ALTER TABLE IF EXISTS ONLY public.messageconversation DROP CONSTRAINT IF EXISTS fk_messageconversation_user_userid;
ALTER TABLE IF EXISTS ONLY public.messageconversation DROP CONSTRAINT IF EXISTS fk_messageconversation_user_user_assigned;
ALTER TABLE IF EXISTS ONLY public.messageconversation_messages DROP CONSTRAINT IF EXISTS fk_messageconversation_messages_messageid;
ALTER TABLE IF EXISTS ONLY public.messageconversation_messages DROP CONSTRAINT IF EXISTS fk_messageconversation_messages_messageconversationid;
ALTER TABLE IF EXISTS ONLY public.messageconversation DROP CONSTRAINT IF EXISTS fk_messageconversation_lastsender_userid;
ALTER TABLE IF EXISTS ONLY public.messageattachments DROP CONSTRAINT IF EXISTS fk_messageattachments_fileresourceid;
ALTER TABLE IF EXISTS ONLY public.message DROP CONSTRAINT IF EXISTS fk_message_userid;
ALTER TABLE IF EXISTS ONLY public.map DROP CONSTRAINT IF EXISTS fk_mapview_userid;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS fk_mapview_trackedentitytypeid;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS fk_mapview_relativeperiodsid;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS fk_mapview_programstageid;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS fk_mapview_programid;
ALTER TABLE IF EXISTS ONLY public.mapview_periods DROP CONSTRAINT IF EXISTS fk_mapview_periods_periodid;
ALTER TABLE IF EXISTS ONLY public.mapview_periods DROP CONSTRAINT IF EXISTS fk_mapview_periods_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_orgunitlevels DROP CONSTRAINT IF EXISTS fk_mapview_orgunitlevels_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS fk_mapview_orgunitgroupsetid;
ALTER TABLE IF EXISTS ONLY public.mapview_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS fk_mapview_orgunitgroupsetdimensions_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_organisationunits DROP CONSTRAINT IF EXISTS fk_mapview_organisationunits_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.mapview_organisationunits DROP CONSTRAINT IF EXISTS fk_mapview_organisationunits_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS fk_mapview_maplegendsetid;
ALTER TABLE IF EXISTS ONLY public.mapview_itemorgunitgroups DROP CONSTRAINT IF EXISTS fk_mapview_itemorgunitunitgroups_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_itemorgunitgroups DROP CONSTRAINT IF EXISTS fk_mapview_itemorgunitgroups_orgunitgroupid;
ALTER TABLE IF EXISTS ONLY public.mapview_filters DROP CONSTRAINT IF EXISTS fk_mapview_filters_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS fk_mapview_dimensions_orgunitgroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.mapview_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS fk_mapview_dimensions_catoptiongroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.mapview_dataelementdimensions DROP CONSTRAINT IF EXISTS fk_mapview_dataelementdimensions_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_dataelementdimensions DROP CONSTRAINT IF EXISTS fk_mapview_dataelementdimensions_dataelementdimensionid;
ALTER TABLE IF EXISTS ONLY public.mapview_datadimensionitems DROP CONSTRAINT IF EXISTS fk_mapview_datadimensionitems_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_datadimensionitems DROP CONSTRAINT IF EXISTS fk_mapview_datadimensionitems_datadimensionitemid;
ALTER TABLE IF EXISTS ONLY public.mapview_columns DROP CONSTRAINT IF EXISTS fk_mapview_columns_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS fk_mapview_catoptiongroupsetdimensions_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_categorydimensions DROP CONSTRAINT IF EXISTS fk_mapview_categorydimensions_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_categorydimensions DROP CONSTRAINT IF EXISTS fk_mapview_categorydimensions_categorydimensionid;
ALTER TABLE IF EXISTS ONLY public.mapview_attributedimensions DROP CONSTRAINT IF EXISTS fk_mapview_attributedimensions_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapview_attributedimensions DROP CONSTRAINT IF EXISTS fk_mapview_attributedimensions_attributedimensionid;
ALTER TABLE IF EXISTS ONLY public.mapmapviews DROP CONSTRAINT IF EXISTS fk_mapmapview_mapviewid;
ALTER TABLE IF EXISTS ONLY public.mapmapviews DROP CONSTRAINT IF EXISTS fk_mapmapview_mapid;
ALTER TABLE IF EXISTS ONLY public.maplegend DROP CONSTRAINT IF EXISTS fk_maplegend_maplegendsetid;
ALTER TABLE IF EXISTS ONLY public.lockexception DROP CONSTRAINT IF EXISTS fk_lockexception_periodid;
ALTER TABLE IF EXISTS ONLY public.lockexception DROP CONSTRAINT IF EXISTS fk_lockexception_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.lockexception DROP CONSTRAINT IF EXISTS fk_lockexception_datasetid;
ALTER TABLE IF EXISTS ONLY public.maplegendset DROP CONSTRAINT IF EXISTS fk_legendset_userid;
ALTER TABLE IF EXISTS ONLY public.eventfilter DROP CONSTRAINT IF EXISTS fk_lastupdatedby_userid;
ALTER TABLE IF EXISTS ONLY public.validationrulegroup DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplate DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.userrole DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.userkeyjsonvalue DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.usergroup DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.trackedentitytypeattribute DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.trackedentitytype DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.trackedentityfilter DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattribute DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.trackedentity DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.tablehook DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.sqlview DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.section DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.report DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.relationship DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.pushanalysis DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programstagesection DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programstagedataelement DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programstage DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programsection DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programrulevariable DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programrule DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programnotificationinstance DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programmessage DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programindicatorgroup DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.programindicator DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.program_attributes DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.predictorgroup DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.periodboundary DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.orgunitlevel DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupset DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroup DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.organisationunit DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.optionset DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.optiongroupset DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.optiongroup DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.oauth2client DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.note DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.metadataversion DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.maplegendset DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.maplegend DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.map DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.keyjsonvalue DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.jobconfiguration DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.indicatortype DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupset DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.indicatorgroup DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.indicator DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.i18nlocale DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.fileresource DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.externalmaplayer DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.externalfileresource DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.expressiondimensionitem DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.document DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.datastatistics DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.datasetnotificationtemplate DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.dataentryform DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupset DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroup DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflow DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.dataapprovallevel DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.dashboard DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.constant DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupset DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroup DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.categoryoptioncombo DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.categoryoption DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.categorycombo DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.attribute DROP CONSTRAINT IF EXISTS fk_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.keyjsonvalue DROP CONSTRAINT IF EXISTS fk_keyjsonvalue_userid;
ALTER TABLE IF EXISTS ONLY public.interpretationcomment DROP CONSTRAINT IF EXISTS fk_interpretationcomment_userid;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS fk_interpretation_visualizationid;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS fk_interpretation_userid;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS fk_interpretation_periodid;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS fk_interpretation_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS fk_interpretation_mapid;
ALTER TABLE IF EXISTS ONLY public.intepretation_likedby DROP CONSTRAINT IF EXISTS fk_interpretation_likedby_interpretationid;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS fk_interpretation_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS fk_interpretation_eventreportid;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS fk_interpretation_eventchartid;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS fk_interpretation_datasetid;
ALTER TABLE IF EXISTS ONLY public.interpretation_comments DROP CONSTRAINT IF EXISTS fk_interpretation_comments_interpretationid;
ALTER TABLE IF EXISTS ONLY public.interpretation_comments DROP CONSTRAINT IF EXISTS fk_interpretation_comments_interpretationcommentid;
ALTER TABLE IF EXISTS ONLY public.intepretation_likedby DROP CONSTRAINT IF EXISTS fk_intepretation_likedby_userid;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupsetmembers DROP CONSTRAINT IF EXISTS fk_indicatorgroupsetmembers_indicatorgroupsetid;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupset DROP CONSTRAINT IF EXISTS fk_indicatorgroupset_userid;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupsetmembers DROP CONSTRAINT IF EXISTS fk_indicatorgroupset_indicatorgroupid;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupmembers DROP CONSTRAINT IF EXISTS fk_indicatorgroupmembers_indicatorgroupid;
ALTER TABLE IF EXISTS ONLY public.indicatorgroup DROP CONSTRAINT IF EXISTS fk_indicatorgroup_userid;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupmembers DROP CONSTRAINT IF EXISTS fk_indicatorgroup_indicatorid;
ALTER TABLE IF EXISTS ONLY public.indicator DROP CONSTRAINT IF EXISTS fk_indicator_userid;
ALTER TABLE IF EXISTS ONLY public.indicatorlegendsets DROP CONSTRAINT IF EXISTS fk_indicator_legendsetid;
ALTER TABLE IF EXISTS ONLY public.indicator DROP CONSTRAINT IF EXISTS fk_indicator_indicatortypeid;
ALTER TABLE IF EXISTS ONLY public.incomingsms DROP CONSTRAINT IF EXISTS fk_incomingsms_userid;
ALTER TABLE IF EXISTS ONLY public.icon DROP CONSTRAINT IF EXISTS fk_icon_fileresource;
ALTER TABLE IF EXISTS ONLY public.users_cogsdimensionconstraints DROP CONSTRAINT IF EXISTS fk_fk_users_cogsconstraints_categoryoptiongroupsetid;
ALTER TABLE IF EXISTS ONLY public.users_catdimensionconstraints DROP CONSTRAINT IF EXISTS fk_fk_users_catconstraints_dataelementcategoryid;
ALTER TABLE IF EXISTS ONLY public.metadataproposal DROP CONSTRAINT IF EXISTS fk_finalisedby_userid;
ALTER TABLE IF EXISTS ONLY public.fileresource DROP CONSTRAINT IF EXISTS fk_fileresource_userid;
ALTER TABLE IF EXISTS ONLY public.externalfileresource DROP CONSTRAINT IF EXISTS fk_fileresource_externalfileresource;
ALTER TABLE IF EXISTS ONLY public.externalmaplayer DROP CONSTRAINT IF EXISTS fk_externalmaplayer_userid;
ALTER TABLE IF EXISTS ONLY public.externalmaplayer DROP CONSTRAINT IF EXISTS fk_externalmaplayer_legendsetid;
ALTER TABLE IF EXISTS ONLY public.expressiondimensionitem DROP CONSTRAINT IF EXISTS fk_expressiondimensionitem_userid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_userid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_trackedentitytypeid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_rows DROP CONSTRAINT IF EXISTS fk_evisualization_rows_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_report_relativeperiodsid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_relativeperiodsid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_programstageid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_programindicatordimensions DROP CONSTRAINT IF EXISTS fk_evisualization_programindicatordimensions_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_programindicatordimensions DROP CONSTRAINT IF EXISTS fk_evisualization_programindicatordim_programindicatordimid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_programid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_programindicatordimensions DROP CONSTRAINT IF EXISTS fk_evisualization_prindicatordimensions_prindicatordimensionid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_periods DROP CONSTRAINT IF EXISTS fk_evisualization_periods_periodid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_periods DROP CONSTRAINT IF EXISTS fk_evisualization_periods_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_orgunitlevels DROP CONSTRAINT IF EXISTS fk_evisualization_orgunitlevels_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS fk_evisualization_orgunitgroupsetdimensions_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_organisationunits DROP CONSTRAINT IF EXISTS fk_evisualization_organisationunits_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_organisationunits DROP CONSTRAINT IF EXISTS fk_evisualization_organisationunits_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_legendsetid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_lastupdateby_userid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_itemorgunitgroups DROP CONSTRAINT IF EXISTS fk_evisualization_itemorgunitunitgroups_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_itemorgunitgroups DROP CONSTRAINT IF EXISTS fk_evisualization_itemorgunitgroups_orgunitgroupid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_filters DROP CONSTRAINT IF EXISTS fk_evisualization_filters_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS fk_evisualization_dimensions_ogunitgroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS fk_evisualization_dimensions_catoptiongroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_dataelementvaluedimensionid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_dataelementdimensions DROP CONSTRAINT IF EXISTS fk_evisualization_dataelementdimensions_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_dataelementdimensions DROP CONSTRAINT IF EXISTS fk_evisualization_dataelementdimensions_dataelementdimensionid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_columns DROP CONSTRAINT IF EXISTS fk_evisualization_columns_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS fk_evisualization_catoptiongroupsetdimensions_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_categorydimensions DROP CONSTRAINT IF EXISTS fk_evisualization_categorydimensions_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_categorydimensions DROP CONSTRAINT IF EXISTS fk_evisualization_categorydimensions_categorydimensionid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS fk_evisualization_attributevaluedimensionid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_attributedimensions DROP CONSTRAINT IF EXISTS fk_evisualization_attributedimensions_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_attributedimensions DROP CONSTRAINT IF EXISTS fk_evisualization_attributedimensions_attributedimensionid;
ALTER TABLE IF EXISTS ONLY public.eventhook DROP CONSTRAINT IF EXISTS fk_eventhook_userid_userinfoid;
ALTER TABLE IF EXISTS ONLY public.eventhook DROP CONSTRAINT IF EXISTS fk_eventhook_lastupdateby_userinfoid;
ALTER TABLE IF EXISTS ONLY public.trackedentitydatavalueaudit DROP CONSTRAINT IF EXISTS fk_entityinstancedatavalueaudit_programstageinstanceid;
ALTER TABLE IF EXISTS ONLY public.trackedentitydatavalueaudit DROP CONSTRAINT IF EXISTS fk_entityinstancedatavalueaudit_dataelementid;
ALTER TABLE IF EXISTS ONLY public.document DROP CONSTRAINT IF EXISTS fk_document_userid;
ALTER TABLE IF EXISTS ONLY public.document DROP CONSTRAINT IF EXISTS fk_document_fileresourceid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupsetdimension DROP CONSTRAINT IF EXISTS fk_dimension_orgunitgroupsetid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupsetdimension_items DROP CONSTRAINT IF EXISTS fk_dimension_items_orgunitgroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupsetdimension_items DROP CONSTRAINT IF EXISTS fk_dimension_items_orgunitgroupid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupsetdimension_items DROP CONSTRAINT IF EXISTS fk_dimension_items_dataelementgroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupsetdimension_items DROP CONSTRAINT IF EXISTS fk_dimension_items_dataelementgroupid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupsetdimension_items DROP CONSTRAINT IF EXISTS fk_dimension_items_categoryoptiongroupsetdimensionid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupsetdimension_items DROP CONSTRAINT IF EXISTS fk_dimension_items_categoryoptiongroupid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupsetdimension DROP CONSTRAINT IF EXISTS fk_dimension_dataelementgroupsetid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupsetdimension DROP CONSTRAINT IF EXISTS fk_dimension_categoryoptiongroupsetid;
ALTER TABLE IF EXISTS ONLY public.datavalueaudit DROP CONSTRAINT IF EXISTS fk_datavalueaudit_periodid;
ALTER TABLE IF EXISTS ONLY public.datavalueaudit DROP CONSTRAINT IF EXISTS fk_datavalueaudit_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.datavalueaudit DROP CONSTRAINT IF EXISTS fk_datavalueaudit_dataelementid;
ALTER TABLE IF EXISTS ONLY public.datavalueaudit DROP CONSTRAINT IF EXISTS fk_datavalueaudit_categoryoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.datavalueaudit DROP CONSTRAINT IF EXISTS fk_datavalueaudit_attributeoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.datavalue DROP CONSTRAINT IF EXISTS fk_datavalue_periodid;
ALTER TABLE IF EXISTS ONLY public.datavalue DROP CONSTRAINT IF EXISTS fk_datavalue_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.datavalue DROP CONSTRAINT IF EXISTS fk_datavalue_dataelementid;
ALTER TABLE IF EXISTS ONLY public.datavalue DROP CONSTRAINT IF EXISTS fk_datavalue_categoryoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.datavalue DROP CONSTRAINT IF EXISTS fk_datavalue_attributeoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.datasetsource DROP CONSTRAINT IF EXISTS fk_datasetsource_datasetid;
ALTER TABLE IF EXISTS ONLY public.datasetnotification_datasets DROP CONSTRAINT IF EXISTS fk_datasets_datasetnotificationtemplateid;
ALTER TABLE IF EXISTS ONLY public.datasetoperands DROP CONSTRAINT IF EXISTS fk_datasetoperands_datasetid;
ALTER TABLE IF EXISTS ONLY public.datasetnotificationtemplate DROP CONSTRAINT IF EXISTS fk_datasetnotification_usergroup;
ALTER TABLE IF EXISTS ONLY public.datasetelement DROP CONSTRAINT IF EXISTS fk_datasetmembers_datasetid;
ALTER TABLE IF EXISTS ONLY public.datasetelement DROP CONSTRAINT IF EXISTS fk_datasetmembers_dataelementid;
ALTER TABLE IF EXISTS ONLY public.datasetindicators DROP CONSTRAINT IF EXISTS fk_datasetindicators_datasetid;
ALTER TABLE IF EXISTS ONLY public.datasetelement DROP CONSTRAINT IF EXISTS fk_datasetelement_categorycomboid;
ALTER TABLE IF EXISTS ONLY public.datainputperiod DROP CONSTRAINT IF EXISTS fk_datasetdatainputperiods_datasetid;
ALTER TABLE IF EXISTS ONLY public.completedatasetregistration DROP CONSTRAINT IF EXISTS fk_datasetcompleteregistration_periodid;
ALTER TABLE IF EXISTS ONLY public.completedatasetregistration DROP CONSTRAINT IF EXISTS fk_datasetcompleteregistration_datasetid;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS fk_dataset_workflowid;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS fk_dataset_userid;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS fk_dataset_periodtypeid;
ALTER TABLE IF EXISTS ONLY public.datasetsource DROP CONSTRAINT IF EXISTS fk_dataset_organisationunit;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS fk_dataset_notificationrecipients;
ALTER TABLE IF EXISTS ONLY public.datasetlegendsets DROP CONSTRAINT IF EXISTS fk_dataset_legendsetid;
ALTER TABLE IF EXISTS ONLY public.datasetindicators DROP CONSTRAINT IF EXISTS fk_dataset_indicatorid;
ALTER TABLE IF EXISTS ONLY public.smscommands DROP CONSTRAINT IF EXISTS fk_dataset_datasetid;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS fk_dataset_dataentryform;
ALTER TABLE IF EXISTS ONLY public.datasetoperands DROP CONSTRAINT IF EXISTS fk_dataset_dataelementoperandid;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS fk_dataset_categorycomboid;
ALTER TABLE IF EXISTS ONLY public.datainputperiod DROP CONSTRAINT IF EXISTS fk_datainputperiod_period;
ALTER TABLE IF EXISTS ONLY public.dataelementoperand DROP CONSTRAINT IF EXISTS fk_dataelementoperand_dataelementcategoryoptioncombo;
ALTER TABLE IF EXISTS ONLY public.dataelementoperand DROP CONSTRAINT IF EXISTS fk_dataelementoperand_dataelement;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupsetmembers DROP CONSTRAINT IF EXISTS fk_dataelementgroupsetmembers_dataelementgroupsetid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupset DROP CONSTRAINT IF EXISTS fk_dataelementgroupset_userid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupsetmembers DROP CONSTRAINT IF EXISTS fk_dataelementgroupset_dataelementgroupid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupmembers DROP CONSTRAINT IF EXISTS fk_dataelementgroupmembers_dataelementgroupid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroup DROP CONSTRAINT IF EXISTS fk_dataelementgroup_userid;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupmembers DROP CONSTRAINT IF EXISTS fk_dataelementgroup_dataelementid;
ALTER TABLE IF EXISTS ONLY public.categoryoption DROP CONSTRAINT IF EXISTS fk_dataelementcategoryoption_userid;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS fk_dataelementcategory_userid;
ALTER TABLE IF EXISTS ONLY public.dataelementaggregationlevels DROP CONSTRAINT IF EXISTS fk_dataelementaggregationlevels_dataelementid;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS fk_dataelement_userid;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS fk_dataelement_optionsetid;
ALTER TABLE IF EXISTS ONLY public.dataelementlegendsets DROP CONSTRAINT IF EXISTS fk_dataelement_legendsetid;
ALTER TABLE IF EXISTS ONLY public.smscodes DROP CONSTRAINT IF EXISTS fk_dataelement_dataelementid;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS fk_dataelement_commentoptionsetid;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS fk_dataelement_categorycomboid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_programindicatorid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_programdataelement_programid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_programdataelement_dataelementid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_programattribute_programid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_programattribute_attributeid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_indicatorid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_expressiondimensionitemid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_datasetid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_dataelementoperand_dataelementid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_dataelementoperand_categoryoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS fk_datadimensionitem_dataelementid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflowlevels DROP CONSTRAINT IF EXISTS fk_dataapprovalworkflowlevels_workflowid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflowlevels DROP CONSTRAINT IF EXISTS fk_dataapprovalworkflowlevels_levelid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflow DROP CONSTRAINT IF EXISTS fk_dataapprovalworkflow_userid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflow DROP CONSTRAINT IF EXISTS fk_dataapprovalworkflow_periodtypeid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflow DROP CONSTRAINT IF EXISTS fk_dataapprovalworkflow_categorycomboid;
ALTER TABLE IF EXISTS ONLY public.dataapprovallevel DROP CONSTRAINT IF EXISTS fk_dataapprovallevel_userid;
ALTER TABLE IF EXISTS ONLY public.dataapprovallevel DROP CONSTRAINT IF EXISTS fk_dataapprovallevel_categoryoptiongroupsetid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalaudit DROP CONSTRAINT IF EXISTS fk_dataapprovalaudit_workflowid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalaudit DROP CONSTRAINT IF EXISTS fk_dataapprovalaudit_periodid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalaudit DROP CONSTRAINT IF EXISTS fk_dataapprovalaudit_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalaudit DROP CONSTRAINT IF EXISTS fk_dataapprovalaudit_levelid;
ALTER TABLE IF EXISTS ONLY public.dataapprovalaudit DROP CONSTRAINT IF EXISTS fk_dataapprovalaudit_attributeoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.dataapproval DROP CONSTRAINT IF EXISTS fk_dataapproval_workflowid;
ALTER TABLE IF EXISTS ONLY public.dataapproval DROP CONSTRAINT IF EXISTS fk_dataapproval_periodid;
ALTER TABLE IF EXISTS ONLY public.dataapproval DROP CONSTRAINT IF EXISTS fk_dataapproval_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.dataapproval DROP CONSTRAINT IF EXISTS fk_dataapproval_lastupdateby;
ALTER TABLE IF EXISTS ONLY public.dataapproval DROP CONSTRAINT IF EXISTS fk_dataapproval_dataapprovallevel;
ALTER TABLE IF EXISTS ONLY public.dataapprovalaudit DROP CONSTRAINT IF EXISTS fk_dataapproval_creator;
ALTER TABLE IF EXISTS ONLY public.dataapproval DROP CONSTRAINT IF EXISTS fk_dataapproval_creator;
ALTER TABLE IF EXISTS ONLY public.dataapproval DROP CONSTRAINT IF EXISTS fk_dataapproval_attributeoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem DROP CONSTRAINT IF EXISTS fk_dashboarditem_visualizationid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem_users DROP CONSTRAINT IF EXISTS fk_dashboarditem_users_userinfoid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem_users DROP CONSTRAINT IF EXISTS fk_dashboarditem_users_dashboardid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem_resources DROP CONSTRAINT IF EXISTS fk_dashboarditem_resources_resourceid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem_resources DROP CONSTRAINT IF EXISTS fk_dashboarditem_resources_dashboardid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem_reports DROP CONSTRAINT IF EXISTS fk_dashboarditem_reports_reportid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem_reports DROP CONSTRAINT IF EXISTS fk_dashboarditem_reports_dashboardid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem DROP CONSTRAINT IF EXISTS fk_dashboarditem_mapid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem DROP CONSTRAINT IF EXISTS fk_dashboarditem_evisualizationid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem DROP CONSTRAINT IF EXISTS fk_dashboarditem_eventreportid;
ALTER TABLE IF EXISTS ONLY public.dashboarditem DROP CONSTRAINT IF EXISTS fk_dashboarditem_eventchartid;
ALTER TABLE IF EXISTS ONLY public.dashboard DROP CONSTRAINT IF EXISTS fk_dashboard_userid;
ALTER TABLE IF EXISTS ONLY public.dashboard_items DROP CONSTRAINT IF EXISTS fk_dashboard_items_dashboarditemid;
ALTER TABLE IF EXISTS ONLY public.dashboard_items DROP CONSTRAINT IF EXISTS fk_dashboard_items_dashboardid;
ALTER TABLE IF EXISTS ONLY public.metadataproposal DROP CONSTRAINT IF EXISTS fk_createdby_userid;
ALTER TABLE IF EXISTS ONLY public.icon DROP CONSTRAINT IF EXISTS fk_createdby_userid;
ALTER TABLE IF EXISTS ONLY public.constant DROP CONSTRAINT IF EXISTS fk_constant_userid;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_systemupdatenotification_recipients;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_selfregistrationrole;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_selfregistrationorgunit;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_offline_orgunit_level;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_infrastructural_periodtype;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_infrastructural_indicators;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_infrastructural_dataelements;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_feedback_recipients;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_facilityorgunitlevel;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS fk_configuration_facilityorgunitgroupset;
ALTER TABLE IF EXISTS ONLY public.configuration_corswhitelist DROP CONSTRAINT IF EXISTS fk_configuration_corswhitelist;
ALTER TABLE IF EXISTS ONLY public.completedatasetregistration DROP CONSTRAINT IF EXISTS fk_completedatasetregistration_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.completedatasetregistration DROP CONSTRAINT IF EXISTS fk_completedatasetregistration_attributeoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupsetmembers DROP CONSTRAINT IF EXISTS fk_categoryoptiongroupsetmembers_categoryoptiongroupsetid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupsetmembers DROP CONSTRAINT IF EXISTS fk_categoryoptiongroupsetmembers_categoryoptiongroupid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupset DROP CONSTRAINT IF EXISTS fk_categoryoptiongroupset_userid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupmembers DROP CONSTRAINT IF EXISTS fk_categoryoptiongroupmembers_categoryoptionid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupmembers DROP CONSTRAINT IF EXISTS fk_categoryoptiongroupmembers_categoryoptiongroupid;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroup DROP CONSTRAINT IF EXISTS fk_categoryoptiongroup_userid;
ALTER TABLE IF EXISTS ONLY public.categoryoptioncombos_categoryoptions DROP CONSTRAINT IF EXISTS fk_categoryoptioncombos_categoryoptions_categoryoptionid;
ALTER TABLE IF EXISTS ONLY public.smscodes DROP CONSTRAINT IF EXISTS fk_categoryoptioncombo_categoryoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.categoryoption_organisationunits DROP CONSTRAINT IF EXISTS fk_categoryoption_organisationunits_organisationunitid;
ALTER TABLE IF EXISTS ONLY public.categoryoption_organisationunits DROP CONSTRAINT IF EXISTS fk_categoryoption_organisationunits_categoryoptionid;
ALTER TABLE IF EXISTS ONLY public.categoryoptioncombos_categoryoptions DROP CONSTRAINT IF EXISTS fk_categoryoption_categoryoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.categorydimension_items DROP CONSTRAINT IF EXISTS fk_categorydimension_items_categoryoptionid;
ALTER TABLE IF EXISTS ONLY public.categorydimension_items DROP CONSTRAINT IF EXISTS fk_categorydimension_items_categorydimensionid;
ALTER TABLE IF EXISTS ONLY public.categorydimension DROP CONSTRAINT IF EXISTS fk_categorydimension_category;
ALTER TABLE IF EXISTS ONLY public.categorycombos_optioncombos DROP CONSTRAINT IF EXISTS fk_categorycombos_optioncombos_categorycomboid;
ALTER TABLE IF EXISTS ONLY public.categorycombos_categories DROP CONSTRAINT IF EXISTS fk_categorycombos_categories_categorycomboid;
ALTER TABLE IF EXISTS ONLY public.categorycombo DROP CONSTRAINT IF EXISTS fk_categorycombo_userid;
ALTER TABLE IF EXISTS ONLY public.categorycombos_optioncombos DROP CONSTRAINT IF EXISTS fk_categorycombo_categoryoptioncomboid;
ALTER TABLE IF EXISTS ONLY public.categorycombos_categories DROP CONSTRAINT IF EXISTS fk_categorycombo_categoryid;
ALTER TABLE IF EXISTS ONLY public.categories_categoryoptions DROP CONSTRAINT IF EXISTS fk_category_categoryoptionid;
ALTER TABLE IF EXISTS ONLY public.categories_categoryoptions DROP CONSTRAINT IF EXISTS fk_categories_categoryoptions_categoryid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributevalueaudit DROP CONSTRAINT IF EXISTS fk_attributevalueaudit_trackedentityinstanceid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributevalueaudit DROP CONSTRAINT IF EXISTS fk_attributevalueaudit_trackedentityattributeid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributevalue DROP CONSTRAINT IF EXISTS fk_attributevalue_trackedentityinstanceid;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributevalue DROP CONSTRAINT IF EXISTS fk_attributevalue_trackedentityattributeid;
ALTER TABLE IF EXISTS ONLY public.attributevalue DROP CONSTRAINT IF EXISTS fk_attributevalue_attributeid;
ALTER TABLE IF EXISTS ONLY public.attribute DROP CONSTRAINT IF EXISTS fk_attribute_userid;
ALTER TABLE IF EXISTS ONLY public.attribute DROP CONSTRAINT IF EXISTS fk_attribute_optionsetid;
ALTER TABLE IF EXISTS ONLY public.aggregatedataexchange DROP CONSTRAINT IF EXISTS fk_aggregatedataexchange_userid_userinfoid;
ALTER TABLE IF EXISTS ONLY public.aggregatedataexchange DROP CONSTRAINT IF EXISTS fk_aggregatedataexchange_lastupdateby_userinfoid;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate DROP CONSTRAINT IF EXISTS fk9whlsdwfojxbp8yclqolqwm9;
ALTER TABLE IF EXISTS ONLY public.datasetlegendsets DROP CONSTRAINT IF EXISTS fk9f6ich22mw6be835i07khg9ld;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplate_recipientusergroups DROP CONSTRAINT IF EXISTS fk804hp0os62rpdtroxhrrio76v;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplatevalidationrules DROP CONSTRAINT IF EXISTS fk6oepnl7prbw10034c5vot1jii;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate DROP CONSTRAINT IF EXISTS fk4uq2bl31hdu2s4e07rltemk3d;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate_deliverychannel DROP CONSTRAINT IF EXISTS fk45uc7wfpi4u5gunpl127ehkn2;
ALTER TABLE IF EXISTS ONLY public.programmessage_phonenumbers DROP CONSTRAINT IF EXISTS fk3408hwfswvwfqyfngk1tf5ju8;
ALTER TABLE IF EXISTS ONLY public.indicatorlegendsets DROP CONSTRAINT IF EXISTS fk1ps7mt73qi3wnt6f5g6w6flga;
DROP INDEX IF EXISTS public.uuid_usergroup_idx;
DROP INDEX IF EXISTS public.usermessage_userid;
DROP INDEX IF EXISTS public.usermessage_isread;
DROP INDEX IF EXISTS public.userkeyjsonvalue_user;
DROP INDEX IF EXISTS public.uk_userinfo_uid;
DROP INDEX IF EXISTS public.uk_smscommands_uid;
DROP INDEX IF EXISTS public.uk_outbound_sms_uid;
DROP INDEX IF EXISTS public.uk_messageconversation_uid;
DROP INDEX IF EXISTS public.uk_message_uid;
DROP INDEX IF EXISTS public.uk_interpretationcomment_uid;
DROP INDEX IF EXISTS public.uk_interpretation_uid;
DROP INDEX IF EXISTS public.uk_incomingsms_uid;
DROP INDEX IF EXISTS public.uk_eventvisualization_uid;
DROP INDEX IF EXISTS public.uk_deletedobject_uid;
DROP INDEX IF EXISTS public.sms_status_index;
DROP INDEX IF EXISTS public.sms_originator_index;
DROP INDEX IF EXISTS public.programstageinstance_programinstanceid;
DROP INDEX IF EXISTS public.programstageinstance_organisationunitid;
DROP INDEX IF EXISTS public.programstageinstance_executiondate;
DROP INDEX IF EXISTS public.program_rule_variable_program;
DROP INDEX IF EXISTS public.program_rule_program;
DROP INDEX IF EXISTS public.outbound_sms_status_index;
DROP INDEX IF EXISTS public.messageconversation_lastmessage;
DROP INDEX IF EXISTS public.maplegend_startvalue;
DROP INDEX IF EXISTS public.maplegend_endvalue;
DROP INDEX IF EXISTS public.interpretation_lastupdated;
DROP INDEX IF EXISTS public.index_trackedentitydatavalueaudit_programstageinstanceid;
DROP INDEX IF EXISTS public.index_programinstance;
DROP INDEX IF EXISTS public.in_userinfo_uuid;
DROP INDEX IF EXISTS public.in_userinfo_username;
DROP INDEX IF EXISTS public.in_userinfo_ldapid;
DROP INDEX IF EXISTS public.in_unique_trackedentityprogramowner_teiid_programid_ouid;
DROP INDEX IF EXISTS public.in_trackedentityprogramowner_program_orgunit;
DROP INDEX IF EXISTS public.in_trackedentityinstance_trackedentityattribute_value;
DROP INDEX IF EXISTS public.in_trackedentityinstance_organisationunitid;
DROP INDEX IF EXISTS public.in_trackedentityinstance_deleted;
DROP INDEX IF EXISTS public.in_trackedentityinstance_created;
DROP INDEX IF EXISTS public.in_trackedentityattributevalue_attributeid;
DROP INDEX IF EXISTS public.in_trackedentity_attribute_value;
DROP INDEX IF EXISTS public.in_reservedvalue_value_generation;
DROP INDEX IF EXISTS public.in_relationshipitem_trackedentityinstanceid;
DROP INDEX IF EXISTS public.in_relationshipitem_programstageinstanceid;
DROP INDEX IF EXISTS public.in_relationshipitem_programinstanceid;
DROP INDEX IF EXISTS public.in_relationship_key;
DROP INDEX IF EXISTS public.in_relationship_inverted_key;
DROP INDEX IF EXISTS public.in_psi_deleted_assigneduserid;
DROP INDEX IF EXISTS public.in_programtempowner_validtill;
DROP INDEX IF EXISTS public.in_programstageinstance_status_executiondate;
DROP INDEX IF EXISTS public.in_programinstance_trackedentityinstanceid;
DROP INDEX IF EXISTS public.in_programinstance_programid;
DROP INDEX IF EXISTS public.in_programinstance_deleted;
DROP INDEX IF EXISTS public.in_parentid;
DROP INDEX IF EXISTS public.in_organisationunit_path;
DROP INDEX IF EXISTS public.in_organisationunit_hierarchylevel;
DROP INDEX IF EXISTS public.in_messageconversation_extmessageid;
DROP INDEX IF EXISTS public.in_interpretationcomment_mentions_username;
DROP INDEX IF EXISTS public.in_interpretation_mentions_username;
DROP INDEX IF EXISTS public.in_event_lastupdated;
DROP INDEX IF EXISTS public.in_enrollment_lastupdated;
DROP INDEX IF EXISTS public.in_datavalueaudit;
DROP INDEX IF EXISTS public.in_datavalue_lastupdated;
DROP INDEX IF EXISTS public.in_datavalue_deleted;
DROP INDEX IF EXISTS public.in_datasetsource_sourceid;
DROP INDEX IF EXISTS public.in_dataapprovallevel_level;
DROP INDEX IF EXISTS public.in_categoryoptioncombo_name;
DROP INDEX IF EXISTS public.in_categories_categoryoptions_coid;
DROP INDEX IF EXISTS public.id_datavalueaudit_created;
DROP INDEX IF EXISTS public.flyway_schema_history_s_idx;
DROP INDEX IF EXISTS public."create index in_userinfo_openid";
ALTER TABLE IF EXISTS ONLY public.visualization_yearlyseries DROP CONSTRAINT IF EXISTS visualization_yearlyseries_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization DROP CONSTRAINT IF EXISTS visualization_uid_key;
ALTER TABLE IF EXISTS ONLY public.visualization_rows DROP CONSTRAINT IF EXISTS visualization_rows_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization DROP CONSTRAINT IF EXISTS visualization_relativeperiodsid_key;
ALTER TABLE IF EXISTS ONLY public.visualization DROP CONSTRAINT IF EXISTS visualization_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_periods DROP CONSTRAINT IF EXISTS visualization_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_orgunitlevels DROP CONSTRAINT IF EXISTS visualization_orgunitlevels_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS visualization_orgunitgroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_organisationunits DROP CONSTRAINT IF EXISTS visualization_organisationunits_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_itemorgunitgroups DROP CONSTRAINT IF EXISTS visualization_itemorgunitgroups_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_filters DROP CONSTRAINT IF EXISTS visualization_filters_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_dataelementgroupsetdimensions DROP CONSTRAINT IF EXISTS visualization_dataelementgroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_datadimensionitems DROP CONSTRAINT IF EXISTS visualization_datadimensionitems_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_columns DROP CONSTRAINT IF EXISTS visualization_columns_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization DROP CONSTRAINT IF EXISTS visualization_code_key;
ALTER TABLE IF EXISTS ONLY public.visualization_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS visualization_categoryoptiongroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_categorydimensions DROP CONSTRAINT IF EXISTS visualization_categorydimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.visualization_axis DROP CONSTRAINT IF EXISTS visualization_axis_pkey;
ALTER TABLE IF EXISTS ONLY public.version DROP CONSTRAINT IF EXISTS version_versionkey_key;
ALTER TABLE IF EXISTS ONLY public.version DROP CONSTRAINT IF EXISTS version_pkey;
ALTER TABLE IF EXISTS ONLY public.validationrulegroupmembers DROP CONSTRAINT IF EXISTS validationrulegroupmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.validationrulegroup DROP CONSTRAINT IF EXISTS validationrulegroup_pkey;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS validationrule_pkey;
ALTER TABLE IF EXISTS ONLY public.validationresult DROP CONSTRAINT IF EXISTS validationresult_pkey;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplatevalidationrules DROP CONSTRAINT IF EXISTS validationnotificationtemplatevalidationrules_pkey;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplate_recipientusergroups DROP CONSTRAINT IF EXISTS validationnotificationtemplate_recipientusergroups_pkey;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplate DROP CONSTRAINT IF EXISTS validationnotificationtemplate_pkey;
ALTER TABLE IF EXISTS ONLY public.userteisearchorgunits DROP CONSTRAINT IF EXISTS userteisearchorgunits_pkey;
ALTER TABLE IF EXISTS ONLY public.usersetting DROP CONSTRAINT IF EXISTS usersetting_pkey;
ALTER TABLE IF EXISTS ONLY public.users_cogsdimensionconstraints DROP CONSTRAINT IF EXISTS users_cogsdimensionconstraints_pkey;
ALTER TABLE IF EXISTS ONLY public.users_catdimensionconstraints DROP CONSTRAINT IF EXISTS users_catdimensionconstraints_pkey;
ALTER TABLE IF EXISTS ONLY public.userrolemembers DROP CONSTRAINT IF EXISTS userrolemembers_pkey;
ALTER TABLE IF EXISTS ONLY public.userrole DROP CONSTRAINT IF EXISTS userrole_pkey;
ALTER TABLE IF EXISTS ONLY public.usermessage DROP CONSTRAINT IF EXISTS usermessage_pkey;
ALTER TABLE IF EXISTS ONLY public.usermembership DROP CONSTRAINT IF EXISTS usermembership_pkey;
ALTER TABLE IF EXISTS ONLY public.userkeyjsonvalue DROP CONSTRAINT IF EXISTS userkeyjsonvalue_unique_key_on_user_and_namespace;
ALTER TABLE IF EXISTS ONLY public.userkeyjsonvalue DROP CONSTRAINT IF EXISTS userkeyjsonvalue_pkey;
ALTER TABLE IF EXISTS ONLY public.userinfo DROP CONSTRAINT IF EXISTS userinfo_pkey;
ALTER TABLE IF EXISTS ONLY public.usergroupmembers DROP CONSTRAINT IF EXISTS usergroupmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.usergroupmanaged DROP CONSTRAINT IF EXISTS usergroupmanaged_pkey;
ALTER TABLE IF EXISTS ONLY public.usergroup DROP CONSTRAINT IF EXISTS usergroup_pkey;
ALTER TABLE IF EXISTS ONLY public.userdatavieworgunits DROP CONSTRAINT IF EXISTS userdatavieworgunits_pkey;
ALTER TABLE IF EXISTS ONLY public.userapps DROP CONSTRAINT IF EXISTS userapps_pkey;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS unique_skip_test_expression;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS unique_right_expression;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS unique_left_expression;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS unique_generator_expression;
ALTER TABLE IF EXISTS ONLY public.userinfo DROP CONSTRAINT IF EXISTS uk_userinfo_username;
ALTER TABLE IF EXISTS ONLY public.trackedentitytype DROP CONSTRAINT IF EXISTS uk_to3d8d23u9behgh9acdu2wjvl;
ALTER TABLE IF EXISTS ONLY public.keyjsonvalue DROP CONSTRAINT IF EXISTS uk_tikknlgl0im3w68yvlb0swrgd;
ALTER TABLE IF EXISTS ONLY public.trackedentitytype DROP CONSTRAINT IF EXISTS uk_thb8irn2kmm7jay3vcogqxy3x;
ALTER TABLE IF EXISTS ONLY public.programsection DROP CONSTRAINT IF EXISTS uk_tglbwfy1e3ubt5x5hab46qbh6;
ALTER TABLE IF EXISTS ONLY public.trackedentityprogramowner DROP CONSTRAINT IF EXISTS uk_tei_program;
ALTER TABLE IF EXISTS ONLY public.period DROP CONSTRAINT IF EXISTS uk_tbkbjga8h4j5u33d7hbcuk66t;
ALTER TABLE IF EXISTS ONLY public.programnotificationinstance DROP CONSTRAINT IF EXISTS uk_takpuhb2893t7bbbak9ym3kq9;
ALTER TABLE IF EXISTS ONLY public.indicator DROP CONSTRAINT IF EXISTS uk_ta80keoi67443tkvvmx8l872x;
ALTER TABLE IF EXISTS ONLY public.smscommandcodes DROP CONSTRAINT IF EXISTS uk_t9e1mnpydje0rsvinxq68q1i6;
ALTER TABLE IF EXISTS ONLY public.note DROP CONSTRAINT IF EXISTS uk_t94h9p111tcydbm6je22tla52;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupset DROP CONSTRAINT IF EXISTS uk_t5lxvc1km3ylon5st1fuabsgl;
ALTER TABLE IF EXISTS ONLY public.orgunitgroup DROP CONSTRAINT IF EXISTS uk_t0srkng3akwg3pcp5qlwcx06n;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS uk_t0dg39dopew9f6y64ucsx7194;
ALTER TABLE IF EXISTS ONLY public.indicatorgroup DROP CONSTRAINT IF EXISTS uk_sspviu4m0l0lf7ef3t3cagfxd;
ALTER TABLE IF EXISTS ONLY public.jobconfiguration DROP CONSTRAINT IF EXISTS uk_sdng31h9qjawcikcllry8a8a5;
ALTER TABLE IF EXISTS ONLY public.periodboundary DROP CONSTRAINT IF EXISTS uk_sbipy5btkgy542bdbx7mxppdd;
ALTER TABLE IF EXISTS ONLY public.optionset DROP CONSTRAINT IF EXISTS uk_rvfiukug5ui7qidoiln3el3aa;
ALTER TABLE IF EXISTS ONLY public.jobconfiguration DROP CONSTRAINT IF EXISTS uk_rqkhk3ebvk1kflf7qigbaxeyp;
ALTER TABLE IF EXISTS ONLY public.trackedentity DROP CONSTRAINT IF EXISTS uk_rbr4kyuk4s0kb4jo1r77cuaq9;
ALTER TABLE IF EXISTS ONLY public.validationresult DROP CONSTRAINT IF EXISTS uk_r6ebedjcac8c49c53aa1mpa8e;
ALTER TABLE IF EXISTS ONLY public.externalmaplayer DROP CONSTRAINT IF EXISTS uk_r3ugbbibdsyn234isip3346v4;
ALTER TABLE IF EXISTS ONLY public.program_attributes DROP CONSTRAINT IF EXISTS uk_r2f9o8i6th2w8vqdexdfo72ui;
ALTER TABLE IF EXISTS ONLY public.orgunitgroup DROP CONSTRAINT IF EXISTS uk_qwk9qdapql867enp5r7fa0uic;
ALTER TABLE IF EXISTS ONLY public.pushanalysis DROP CONSTRAINT IF EXISTS uk_qunv1hucv9wi5pt92tur929mr;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS uk_qq5b8o288bhpe59e5ks3op8jy;
ALTER TABLE IF EXISTS ONLY public.categoryoption DROP CONSTRAINT IF EXISTS uk_qp9201a4m6jl53sei0huh4l6s;
ALTER TABLE IF EXISTS ONLY public.i18nlocale DROP CONSTRAINT IF EXISTS uk_qogg9a7yy4qconomxt4j4upql;
ALTER TABLE IF EXISTS ONLY public.categoryoptioncombo DROP CONSTRAINT IF EXISTS uk_qki43s9vdndg15c9tyv718u1j;
ALTER TABLE IF EXISTS ONLY public.optiongroupset DROP CONSTRAINT IF EXISTS uk_q9jv2e3fy49hc1havuwnr0res;
ALTER TABLE IF EXISTS ONLY public.usergroup DROP CONSTRAINT IF EXISTS uk_q20sh82vk885ooi7fekwtboej;
ALTER TABLE IF EXISTS ONLY public.eventreport DROP CONSTRAINT IF EXISTS uk_q0oyainj1lis9c8kkh5sky2ri;
ALTER TABLE IF EXISTS ONLY public.dataentryform DROP CONSTRAINT IF EXISTS uk_q0obvr5rvxhlnjs367y1f0bav;
ALTER TABLE IF EXISTS ONLY public.predictorgroup DROP CONSTRAINT IF EXISTS uk_pxnxtb4ywoh2m74vosk2httc3;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS uk_pw87bi64e3ev11k7dwrmljo78;
ALTER TABLE IF EXISTS ONLY public.organisationunit DROP CONSTRAINT IF EXISTS uk_pw2bgc9ykjad2obefeqha28t4;
ALTER TABLE IF EXISTS ONLY public.eventfilter DROP CONSTRAINT IF EXISTS uk_programstageinstancefilter_uid;
ALTER TABLE IF EXISTS ONLY public.datastatistics DROP CONSTRAINT IF EXISTS uk_ppi146eky8fodu97t1o21vkd8;
ALTER TABLE IF EXISTS ONLY public.categoryoption DROP CONSTRAINT IF EXISTS uk_pbj3u1nk9vnuof8f47utvowmv;
ALTER TABLE IF EXISTS ONLY public.dataentryform DROP CONSTRAINT IF EXISTS uk_p8tvo9tqrdn5tb45d0g5cko5o;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupset DROP CONSTRAINT IF EXISTS uk_p7egnv3sj4ugyl23mk4vga40k;
ALTER TABLE IF EXISTS ONLY public.programrule DROP CONSTRAINT IF EXISTS uk_p7arcbl58mmcrj2didtr0ruqh;
ALTER TABLE IF EXISTS ONLY public.optionset DROP CONSTRAINT IF EXISTS uk_p0rvldurcmk0x3mx39lt5uvsd;
ALTER TABLE IF EXISTS ONLY public.indicatortype DROP CONSTRAINT IF EXISTS uk_p0p3bwhgbsdemu14v23p47qne;
ALTER TABLE IF EXISTS ONLY public.dataelementgroup DROP CONSTRAINT IF EXISTS uk_otvwcgv4bxjtqfj3flhrnmgf7;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate DROP CONSTRAINT IF EXISTS uk_ot8a05g9d4k5l67xi062xx5w6;
ALTER TABLE IF EXISTS ONLY public.programstagedataelement DROP CONSTRAINT IF EXISTS uk_os4r1umsvtmbuqm2bo25s5ej0;
ALTER TABLE IF EXISTS ONLY public.trackedentity DROP CONSTRAINT IF EXISTS uk_orq3pwtro2yu9yydh046bn40j;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroup DROP CONSTRAINT IF EXISTS uk_ol8n7oq6clgxvqjedlpn85aqo;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS uk_oeni5ndit5g033f1s1j08bdry;
ALTER TABLE IF EXISTS ONLY public.constant DROP CONSTRAINT IF EXISTS uk_o2xbcli806eba6dkdfco0o3kc;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS uk_o0v1fdqiyte40ffm9q3nhcj4v;
ALTER TABLE IF EXISTS ONLY public.constant DROP CONSTRAINT IF EXISTS uk_nywvip5682tuvxrnwjomeyg6y;
ALTER TABLE IF EXISTS ONLY public.optiongroup DROP CONSTRAINT IF EXISTS uk_nwq3y4xqct21tdl0l77bvmpoe;
ALTER TABLE IF EXISTS ONLY public.oauth2client DROP CONSTRAINT IF EXISTS uk_nwgvrevv2slj1bvc9m01p89lf;
ALTER TABLE IF EXISTS ONLY public.messageconversation_messages DROP CONSTRAINT IF EXISTS uk_nqdtggpr548q0tnbu919puw0p;
ALTER TABLE IF EXISTS ONLY public.optiongroup DROP CONSTRAINT IF EXISTS uk_nipo7t010a80osh7okxswav2g;
ALTER TABLE IF EXISTS ONLY public.oauth2client DROP CONSTRAINT IF EXISTS uk_ni7epmbxtn4jcax3ya324ff9w;
ALTER TABLE IF EXISTS ONLY public.indicatortype DROP CONSTRAINT IF EXISTS uk_n8mbmryeksa80ucyxj0vg6p9b;
ALTER TABLE IF EXISTS ONLY public.pushanalysis DROP CONSTRAINT IF EXISTS uk_n5ax669vkj63nx3rrvlushqdm;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupset DROP CONSTRAINT IF EXISTS uk_n4xputyk31femiaxls6lbl2rw;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflow DROP CONSTRAINT IF EXISTS uk_n18s4feicujvngv2ajoesdgio;
ALTER TABLE IF EXISTS ONLY public.dashboard DROP CONSTRAINT IF EXISTS uk_myox13mr8r27oxl7ts33ntpd5;
ALTER TABLE IF EXISTS ONLY public.datasetnotificationtemplate DROP CONSTRAINT IF EXISTS uk_mq0y6uuq2erprg2siebo2mk1o;
ALTER TABLE IF EXISTS ONLY public.categoryoption DROP CONSTRAINT IF EXISTS uk_mlop2afk26fwowa69lr9a138y;
ALTER TABLE IF EXISTS ONLY public.externalnotificationlogentry DROP CONSTRAINT IF EXISTS uk_mcn0op3hsf5ajqg5k4oli4xkc;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplate DROP CONSTRAINT IF EXISTS uk_mbt1vxa5exs9cbqqs5px2mopx;
ALTER TABLE IF EXISTS ONLY public.trackedentityfilter DROP CONSTRAINT IF EXISTS uk_m5k30j5e93n1no82gye7jgf25;
ALTER TABLE IF EXISTS ONLY public.programstagesection DROP CONSTRAINT IF EXISTS uk_lycal9jdw3cs0wwebxciswwgr;
ALTER TABLE IF EXISTS ONLY public.enrollment_notes DROP CONSTRAINT IF EXISTS uk_lwep604j10w1ey7vunqdmotx2;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupset DROP CONSTRAINT IF EXISTS uk_lu295rc1y01c7p7t76y6ajaas;
ALTER TABLE IF EXISTS ONLY public.orgunitlevel DROP CONSTRAINT IF EXISTS uk_ltwhby0s0iwayxrcdu6yefeqt;
ALTER TABLE IF EXISTS ONLY public.orgunitgroup DROP CONSTRAINT IF EXISTS uk_lswbn93sime7vmdqqe9lks7ge;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroup DROP CONSTRAINT IF EXISTS uk_lrnagoy2wi83nwmataolh7t6d;
ALTER TABLE IF EXISTS ONLY public.eventreport DROP CONSTRAINT IF EXISTS uk_lnnx8vmalkhkmneryv1ytjq68;
ALTER TABLE IF EXISTS ONLY public.externalnotificationlogentry DROP CONSTRAINT IF EXISTS uk_lner1ovmrqr5qrwn8gwfuhhhn;
ALTER TABLE IF EXISTS ONLY public.program_attributes DROP CONSTRAINT IF EXISTS uk_lgju00pi2jk7y6sl4dkhaykux;
ALTER TABLE IF EXISTS ONLY public.metadataversion DROP CONSTRAINT IF EXISTS uk_ktwf16f728hce9ahtpmm7w5lx;
ALTER TABLE IF EXISTS ONLY public.i18nlocale DROP CONSTRAINT IF EXISTS uk_krm9w69donjqsejkmfw17jbcx;
ALTER TABLE IF EXISTS ONLY public.indicatorgroup DROP CONSTRAINT IF EXISTS uk_kqbwxccoqctky1kdkimjya03s;
ALTER TABLE IF EXISTS ONLY public.indicator DROP CONSTRAINT IF EXISTS uk_kmpefoaw81v4bxpoey6y1y3xl;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupset DROP CONSTRAINT IF EXISTS uk_ke8p30sy68dl7fggednkimdb6;
ALTER TABLE IF EXISTS ONLY public.report DROP CONSTRAINT IF EXISTS uk_kc1wmcky1ooleovi36oqcqmqe;
ALTER TABLE IF EXISTS ONLY public.trackedentityattribute DROP CONSTRAINT IF EXISTS uk_kbqnrdakcjfooofmti30d4p8x;
ALTER TABLE IF EXISTS ONLY public.interpretation_comments DROP CONSTRAINT IF EXISTS uk_k48tayhxu52jiq782pikev9d9;
ALTER TABLE IF EXISTS ONLY public.fileresource DROP CONSTRAINT IF EXISTS uk_jxqj907hbrng860p6mypvl63k;
ALTER TABLE IF EXISTS ONLY public.document DROP CONSTRAINT IF EXISTS uk_jxodv1lvot26euasttk021jio;
ALTER TABLE IF EXISTS ONLY public.dataelementgroup DROP CONSTRAINT IF EXISTS uk_jo65jc3wyrxfekiu3upk80mtr;
ALTER TABLE IF EXISTS ONLY public.datasetnotificationtemplate DROP CONSTRAINT IF EXISTS uk_jjt6ctp2xi4d7vtv4pwkkdhh0;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS uk_jc27pe1xeptws5xprct7mgxrj;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroup DROP CONSTRAINT IF EXISTS uk_j9oya1t1tvj8yn5h8fega4ltr;
ALTER TABLE IF EXISTS ONLY public.messageconversation_usermessages DROP CONSTRAINT IF EXISTS uk_j5pi1qwi2m228qrsxql48o61s;
ALTER TABLE IF EXISTS ONLY public.jobconfiguration DROP CONSTRAINT IF EXISTS uk_igo4gx1d74k7m93vxnn4n77jf;
ALTER TABLE IF EXISTS ONLY public.sqlview DROP CONSTRAINT IF EXISTS uk_iedy6hh42wl3gr3m87ntd6so8;
ALTER TABLE IF EXISTS ONLY public.maplegend DROP CONSTRAINT IF EXISTS uk_id4stsb5slq35axmjeojnjnoa;
ALTER TABLE IF EXISTS ONLY public.predictorgroup DROP CONSTRAINT IF EXISTS uk_i4dix5cj64521ivv59c0wgvfq;
ALTER TABLE IF EXISTS ONLY public.dataapprovallevel DROP CONSTRAINT IF EXISTS uk_i1uhc0c8jgxkhlswl9fujsicf;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupset DROP CONSTRAINT IF EXISTS uk_hs57i9hma97ps6jpsrbb24lm9;
ALTER TABLE IF EXISTS ONLY public.dataapprovallevel DROP CONSTRAINT IF EXISTS uk_hqekpuhjg3g4k4t7xdnu10jy4;
ALTER TABLE IF EXISTS ONLY public.attribute DROP CONSTRAINT IF EXISTS uk_hpwum0iq12fs4ej5d0tgy6wsn;
ALTER TABLE IF EXISTS ONLY public.userrole DROP CONSTRAINT IF EXISTS uk_hjocbvo9fla04bgj7ku32vwsn;
ALTER TABLE IF EXISTS ONLY public.userrole DROP CONSTRAINT IF EXISTS uk_hebhkhm8gpwg9xsp8q4f7wlx1;
ALTER TABLE IF EXISTS ONLY public.categorycombo DROP CONSTRAINT IF EXISTS uk_h97pko7n41oky8pfptkflp8l6;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS uk_h4omjcs2ktifdrf2m36u886ae;
ALTER TABLE IF EXISTS ONLY public.event DROP CONSTRAINT IF EXISTS uk_gy44hufdeduoma7eeh3j6abm7;
ALTER TABLE IF EXISTS ONLY public.relationship DROP CONSTRAINT IF EXISTS uk_gsvll3t3tsda7kx38waqnegkw;
ALTER TABLE IF EXISTS ONLY public.map DROP CONSTRAINT IF EXISTS uk_grp9b5jne53f806pc92sfd5s8;
ALTER TABLE IF EXISTS ONLY public.userinfo DROP CONSTRAINT IF EXISTS uk_gky85ptfkcumyuqhr5yvjxwsa;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS uk_gio4nn8l23jikmebud3jwql43;
ALTER TABLE IF EXISTS ONLY public.trackedentityattribute DROP CONSTRAINT IF EXISTS uk_gg9gc0pyaqjuxi8mr4y93i03w;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroup DROP CONSTRAINT IF EXISTS uk_ge3y4pf6qlne9p7rfmhlvg941;
ALTER TABLE IF EXISTS ONLY public.oauth2client DROP CONSTRAINT IF EXISTS uk_gdfuf3j66jxnvwwnksjxqysac;
ALTER TABLE IF EXISTS ONLY public.organisationunit DROP CONSTRAINT IF EXISTS uk_g1nrfjv5x04ap1ceohiwah380;
ALTER TABLE IF EXISTS ONLY public.oauth2client DROP CONSTRAINT IF EXISTS uk_fx3xx9xe0xpurjt6v5p7rv8da;
ALTER TABLE IF EXISTS ONLY public.orgunitlevel DROP CONSTRAINT IF EXISTS uk_fvgc7isaflcan55g51ysm9df2;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS uk_fuq6kda6folarp19oggaf02vb;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupset DROP CONSTRAINT IF EXISTS uk_fuentbuhbbr0ix49td9jqlfe5;
ALTER TABLE IF EXISTS ONLY public.sqlview DROP CONSTRAINT IF EXISTS uk_fps2ja521pudngaitlp0805du;
ALTER TABLE IF EXISTS ONLY public.userrole DROP CONSTRAINT IF EXISTS uk_ff1da38in40mg91rlgqhw02ff;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS uk_fbferisvig2o4f5owb5lnygf3;
ALTER TABLE IF EXISTS ONLY public.metadataversion DROP CONSTRAINT IF EXISTS uk_f93o7l4afmkassm3t4f2op9ps;
ALTER TABLE IF EXISTS ONLY public.programindicatorgroup DROP CONSTRAINT IF EXISTS uk_f7wfef3jx1yl73stqs7b45ewb;
ALTER TABLE IF EXISTS ONLY public.trackedentityattribute DROP CONSTRAINT IF EXISTS uk_evp7d8obarxt3kewepigkwahc;
ALTER TABLE IF EXISTS ONLY public.smscommandspecialcharacters DROP CONSTRAINT IF EXISTS uk_etm1elt7pbwyia8e0kfnrvqo3;
ALTER TABLE IF EXISTS ONLY public.eventreport DROP CONSTRAINT IF EXISTS uk_eqd95mucf5pd856dqlwe6y36c;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS uk_enhquk04unrpri78inaske3jq;
ALTER TABLE IF EXISTS ONLY public.dashboard DROP CONSTRAINT IF EXISTS uk_emyh4fed0f1kknqhimmrhnek8;
ALTER TABLE IF EXISTS ONLY public.version DROP CONSTRAINT IF EXISTS uk_emoyyyy114ofh6cwo6do8xsi0;
ALTER TABLE IF EXISTS ONLY public.keyjsonvalue DROP CONSTRAINT IF EXISTS uk_em6b7qxcas7dn6y506i3nd2x6;
ALTER TABLE IF EXISTS ONLY public.document DROP CONSTRAINT IF EXISTS uk_elt3kiqdmmm5fwqfxsxk9lvh0;
ALTER TABLE IF EXISTS ONLY public.usergroup DROP CONSTRAINT IF EXISTS uk_ekb018cvmpvll5dgtn97leerj;
ALTER TABLE IF EXISTS ONLY public.organisationunit DROP CONSTRAINT IF EXISTS uk_ehl4v33tq7hlkmc28vbno1b4n;
ALTER TABLE IF EXISTS ONLY public.trackedentityattribute DROP CONSTRAINT IF EXISTS uk_eh4c3whbwi94nhh772q6l5t7m;
ALTER TABLE IF EXISTS ONLY public.fileresource DROP CONSTRAINT IF EXISTS uk_eh2epuhchf9mci86ihl06i31g;
ALTER TABLE IF EXISTS ONLY public.constant DROP CONSTRAINT IF EXISTS uk_edy7cktu2fqg01r3n0fjyk1kk;
ALTER TABLE IF EXISTS ONLY public.maplegendset DROP CONSTRAINT IF EXISTS uk_ec7ehyocpresxxhm7yjstdnwt;
ALTER TABLE IF EXISTS ONLY public.programstage DROP CONSTRAINT IF EXISTS uk_e6s6o9jau6tx04m62t7ey4i81;
ALTER TABLE IF EXISTS ONLY public.programrulevariable DROP CONSTRAINT IF EXISTS uk_e5mhmtj1h7xdfiio2panhapgg;
ALTER TABLE IF EXISTS ONLY public.optiongroup DROP CONSTRAINT IF EXISTS uk_dt8m81o2pw5p9ttid369e92bg;
ALTER TABLE IF EXISTS ONLY public.systemsetting DROP CONSTRAINT IF EXISTS uk_do99wgsyk5wflbhb937u5av8m;
ALTER TABLE IF EXISTS ONLY public.programindicator DROP CONSTRAINT IF EXISTS uk_do17h5nk71uvc3xjry6kgevj9;
ALTER TABLE IF EXISTS ONLY public.categorycombo DROP CONSTRAINT IF EXISTS uk_dlhi39gmt2e0dun73f04w7w7u;
ALTER TABLE IF EXISTS ONLY public.dataentryform DROP CONSTRAINT IF EXISTS uk_dhl0qt8y7hht7krbiym1e9x3n;
ALTER TABLE IF EXISTS ONLY public.externalfileresource DROP CONSTRAINT IF EXISTS uk_d4gp8a84gn643g0r28hdnn4so;
ALTER TABLE IF EXISTS ONLY public.metadataversion DROP CONSTRAINT IF EXISTS uk_d3qpxp187x8t4c1rsn64crgqu;
ALTER TABLE IF EXISTS ONLY public.enrollment DROP CONSTRAINT IF EXISTS uk_d3lsa2h8me94ksyp53l6rpe3g;
ALTER TABLE IF EXISTS ONLY public.programrulevariable DROP CONSTRAINT IF EXISTS uk_cto4jvd9q49voite13v0egy3i;
ALTER TABLE IF EXISTS ONLY public.datastatistics DROP CONSTRAINT IF EXISTS uk_cswvqawieb2sfq5qsy5wpqp1k;
ALTER TABLE IF EXISTS ONLY public.externalfileresource DROP CONSTRAINT IF EXISTS uk_ccwoighljmk4fy165ipnwl5n4;
ALTER TABLE IF EXISTS ONLY public.dashboarditem DROP CONSTRAINT IF EXISTS uk_c8bnosb06cchme5sig7b54uot;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflow DROP CONSTRAINT IF EXISTS uk_by4pqq1ans00ffmrgqqh9ehog;
ALTER TABLE IF EXISTS ONLY public.maplegendset DROP CONSTRAINT IF EXISTS uk_bv71u83esume24hp4gsaj5p4f;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupset DROP CONSTRAINT IF EXISTS uk_bjs0n874pj6eoag98jmeidy9a;
ALTER TABLE IF EXISTS ONLY public.predictorgroup DROP CONSTRAINT IF EXISTS uk_biaq93npnr9ho37lxo51sbt3b;
ALTER TABLE IF EXISTS ONLY public.programstage DROP CONSTRAINT IF EXISTS uk_b3oan3noe4cj9dvyi0amofndv;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS uk_b0ii4jdfy88pffbapohsr2lor;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS uk_aypbls80uca5qu23w4fbqns2f;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS uk_ayk5ey2r1fh1akknxtpcpyp9r;
ALTER TABLE IF EXISTS ONLY public.constant DROP CONSTRAINT IF EXISTS uk_aygjfui3fpgrsxbj6qj782h6f;
ALTER TABLE IF EXISTS ONLY public.dataelementgroup DROP CONSTRAINT IF EXISTS uk_aqbaj76r9qxmnylr6p8kj9g37;
ALTER TABLE IF EXISTS ONLY public.optiongroupset DROP CONSTRAINT IF EXISTS uk_aee54nmg1ci2cpitnpiwa845p;
ALTER TABLE IF EXISTS ONLY public.trackedentityfilter DROP CONSTRAINT IF EXISTS uk_acvg948kspicwqw3gmg4ehu8i;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupset DROP CONSTRAINT IF EXISTS uk_actuoxkkqulslxjpj5hagib9r;
ALTER TABLE IF EXISTS ONLY public.section DROP CONSTRAINT IF EXISTS uk_a50otc0l2chm0heii6scpit4k;
ALTER TABLE IF EXISTS ONLY public.event DROP CONSTRAINT IF EXISTS uk_9ydk6ypaj0xdjoyo1d5asap3m;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS uk_9ut6k8m3216v5kjcryy7d2y9w;
ALTER TABLE IF EXISTS ONLY public.attribute DROP CONSTRAINT IF EXISTS uk_9mqbhximifdn1n8ru52lan3fw;
ALTER TABLE IF EXISTS ONLY public.metadataversion DROP CONSTRAINT IF EXISTS uk_9k7bv5o2ut4t0unxcwfyf1ay0;
ALTER TABLE IF EXISTS ONLY public.i18nlocale DROP CONSTRAINT IF EXISTS uk_9j6xjgegveyc0uqs506yy2wrp;
ALTER TABLE IF EXISTS ONLY public.section DROP CONSTRAINT IF EXISTS uk_9hvlbsw019hscf35xb5behfx9;
ALTER TABLE IF EXISTS ONLY public.maplegend DROP CONSTRAINT IF EXISTS uk_9csrw908a1fvfwbhjwm0jfl4e;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS uk_94srnunkibylfaxt4knxfn58e;
ALTER TABLE IF EXISTS ONLY public.externalfileresource DROP CONSTRAINT IF EXISTS uk_8v1lxgqdnnocvm9ah6clxmjf;
ALTER TABLE IF EXISTS ONLY public.note DROP CONSTRAINT IF EXISTS uk_8ul0w6gi3mdnr0kficn5syigg;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS uk_8eyremdx683wcd9owh1t5jufs;
ALTER TABLE IF EXISTS ONLY public.indicatortype DROP CONSTRAINT IF EXISTS uk_8dcmrupnoi7hiiom466aoa2y;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS uk_8d4xrx2gygb4aivpcwrp613hj;
ALTER TABLE IF EXISTS ONLY public.validationrulegroup DROP CONSTRAINT IF EXISTS uk_8alvmsgu0onl4i0a0sqb6mqx;
ALTER TABLE IF EXISTS ONLY public.validationnotificationtemplate DROP CONSTRAINT IF EXISTS uk_87wso1e1xtxsl34nxey6nr922;
ALTER TABLE IF EXISTS ONLY public.programsection DROP CONSTRAINT IF EXISTS uk_84abcabq3so8ktgt726o5du9d;
ALTER TABLE IF EXISTS ONLY public.maplegendset DROP CONSTRAINT IF EXISTS uk_842ips1xb81udqc3dw5uax7u5;
ALTER TABLE IF EXISTS ONLY public.optionset DROP CONSTRAINT IF EXISTS uk_81gfx3yt7ngwmkk0t8qgcovhi;
ALTER TABLE IF EXISTS ONLY public.programindicator DROP CONSTRAINT IF EXISTS uk_7udjng39j4ddafjn57r58v7oq;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS uk_7rnfvkitq6l0kr5ju2slxopfi;
ALTER TABLE IF EXISTS ONLY public.programrule DROP CONSTRAINT IF EXISTS uk_7odx4uo6s5bg55kt1fxky4a8v;
ALTER TABLE IF EXISTS ONLY public.programindicatorgroup DROP CONSTRAINT IF EXISTS uk_7carnwjb5dtsk6i5dn43wy9ck;
ALTER TABLE IF EXISTS ONLY public.relationship DROP CONSTRAINT IF EXISTS uk_799tkjg7am2injr1dypaidt4p;
ALTER TABLE IF EXISTS ONLY public.tablehook DROP CONSTRAINT IF EXISTS uk_78x5lua91w1j6upu02wh8pfx9;
ALTER TABLE IF EXISTS ONLY public.relationship DROP CONSTRAINT IF EXISTS uk_74iy11sx99wxaut3skkphkvgi;
ALTER TABLE IF EXISTS ONLY public.dataelementgroup DROP CONSTRAINT IF EXISTS uk_6x37lph70r5mh15a71pf1tj17;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS uk_6nm3ynkrtuj01bpo1uwcryq06;
ALTER TABLE IF EXISTS ONLY public.optiongroup DROP CONSTRAINT IF EXISTS uk_6ni8qsiimdcy626hwls002flo;
ALTER TABLE IF EXISTS ONLY public.trackedentitytypeattribute DROP CONSTRAINT IF EXISTS uk_6lycqfymeu4sdi4t3cdh6ul1k;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupset DROP CONSTRAINT IF EXISTS uk_6itpx2frqt3msln8p32rk7qta;
ALTER TABLE IF EXISTS ONLY public.eventchart DROP CONSTRAINT IF EXISTS uk_6dyim42vl218i9e9waqrvw36k;
ALTER TABLE IF EXISTS ONLY public.eventchart DROP CONSTRAINT IF EXISTS uk_679r4uoqpust6h694bed8nrh9;
ALTER TABLE IF EXISTS ONLY public.tablehook DROP CONSTRAINT IF EXISTS uk_668dyd20363ufr44a805inegm;
ALTER TABLE IF EXISTS ONLY public.externalmaplayer DROP CONSTRAINT IF EXISTS uk_64w4wa4oc3hkxo86hjo63cd1x;
ALTER TABLE IF EXISTS ONLY public.categoryoptioncombo DROP CONSTRAINT IF EXISTS uk_60p9gh2un0pb7l9tctfd4o3b3;
ALTER TABLE IF EXISTS ONLY public.eventchart DROP CONSTRAINT IF EXISTS uk_5w429v9hdlvivan4a69x3ntx5;
ALTER TABLE IF EXISTS ONLY public.dataapprovallevel DROP CONSTRAINT IF EXISTS uk_5mq4bmpyevmr1ddkkopweted1;
ALTER TABLE IF EXISTS ONLY public.orgunitlevel DROP CONSTRAINT IF EXISTS uk_5km0xiwk0dg7pnoru5yfvqsdo;
ALTER TABLE IF EXISTS ONLY public.programindicator DROP CONSTRAINT IF EXISTS uk_59abitsfd3u0jx4ntrrblven0;
ALTER TABLE IF EXISTS ONLY public.externalmaplayer DROP CONSTRAINT IF EXISTS uk_581ayy658kxytmijcfd2rxnq0;
ALTER TABLE IF EXISTS ONLY public.sqlview DROP CONSTRAINT IF EXISTS uk_50aqn6tun6lt4u3ablvdxgoi6;
ALTER TABLE IF EXISTS ONLY public.categoryoption DROP CONSTRAINT IF EXISTS uk_4pi5lfmisrt8un89dnb17xrdy;
ALTER TABLE IF EXISTS ONLY public.programnotificationinstance DROP CONSTRAINT IF EXISTS uk_4mi7q6tbreuo0hspppxyodibk;
ALTER TABLE IF EXISTS ONLY public.userkeyjsonvalue DROP CONSTRAINT IF EXISTS uk_4k3a3mf7dgr4b2btftg5jkmt7;
ALTER TABLE IF EXISTS ONLY public.trackedentitytype DROP CONSTRAINT IF EXISTS uk_4iylxmooa7ca562qvw4tjq5ys;
ALTER TABLE IF EXISTS ONLY public.periodboundary DROP CONSTRAINT IF EXISTS uk_4e9t02lypy6ynejqfegixx36k;
ALTER TABLE IF EXISTS ONLY public.fileresource DROP CONSTRAINT IF EXISTS uk_4dlqoc6s8ilws9yhacy5qkddb;
ALTER TABLE IF EXISTS ONLY public.tablehook DROP CONSTRAINT IF EXISTS uk_4bcigh7ivtiraxnhqrg72tldo;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS uk_4b97sdsm2p477cc05eody10lm;
ALTER TABLE IF EXISTS ONLY public.report DROP CONSTRAINT IF EXISTS uk_478bg522jkn8460hkeshlw1j1;
ALTER TABLE IF EXISTS ONLY public.programindicator DROP CONSTRAINT IF EXISTS uk_4372w9f7asbu1ybpduj2xqjmt;
ALTER TABLE IF EXISTS ONLY public.programmessage DROP CONSTRAINT IF EXISTS uk_3vgkycs0lsgpxaqtytfijr1ji;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflow DROP CONSTRAINT IF EXISTS uk_3svwn20y9qda34bmatesg5c0j;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS uk_3r6dr8m9qwa89afngtr43x9jh;
ALTER TABLE IF EXISTS ONLY public.orgunitgroup DROP CONSTRAINT IF EXISTS uk_3phvecdmy2msmcpitqifpcy3c;
ALTER TABLE IF EXISTS ONLY public.dashboarditem DROP CONSTRAINT IF EXISTS uk_3idqsvkpmxpehxqv615s952vd;
ALTER TABLE IF EXISTS ONLY public.validationrulegroup DROP CONSTRAINT IF EXISTS uk_3cl2o6ha8naw5w6my3q4el6gk;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS uk_3c2n8db21er764e4skh3qg57w;
ALTER TABLE IF EXISTS ONLY public.categorycombo DROP CONSTRAINT IF EXISTS uk_3a4ee92kxafw85hsopq4qle47;
ALTER TABLE IF EXISTS ONLY public.map DROP CONSTRAINT IF EXISTS uk_37l2m3o1xfuagpki90gfh5kqb;
ALTER TABLE IF EXISTS ONLY public.userkeyjsonvalue DROP CONSTRAINT IF EXISTS uk_2ubxwwtgyqd0h2mvy46u3prfq;
ALTER TABLE IF EXISTS ONLY public.dataapprovallevel DROP CONSTRAINT IF EXISTS uk_2r18tvmbtksk69j35uxpwej44;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate DROP CONSTRAINT IF EXISTS uk_2pimmculf9ttu2dxquomb9ram;
ALTER TABLE IF EXISTS ONLY public.programindicatorgroup DROP CONSTRAINT IF EXISTS uk_2p9x16ryxtek0g6bqwd49et0c;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS uk_2nhc265rlfu3dlc3qouvjdprl;
ALTER TABLE IF EXISTS ONLY public.i18nlocale DROP CONSTRAINT IF EXISTS uk_2l0ovv74pjtairmeyiwy4i2ui;
ALTER TABLE IF EXISTS ONLY public.relationship DROP CONSTRAINT IF EXISTS uk_2gbm9ji77snuoll07yvpgj3o5;
ALTER TABLE IF EXISTS ONLY public.programstagedataelement DROP CONSTRAINT IF EXISTS uk_2ejl9l5vm4rhtqj8eit31g0u6;
ALTER TABLE IF EXISTS ONLY public.optiongroupset DROP CONSTRAINT IF EXISTS uk_2boebaetgus89t1k8nn4dac65;
ALTER TABLE IF EXISTS ONLY public.programstagesection DROP CONSTRAINT IF EXISTS uk_22wt9yk9idujmywno44v9qf66;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupset DROP CONSTRAINT IF EXISTS uk_1xk8j7j0a3li8o0ukblanosky;
ALTER TABLE IF EXISTS ONLY public.programmessage DROP CONSTRAINT IF EXISTS uk_1qlw3rts2pog96ye7r6fqd122;
ALTER TABLE IF EXISTS ONLY public.event_notes DROP CONSTRAINT IF EXISTS uk_1n7xvxj0jupob5f2v86cv8qer;
ALTER TABLE IF EXISTS ONLY public.validationrulegroup DROP CONSTRAINT IF EXISTS uk_1lvk8ftq028jrr28qouou9q3c;
ALTER TABLE IF EXISTS ONLY public.report DROP CONSTRAINT IF EXISTS uk_1ie06vhy3begtwuuvrv0f71se;
ALTER TABLE IF EXISTS ONLY public.optiongroupsetmembers DROP CONSTRAINT IF EXISTS uk_1film7lsn5m1wyeku7yh5anfa;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS uk_1ev6xqtcsfr4wv6rel0lkg44n;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS uk_1dw8gju4leg7iud4gpsr5r1ng;
ALTER TABLE IF EXISTS ONLY public.optionvalue DROP CONSTRAINT IF EXISTS uk_18b68rcofdwt1sbr6rf55poog;
ALTER TABLE IF EXISTS ONLY public.attribute DROP CONSTRAINT IF EXISTS uk_1774shfid1uaopl9tu8am19fq;
ALTER TABLE IF EXISTS ONLY public.validationrule DROP CONSTRAINT IF EXISTS uk_13x63e3skbl5qj4mc1qgq2xex;
ALTER TABLE IF EXISTS ONLY public.trackedentitytypeattribute DROP CONSTRAINT IF EXISTS uk_10sblshxcb7dd4qi3s879u35h;
ALTER TABLE IF EXISTS ONLY public.trackedentitytypeattribute DROP CONSTRAINT IF EXISTS trackedentitytypeattribute_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentitytype DROP CONSTRAINT IF EXISTS trackedentitytype_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentityprogramowner DROP CONSTRAINT IF EXISTS trackedentityprogramowner_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentityprogramindicatordimension DROP CONSTRAINT IF EXISTS trackedentityprogramindicatordimension_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentityfilter DROP CONSTRAINT IF EXISTS trackedentityinstancefilter_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentityaudit DROP CONSTRAINT IF EXISTS trackedentityinstanceaudit_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentity DROP CONSTRAINT IF EXISTS trackedentityinstance_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentitydatavalueaudit DROP CONSTRAINT IF EXISTS trackedentitydatavalueaudit_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentitydataelementdimension DROP CONSTRAINT IF EXISTS trackedentitydataelementdimension_pkey;
ALTER TABLE IF EXISTS ONLY public.note DROP CONSTRAINT IF EXISTS trackedentitycomment_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributevalueaudit DROP CONSTRAINT IF EXISTS trackedentityattributevalueaudit_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributevalue DROP CONSTRAINT IF EXISTS trackedentityattributevalue_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributelegendsets DROP CONSTRAINT IF EXISTS trackedentityattributelegendsets_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentityattributedimension DROP CONSTRAINT IF EXISTS trackedentityattributedimension_pkey;
ALTER TABLE IF EXISTS ONLY public.trackedentityattribute DROP CONSTRAINT IF EXISTS trackedentityattribute_pkey;
ALTER TABLE IF EXISTS ONLY public.tablehook DROP CONSTRAINT IF EXISTS tablehook_pkey;
ALTER TABLE IF EXISTS ONLY public.systemsetting DROP CONSTRAINT IF EXISTS systemsetting_pkey;
ALTER TABLE IF EXISTS ONLY public.sqlview DROP CONSTRAINT IF EXISTS sqlview_pkey;
ALTER TABLE IF EXISTS ONLY public.smsspecialcharacter DROP CONSTRAINT IF EXISTS smsspecialcharacter_pkey;
ALTER TABLE IF EXISTS ONLY public.smscommandspecialcharacters DROP CONSTRAINT IF EXISTS smscommandspecialcharacters_pkey;
ALTER TABLE IF EXISTS ONLY public.smscommands DROP CONSTRAINT IF EXISTS smscommands_pkey;
ALTER TABLE IF EXISTS ONLY public.smscommandcodes DROP CONSTRAINT IF EXISTS smscommandcodes_pkey;
ALTER TABLE IF EXISTS ONLY public.smscodes DROP CONSTRAINT IF EXISTS smscodes_pkey;
ALTER TABLE IF EXISTS ONLY public.series DROP CONSTRAINT IF EXISTS series_pkey;
ALTER TABLE IF EXISTS ONLY public.sequentialnumbercounter DROP CONSTRAINT IF EXISTS seqnumcount_pkey;
ALTER TABLE IF EXISTS ONLY public.sectionindicators DROP CONSTRAINT IF EXISTS sectionindicators_pkey;
ALTER TABLE IF EXISTS ONLY public.sectiongreyedfields DROP CONSTRAINT IF EXISTS sectiongreyedfields_pkey;
ALTER TABLE IF EXISTS ONLY public.sectiondataelements DROP CONSTRAINT IF EXISTS sectiondataelements_pkey;
ALTER TABLE IF EXISTS ONLY public.section DROP CONSTRAINT IF EXISTS section_pkey;
ALTER TABLE IF EXISTS ONLY public.route DROP CONSTRAINT IF EXISTS route_uid_key;
ALTER TABLE IF EXISTS ONLY public.route DROP CONSTRAINT IF EXISTS route_pkey;
ALTER TABLE IF EXISTS ONLY public.route DROP CONSTRAINT IF EXISTS route_name_key;
ALTER TABLE IF EXISTS ONLY public.route DROP CONSTRAINT IF EXISTS route_code_key;
ALTER TABLE IF EXISTS ONLY public.reservedvalue DROP CONSTRAINT IF EXISTS reservedvalue_pkey;
ALTER TABLE IF EXISTS ONLY public.report DROP CONSTRAINT IF EXISTS report_pkey;
ALTER TABLE IF EXISTS ONLY public.relativeperiods DROP CONSTRAINT IF EXISTS relativeperiods_pkey;
ALTER TABLE IF EXISTS ONLY public.relationshiptype DROP CONSTRAINT IF EXISTS relationshiptype_pkey;
ALTER TABLE IF EXISTS ONLY public.relationshipitem DROP CONSTRAINT IF EXISTS relationshipitem_pkey;
ALTER TABLE IF EXISTS ONLY public.relationshipconstraint DROP CONSTRAINT IF EXISTS relationshipconstraint_pkey;
ALTER TABLE IF EXISTS ONLY public.relationship DROP CONSTRAINT IF EXISTS relationship_pkey;
ALTER TABLE IF EXISTS ONLY public.pushanalysisrecipientusergroups DROP CONSTRAINT IF EXISTS pushanalysisrecipientusergroups_pkey;
ALTER TABLE IF EXISTS ONLY public.pushanalysis DROP CONSTRAINT IF EXISTS pushanalysis_pkey;
ALTER TABLE IF EXISTS ONLY public.program_attributes DROP CONSTRAINT IF EXISTS programtrackedentityattribute_unique_key;
ALTER TABLE IF EXISTS ONLY public.programtempownershipaudit DROP CONSTRAINT IF EXISTS programtempownershipaudit_pkey;
ALTER TABLE IF EXISTS ONLY public.programtempowner DROP CONSTRAINT IF EXISTS programtempowner_pkey;
ALTER TABLE IF EXISTS ONLY public.programstageworkinglist DROP CONSTRAINT IF EXISTS programstageworkinglist_uid_key;
ALTER TABLE IF EXISTS ONLY public.programstageworkinglist DROP CONSTRAINT IF EXISTS programstageworkinglist_pkey;
ALTER TABLE IF EXISTS ONLY public.programstageworkinglist DROP CONSTRAINT IF EXISTS programstageworkinglist_code_key;
ALTER TABLE IF EXISTS ONLY public.programstagesection_programindicators DROP CONSTRAINT IF EXISTS programstagesection_programindicators_pkey;
ALTER TABLE IF EXISTS ONLY public.programstagesection DROP CONSTRAINT IF EXISTS programstagesection_pkey;
ALTER TABLE IF EXISTS ONLY public.programstagesection_dataelements DROP CONSTRAINT IF EXISTS programstagesection_dataelements_pkey;
ALTER TABLE IF EXISTS ONLY public.eventfilter DROP CONSTRAINT IF EXISTS programstageinstancefilter_pkey;
ALTER TABLE IF EXISTS ONLY public.event_notes DROP CONSTRAINT IF EXISTS programstageinstancecomments_pkey;
ALTER TABLE IF EXISTS ONLY public.event DROP CONSTRAINT IF EXISTS programstageinstance_pkey;
ALTER TABLE IF EXISTS ONLY public.programstagedataelement DROP CONSTRAINT IF EXISTS programstagedataelement_unique_key;
ALTER TABLE IF EXISTS ONLY public.programstagedataelement DROP CONSTRAINT IF EXISTS programstagedataelement_pkey;
ALTER TABLE IF EXISTS ONLY public.programstage DROP CONSTRAINT IF EXISTS programstage_pkey;
ALTER TABLE IF EXISTS ONLY public.programsection DROP CONSTRAINT IF EXISTS programsection_pkey;
ALTER TABLE IF EXISTS ONLY public.programsection_attributes DROP CONSTRAINT IF EXISTS programsection_attributes_pkey;
ALTER TABLE IF EXISTS ONLY public.programrulevariable DROP CONSTRAINT IF EXISTS programrulevariable_pkey;
ALTER TABLE IF EXISTS ONLY public.programruleaction DROP CONSTRAINT IF EXISTS programruleaction_pkey;
ALTER TABLE IF EXISTS ONLY public.programrule DROP CONSTRAINT IF EXISTS programrule_pkey;
ALTER TABLE IF EXISTS ONLY public.programownershiphistory DROP CONSTRAINT IF EXISTS programownershiphistory_pkey;
ALTER TABLE IF EXISTS ONLY public.programnotificationtemplate DROP CONSTRAINT IF EXISTS programnotificationtemplate_pkey;
ALTER TABLE IF EXISTS ONLY public.programnotificationinstance DROP CONSTRAINT IF EXISTS programnotificationinstance_pkey;
ALTER TABLE IF EXISTS ONLY public.programmessage DROP CONSTRAINT IF EXISTS programmessage_pkey;
ALTER TABLE IF EXISTS ONLY public.enrollment_notes DROP CONSTRAINT IF EXISTS programinstancecomments_pkey;
ALTER TABLE IF EXISTS ONLY public.enrollment DROP CONSTRAINT IF EXISTS programinstance_pkey;
ALTER TABLE IF EXISTS ONLY public.programindicatorlegendsets DROP CONSTRAINT IF EXISTS programindicatorlegendsets_pkey;
ALTER TABLE IF EXISTS ONLY public.programindicatorgroupmembers DROP CONSTRAINT IF EXISTS programindicatorgroupmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.programindicatorgroup DROP CONSTRAINT IF EXISTS programindicatorgroup_pkey;
ALTER TABLE IF EXISTS ONLY public.programindicator DROP CONSTRAINT IF EXISTS programindicator_pkey;
ALTER TABLE IF EXISTS ONLY public.programexpression DROP CONSTRAINT IF EXISTS programexpression_pkey;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS program_pkey;
ALTER TABLE IF EXISTS ONLY public.program_organisationunits DROP CONSTRAINT IF EXISTS program_organisationunits_pkey;
ALTER TABLE IF EXISTS ONLY public.program_attributes DROP CONSTRAINT IF EXISTS program_attributes_pkey;
ALTER TABLE IF EXISTS ONLY public.previouspasswords DROP CONSTRAINT IF EXISTS previouspasswords_pkey;
ALTER TABLE IF EXISTS ONLY public.predictororgunitlevels DROP CONSTRAINT IF EXISTS predictororgunitlevels_pkey;
ALTER TABLE IF EXISTS ONLY public.predictorgroupmembers DROP CONSTRAINT IF EXISTS predictorgroupmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.predictorgroup DROP CONSTRAINT IF EXISTS predictorgroup_pkey;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS predictor_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.predictor DROP CONSTRAINT IF EXISTS predictor_pkey;
ALTER TABLE IF EXISTS ONLY public.potentialduplicate DROP CONSTRAINT IF EXISTS potentialduplicate_uid_key;
ALTER TABLE IF EXISTS ONLY public.potentialduplicate DROP CONSTRAINT IF EXISTS potentialduplicate_teia_teib;
ALTER TABLE IF EXISTS ONLY public.potentialduplicate DROP CONSTRAINT IF EXISTS potentialduplicate_pkey;
ALTER TABLE IF EXISTS ONLY public.periodtype DROP CONSTRAINT IF EXISTS periodtype_pkey;
ALTER TABLE IF EXISTS ONLY public.periodboundary DROP CONSTRAINT IF EXISTS periodboundary_pkey;
ALTER TABLE IF EXISTS ONLY public.period DROP CONSTRAINT IF EXISTS period_pkey;
ALTER TABLE IF EXISTS ONLY public.outbound_sms DROP CONSTRAINT IF EXISTS outbound_sms_pkey;
ALTER TABLE IF EXISTS ONLY public.orgunitlevel DROP CONSTRAINT IF EXISTS orgunitlevel_pkey;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupsetmembers DROP CONSTRAINT IF EXISTS orgunitgroupsetmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupsetdimension DROP CONSTRAINT IF EXISTS orgunitgroupsetdimension_pkey;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupsetdimension_items DROP CONSTRAINT IF EXISTS orgunitgroupsetdimension_items_pkey;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupset DROP CONSTRAINT IF EXISTS orgunitgroupset_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupset DROP CONSTRAINT IF EXISTS orgunitgroupset_pkey;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupset DROP CONSTRAINT IF EXISTS orgunitgroupset_name_key;
ALTER TABLE IF EXISTS ONLY public.orgunitgroupmembers DROP CONSTRAINT IF EXISTS orgunitgroupmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.orgunitgroup DROP CONSTRAINT IF EXISTS orgunitgroup_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.orgunitgroup DROP CONSTRAINT IF EXISTS orgunitgroup_pkey;
ALTER TABLE IF EXISTS ONLY public.orgunitgroup DROP CONSTRAINT IF EXISTS orgunitgroup_name_key;
ALTER TABLE IF EXISTS ONLY public.organisationunit DROP CONSTRAINT IF EXISTS organisationunit_pkey;
ALTER TABLE IF EXISTS ONLY public.organisationunit DROP CONSTRAINT IF EXISTS organisationunit_code_key;
ALTER TABLE IF EXISTS ONLY public.optionvalue DROP CONSTRAINT IF EXISTS optionvalue_unique_optionsetid_and_code;
ALTER TABLE IF EXISTS ONLY public.optionvalue DROP CONSTRAINT IF EXISTS optionvalue_pkey;
ALTER TABLE IF EXISTS ONLY public.optionset DROP CONSTRAINT IF EXISTS optionset_pkey;
ALTER TABLE IF EXISTS ONLY public.optiongroupsetmembers DROP CONSTRAINT IF EXISTS optiongroupsetmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.optiongroupset DROP CONSTRAINT IF EXISTS optiongroupset_pkey;
ALTER TABLE IF EXISTS ONLY public.optiongroupmembers DROP CONSTRAINT IF EXISTS optiongroupmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.optiongroup DROP CONSTRAINT IF EXISTS optiongroup_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth_access_token DROP CONSTRAINT IF EXISTS oauth_access_token_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth2clientredirecturis DROP CONSTRAINT IF EXISTS oauth2clientredirecturis_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth2clientgranttypes DROP CONSTRAINT IF EXISTS oauth2clientgranttypes_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth2client DROP CONSTRAINT IF EXISTS oauth2client_pkey;
ALTER TABLE IF EXISTS ONLY public.minmaxdataelement DROP CONSTRAINT IF EXISTS minmaxdataelement_pkey;
ALTER TABLE IF EXISTS ONLY public.metadataversion DROP CONSTRAINT IF EXISTS metadataversion_pkey;
ALTER TABLE IF EXISTS ONLY public.metadataproposal DROP CONSTRAINT IF EXISTS metadataproposal_uid_key;
ALTER TABLE IF EXISTS ONLY public.metadataproposal DROP CONSTRAINT IF EXISTS metadataproposal_pkey;
ALTER TABLE IF EXISTS ONLY public.messageconversation_usermessages DROP CONSTRAINT IF EXISTS messageconversation_usermessages_pkey;
ALTER TABLE IF EXISTS ONLY public.messageconversation DROP CONSTRAINT IF EXISTS messageconversation_pkey;
ALTER TABLE IF EXISTS ONLY public.messageconversation_messages DROP CONSTRAINT IF EXISTS messageconversation_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.messageattachments DROP CONSTRAINT IF EXISTS messageattachments_pkey;
ALTER TABLE IF EXISTS ONLY public.message DROP CONSTRAINT IF EXISTS message_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview DROP CONSTRAINT IF EXISTS mapview_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_periods DROP CONSTRAINT IF EXISTS mapview_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_orgunitlevels DROP CONSTRAINT IF EXISTS mapview_orgunitlevels_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS mapview_orgunitgroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_organisationunits DROP CONSTRAINT IF EXISTS mapview_organisationunits_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_itemorgunitgroups DROP CONSTRAINT IF EXISTS mapview_itemorgunitgroups_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_filters DROP CONSTRAINT IF EXISTS mapview_filters_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_dataelementdimensions DROP CONSTRAINT IF EXISTS mapview_dataelementdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_datadimensionitems DROP CONSTRAINT IF EXISTS mapview_datadimensionitems_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_columns DROP CONSTRAINT IF EXISTS mapview_columns_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS mapview_categoryoptiongroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_categorydimensions DROP CONSTRAINT IF EXISTS mapview_categorydimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.mapview_attributedimensions DROP CONSTRAINT IF EXISTS mapview_attributedimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.mapmapviews DROP CONSTRAINT IF EXISTS mapmapviews_pkey;
ALTER TABLE IF EXISTS ONLY public.maplegendset DROP CONSTRAINT IF EXISTS maplegendset_pkey;
ALTER TABLE IF EXISTS ONLY public.maplegend DROP CONSTRAINT IF EXISTS maplegend_pkey;
ALTER TABLE IF EXISTS ONLY public.map DROP CONSTRAINT IF EXISTS map_pkey;
ALTER TABLE IF EXISTS ONLY public.lockexception DROP CONSTRAINT IF EXISTS lockexception_pkey;
ALTER TABLE IF EXISTS ONLY public.keyjsonvalue DROP CONSTRAINT IF EXISTS keyjsonvalue_unique_key_in_namespace;
ALTER TABLE IF EXISTS ONLY public.keyjsonvalue DROP CONSTRAINT IF EXISTS keyjsonvalue_pkey;
ALTER TABLE IF EXISTS ONLY public.section DROP CONSTRAINT IF EXISTS key_sectionnamedataset;
ALTER TABLE IF EXISTS ONLY public.deletedobject DROP CONSTRAINT IF EXISTS key_deleted_object_klass_uid;
ALTER TABLE IF EXISTS ONLY public.jobconfiguration DROP CONSTRAINT IF EXISTS jobconfiguration_pkey;
ALTER TABLE IF EXISTS ONLY public.interpretationcomment DROP CONSTRAINT IF EXISTS interpretationcomment_pkey;
ALTER TABLE IF EXISTS ONLY public.interpretation DROP CONSTRAINT IF EXISTS interpretation_pkey;
ALTER TABLE IF EXISTS ONLY public.interpretation_comments DROP CONSTRAINT IF EXISTS interpretation_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.interpretation_comments DROP CONSTRAINT IF EXISTS interpretation_comments_interpretationcommentid_key;
ALTER TABLE IF EXISTS ONLY public.intepretation_likedby DROP CONSTRAINT IF EXISTS intepretation_likedby_pkey;
ALTER TABLE IF EXISTS ONLY public.indicatortype DROP CONSTRAINT IF EXISTS indicatortype_pkey;
ALTER TABLE IF EXISTS ONLY public.indicatorlegendsets DROP CONSTRAINT IF EXISTS indicatorlegendsets_pkey;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupsetmembers DROP CONSTRAINT IF EXISTS indicatorgroupsetmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupset DROP CONSTRAINT IF EXISTS indicatorgroupset_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupset DROP CONSTRAINT IF EXISTS indicatorgroupset_pkey;
ALTER TABLE IF EXISTS ONLY public.indicatorgroupmembers DROP CONSTRAINT IF EXISTS indicatorgroupmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.indicatorgroup DROP CONSTRAINT IF EXISTS indicatorgroup_pkey;
ALTER TABLE IF EXISTS ONLY public.indicator DROP CONSTRAINT IF EXISTS indicator_pkey;
ALTER TABLE IF EXISTS ONLY public.indicator DROP CONSTRAINT IF EXISTS indicator_code_key;
ALTER TABLE IF EXISTS ONLY public.incomingsms DROP CONSTRAINT IF EXISTS incomingsms_pkey;
ALTER TABLE IF EXISTS ONLY public.icon DROP CONSTRAINT IF EXISTS icon_pkey;
ALTER TABLE IF EXISTS ONLY public.icon DROP CONSTRAINT IF EXISTS icon_fileresource_ukey;
ALTER TABLE IF EXISTS ONLY public.i18nlocale DROP CONSTRAINT IF EXISTS i18nlocale_pkey;
ALTER TABLE IF EXISTS ONLY public.flyway_schema_history DROP CONSTRAINT IF EXISTS flyway_schema_history_pk;
ALTER TABLE IF EXISTS ONLY public.fileresource DROP CONSTRAINT IF EXISTS fileresource_pkey;
ALTER TABLE IF EXISTS ONLY public.externalnotificationlogentry DROP CONSTRAINT IF EXISTS externalnotificationlogentry_pkey;
ALTER TABLE IF EXISTS ONLY public.externalmaplayer DROP CONSTRAINT IF EXISTS externalmaplayer_pkey;
ALTER TABLE IF EXISTS ONLY public.externalfileresource DROP CONSTRAINT IF EXISTS externalfileresource_pkey;
ALTER TABLE IF EXISTS ONLY public.expressiondimensionitem DROP CONSTRAINT IF EXISTS expressiondimensionitem_uid_key;
ALTER TABLE IF EXISTS ONLY public.expressiondimensionitem DROP CONSTRAINT IF EXISTS expressiondimensionitem_pkey;
ALTER TABLE IF EXISTS ONLY public.expressiondimensionitem DROP CONSTRAINT IF EXISTS expressiondimensionitem_code_key;
ALTER TABLE IF EXISTS ONLY public.expression DROP CONSTRAINT IF EXISTS expression_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_rows DROP CONSTRAINT IF EXISTS eventvisualization_rows_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_programindicatordimensions DROP CONSTRAINT IF EXISTS eventvisualization_programindicatordimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization DROP CONSTRAINT IF EXISTS eventvisualization_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_periods DROP CONSTRAINT IF EXISTS eventvisualization_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_orgunitlevels DROP CONSTRAINT IF EXISTS eventvisualization_orgunitlevels_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS eventvisualization_orgunitgroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_organisationunits DROP CONSTRAINT IF EXISTS eventvisualization_organisationunits_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_itemorgunitgroups DROP CONSTRAINT IF EXISTS eventvisualization_itemorgunitgroups_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_filters DROP CONSTRAINT IF EXISTS eventvisualization_filters_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_dataelementdimensions DROP CONSTRAINT IF EXISTS eventvisualization_dataelementdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_columns DROP CONSTRAINT IF EXISTS eventvisualization_columns_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS eventvisualization_categoryoptiongroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_categorydimensions DROP CONSTRAINT IF EXISTS eventvisualization_categorydimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventvisualization_attributedimensions DROP CONSTRAINT IF EXISTS eventvisualization_attributedimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_rows DROP CONSTRAINT IF EXISTS eventreport_rows_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_programindicatordimensions DROP CONSTRAINT IF EXISTS eventreport_programindicatordimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport DROP CONSTRAINT IF EXISTS eventreport_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_periods DROP CONSTRAINT IF EXISTS eventreport_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_orgunitlevels DROP CONSTRAINT IF EXISTS eventreport_orgunitlevels_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS eventreport_orgunitgroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_organisationunits DROP CONSTRAINT IF EXISTS eventreport_organisationunits_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_itemorgunitgroups DROP CONSTRAINT IF EXISTS eventreport_itemorgunitgroups_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_filters DROP CONSTRAINT IF EXISTS eventreport_filters_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_dataelementdimensions DROP CONSTRAINT IF EXISTS eventreport_dataelementdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_columns DROP CONSTRAINT IF EXISTS eventreport_columns_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS eventreport_categoryoptiongroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_categorydimensions DROP CONSTRAINT IF EXISTS eventreport_categorydimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventreport_attributedimensions DROP CONSTRAINT IF EXISTS eventreport_attributedimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventhook DROP CONSTRAINT IF EXISTS eventhook_uid_key;
ALTER TABLE IF EXISTS ONLY public.eventhook DROP CONSTRAINT IF EXISTS eventhook_pkey;
ALTER TABLE IF EXISTS ONLY public.eventhook DROP CONSTRAINT IF EXISTS eventhook_name_key;
ALTER TABLE IF EXISTS ONLY public.eventhook DROP CONSTRAINT IF EXISTS eventhook_code_key;
ALTER TABLE IF EXISTS ONLY public.eventchart_rows DROP CONSTRAINT IF EXISTS eventchart_rows_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_programindicatordimensions DROP CONSTRAINT IF EXISTS eventchart_programindicatordimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart DROP CONSTRAINT IF EXISTS eventchart_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_periods DROP CONSTRAINT IF EXISTS eventchart_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_orgunitlevels DROP CONSTRAINT IF EXISTS eventchart_orgunitlevels_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_orgunitgroupsetdimensions DROP CONSTRAINT IF EXISTS eventchart_orgunitgroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_organisationunits DROP CONSTRAINT IF EXISTS eventchart_organisationunits_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_itemorgunitgroups DROP CONSTRAINT IF EXISTS eventchart_itemorgunitgroups_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_filters DROP CONSTRAINT IF EXISTS eventchart_filters_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_dataelementdimensions DROP CONSTRAINT IF EXISTS eventchart_dataelementdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_columns DROP CONSTRAINT IF EXISTS eventchart_columns_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_categoryoptiongroupsetdimensions DROP CONSTRAINT IF EXISTS eventchart_categoryoptiongroupsetdimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_categorydimensions DROP CONSTRAINT IF EXISTS eventchart_categorydimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.eventchart_attributedimensions DROP CONSTRAINT IF EXISTS eventchart_attributedimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.document DROP CONSTRAINT IF EXISTS document_pkey;
ALTER TABLE IF EXISTS ONLY public.deletedobject DROP CONSTRAINT IF EXISTS deletedobject_pkey;
ALTER TABLE IF EXISTS ONLY public.datavalueaudit DROP CONSTRAINT IF EXISTS datavalueaudit_pkey;
ALTER TABLE IF EXISTS ONLY public.datavalue DROP CONSTRAINT IF EXISTS datavalue_pkey;
ALTER TABLE IF EXISTS ONLY public.datastatisticsevent DROP CONSTRAINT IF EXISTS datastatisticsevent_pkey;
ALTER TABLE IF EXISTS ONLY public.datastatistics DROP CONSTRAINT IF EXISTS datastatistics_pkey;
ALTER TABLE IF EXISTS ONLY public.datasetsource DROP CONSTRAINT IF EXISTS datasetsource_pkey;
ALTER TABLE IF EXISTS ONLY public.datasetoperands DROP CONSTRAINT IF EXISTS datasetoperands_pkey;
ALTER TABLE IF EXISTS ONLY public.datasetnotificationtemplate DROP CONSTRAINT IF EXISTS datasetnotificationtemplate_pkey;
ALTER TABLE IF EXISTS ONLY public.datasetnotification_datasets DROP CONSTRAINT IF EXISTS datasetnotification_datasets_pkey;
ALTER TABLE IF EXISTS ONLY public.datasetlegendsets DROP CONSTRAINT IF EXISTS datasetlegendsets_pkey;
ALTER TABLE IF EXISTS ONLY public.datasetindicators DROP CONSTRAINT IF EXISTS datasetindicators_pkey;
ALTER TABLE IF EXISTS ONLY public.datasetelement DROP CONSTRAINT IF EXISTS datasetelement_unique_key;
ALTER TABLE IF EXISTS ONLY public.datasetelement DROP CONSTRAINT IF EXISTS datasetelement_pkey;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS dataset_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.dataset DROP CONSTRAINT IF EXISTS dataset_pkey;
ALTER TABLE IF EXISTS ONLY public.datainputperiod DROP CONSTRAINT IF EXISTS datainputperiod_pkey;
ALTER TABLE IF EXISTS ONLY public.dataentryform DROP CONSTRAINT IF EXISTS dataentryform_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelementoperand DROP CONSTRAINT IF EXISTS dataelementoperand_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelementlegendsets DROP CONSTRAINT IF EXISTS dataelementlegendsets_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupsetmembers DROP CONSTRAINT IF EXISTS dataelementgroupsetmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupsetdimension DROP CONSTRAINT IF EXISTS dataelementgroupsetdimension_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupsetdimension_items DROP CONSTRAINT IF EXISTS dataelementgroupsetdimension_items_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupset DROP CONSTRAINT IF EXISTS dataelementgroupset_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupset DROP CONSTRAINT IF EXISTS dataelementgroupset_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelementgroupmembers DROP CONSTRAINT IF EXISTS dataelementgroupmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelementgroup DROP CONSTRAINT IF EXISTS dataelementgroup_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.dataelementgroup DROP CONSTRAINT IF EXISTS dataelementgroup_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoption DROP CONSTRAINT IF EXISTS dataelementcategoryoption_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.categoryoption DROP CONSTRAINT IF EXISTS dataelementcategoryoption_pkey;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS dataelementcategory_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS dataelementcategory_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelementaggregationlevels DROP CONSTRAINT IF EXISTS dataelementaggregationlevels_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS dataelement_pkey;
ALTER TABLE IF EXISTS ONLY public.dataelement DROP CONSTRAINT IF EXISTS dataelement_code_key;
ALTER TABLE IF EXISTS ONLY public.datadimensionitem DROP CONSTRAINT IF EXISTS datadimensionitem_pkey;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflowlevels DROP CONSTRAINT IF EXISTS dataapprovalworkflowlevels_pkey;
ALTER TABLE IF EXISTS ONLY public.dataapprovalworkflow DROP CONSTRAINT IF EXISTS dataapprovalworkflow_pkey;
ALTER TABLE IF EXISTS ONLY public.dataapprovallevel DROP CONSTRAINT IF EXISTS dataapprovallevel_pkey;
ALTER TABLE IF EXISTS ONLY public.dataapprovalaudit DROP CONSTRAINT IF EXISTS dataapprovalaudit_pkey;
ALTER TABLE IF EXISTS ONLY public.dataapproval DROP CONSTRAINT IF EXISTS dataapproval_unique_key;
ALTER TABLE IF EXISTS ONLY public.dataapproval DROP CONSTRAINT IF EXISTS dataapproval_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboarditem_users DROP CONSTRAINT IF EXISTS dashboarditem_users_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboarditem_resources DROP CONSTRAINT IF EXISTS dashboarditem_resources_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboarditem_reports DROP CONSTRAINT IF EXISTS dashboarditem_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboarditem DROP CONSTRAINT IF EXISTS dashboarditem_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboard DROP CONSTRAINT IF EXISTS dashboard_unique_code;
ALTER TABLE IF EXISTS ONLY public.dashboard DROP CONSTRAINT IF EXISTS dashboard_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_items DROP CONSTRAINT IF EXISTS dashboard_items_pkey;
ALTER TABLE IF EXISTS ONLY public.constant DROP CONSTRAINT IF EXISTS constant_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.constant DROP CONSTRAINT IF EXISTS constant_pkey;
ALTER TABLE IF EXISTS ONLY public.configuration DROP CONSTRAINT IF EXISTS configuration_pkey;
ALTER TABLE IF EXISTS ONLY public.completedatasetregistration DROP CONSTRAINT IF EXISTS completedatasetregistration_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupsetmembers DROP CONSTRAINT IF EXISTS categoryoptiongroupsetmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupsetdimension DROP CONSTRAINT IF EXISTS categoryoptiongroupsetdimension_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupsetdimension_items DROP CONSTRAINT IF EXISTS categoryoptiongroupsetdimension_items_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupset DROP CONSTRAINT IF EXISTS categoryoptiongroupset_unique_shortname;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupset DROP CONSTRAINT IF EXISTS categoryoptiongroupset_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroupmembers DROP CONSTRAINT IF EXISTS categoryoptiongroupmembers_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoptiongroup DROP CONSTRAINT IF EXISTS categoryoptiongroup_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoptioncombos_categoryoptions DROP CONSTRAINT IF EXISTS categoryoptioncombos_categoryoptions_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoptioncombo DROP CONSTRAINT IF EXISTS categoryoptioncombo_pkey;
ALTER TABLE IF EXISTS ONLY public.categoryoption_organisationunits DROP CONSTRAINT IF EXISTS categoryoption_organisationunits_pkey;
ALTER TABLE IF EXISTS ONLY public.categorydimension DROP CONSTRAINT IF EXISTS categorydimension_pkey;
ALTER TABLE IF EXISTS ONLY public.categorydimension_items DROP CONSTRAINT IF EXISTS categorydimension_items_pkey;
ALTER TABLE IF EXISTS ONLY public.categorycombos_optioncombos DROP CONSTRAINT IF EXISTS categorycombos_optioncombos_pkey;
ALTER TABLE IF EXISTS ONLY public.categorycombos_categories DROP CONSTRAINT IF EXISTS categorycombos_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categorycombo DROP CONSTRAINT IF EXISTS categorycombo_pkey;
ALTER TABLE IF EXISTS ONLY public.categories_categoryoptions DROP CONSTRAINT IF EXISTS categories_categoryoptions_pkey;
ALTER TABLE IF EXISTS ONLY public.axis DROP CONSTRAINT IF EXISTS axis_pkey;
ALTER TABLE IF EXISTS ONLY public.audit DROP CONSTRAINT IF EXISTS audit_pkey;
ALTER TABLE IF EXISTS ONLY public.attributevalue DROP CONSTRAINT IF EXISTS attributevalue_pkey;
ALTER TABLE IF EXISTS ONLY public.attribute DROP CONSTRAINT IF EXISTS attribute_pkey;
ALTER TABLE IF EXISTS ONLY public.api_token DROP CONSTRAINT IF EXISTS api_token_uid_key;
ALTER TABLE IF EXISTS ONLY public.api_token DROP CONSTRAINT IF EXISTS api_token_pkey;
ALTER TABLE IF EXISTS ONLY public.api_token DROP CONSTRAINT IF EXISTS api_token_code_key;
ALTER TABLE IF EXISTS ONLY public.aggregatedataexchange DROP CONSTRAINT IF EXISTS aggregatedataexchange_uid_key;
ALTER TABLE IF EXISTS ONLY public.aggregatedataexchange DROP CONSTRAINT IF EXISTS aggregatedataexchange_pkey;
ALTER TABLE IF EXISTS ONLY public.aggregatedataexchange DROP CONSTRAINT IF EXISTS aggregatedataexchange_name_key;
ALTER TABLE IF EXISTS ONLY public.aggregatedataexchange DROP CONSTRAINT IF EXISTS aggregatedataexchange_code_key;
ALTER TABLE IF EXISTS public.audit ALTER COLUMN auditid DROP DEFAULT;
DROP TABLE IF EXISTS public.visualization_yearlyseries;
DROP TABLE IF EXISTS public.visualization_rows;
DROP TABLE IF EXISTS public.visualization_periods;
DROP TABLE IF EXISTS public.visualization_orgunitlevels;
DROP TABLE IF EXISTS public.visualization_orgunitgroupsetdimensions;
DROP TABLE IF EXISTS public.visualization_organisationunits;
DROP TABLE IF EXISTS public.visualization_itemorgunitgroups;
DROP TABLE IF EXISTS public.visualization_filters;
DROP TABLE IF EXISTS public.visualization_dataelementgroupsetdimensions;
DROP TABLE IF EXISTS public.visualization_datadimensionitems;
DROP TABLE IF EXISTS public.visualization_columns;
DROP TABLE IF EXISTS public.visualization_categoryoptiongroupsetdimensions;
DROP TABLE IF EXISTS public.visualization_categorydimensions;
DROP TABLE IF EXISTS public.visualization_axis;
DROP TABLE IF EXISTS public.visualization;
DROP TABLE IF EXISTS public.version;
DROP TABLE IF EXISTS public.validationruleorganisationunitlevels;
DROP TABLE IF EXISTS public.validationrulegroupmembers;
DROP TABLE IF EXISTS public.validationrulegroup;
DROP TABLE IF EXISTS public.validationrule;
DROP TABLE IF EXISTS public.validationresult;
DROP TABLE IF EXISTS public.validationnotificationtemplatevalidationrules;
DROP TABLE IF EXISTS public.validationnotificationtemplate_recipientusergroups;
DROP TABLE IF EXISTS public.validationnotificationtemplate;
DROP TABLE IF EXISTS public.userteisearchorgunits;
DROP TABLE IF EXISTS public.usersetting;
DROP TABLE IF EXISTS public.users_cogsdimensionconstraints;
DROP TABLE IF EXISTS public.users_catdimensionconstraints;
DROP TABLE IF EXISTS public.userrolerestrictions;
DROP TABLE IF EXISTS public.userrolemembers;
DROP TABLE IF EXISTS public.userroleauthorities;
DROP TABLE IF EXISTS public.userrole;
DROP SEQUENCE IF EXISTS public.usermessage_sequence;
DROP TABLE IF EXISTS public.usermessage;
DROP TABLE IF EXISTS public.usermembership;
DROP TABLE IF EXISTS public.userkeyjsonvalue;
DROP TABLE IF EXISTS public.userinfo;
DROP TABLE IF EXISTS public.usergroupmembers;
DROP TABLE IF EXISTS public.usergroupmanaged;
DROP TABLE IF EXISTS public.usergroup;
DROP TABLE IF EXISTS public.userdatavieworgunits;
DROP TABLE IF EXISTS public.userapps;
DROP TABLE IF EXISTS public.trackedentitytypeattribute;
DROP TABLE IF EXISTS public.trackedentitytype;
DROP TABLE IF EXISTS public.trackedentityprogramowner;
DROP TABLE IF EXISTS public.trackedentityprogramindicatordimension;
DROP SEQUENCE IF EXISTS public.trackedentityinstanceaudit_sequence;
DROP SEQUENCE IF EXISTS public.trackedentityinstance_sequence;
DROP TABLE IF EXISTS public.trackedentityfilter;
DROP SEQUENCE IF EXISTS public.trackedentitydatavalueaudit_sequence;
DROP TABLE IF EXISTS public.trackedentitydatavalueaudit;
DROP TABLE IF EXISTS public.trackedentitydataelementdimension;
DROP TABLE IF EXISTS public.trackedentityaudit;
DROP TABLE IF EXISTS public.trackedentityattributevalueaudit;
DROP TABLE IF EXISTS public.trackedentityattributevalue;
DROP TABLE IF EXISTS public.trackedentityattributelegendsets;
DROP TABLE IF EXISTS public.trackedentityattributedimension;
DROP TABLE IF EXISTS public.trackedentityattribute;
DROP TABLE IF EXISTS public.trackedentity;
DROP TABLE IF EXISTS public.tablehook;
DROP TABLE IF EXISTS public.systemsetting;
DROP TABLE IF EXISTS public.sqlview;
DROP TABLE IF EXISTS public.smsspecialcharacter;
DROP TABLE IF EXISTS public.smscommandspecialcharacters;
DROP TABLE IF EXISTS public.smscommands;
DROP TABLE IF EXISTS public.smscommandcodes;
DROP TABLE IF EXISTS public.smscodes;
DROP TABLE IF EXISTS public.series;
DROP TABLE IF EXISTS public.sequentialnumbercounter;
DROP TABLE IF EXISTS public.sectionindicators;
DROP TABLE IF EXISTS public.sectiongreyedfields;
DROP TABLE IF EXISTS public.sectiondataelements;
DROP TABLE IF EXISTS public.section;
DROP TABLE IF EXISTS public.route;
DROP SEQUENCE IF EXISTS public.reservedvalue_sequence;
DROP TABLE IF EXISTS public.reservedvalue;
DROP TABLE IF EXISTS public.report;
DROP TABLE IF EXISTS public.relativeperiods;
DROP TABLE IF EXISTS public.relationshiptype;
DROP TABLE IF EXISTS public.relationshipitem;
DROP TABLE IF EXISTS public.relationshipconstraint;
DROP TABLE IF EXISTS public.relationship;
DROP TABLE IF EXISTS public.pushanalysisrecipientusergroups;
DROP TABLE IF EXISTS public.pushanalysis;
DROP TABLE IF EXISTS public.programtempownershipaudit;
DROP TABLE IF EXISTS public.programtempowner;
DROP TABLE IF EXISTS public.programstageworkinglist;
DROP TABLE IF EXISTS public.programstagesection_programindicators;
DROP TABLE IF EXISTS public.programstagesection_dataelements;
DROP TABLE IF EXISTS public.programstagesection;
DROP SEQUENCE IF EXISTS public.programstageinstance_sequence;
DROP TABLE IF EXISTS public.programstagedataelement;
DROP TABLE IF EXISTS public.programstage;
DROP TABLE IF EXISTS public.programsection_attributes;
DROP TABLE IF EXISTS public.programsection;
DROP TABLE IF EXISTS public.programrulevariable;
DROP TABLE IF EXISTS public.programruleaction;
DROP TABLE IF EXISTS public.programrule;
DROP TABLE IF EXISTS public.programownershiphistory;
DROP TABLE IF EXISTS public.programnotificationtemplate_deliverychannel;
DROP TABLE IF EXISTS public.programnotificationtemplate;
DROP TABLE IF EXISTS public.programnotificationinstance;
DROP TABLE IF EXISTS public.programmessage_phonenumbers;
DROP TABLE IF EXISTS public.programmessage_emailaddresses;
DROP TABLE IF EXISTS public.programmessage_deliverychannels;
DROP TABLE IF EXISTS public.programmessage;
DROP SEQUENCE IF EXISTS public.programinstance_sequence;
DROP TABLE IF EXISTS public.programindicatorlegendsets;
DROP TABLE IF EXISTS public.programindicatorgroupmembers;
DROP TABLE IF EXISTS public.programindicatorgroup;
DROP TABLE IF EXISTS public.programindicator;
DROP TABLE IF EXISTS public.programexpression;
DROP TABLE IF EXISTS public.program_userroles;
DROP TABLE IF EXISTS public.program_organisationunits;
DROP TABLE IF EXISTS public.program_attributes;
DROP TABLE IF EXISTS public.program;
DROP TABLE IF EXISTS public.previouspasswords;
DROP TABLE IF EXISTS public.predictororgunitlevels;
DROP TABLE IF EXISTS public.predictorgroupmembers;
DROP TABLE IF EXISTS public.predictorgroup;
DROP TABLE IF EXISTS public.predictor;
DROP SEQUENCE IF EXISTS public.potentialduplicatesequence;
DROP TABLE IF EXISTS public.potentialduplicate;
DROP TABLE IF EXISTS public.periodtype;
DROP TABLE IF EXISTS public.periodboundary;
DROP TABLE IF EXISTS public.period;
DROP TABLE IF EXISTS public.outbound_sms_recipients;
DROP TABLE IF EXISTS public.outbound_sms;
DROP TABLE IF EXISTS public.orgunitlevel;
DROP TABLE IF EXISTS public.orgunitgroupsetmembers;
DROP TABLE IF EXISTS public.orgunitgroupsetdimension_items;
DROP TABLE IF EXISTS public.orgunitgroupsetdimension;
DROP TABLE IF EXISTS public.orgunitgroupset;
DROP TABLE IF EXISTS public.orgunitgroupmembers;
DROP TABLE IF EXISTS public.orgunitgroup;
DROP TABLE IF EXISTS public.organisationunit;
DROP TABLE IF EXISTS public.optionvalue;
DROP TABLE IF EXISTS public.optionset;
DROP TABLE IF EXISTS public.optiongroupsetmembers;
DROP TABLE IF EXISTS public.optiongroupset;
DROP TABLE IF EXISTS public.optiongroupmembers;
DROP TABLE IF EXISTS public.optiongroup;
DROP TABLE IF EXISTS public.oauth_refresh_token;
DROP TABLE IF EXISTS public.oauth_code;
DROP TABLE IF EXISTS public.oauth_access_token;
DROP TABLE IF EXISTS public.oauth2clientredirecturis;
DROP TABLE IF EXISTS public.oauth2clientgranttypes;
DROP TABLE IF EXISTS public.oauth2client;
DROP TABLE IF EXISTS public.note;
DROP TABLE IF EXISTS public.minmaxdataelement;
DROP TABLE IF EXISTS public.metadataversion;
DROP TABLE IF EXISTS public.metadataproposal;
DROP TABLE IF EXISTS public.messageconversation_usermessages;
DROP SEQUENCE IF EXISTS public.messageconversation_sequence;
DROP TABLE IF EXISTS public.messageconversation_messages;
DROP TABLE IF EXISTS public.messageconversation;
DROP TABLE IF EXISTS public.messageattachments;
DROP SEQUENCE IF EXISTS public.message_sequence;
DROP TABLE IF EXISTS public.message;
DROP TABLE IF EXISTS public.mapview_periods;
DROP TABLE IF EXISTS public.mapview_orgunitlevels;
DROP TABLE IF EXISTS public.mapview_orgunitgroupsetdimensions;
DROP TABLE IF EXISTS public.mapview_organisationunits;
DROP TABLE IF EXISTS public.mapview_itemorgunitgroups;
DROP TABLE IF EXISTS public.mapview_filters;
DROP TABLE IF EXISTS public.mapview_dataelementdimensions;
DROP TABLE IF EXISTS public.mapview_datadimensionitems;
DROP TABLE IF EXISTS public.mapview_columns;
DROP TABLE IF EXISTS public.mapview_categoryoptiongroupsetdimensions;
DROP TABLE IF EXISTS public.mapview_categorydimensions;
DROP TABLE IF EXISTS public.mapview_attributedimensions;
DROP TABLE IF EXISTS public.mapview;
DROP TABLE IF EXISTS public.mapmapviews;
DROP TABLE IF EXISTS public.maplegendset;
DROP TABLE IF EXISTS public.maplegend;
DROP TABLE IF EXISTS public.map;
DROP TABLE IF EXISTS public.lockexception;
DROP TABLE IF EXISTS public.keyjsonvalue;
DROP TABLE IF EXISTS public.jobconfiguration;
DROP TABLE IF EXISTS public.interpretationcomment;
DROP TABLE IF EXISTS public.interpretation_comments;
DROP TABLE IF EXISTS public.interpretation;
DROP TABLE IF EXISTS public.intepretation_likedby;
DROP TABLE IF EXISTS public.indicatortype;
DROP TABLE IF EXISTS public.indicatorlegendsets;
DROP TABLE IF EXISTS public.indicatorgroupsetmembers;
DROP TABLE IF EXISTS public.indicatorgroupset;
DROP TABLE IF EXISTS public.indicatorgroupmembers;
DROP TABLE IF EXISTS public.indicatorgroup;
DROP TABLE IF EXISTS public.indicator;
DROP TABLE IF EXISTS public.incomingsms;
DROP TABLE IF EXISTS public.icon;
DROP TABLE IF EXISTS public.i18nlocale;
DROP SEQUENCE IF EXISTS public.hibernate_sequence;
DROP TABLE IF EXISTS public.flyway_schema_history;
DROP TABLE IF EXISTS public.fileresource;
DROP TABLE IF EXISTS public.externalnotificationlogentry;
DROP TABLE IF EXISTS public.externalmaplayer;
DROP TABLE IF EXISTS public.externalfileresource;
DROP TABLE IF EXISTS public.expressiondimensionitem;
DROP TABLE IF EXISTS public.expression;
DROP TABLE IF EXISTS public.eventvisualization_rows;
DROP TABLE IF EXISTS public.eventvisualization_programindicatordimensions;
DROP TABLE IF EXISTS public.eventvisualization_periods;
DROP TABLE IF EXISTS public.eventvisualization_orgunitlevels;
DROP TABLE IF EXISTS public.eventvisualization_orgunitgroupsetdimensions;
DROP TABLE IF EXISTS public.eventvisualization_organisationunits;
DROP TABLE IF EXISTS public.eventvisualization_itemorgunitgroups;
DROP TABLE IF EXISTS public.eventvisualization_filters;
DROP TABLE IF EXISTS public.eventvisualization_dataelementdimensions;
DROP TABLE IF EXISTS public.eventvisualization_columns;
DROP TABLE IF EXISTS public.eventvisualization_categoryoptiongroupsetdimensions;
DROP TABLE IF EXISTS public.eventvisualization_categorydimensions;
DROP TABLE IF EXISTS public.eventvisualization_attributedimensions;
DROP TABLE IF EXISTS public.eventvisualization;
DROP TABLE IF EXISTS public.eventreport_rows;
DROP TABLE IF EXISTS public.eventreport_programindicatordimensions;
DROP TABLE IF EXISTS public.eventreport_periods;
DROP TABLE IF EXISTS public.eventreport_orgunitlevels;
DROP TABLE IF EXISTS public.eventreport_orgunitgroupsetdimensions;
DROP TABLE IF EXISTS public.eventreport_organisationunits;
DROP TABLE IF EXISTS public.eventreport_itemorgunitgroups;
DROP TABLE IF EXISTS public.eventreport_filters;
DROP TABLE IF EXISTS public.eventreport_dataelementdimensions;
DROP TABLE IF EXISTS public.eventreport_columns;
DROP TABLE IF EXISTS public.eventreport_categoryoptiongroupsetdimensions;
DROP TABLE IF EXISTS public.eventreport_categorydimensions;
DROP TABLE IF EXISTS public.eventreport_attributedimensions;
DROP TABLE IF EXISTS public.eventreport;
DROP TABLE IF EXISTS public.eventhook;
DROP TABLE IF EXISTS public.eventfilter;
DROP TABLE IF EXISTS public.eventchart_rows;
DROP TABLE IF EXISTS public.eventchart_programindicatordimensions;
DROP TABLE IF EXISTS public.eventchart_periods;
DROP TABLE IF EXISTS public.eventchart_orgunitlevels;
DROP TABLE IF EXISTS public.eventchart_orgunitgroupsetdimensions;
DROP TABLE IF EXISTS public.eventchart_organisationunits;
DROP TABLE IF EXISTS public.eventchart_itemorgunitgroups;
DROP TABLE IF EXISTS public.eventchart_filters;
DROP TABLE IF EXISTS public.eventchart_dataelementdimensions;
DROP TABLE IF EXISTS public.eventchart_columns;
DROP TABLE IF EXISTS public.eventchart_categoryoptiongroupsetdimensions;
DROP TABLE IF EXISTS public.eventchart_categorydimensions;
DROP TABLE IF EXISTS public.eventchart_attributedimensions;
DROP TABLE IF EXISTS public.eventchart;
DROP TABLE IF EXISTS public.event_notes;
DROP TABLE IF EXISTS public.event;
DROP TABLE IF EXISTS public.enrollment_notes;
DROP TABLE IF EXISTS public.enrollment;
DROP TABLE IF EXISTS public.document;
DROP SEQUENCE IF EXISTS public.deletedobject_sequence;
DROP TABLE IF EXISTS public.deletedobject;
DROP SEQUENCE IF EXISTS public.datavalueaudit_sequence;
DROP TABLE IF EXISTS public.datavalueaudit;
DROP TABLE IF EXISTS public.datavalue;
DROP TABLE IF EXISTS public.datastatisticsevent;
DROP TABLE IF EXISTS public.datastatistics;
DROP TABLE IF EXISTS public.datasetsource;
DROP TABLE IF EXISTS public.datasetoperands;
DROP TABLE IF EXISTS public.datasetnotificationtemplate_deliverychannel;
DROP TABLE IF EXISTS public.datasetnotificationtemplate;
DROP TABLE IF EXISTS public.datasetnotification_datasets;
DROP TABLE IF EXISTS public.datasetlegendsets;
DROP TABLE IF EXISTS public.datasetindicators;
DROP TABLE IF EXISTS public.datasetelement;
DROP TABLE IF EXISTS public.dataset;
DROP TABLE IF EXISTS public.datainputperiod;
DROP TABLE IF EXISTS public.dataentryform;
DROP TABLE IF EXISTS public.dataelementoperand;
DROP TABLE IF EXISTS public.dataelementlegendsets;
DROP TABLE IF EXISTS public.dataelementgroupsetmembers;
DROP TABLE IF EXISTS public.dataelementgroupsetdimension_items;
DROP TABLE IF EXISTS public.dataelementgroupsetdimension;
DROP TABLE IF EXISTS public.dataelementgroupset;
DROP TABLE IF EXISTS public.dataelementgroupmembers;
DROP TABLE IF EXISTS public.dataelementgroup;
DROP TABLE IF EXISTS public.dataelementaggregationlevels;
DROP TABLE IF EXISTS public.dataelement;
DROP TABLE IF EXISTS public.datadimensionitem;
DROP TABLE IF EXISTS public.dataapprovalworkflowlevels;
DROP TABLE IF EXISTS public.dataapprovalworkflow;
DROP TABLE IF EXISTS public.dataapprovallevel;
DROP TABLE IF EXISTS public.dataapprovalaudit;
DROP TABLE IF EXISTS public.dataapproval;
DROP TABLE IF EXISTS public.dashboarditem_users;
DROP TABLE IF EXISTS public.dashboarditem_resources;
DROP TABLE IF EXISTS public.dashboarditem_reports;
DROP TABLE IF EXISTS public.dashboarditem;
DROP TABLE IF EXISTS public.dashboard_items;
DROP TABLE IF EXISTS public.dashboard;
DROP TABLE IF EXISTS public.constant;
DROP TABLE IF EXISTS public.configuration_corswhitelist;
DROP TABLE IF EXISTS public.configuration;
DROP TABLE IF EXISTS public.completedatasetregistration;
DROP TABLE IF EXISTS public.categoryoptiongroupsetmembers;
DROP TABLE IF EXISTS public.categoryoptiongroupsetdimension_items;
DROP TABLE IF EXISTS public.categoryoptiongroupsetdimension;
DROP TABLE IF EXISTS public.categoryoptiongroupset;
DROP TABLE IF EXISTS public.categoryoptiongroupmembers;
DROP TABLE IF EXISTS public.categoryoptiongroup;
DROP TABLE IF EXISTS public.categoryoptioncombos_categoryoptions;
DROP TABLE IF EXISTS public.categoryoptioncombo;
DROP TABLE IF EXISTS public.categoryoption_organisationunits;
DROP TABLE IF EXISTS public.categoryoption;
DROP TABLE IF EXISTS public.categorydimension_items;
DROP TABLE IF EXISTS public.categorydimension;
DROP TABLE IF EXISTS public.categorycombos_optioncombos;
DROP TABLE IF EXISTS public.categorycombos_categories;
DROP TABLE IF EXISTS public.categorycombo;
DROP TABLE IF EXISTS public.category;
DROP TABLE IF EXISTS public.categories_categoryoptions;
DROP TABLE IF EXISTS public.axis;
DROP SEQUENCE IF EXISTS public.audit_auditid_seq;
DROP TABLE IF EXISTS public.audit;
DROP TABLE IF EXISTS public.attributevalue;
DROP TABLE IF EXISTS public.attribute;
DROP TABLE IF EXISTS public.api_token;
DROP TABLE IF EXISTS public.aggregatedataexchange;
DROP FUNCTION IF EXISTS public.regexp_search(character varying, character varying);
DROP FUNCTION IF EXISTS public.make_uid_unique(p_table_name text);
DROP FUNCTION IF EXISTS public.jsonb_search_translated_token(jsonb, text, text, text);
DROP FUNCTION IF EXISTS public.jsonb_has_user_id(jsonb, text);
DROP FUNCTION IF EXISTS public.jsonb_has_user_group_ids(jsonb, text);
DROP FUNCTION IF EXISTS public.jsonb_check_user_groups_access(jsonb, text, text);
DROP FUNCTION IF EXISTS public.jsonb_check_user_access(jsonb, text, text);
DROP FUNCTION IF EXISTS public.jsonb_build_array_without_nulls(VARIADIC anyarray);
DROP FUNCTION IF EXISTS public.incrementsequentialcounter(counter_owner text, counter_key text, size integer);
DROP FUNCTION IF EXISTS public.get_tables_with_uid_column();
DROP FUNCTION IF EXISTS public.get_tables_missing_uid_index();
DROP FUNCTION IF EXISTS public.generate_uid();
DROP FUNCTION IF EXISTS public.gen_random_uuid();
DROP FUNCTION IF EXISTS public.create_missing_uid_indexes_all_tables();
DROP FUNCTION IF EXISTS public.alter_uid_not_null_all_tables_missing();
DROP FUNCTION IF EXISTS public.alter_uid_not_null(p_table_name text);
DROP EXTENSION IF EXISTS postgis_topology;
DROP EXTENSION IF EXISTS postgis_tiger_geocoder;
DROP EXTENSION IF EXISTS postgis;
DROP EXTENSION IF EXISTS pg_trgm;
DROP EXTENSION IF EXISTS fuzzystrmatch;
DROP EXTENSION IF EXISTS btree_gin;
DROP SCHEMA IF EXISTS topology;
DROP SCHEMA IF EXISTS tiger_data;
DROP SCHEMA IF EXISTS tiger;
--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA tiger;


--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA tiger_data;


--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA topology;


--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: alter_uid_not_null(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.alter_uid_not_null(p_table_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_sql TEXT;
BEGIN
    -- Update the table
    v_sql := format('UPDATE %I SET uid = generate_uid() WHERE uid IS NULL;', p_table_name);
    EXECUTE v_sql;

    -- Alter the table
    v_sql := format('ALTER TABLE %I ALTER COLUMN uid SET NOT NULL;', p_table_name);
    EXECUTE v_sql;
END;
$$;


--
-- Name: alter_uid_not_null_all_tables_missing(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.alter_uid_not_null_all_tables_missing() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN (
        SELECT * FROM get_tables_missing_uid_index()
    ) LOOP
            -- Check if the table name starts with '_view'
            IF rec.table_name <> 'audit' THEN
                PERFORM alter_uid_not_null(format('%I', rec.table_name));
            END IF;
        END LOOP;
END;
$$;


--
-- Name: create_missing_uid_indexes_all_tables(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_missing_uid_indexes_all_tables() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN (
        SELECT * FROM get_tables_missing_uid_index()
    ) LOOP
            IF rec.table_name <> 'audit' THEN
                PERFORM make_uid_unique(format('%I', rec.table_name));
            END IF;
        END LOOP;
END;
$$;


--
-- Name: gen_random_uuid(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.gen_random_uuid() RETURNS uuid
    LANGUAGE sql
    AS $$
        SELECT md5(random()::text || random()::text)::uuid
    $$;


--
-- Name: generate_uid(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.generate_uid() RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
chars  text [] := '{0,1,2,3,4,5,6,7,8,9,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z}';
 result text := chars [11 + random() * (array_length(chars, 1) - 11)];
begin
 for i in 1..10 loop
 result := result || chars [1 + random() * (array_length(chars, 1) - 1)];
 end loop;
return result;
end;
$$;


--
-- Name: get_tables_missing_uid_index(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_tables_missing_uid_index() RETURNS TABLE(table_schema character varying, table_name character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN (
        SELECT * FROM get_tables_with_uid_column()
    ) LOOP
            IF NOT EXISTS (
                SELECT 1
                FROM pg_indexes
                WHERE
                        schemaname = rec.table_schema
                  AND tablename = rec.table_name
                  AND indexdef LIKE '%(uid)%'
            ) THEN
                table_schema := rec.table_schema;
                table_name := rec.table_name;
                RETURN NEXT;
            END IF;
        END LOOP;
END;
$$;


--
-- Name: get_tables_with_uid_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_tables_with_uid_column() RETURNS TABLE(table_schema character varying, table_name character varying, table_type character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
        SELECT c.table_schema::VARCHAR,
               c.table_name::VARCHAR,
               t.table_type::VARCHAR
        FROM information_schema.columns c
                 INNER JOIN information_schema.tables t
                            ON c.table_schema = t.table_schema
                                AND c.table_name = t.table_name
        WHERE c.column_name = 'uid'
          AND t.table_type = 'BASE TABLE'
        GROUP BY c.table_schema,
                 c.table_name,
                 t.table_type;
END;
$$;


--
-- Name: incrementsequentialcounter(text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.incrementsequentialcounter(counter_owner text, counter_key text, size integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
	DECLARE
		current_counter integer;
	BEGIN
        INSERT INTO sequentialnumbercounter  (id, owneruid, key, counter)
        VALUES(nextval('hibernate_sequence'), counter_owner, counter_key, (1 + size) )

        ON CONFLICT (owneruid, key)
            DO
                UPDATE SET counter = (sequentialnumbercounter.counter + size)
                WHERE sequentialnumbercounter.owneruid = counter_owner
                AND sequentialnumbercounter.key = counter_key

        RETURNING counter INTO current_counter;

        RETURN current_counter;

	END;
$$;


--
-- Name: jsonb_build_array_without_nulls(anyarray); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.jsonb_build_array_without_nulls(VARIADIC anyarray) RETURNS jsonb
    LANGUAGE sql IMMUTABLE
    AS $_$
select jsonb_agg(elem)
from unnest($1) as elem
where elem is not null
$_$;


--
-- Name: jsonb_check_user_access(jsonb, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.jsonb_check_user_access(jsonb, text, text) RETURNS boolean
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $_$
select  $1->'users'->$2->>'access' like $3
$_$;


--
-- Name: jsonb_check_user_groups_access(jsonb, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.jsonb_check_user_groups_access(jsonb, text, text) RETURNS boolean
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $_$
SELECT exists(
         SELECT 1
         FROM  jsonb_each($1->'userGroups') je
         WHERE je.key = ANY ($3::text[])
         AND je.value->>'access' LIKE $2
     );
$_$;


--
-- Name: jsonb_has_user_group_ids(jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.jsonb_has_user_group_ids(jsonb, text) RETURNS boolean
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $_$
SELECT   $1->'userGroups' ?| $2::text[];
$_$;


--
-- Name: jsonb_has_user_id(jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.jsonb_has_user_id(jsonb, text) RETURNS boolean
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $_$
select  $1->'users' ? $2
$_$;


--
-- Name: jsonb_search_translated_token(jsonb, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.jsonb_search_translated_token(jsonb, text, text, text) RETURNS boolean
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $_$
SELECT exists(
    SELECT 1
    FROM  jsonb_array_elements($1) trans
    WHERE trans->>'property' = ANY ($2::text[])
         AND trans->>'locale' = $3
         AND trans->>'value' ~* $4
);
$_$;


--
-- Name: make_uid_unique(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.make_uid_unique(p_table_name text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    duplicate_count INTEGER;
BEGIN
    EXECUTE format('SELECT COUNT(*) FROM (SELECT uid FROM %I GROUP BY uid HAVING COUNT(*) > 1) AS duplicates', p_table_name)
        INTO duplicate_count;

    IF duplicate_count = 0 THEN
        EXECUTE format('DROP INDEX IF EXISTS uk_%I_uid', p_table_name);
        EXECUTE format('CREATE UNIQUE INDEX uk_%I_uid ON %I (uid)', p_table_name, p_table_name);
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END;
$$;


--
-- Name: regexp_search(character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.regexp_search(character varying, character varying) RETURNS boolean
    LANGUAGE sql
    AS $_$select $1 ~* $2;$_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aggregatedataexchange; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aggregatedataexchange (
    aggregatedataexchangeid bigint NOT NULL,
    uid character varying(11),
    code character varying(100),
    created timestamp without time zone,
    userid bigint,
    lastupdated timestamp without time zone,
    lastupdatedby bigint,
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    name character varying(230) NOT NULL,
    source jsonb NOT NULL,
    target jsonb NOT NULL
);


--
-- Name: api_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_token (
    apitokenid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint NOT NULL,
    createdby bigint NOT NULL,
    version integer NOT NULL,
    type character varying(50) NOT NULL,
    expire bigint NOT NULL,
    key character varying(128) NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attribute (
    attributeid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50),
    description text,
    valuetype character varying(50) NOT NULL,
    mandatory boolean NOT NULL,
    isunique boolean,
    sortorder integer,
    optionsetid bigint,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    objecttypes jsonb NOT NULL
);


--
-- Name: attributevalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attributevalue (
    attributevalueid bigint NOT NULL,
    created timestamp without time zone,
    lastupdated timestamp without time zone,
    value text,
    attributeid bigint NOT NULL
);


--
-- Name: audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit (
    auditid integer NOT NULL,
    audittype text NOT NULL,
    auditscope text NOT NULL,
    createdat timestamp without time zone NOT NULL,
    createdby text NOT NULL,
    klass text,
    uid text,
    code text,
    attributes jsonb DEFAULT '{}'::jsonb,
    data bytea
);


--
-- Name: audit_auditid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_auditid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_auditid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_auditid_seq OWNED BY public.audit.auditid;


--
-- Name: axis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.axis (
    axisid bigint NOT NULL,
    dimensionalitem character varying(255) NOT NULL,
    axis integer NOT NULL
);


--
-- Name: categories_categoryoptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories_categoryoptions (
    categoryid bigint NOT NULL,
    sort_order integer NOT NULL,
    categoryoptionid bigint NOT NULL
);


--
-- Name: category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.category (
    categoryid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    datadimensiontype character varying(255) NOT NULL,
    datadimension boolean NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    shortname character varying(50) NOT NULL,
    description text
);


--
-- Name: categorycombo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorycombo (
    categorycomboid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    datadimensiontype character varying(255) NOT NULL,
    skiptotal boolean NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: categorycombos_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorycombos_categories (
    categoryid bigint,
    sort_order integer NOT NULL,
    categorycomboid bigint NOT NULL
);


--
-- Name: categorycombos_optioncombos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorycombos_optioncombos (
    categoryoptioncomboid bigint NOT NULL,
    categorycomboid bigint NOT NULL
);


--
-- Name: categorydimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorydimension (
    categorydimensionid integer NOT NULL,
    categoryid bigint
);


--
-- Name: categorydimension_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorydimension_items (
    categorydimensionid integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptionid bigint NOT NULL
);


--
-- Name: categoryoption; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoption (
    categoryoptionid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    startdate date,
    enddate date,
    style jsonb,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    formname character varying(230),
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    description text
);


--
-- Name: categoryoption_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoption_organisationunits (
    organisationunitid bigint NOT NULL,
    categoryoptionid bigint NOT NULL
);


--
-- Name: categoryoptioncombo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptioncombo (
    categoryoptioncomboid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name text,
    ignoreapproval boolean,
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb
);


--
-- Name: categoryoptioncombos_categoryoptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptioncombos_categoryoptions (
    categoryoptioncomboid bigint NOT NULL,
    categoryoptionid bigint NOT NULL
);


--
-- Name: categoryoptiongroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroup (
    categoryoptiongroupid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    datadimensiontype character varying(255),
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    description text
);


--
-- Name: categoryoptiongroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupmembers (
    categoryoptiongroupid bigint NOT NULL,
    categoryoptionid bigint NOT NULL
);


--
-- Name: categoryoptiongroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupset (
    categoryoptiongroupsetid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    datadimension boolean NOT NULL,
    datadimensiontype character varying(255),
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    shortname character varying(50) NOT NULL
);


--
-- Name: categoryoptiongroupsetdimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupsetdimension (
    categoryoptiongroupsetdimensionid integer NOT NULL,
    categoryoptiongroupsetid bigint
);


--
-- Name: categoryoptiongroupsetdimension_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupsetdimension_items (
    categoryoptiongroupsetdimensionid integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupid bigint NOT NULL
);


--
-- Name: categoryoptiongroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupsetmembers (
    categoryoptiongroupid bigint,
    categoryoptiongroupsetid bigint NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: completedatasetregistration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.completedatasetregistration (
    datasetid bigint NOT NULL,
    periodid bigint NOT NULL,
    sourceid bigint NOT NULL,
    attributeoptioncomboid bigint NOT NULL,
    date timestamp without time zone,
    storedby character varying(255),
    lastupdatedby character varying(255),
    lastupdated timestamp without time zone,
    completed boolean NOT NULL
);


--
-- Name: configuration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.configuration (
    configurationid integer NOT NULL,
    systemid character varying(255),
    feedbackrecipientsid bigint,
    offlineorgunitlevelid bigint,
    infrastructuralindicatorsid bigint,
    infrastructuraldataelementsid bigint,
    infrastructuralperiodtypeid integer,
    selfregistrationrole bigint,
    selfregistrationorgunit bigint,
    facilityorgunitgroupset bigint,
    facilityorgunitlevel bigint,
    systemupdatenotificationrecipientsid bigint
);


--
-- Name: configuration_corswhitelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.configuration_corswhitelist (
    configurationid integer NOT NULL,
    corswhitelist character varying(255)
);

ALTER TABLE ONLY public.configuration_corswhitelist REPLICA IDENTITY FULL;


--
-- Name: constant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.constant (
    constantid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    value double precision NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: dashboard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard (
    dashboardid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    userid bigint,
    externalaccess boolean,
    publicaccess character varying(8),
    favorites jsonb,
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    restrictfilters boolean NOT NULL,
    allowedfilters jsonb,
    layout jsonb,
    itemconfig jsonb
);


--
-- Name: dashboard_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_items (
    dashboardid bigint NOT NULL,
    sort_order integer NOT NULL,
    dashboarditemid bigint NOT NULL
);


--
-- Name: dashboarditem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarditem (
    dashboarditemid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    eventchartid bigint,
    mapid bigint,
    textcontent text,
    messages boolean,
    appkey character varying(255),
    shape character varying(50),
    x integer,
    y integer,
    height integer,
    width integer,
    eventreport bigint,
    translations jsonb,
    visualizationid bigint,
    eventvisualizationid bigint
);


--
-- Name: dashboarditem_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarditem_reports (
    dashboarditemid bigint NOT NULL,
    sort_order integer NOT NULL,
    reportid bigint NOT NULL
);


--
-- Name: dashboarditem_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarditem_resources (
    dashboarditemid bigint NOT NULL,
    sort_order integer NOT NULL,
    resourceid bigint NOT NULL
);


--
-- Name: dashboarditem_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarditem_users (
    dashboarditemid bigint NOT NULL,
    sort_order integer NOT NULL,
    userid bigint NOT NULL
);


--
-- Name: dataapproval; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapproval (
    dataapprovalid bigint NOT NULL,
    dataapprovallevelid bigint NOT NULL,
    workflowid bigint NOT NULL,
    periodid bigint NOT NULL,
    organisationunitid bigint NOT NULL,
    attributeoptioncomboid bigint NOT NULL,
    accepted boolean NOT NULL,
    created timestamp without time zone NOT NULL,
    creator bigint NOT NULL,
    lastupdated timestamp without time zone,
    lastupdatedby bigint
);


--
-- Name: dataapprovalaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalaudit (
    dataapprovalauditid bigint NOT NULL,
    levelid bigint NOT NULL,
    workflowid bigint NOT NULL,
    periodid bigint NOT NULL,
    organisationunitid bigint NOT NULL,
    attributeoptioncomboid bigint NOT NULL,
    action character varying(100) NOT NULL,
    created timestamp without time zone NOT NULL,
    creator bigint NOT NULL
);


--
-- Name: dataapprovallevel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovallevel (
    dataapprovallevelid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    level integer NOT NULL,
    orgunitlevel integer NOT NULL,
    categoryoptiongroupsetid bigint,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: dataapprovalworkflow; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalworkflow (
    workflowid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    periodtypeid integer NOT NULL,
    categorycomboid bigint,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: dataapprovalworkflowlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalworkflowlevels (
    workflowid bigint NOT NULL,
    dataapprovallevelid bigint NOT NULL
);


--
-- Name: datadimensionitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datadimensionitem (
    datadimensionitemid integer NOT NULL,
    indicatorid bigint,
    dataelementid bigint,
    dataelementoperand_dataelementid bigint,
    dataelementoperand_categoryoptioncomboid bigint,
    datasetid bigint,
    metric character varying(50),
    programindicatorid bigint,
    programdataelement_programid bigint,
    programdataelement_dataelementid bigint,
    programattribute_programid bigint,
    programattribute_attributeid bigint,
    expressiondimensionitemid bigint
);


--
-- Name: dataelement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelement (
    dataelementid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname character varying(230),
    style jsonb,
    valuetype character varying(50) NOT NULL,
    domaintype character varying(255) NOT NULL,
    aggregationtype character varying(50) NOT NULL,
    categorycomboid bigint NOT NULL,
    url character varying(255),
    zeroissignificant boolean NOT NULL,
    optionsetid bigint,
    commentoptionsetid bigint,
    userid bigint,
    publicaccess character varying(8),
    fieldmask character varying(255),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    valuetypeoptions jsonb
);


--
-- Name: dataelementaggregationlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementaggregationlevels (
    dataelementid bigint NOT NULL,
    sort_order integer NOT NULL,
    aggregationlevel integer
);


--
-- Name: dataelementgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroup (
    dataelementgroupid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    description text,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: dataelementgroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupmembers (
    dataelementid bigint NOT NULL,
    dataelementgroupid bigint NOT NULL
);


--
-- Name: dataelementgroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupset (
    dataelementgroupsetid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    compulsory boolean,
    datadimension boolean NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    shortname character varying(50) NOT NULL
);


--
-- Name: dataelementgroupsetdimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupsetdimension (
    dataelementgroupsetdimensionid integer NOT NULL,
    dataelementgroupsetid bigint
);


--
-- Name: dataelementgroupsetdimension_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupsetdimension_items (
    dataelementgroupsetdimensionid integer NOT NULL,
    sort_order integer NOT NULL,
    dataelementgroupid bigint NOT NULL
);


--
-- Name: dataelementgroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupsetmembers (
    dataelementgroupsetid bigint NOT NULL,
    sort_order integer NOT NULL,
    dataelementgroupid bigint NOT NULL
);


--
-- Name: dataelementlegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementlegendsets (
    dataelementid bigint NOT NULL,
    sort_order integer NOT NULL,
    legendsetid bigint NOT NULL
);


--
-- Name: dataelementoperand; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementoperand (
    dataelementoperandid bigint NOT NULL,
    dataelementid bigint,
    categoryoptioncomboid bigint
);


--
-- Name: dataentryform; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataentryform (
    dataentryformid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(160) NOT NULL,
    style character varying(40),
    htmlcode text,
    format integer,
    translations jsonb
);


--
-- Name: datainputperiod; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datainputperiod (
    datainputperiodid integer NOT NULL,
    periodid bigint NOT NULL,
    openingdate timestamp without time zone,
    closingdate timestamp without time zone,
    datasetid bigint
);


--
-- Name: dataset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataset (
    datasetid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname text,
    style jsonb,
    periodtypeid integer NOT NULL,
    categorycomboid bigint NOT NULL,
    mobile boolean NOT NULL,
    version integer,
    expirydays integer,
    timelydays double precision,
    notifycompletinguser boolean,
    workflowid bigint,
    openfutureperiods integer,
    fieldcombinationrequired boolean,
    validcompleteonly boolean,
    novaluerequirescomment boolean,
    skipoffline boolean,
    dataelementdecoration boolean,
    renderastabs boolean,
    renderhorizontally boolean,
    compulsoryfieldscompleteonly boolean,
    userid bigint,
    publicaccess character varying(8),
    dataentryform bigint,
    notificationrecipients bigint,
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    openperiodsaftercoenddate integer DEFAULT 0,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: datasetelement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetelement (
    datasetelementid integer NOT NULL,
    datasetid bigint,
    dataelementid bigint NOT NULL,
    categorycomboid bigint
);


--
-- Name: datasetindicators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetindicators (
    indicatorid bigint NOT NULL,
    datasetid bigint NOT NULL
);


--
-- Name: datasetlegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetlegendsets (
    datasetid bigint NOT NULL,
    sort_order integer NOT NULL,
    legendsetid bigint NOT NULL
);


--
-- Name: datasetnotification_datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetnotification_datasets (
    datasetnotificationtemplateid bigint NOT NULL,
    datasetid bigint NOT NULL
);


--
-- Name: datasetnotificationtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetnotificationtemplate (
    datasetnotificationtemplateid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    subjecttemplate character varying(100),
    messagetemplate text NOT NULL,
    relativescheduleddays integer,
    notifyparentorganisationunitonly boolean,
    notifyusersinhierarchyonly boolean,
    sendstrategy character varying(50),
    usergroupid bigint,
    datasetnotificationtrigger character varying(255),
    notificationrecipienttype character varying(255),
    translations jsonb DEFAULT '[]'::jsonb
);


--
-- Name: datasetnotificationtemplate_deliverychannel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetnotificationtemplate_deliverychannel (
    datasetnotificationtemplateid bigint NOT NULL,
    deliverychannel character varying(255)
);

ALTER TABLE ONLY public.datasetnotificationtemplate_deliverychannel REPLICA IDENTITY FULL;


--
-- Name: datasetoperands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetoperands (
    datasetid bigint NOT NULL,
    dataelementoperandid bigint NOT NULL
);


--
-- Name: datasetsource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetsource (
    sourceid bigint NOT NULL,
    datasetid bigint NOT NULL
);


--
-- Name: datastatistics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datastatistics (
    statisticsid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    mapviews double precision,
    eventreportviews double precision,
    eventchartviews double precision,
    dashboardviews double precision,
    datasetreportviews double precision,
    active_users integer,
    totalviews double precision,
    maps double precision,
    eventreports double precision,
    eventcharts double precision,
    dashboards double precision,
    indicators double precision,
    datavalues double precision,
    users integer,
    visualizationviews double precision,
    visualizations double precision,
    passivedashboardviews double precision,
    eventvisualizationviews double precision,
    eventvisualizations double precision
);


--
-- Name: datastatisticsevent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datastatisticsevent (
    eventid integer NOT NULL,
    eventtype character varying,
    "timestamp" timestamp without time zone,
    username character varying(255),
    favoriteuid character varying(255)
);


--
-- Name: datavalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datavalue (
    dataelementid bigint NOT NULL,
    periodid bigint NOT NULL,
    sourceid bigint NOT NULL,
    categoryoptioncomboid bigint NOT NULL,
    attributeoptioncomboid bigint NOT NULL,
    value character varying(50000),
    storedby character varying(255),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    comment character varying(50000),
    followup boolean,
    deleted boolean NOT NULL
);


--
-- Name: datavalueaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datavalueaudit (
    datavalueauditid bigint NOT NULL,
    dataelementid bigint NOT NULL,
    periodid bigint NOT NULL,
    organisationunitid bigint NOT NULL,
    categoryoptioncomboid bigint NOT NULL,
    attributeoptioncomboid bigint NOT NULL,
    value character varying(50000),
    created timestamp without time zone,
    modifiedby character varying(100),
    audittype character varying(100) NOT NULL
);


--
-- Name: datavalueaudit_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.datavalueaudit_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deletedobject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deletedobject (
    deletedobjectid bigint NOT NULL,
    klass character varying(255) NOT NULL,
    uid character varying(255) NOT NULL,
    code character varying(255),
    deleted_at timestamp without time zone NOT NULL,
    deleted_by character varying(255)
);


--
-- Name: deletedobject_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deletedobject_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    documentid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    url text NOT NULL,
    fileresource bigint,
    external boolean NOT NULL,
    contenttype character varying(255),
    attachment boolean,
    externalaccess boolean,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: enrollment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enrollment (
    enrollmentid bigint NOT NULL,
    uid character varying(11),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    createdatclient timestamp without time zone,
    lastupdatedatclient timestamp without time zone,
    occurreddate timestamp without time zone,
    enrollmentdate timestamp without time zone NOT NULL,
    completeddate timestamp without time zone,
    followup boolean,
    completedby character varying(255),
    deleted boolean NOT NULL,
    storedby character varying(255),
    status character varying(50),
    trackedentityid bigint,
    programid bigint NOT NULL,
    organisationunitid bigint,
    geometry public.geometry,
    createdbyuserinfo jsonb,
    lastupdatedbyuserinfo jsonb
);


--
-- Name: enrollment_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enrollment_notes (
    enrollmentid bigint NOT NULL,
    sort_order integer NOT NULL,
    noteid bigint NOT NULL
);


--
-- Name: event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event (
    eventid bigint NOT NULL,
    uid character varying(11),
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    createdatclient timestamp without time zone,
    lastupdatedatclient timestamp without time zone,
    lastsynchronized timestamp without time zone DEFAULT to_timestamp((0)::double precision) NOT NULL,
    enrollmentid bigint NOT NULL,
    programstageid bigint NOT NULL,
    attributeoptioncomboid bigint,
    deleted boolean NOT NULL,
    storedby character varying(255),
    scheduleddate timestamp without time zone,
    occurreddate timestamp without time zone,
    organisationunitid bigint,
    status character varying(25) NOT NULL,
    completedby character varying(255),
    completeddate timestamp without time zone,
    geometry public.geometry,
    eventdatavalues jsonb DEFAULT '{}'::jsonb NOT NULL,
    assigneduserid bigint,
    createdbyuserinfo jsonb,
    lastupdatedbyuserinfo jsonb
);


--
-- Name: event_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_notes (
    eventid bigint NOT NULL,
    sort_order integer NOT NULL,
    noteid bigint NOT NULL
);


--
-- Name: eventchart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart (
    eventchartid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    relativeperiodsid integer,
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    programid bigint NOT NULL,
    programstageid bigint,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    dataelementvaluedimensionid bigint,
    attributevaluedimensionid bigint,
    aggregationtype character varying(40),
    completedonly boolean,
    timefield character varying(255),
    title character varying(255),
    subtitle character varying(255),
    hidetitle boolean,
    hidesubtitle boolean,
    type character varying(40) NOT NULL,
    showdata boolean,
    hideemptyrowitems character varying(40),
    hidenadata boolean,
    programstatus character varying(40),
    eventstatus character varying(40),
    percentstackedvalues boolean,
    cumulativevalues boolean,
    rangeaxismaxvalue double precision,
    rangeaxisminvalue double precision,
    rangeaxissteps integer,
    rangeaxisdecimals integer,
    outputtype character varying(30),
    collapsedatadimensions boolean,
    domainaxislabel character varying(255),
    rangeaxislabel character varying(255),
    hidelegend boolean,
    nospacebetweencolumns boolean,
    regressiontype character varying(40) NOT NULL,
    targetlinevalue double precision,
    targetlinelabel character varying(255),
    baselinevalue double precision,
    baselinelabel character varying(255),
    sortorder integer,
    externalaccess boolean,
    userid bigint,
    publicaccess character varying(8),
    favorites jsonb,
    subscribers jsonb,
    translations jsonb,
    orgunitfield character varying(255),
    userorgunittype character varying(20),
    sharing jsonb DEFAULT '{}'::jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb
);


--
-- Name: eventchart_attributedimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_attributedimensions (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    trackedentityattributedimensionid integer NOT NULL
);


--
-- Name: eventchart_categorydimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_categorydimensions (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    categorydimensionid integer NOT NULL
);


--
-- Name: eventchart_categoryoptiongroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_categoryoptiongroupsetdimensions (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupsetdimensionid integer NOT NULL
);


--
-- Name: eventchart_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_columns (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventchart_dataelementdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_dataelementdimensions (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    trackedentitydataelementdimensionid integer NOT NULL
);


--
-- Name: eventchart_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_filters (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventchart_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_itemorgunitgroups (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid bigint NOT NULL
);


--
-- Name: eventchart_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_organisationunits (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    organisationunitid bigint NOT NULL
);


--
-- Name: eventchart_orgunitgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_orgunitgroupsetdimensions (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupsetdimensionid integer NOT NULL
);


--
-- Name: eventchart_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_orgunitlevels (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitlevel integer
);


--
-- Name: eventchart_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_periods (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    periodid bigint NOT NULL
);


--
-- Name: eventchart_programindicatordimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_programindicatordimensions (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    trackedentityprogramindicatordimensionid integer NOT NULL
);


--
-- Name: eventchart_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_rows (
    eventchartid bigint NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventfilter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventfilter (
    eventfilterid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description character varying(255),
    program character varying(11) NOT NULL,
    programstage character varying(11),
    eventquerycriteria jsonb,
    userid bigint,
    publicaccess character varying(8),
    sharing jsonb DEFAULT '{}'::jsonb,
    translations jsonb
);


--
-- Name: eventhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventhook (
    eventhookid bigint NOT NULL,
    uid character varying(11),
    code character varying(100),
    disabled boolean NOT NULL,
    created timestamp without time zone,
    userid bigint,
    lastupdated timestamp without time zone,
    lastupdatedby bigint,
    description text,
    translations jsonb DEFAULT '[]'::jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    name character varying(230) NOT NULL,
    source jsonb DEFAULT '{}'::jsonb,
    targets jsonb DEFAULT '[]'::jsonb
);


--
-- Name: eventreport; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport (
    eventreportid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    relativeperiodsid integer,
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    programid bigint NOT NULL,
    programstageid bigint,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    dataelementvaluedimensionid bigint,
    attributevaluedimensionid bigint,
    aggregationtype character varying(40),
    completedonly boolean,
    timefield character varying(255),
    title character varying(255),
    subtitle character varying(255),
    hidetitle boolean,
    hidesubtitle boolean,
    datatype character varying(40),
    rowtotals boolean,
    coltotals boolean,
    rowsubtotals boolean,
    colsubtotals boolean,
    hideemptyrows boolean,
    hidenadata boolean,
    showhierarchy boolean,
    outputtype character varying(30),
    collapsedatadimensions boolean,
    showdimensionlabels boolean,
    digitgroupseparator character varying(40),
    displaydensity character varying(40),
    fontsize character varying(40),
    programstatus character varying(40),
    eventstatus character varying(40),
    sortorder integer,
    toplimit integer,
    externalaccess boolean,
    userid bigint,
    publicaccess character varying(8),
    favorites jsonb,
    subscribers jsonb,
    translations jsonb,
    orgunitfield character varying(255),
    userorgunittype character varying(20),
    sharing jsonb DEFAULT '{}'::jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    simpledimensions jsonb
);


--
-- Name: eventreport_attributedimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_attributedimensions (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    trackedentityattributedimensionid integer NOT NULL
);


--
-- Name: eventreport_categorydimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_categorydimensions (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    categorydimensionid integer NOT NULL
);


--
-- Name: eventreport_categoryoptiongroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_categoryoptiongroupsetdimensions (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupsetdimensionid integer NOT NULL
);


--
-- Name: eventreport_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_columns (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventreport_dataelementdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_dataelementdimensions (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    trackedentitydataelementdimensionid integer NOT NULL
);


--
-- Name: eventreport_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_filters (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventreport_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_itemorgunitgroups (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid bigint NOT NULL
);


--
-- Name: eventreport_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_organisationunits (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    organisationunitid bigint NOT NULL
);


--
-- Name: eventreport_orgunitgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_orgunitgroupsetdimensions (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupsetdimensionid integer NOT NULL
);


--
-- Name: eventreport_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_orgunitlevels (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitlevel integer
);


--
-- Name: eventreport_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_periods (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    periodid bigint NOT NULL
);


--
-- Name: eventreport_programindicatordimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_programindicatordimensions (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    trackedentityprogramindicatordimensionid integer NOT NULL
);


--
-- Name: eventreport_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_rows (
    eventreportid bigint NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventvisualization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization (
    eventvisualizationid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone,
    lastupdated timestamp without time zone,
    name character varying(230) NOT NULL,
    relativeperiodsid integer,
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    externalaccess boolean,
    userid bigint,
    publicaccess character varying(8),
    programid bigint,
    programstageid bigint,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    sortorder integer,
    toplimit integer,
    outputtype character varying(30),
    dataelementvaluedimensionid bigint,
    attributevaluedimensionid bigint,
    aggregationtype character varying(30),
    collapsedatadimensions boolean,
    hidenadata boolean,
    completedonly boolean,
    description text,
    title character varying(255),
    lastupdatedby bigint,
    subtitle character varying(255),
    hidetitle boolean,
    hidesubtitle boolean,
    programstatus character varying(40),
    eventstatus character varying(40),
    favorites jsonb,
    subscribers jsonb,
    timefield character varying(255),
    translations jsonb,
    orgunitfield character varying(255),
    userorgunittype character varying(20),
    sharing jsonb DEFAULT '{}'::jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    type character varying(255) NOT NULL,
    showdata boolean,
    rangeaxismaxvalue double precision,
    rangeaxisminvalue double precision,
    rangeaxissteps integer,
    rangeaxisdecimals integer,
    domainaxislabel character varying(255),
    rangeaxislabel character varying(255),
    hidelegend boolean,
    targetlinevalue double precision,
    targetlinelabel character varying(255),
    baselinevalue double precision,
    baselinelabel character varying(255),
    regressiontype character varying(40),
    hideemptyrowitems character varying(40),
    percentstackedvalues boolean,
    cumulativevalues boolean,
    nospacebetweencolumns boolean,
    datatype character varying(230),
    hideemptyrows boolean,
    digitgroupseparator character varying(255),
    displaydensity character varying(255),
    fontsize character varying(255),
    showhierarchy boolean,
    rowtotals boolean,
    coltotals boolean,
    showdimensionlabels boolean,
    rowsubtotals boolean,
    colsubtotals boolean,
    legacy boolean,
    simpledimensions jsonb,
    eventrepetitions jsonb,
    legendsetid bigint,
    legenddisplaystrategy character varying(40),
    legenddisplaystyle character varying(40),
    legendshowkey boolean,
    sorting jsonb DEFAULT '[]'::jsonb,
    skiprounding boolean DEFAULT false NOT NULL,
    trackedentitytypeid bigint,
    relativeperiods jsonb
);


--
-- Name: eventvisualization_attributedimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_attributedimensions (
    eventvisualizationid bigint NOT NULL,
    trackedentityattributedimensionid integer NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: eventvisualization_categorydimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_categorydimensions (
    eventvisualizationid bigint NOT NULL,
    sort_order integer NOT NULL,
    categorydimensionid integer NOT NULL
);


--
-- Name: eventvisualization_categoryoptiongroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_categoryoptiongroupsetdimensions (
    eventvisualizationid bigint NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupsetdimensionid integer NOT NULL
);


--
-- Name: eventvisualization_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_columns (
    eventvisualizationid bigint NOT NULL,
    dimension character varying(255),
    sort_order integer NOT NULL
);


--
-- Name: eventvisualization_dataelementdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_dataelementdimensions (
    eventvisualizationid bigint NOT NULL,
    trackedentitydataelementdimensionid integer NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: eventvisualization_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_filters (
    eventvisualizationid bigint NOT NULL,
    dimension character varying(255),
    sort_order integer NOT NULL
);


--
-- Name: eventvisualization_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_itemorgunitgroups (
    eventvisualizationid bigint NOT NULL,
    orgunitgroupid bigint NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: eventvisualization_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_organisationunits (
    eventvisualizationid bigint NOT NULL,
    organisationunitid bigint NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: eventvisualization_orgunitgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_orgunitgroupsetdimensions (
    eventvisualizationid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupsetdimensionid integer NOT NULL
);


--
-- Name: eventvisualization_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_orgunitlevels (
    eventvisualizationid bigint NOT NULL,
    orgunitlevel integer,
    sort_order integer NOT NULL
);


--
-- Name: eventvisualization_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_periods (
    eventvisualizationid bigint NOT NULL,
    periodid bigint NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: eventvisualization_programindicatordimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_programindicatordimensions (
    eventvisualizationid bigint NOT NULL,
    trackedentityprogramindicatordimensionid integer NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: eventvisualization_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventvisualization_rows (
    eventvisualizationid bigint NOT NULL,
    dimension character varying(255),
    sort_order integer NOT NULL
);


--
-- Name: expression; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expression (
    expressionid bigint NOT NULL,
    description character varying(255),
    expression text,
    slidingwindow boolean,
    missingvaluestrategy character varying(100) NOT NULL,
    translations jsonb DEFAULT '[]'::jsonb
);


--
-- Name: expressiondimensionitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expressiondimensionitem (
    expressiondimensionitemid bigint NOT NULL,
    code character varying(50),
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    formname character varying(230),
    expression text,
    description text,
    missingvaluestrategy character varying(255) NOT NULL,
    slidingwindow boolean,
    lastupdated timestamp without time zone,
    uid character varying(11),
    created timestamp without time zone,
    userid bigint,
    publicaccess character varying(8),
    lastupdatedby bigint,
    translations jsonb DEFAULT '[]'::jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: externalfileresource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.externalfileresource (
    externalfileresourceid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    accesstoken character varying(255),
    expires timestamp without time zone,
    fileresourceid bigint NOT NULL
);


--
-- Name: externalmaplayer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.externalmaplayer (
    externalmaplayerid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    attribution text,
    url text NOT NULL,
    legendseturl text,
    maplayerposition bytea NOT NULL,
    layers text,
    imageformat bytea NOT NULL,
    mapservice bytea NOT NULL,
    legendsetid bigint,
    userid bigint,
    publicaccess character varying(8),
    sharing jsonb DEFAULT '{}'::jsonb,
    translations jsonb DEFAULT '[]'::jsonb
);


--
-- Name: externalnotificationlogentry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.externalnotificationlogentry (
    externalnotificationlogentryid bigint NOT NULL,
    uid character varying(11),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastsentat timestamp without time zone,
    retries integer,
    key text NOT NULL,
    templateuid text NOT NULL,
    allowmultiple boolean,
    triggerby character varying(255)
);


--
-- Name: fileresource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fileresource (
    fileresourceid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    contenttype character varying(255) NOT NULL,
    contentlength bigint NOT NULL,
    contentmd5 character varying(32) NOT NULL,
    storagekey character varying(1024) NOT NULL,
    isassigned boolean NOT NULL,
    domain character varying(40),
    userid bigint,
    hasmultiplestoragefiles boolean,
    fileresourceowner character varying(255)
);


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: i18nlocale; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.i18nlocale (
    i18nlocaleid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(250) NOT NULL,
    locale character varying(15) NOT NULL
);


--
-- Name: icon; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.icon (
    iconkey character varying(100) NOT NULL,
    fileresourceid bigint NOT NULL,
    description text,
    keywords jsonb,
    created timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lastupdated timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    createdby bigint,
    custom boolean NOT NULL
);


--
-- Name: incomingsms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incomingsms (
    id bigint NOT NULL,
    originator character varying(255) NOT NULL,
    encoding integer NOT NULL,
    sentdate timestamp without time zone NOT NULL,
    receiveddate timestamp without time zone NOT NULL,
    text character varying(255),
    gatewayid character varying(255) NOT NULL,
    status integer NOT NULL,
    parsed boolean,
    statusmessage character varying(255),
    userid bigint,
    uid character varying(255) NOT NULL
);


--
-- Name: indicator; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicator (
    indicatorid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname text,
    annualized boolean NOT NULL,
    decimals integer,
    indicatortypeid bigint NOT NULL,
    numerator text NOT NULL,
    numeratordescription text,
    denominator text NOT NULL,
    denominatordescription text,
    url character varying(255),
    style jsonb,
    aggregateexportcategoryoptioncombo character varying(255),
    aggregateexportattributeoptioncombo character varying(255),
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: indicatorgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroup (
    indicatorgroupid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    description text,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: indicatorgroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupmembers (
    indicatorid bigint NOT NULL,
    indicatorgroupid bigint NOT NULL
);


--
-- Name: indicatorgroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupset (
    indicatorgroupsetid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    compulsory boolean,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    shortname character varying(50) NOT NULL
);


--
-- Name: indicatorgroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupsetmembers (
    indicatorgroupid bigint NOT NULL,
    indicatorgroupsetid bigint NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: indicatorlegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorlegendsets (
    indicatorid bigint NOT NULL,
    sort_order integer NOT NULL,
    legendsetid bigint NOT NULL
);


--
-- Name: indicatortype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatortype (
    indicatortypeid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    indicatorfactor integer NOT NULL,
    indicatornumber boolean,
    translations jsonb
);


--
-- Name: intepretation_likedby; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.intepretation_likedby (
    interpretationid bigint NOT NULL,
    userid bigint NOT NULL
);


--
-- Name: interpretation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interpretation (
    interpretationid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    mapid bigint,
    eventreportid bigint,
    eventchartid bigint,
    datasetid bigint,
    periodid bigint,
    organisationunitid bigint,
    interpretationtext text,
    created timestamp without time zone NOT NULL,
    likes integer,
    userid bigint,
    publicaccess character varying(8),
    mentions jsonb,
    visualizationid bigint,
    sharing jsonb DEFAULT '{}'::jsonb,
    eventvisualizationid bigint
);


--
-- Name: interpretation_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interpretation_comments (
    interpretationid bigint NOT NULL,
    sort_order integer NOT NULL,
    interpretationcommentid bigint NOT NULL
);


--
-- Name: interpretationcomment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interpretationcomment (
    interpretationcommentid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    commenttext text,
    mentions jsonb,
    userid bigint NOT NULL,
    created timestamp without time zone NOT NULL
);


--
-- Name: jobconfiguration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobconfiguration (
    jobconfigurationid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    cronexpression character varying(255),
    lastexecuted timestamp without time zone,
    enabled boolean NOT NULL,
    jsonbjobparameters jsonb,
    jobtype character varying(120) NOT NULL,
    jobstatus character varying(120) NOT NULL,
    lastexecutedstatus character varying(120) NOT NULL,
    delay integer,
    queuename character varying(50),
    queueposition integer,
    executedby character varying(11),
    schedulingtype character varying(12) DEFAULT 'ONCE_ASAP'::character varying NOT NULL,
    lastalive timestamp without time zone,
    lastfinished timestamp without time zone,
    cancel boolean DEFAULT false NOT NULL,
    progress jsonb,
    errorcodes text
);


--
-- Name: keyjsonvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keyjsonvalue (
    keyjsonvalueid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    namespace character varying(255) NOT NULL,
    namespacekey character varying(255) NOT NULL,
    encrypted_value character varying(255),
    encrypted boolean,
    userid bigint,
    publicaccess character varying(8),
    jbvalue jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: lockexception; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lockexception (
    lockexceptionid bigint NOT NULL,
    organisationunitid bigint,
    periodid bigint,
    datasetid bigint,
    created timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map (
    mapid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    longitude double precision,
    latitude double precision,
    zoom integer,
    basemap character varying(255),
    title character varying(255),
    externalaccess boolean,
    userid bigint,
    publicaccess character varying(8),
    favorites jsonb,
    subscribers jsonb,
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb
);


--
-- Name: maplegend; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maplegend (
    maplegendid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    startvalue double precision NOT NULL,
    endvalue double precision NOT NULL,
    color character varying(255),
    image character varying(255),
    maplegendsetid bigint,
    translations jsonb
);


--
-- Name: maplegendset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maplegendset (
    maplegendsetid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    symbolizer character varying(255),
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: mapmapviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapmapviews (
    mapid bigint NOT NULL,
    sort_order integer NOT NULL,
    mapviewid bigint NOT NULL
);


--
-- Name: mapview; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview (
    mapviewid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    description text,
    layer character varying(255) NOT NULL,
    relativeperiodsid integer,
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    aggregationtype character varying(40),
    programid bigint,
    programstageid bigint,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    trackedentitytypeid bigint,
    programstatus character varying(40),
    followup boolean,
    organisationunitselectionmode character varying(40),
    method integer,
    classes integer,
    colorlow character varying(255),
    colorhigh character varying(255),
    colorscale character varying(255),
    legendsetid bigint,
    radiuslow integer,
    radiushigh integer,
    opacity double precision,
    orgunitgroupsetid bigint,
    arearadius integer,
    hidden boolean,
    labels boolean,
    labelfontsize character varying(255),
    labelfontweight character varying(255),
    labelfontstyle character varying(255),
    labelfontcolor character varying(255),
    eventclustering boolean,
    eventcoordinatefield character varying(255),
    eventpointcolor character varying(255),
    eventpointradius integer,
    config text,
    styledataitem jsonb,
    translations jsonb,
    renderingstrategy character varying(50) NOT NULL,
    userorgunittype character varying(20),
    thematicmaptype character varying(50),
    nodatacolor character varying(7),
    eventstatus character varying(50),
    organisationunitcolor character varying(7),
    orgunitfield character varying(255),
    labeltemplate character varying(50),
    relativeperiods jsonb
);


--
-- Name: mapview_attributedimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_attributedimensions (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    trackedentityattributedimensionid integer NOT NULL
);


--
-- Name: mapview_categorydimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_categorydimensions (
    mapviewid bigint NOT NULL,
    categorydimensionid integer NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: mapview_categoryoptiongroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_categoryoptiongroupsetdimensions (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupsetdimensionid integer NOT NULL
);


--
-- Name: mapview_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_columns (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: mapview_datadimensionitems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_datadimensionitems (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    datadimensionitemid integer NOT NULL
);


--
-- Name: mapview_dataelementdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_dataelementdimensions (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    trackedentitydataelementdimensionid integer NOT NULL
);


--
-- Name: mapview_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_filters (
    mapviewid bigint NOT NULL,
    dimension character varying(255),
    sort_order integer NOT NULL
);


--
-- Name: mapview_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_itemorgunitgroups (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid bigint NOT NULL
);


--
-- Name: mapview_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_organisationunits (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    organisationunitid bigint NOT NULL
);


--
-- Name: mapview_orgunitgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_orgunitgroupsetdimensions (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupsetdimensionid integer NOT NULL
);


--
-- Name: mapview_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_orgunitlevels (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitlevel integer
);


--
-- Name: mapview_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_periods (
    mapviewid bigint NOT NULL,
    sort_order integer NOT NULL,
    periodid bigint NOT NULL
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    messageid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    messagetext text,
    internal boolean,
    metadata character varying(255),
    userid bigint
);


--
-- Name: message_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.message_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messageattachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messageattachments (
    messageid bigint NOT NULL,
    fileresourceid bigint NOT NULL
);


--
-- Name: messageconversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messageconversation (
    messageconversationid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    messagecount integer,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    subject character varying(255) NOT NULL,
    messagetype character varying(255) NOT NULL,
    priority character varying(255),
    status character varying(255),
    user_assigned bigint,
    lastsenderid bigint,
    lastmessage timestamp without time zone,
    userid bigint,
    extmessageid character varying(64)
);


--
-- Name: messageconversation_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messageconversation_messages (
    messageconversationid bigint NOT NULL,
    sort_order integer NOT NULL,
    messageid bigint NOT NULL
);


--
-- Name: messageconversation_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messageconversation_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messageconversation_usermessages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messageconversation_usermessages (
    messageconversationid bigint NOT NULL,
    usermessageid integer NOT NULL
);


--
-- Name: metadataproposal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metadataproposal (
    proposalid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    type character varying(6) NOT NULL,
    status character varying(12) NOT NULL,
    target character varying(30) NOT NULL,
    targetuid character varying(11),
    created timestamp without time zone NOT NULL,
    createdby bigint NOT NULL,
    change jsonb NOT NULL,
    comment character varying(255),
    reason character varying(1024),
    finalised timestamp without time zone,
    finalisedby bigint
);


--
-- Name: metadataversion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metadataversion (
    versionid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    versiontype character varying(50),
    importdate timestamp without time zone,
    hashcode character varying(50) NOT NULL
);


--
-- Name: minmaxdataelement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.minmaxdataelement (
    minmaxdataelementid bigint DEFAULT nextval('public.hibernate_sequence'::regclass) NOT NULL,
    sourceid bigint NOT NULL,
    dataelementid bigint NOT NULL,
    categoryoptioncomboid bigint NOT NULL,
    minimumvalue integer NOT NULL,
    maximumvalue integer NOT NULL,
    generatedvalue boolean NOT NULL
);


--
-- Name: note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note (
    noteid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    notetext text,
    creator character varying(255)
);


--
-- Name: oauth2client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth2client (
    oauth2clientid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    cid character varying(230) NOT NULL,
    secret character varying(512) NOT NULL
);


--
-- Name: oauth2clientgranttypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth2clientgranttypes (
    oauth2clientid bigint NOT NULL,
    sort_order integer NOT NULL,
    granttype character varying(255)
);


--
-- Name: oauth2clientredirecturis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth2clientredirecturis (
    oauth2clientid bigint NOT NULL,
    sort_order integer NOT NULL,
    redirecturi character varying(255)
);


--
-- Name: oauth_access_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_token (
    token_id character varying(256),
    token bytea,
    authentication_id character varying(256) NOT NULL,
    user_name character varying(256),
    client_id character varying(256),
    authentication bytea,
    refresh_token character varying(256)
);


--
-- Name: oauth_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_code (
    code character varying(256),
    authentication bytea
);

ALTER TABLE ONLY public.oauth_code REPLICA IDENTITY FULL;


--
-- Name: oauth_refresh_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_refresh_token (
    token_id character varying(256),
    token bytea,
    authentication bytea
);

ALTER TABLE ONLY public.oauth_refresh_token REPLICA IDENTITY FULL;


--
-- Name: optiongroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroup (
    optiongroupid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    optionsetid bigint,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    description text
);


--
-- Name: optiongroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupmembers (
    optiongroupid bigint NOT NULL,
    optionid bigint NOT NULL
);


--
-- Name: optiongroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupset (
    optiongroupsetid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    datadimension boolean NOT NULL,
    optionsetid bigint,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: optiongroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupsetmembers (
    optiongroupsetid bigint NOT NULL,
    sort_order integer NOT NULL,
    optiongroupid bigint NOT NULL
);


--
-- Name: optionset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionset (
    optionsetid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    valuetype character varying(50) NOT NULL,
    version integer,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    description text
);


--
-- Name: optionvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionvalue (
    optionvalueid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(230) NOT NULL,
    name character varying(230) NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    sort_order integer,
    description text,
    formname text,
    style jsonb,
    optionsetid bigint,
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb
);


--
-- Name: organisationunit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organisationunit (
    organisationunitid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    parentid bigint,
    path character varying(255),
    hierarchylevel integer,
    description text,
    openingdate date NOT NULL,
    closeddate date,
    comment text,
    url character varying(255),
    contactperson character varying(255),
    address character varying(255),
    email character varying(150),
    phonenumber character varying(150),
    userid bigint,
    translations jsonb,
    geometry public.geometry(Geometry,4326),
    attributevalues jsonb DEFAULT '{}'::jsonb,
    image bigint
);


--
-- Name: orgunitgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroup (
    orgunitgroupid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    symbol character varying(255),
    color character varying(255),
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    geometry public.geometry(Geometry,4326),
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    description text
);


--
-- Name: orgunitgroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupmembers (
    organisationunitid bigint NOT NULL,
    orgunitgroupid bigint NOT NULL
);


--
-- Name: orgunitgroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupset (
    orgunitgroupsetid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    compulsory boolean NOT NULL,
    includesubhierarchyinanalytics boolean,
    datadimension boolean NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    shortname character varying(50) NOT NULL
);


--
-- Name: orgunitgroupsetdimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsetdimension (
    orgunitgroupsetdimensionid integer NOT NULL,
    orgunitgroupsetid bigint
);


--
-- Name: orgunitgroupsetdimension_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsetdimension_items (
    orgunitgroupsetdimensionid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid bigint NOT NULL
);


--
-- Name: orgunitgroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsetmembers (
    orgunitgroupsetid bigint NOT NULL,
    orgunitgroupid bigint NOT NULL
);


--
-- Name: orgunitlevel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitlevel (
    orgunitlevelid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    level integer NOT NULL,
    offlinelevels integer,
    translations jsonb
);


--
-- Name: outbound_sms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbound_sms (
    id bigint NOT NULL,
    date timestamp without time zone NOT NULL,
    message text,
    status integer NOT NULL,
    sender character varying(255),
    uid character varying(255) NOT NULL
);


--
-- Name: outbound_sms_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbound_sms_recipients (
    outbound_sms_id bigint NOT NULL,
    elt text
);

ALTER TABLE ONLY public.outbound_sms_recipients REPLICA IDENTITY FULL;


--
-- Name: period; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.period (
    periodid bigint NOT NULL,
    periodtypeid integer,
    startdate date NOT NULL,
    enddate date NOT NULL
);


--
-- Name: periodboundary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periodboundary (
    periodboundaryid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    boundarytarget character varying(50),
    analyticsperiodboundarytype character varying(50),
    offsetperiods integer,
    offsetperiodtypeid integer,
    programindicatorid bigint
);


--
-- Name: periodtype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periodtype (
    periodtypeid integer NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: potentialduplicate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.potentialduplicate (
    potentialduplicateid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    original character varying(11) NOT NULL,
    duplicate character varying(11) NOT NULL,
    status character varying(255) NOT NULL,
    createdbyusername character varying(255) NOT NULL,
    lastupdatebyusername character varying(255) NOT NULL
);


--
-- Name: potentialduplicatesequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.potentialduplicatesequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: predictor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.predictor (
    predictorid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    generatorexpressionid bigint,
    generatoroutput bigint NOT NULL,
    generatoroutputcombo bigint,
    skiptestexpressionid bigint,
    periodtypeid integer NOT NULL,
    sequentialsamplecount integer NOT NULL,
    annualsamplecount integer NOT NULL,
    sequentialskipcount integer,
    translations jsonb DEFAULT '[]'::jsonb,
    organisationunitdescendants character varying(100) DEFAULT 'SELECTED'::character varying,
    shortname character varying(50) NOT NULL
);


--
-- Name: predictorgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.predictorgroup (
    predictorgroupid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: predictorgroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.predictorgroupmembers (
    predictorid bigint NOT NULL,
    predictorgroupid bigint NOT NULL
);


--
-- Name: predictororgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.predictororgunitlevels (
    predictorid bigint NOT NULL,
    orgunitlevelid bigint NOT NULL
);


--
-- Name: previouspasswords; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.previouspasswords (
    userid bigint NOT NULL,
    list_index integer NOT NULL,
    previouspassword text
);


--
-- Name: program; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program (
    programid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname text,
    version integer,
    enrollmentdatelabel text,
    incidentdatelabel text,
    type character varying(255) NOT NULL,
    displayincidentdate boolean,
    onlyenrollonce boolean,
    skipoffline boolean NOT NULL,
    displayfrontpagelist boolean,
    usefirststageduringregistration boolean,
    capturecoordinates boolean,
    expirydays integer,
    completeeventsexpirydays integer,
    minattributesrequiredtosearch integer,
    maxteicounttoreturn integer,
    style jsonb,
    accesslevel character varying(100),
    expiryperiodtypeid integer,
    ignoreoverdueevents boolean,
    selectenrollmentdatesinfuture boolean,
    selectincidentdatesinfuture boolean,
    relatedprogramid bigint,
    categorycomboid bigint NOT NULL,
    trackedentitytypeid bigint,
    dataentryformid bigint,
    userid bigint,
    publicaccess character varying(8),
    featuretype character varying(255),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    opendaysaftercoenddate integer DEFAULT 0,
    enrollmentlabel text,
    followuplabel text,
    orgunitlabel text,
    relationshiplabel text,
    notelabel text,
    trackedentityattributelabel text,
    programstagelabel text,
    eventlabel text
);


--
-- Name: program_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program_attributes (
    programtrackedentityattributeid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    programid bigint,
    trackedentityattributeid bigint NOT NULL,
    displayinlist boolean,
    mandatory boolean,
    sort_order integer,
    allowfuturedate boolean,
    renderoptionsasradio boolean,
    rendertype jsonb,
    searchable boolean
);


--
-- Name: program_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program_organisationunits (
    organisationunitid bigint NOT NULL,
    programid bigint NOT NULL
);


--
-- Name: program_userroles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program_userroles (
    programid bigint,
    userroleid bigint NOT NULL
);

ALTER TABLE ONLY public.program_userroles REPLICA IDENTITY FULL;


--
-- Name: programexpression; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programexpression (
    programexpressionid bigint NOT NULL,
    description character varying(255),
    expression text
);


--
-- Name: programindicator; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicator (
    programindicatorid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname text,
    style jsonb,
    programid bigint NOT NULL,
    expression text,
    filter text,
    aggregationtype character varying(40),
    decimals integer,
    aggregateexportcategoryoptioncombo character varying(255),
    aggregateexportattributeoptioncombo character varying(255),
    displayinform boolean,
    analyticstype character varying(15) NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    orgunitfield text
);


--
-- Name: programindicatorgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorgroup (
    programindicatorgroupid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: programindicatorgroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorgroupmembers (
    programindicatorid bigint NOT NULL,
    programindicatorgroupid bigint NOT NULL
);


--
-- Name: programindicatorlegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorlegendsets (
    programindicatorid bigint NOT NULL,
    sort_order integer NOT NULL,
    legendsetid bigint NOT NULL
);


--
-- Name: programinstance_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.programinstance_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: programmessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programmessage (
    id bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    text character varying(500) NOT NULL,
    subject character varying(200),
    processeddate timestamp without time zone,
    messagestatus character varying(50),
    trackedentityid bigint,
    organisationunitid bigint,
    enrollmentid bigint,
    eventid bigint,
    translations jsonb,
    notificationtemplate character varying(255)
);


--
-- Name: programmessage_deliverychannels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programmessage_deliverychannels (
    programmessagedeliverychannelsid bigint NOT NULL,
    deliverychannel character varying(255)
);

ALTER TABLE ONLY public.programmessage_deliverychannels REPLICA IDENTITY FULL;


--
-- Name: programmessage_emailaddresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programmessage_emailaddresses (
    programmessageemailaddressid bigint NOT NULL,
    email text
);

ALTER TABLE ONLY public.programmessage_emailaddresses REPLICA IDENTITY FULL;


--
-- Name: programmessage_phonenumbers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programmessage_phonenumbers (
    programmessagephonenumberid bigint NOT NULL,
    phonenumber text
);

ALTER TABLE ONLY public.programmessage_phonenumbers REPLICA IDENTITY FULL;


--
-- Name: programnotificationinstance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programnotificationinstance (
    programnotificationinstanceid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    enrollmentid bigint,
    eventid bigint,
    programnotificationtemplateid bigint,
    scheduledat timestamp without time zone,
    sentat timestamp without time zone,
    programnotificationtemplatesnapshot jsonb
);


--
-- Name: programnotificationtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programnotificationtemplate (
    programnotificationtemplateid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    relativescheduleddays integer,
    usergroupid bigint,
    trackedentityattributeid bigint,
    dataelementid bigint,
    subjecttemplate character varying(100),
    messagetemplate text NOT NULL,
    notifyparentorganisationunitonly boolean,
    notifyusersinhierarchyonly boolean,
    notificationtrigger character varying(255),
    notificationrecipienttype character varying(255),
    programstageid bigint,
    programid bigint,
    sendrepeatable boolean NOT NULL,
    translations jsonb DEFAULT '[]'::jsonb
);


--
-- Name: programnotificationtemplate_deliverychannel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programnotificationtemplate_deliverychannel (
    programnotificationtemplatedeliverychannelid bigint NOT NULL,
    deliverychannel character varying(255)
);

ALTER TABLE ONLY public.programnotificationtemplate_deliverychannel REPLICA IDENTITY FULL;


--
-- Name: programownershiphistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programownershiphistory (
    programownershiphistoryid integer NOT NULL,
    programid bigint,
    trackedentityid bigint,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    createdby character varying(255),
    organisationunitid bigint
);


--
-- Name: programrule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programrule (
    programruleid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description character varying(255),
    programid bigint NOT NULL,
    programstageid bigint,
    rulecondition text,
    priority integer,
    translations jsonb
);


--
-- Name: programruleaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programruleaction (
    programruleactionid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    programruleid bigint,
    actiontype character varying(255) NOT NULL,
    dataelementid bigint,
    trackedentityattributeid bigint,
    programindicatorid bigint,
    programstagesectionid bigint,
    programstageid bigint,
    optionid bigint,
    optiongroupid bigint,
    location character varying(255),
    content text,
    data text,
    templateuid text,
    evaluationtime character varying(50),
    environments jsonb,
    translations jsonb
);


--
-- Name: programrulevariable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programrulevariable (
    programrulevariableid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    programid bigint NOT NULL,
    sourcetype character varying(255) NOT NULL,
    trackedentityattributeid bigint,
    dataelementid bigint,
    usecodeforoptionset boolean,
    programstageid bigint,
    translations jsonb DEFAULT '[]'::jsonb,
    valuetype character varying(50) NOT NULL
);


--
-- Name: programsection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programsection (
    programsectionid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    formname text,
    style jsonb,
    rendertype jsonb,
    programid bigint,
    sortorder integer NOT NULL,
    translations jsonb
);


--
-- Name: programsection_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programsection_attributes (
    programsectionid bigint NOT NULL,
    sort_order integer NOT NULL,
    trackedentityattributeid bigint NOT NULL
);


--
-- Name: programstage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstage (
    programstageid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    formname text,
    mindaysfromstart integer NOT NULL,
    programid bigint,
    repeatable boolean NOT NULL,
    dataentryformid bigint,
    standardinterval integer,
    executiondatelabel character varying(255),
    duedatelabel character varying(255),
    autogenerateevent boolean,
    displaygenerateeventbox boolean,
    generatedbyenrollmentdate boolean,
    blockentryform boolean,
    remindcompleted boolean,
    allowgeneratenextvisit boolean,
    openafterenrollment boolean,
    reportdatetouse character varying(255),
    pregenerateuid boolean,
    style jsonb,
    hideduedate boolean,
    sort_order integer,
    featuretype character varying(255),
    periodtypeid integer,
    userid bigint,
    publicaccess character varying(8),
    validationstrategy character varying(32) NOT NULL,
    translations jsonb,
    enableuserassignment boolean NOT NULL,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    nextscheduledateid bigint,
    sharing jsonb DEFAULT '{}'::jsonb,
    referral boolean DEFAULT false NOT NULL,
    programstagelabel text,
    eventlabel text
);


--
-- Name: programstagedataelement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagedataelement (
    programstagedataelementid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    programstageid bigint,
    dataelementid bigint NOT NULL,
    compulsory boolean NOT NULL,
    allowprovidedelsewhere boolean,
    sort_order integer,
    displayinreports boolean,
    allowfuturedate boolean,
    renderoptionsasradio boolean,
    rendertype jsonb,
    skipsynchronization boolean NOT NULL,
    skipanalytics boolean NOT NULL
);


--
-- Name: programstageinstance_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.programstageinstance_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: programstagesection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagesection (
    programstagesectionid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    formname text,
    style jsonb,
    rendertype jsonb,
    programstageid bigint,
    sortorder integer NOT NULL,
    translations jsonb
);


--
-- Name: programstagesection_dataelements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagesection_dataelements (
    programstagesectionid bigint NOT NULL,
    sort_order integer NOT NULL,
    dataelementid bigint NOT NULL
);


--
-- Name: programstagesection_programindicators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagesection_programindicators (
    programstagesectionid bigint NOT NULL,
    sort_order integer NOT NULL,
    programindicatorid bigint NOT NULL
);


--
-- Name: programstageworkinglist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstageworkinglist (
    programstageworkinglistid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    createdby bigint,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    programid bigint NOT NULL,
    programstageid bigint NOT NULL,
    programstagequerycriteria jsonb DEFAULT '[]'::jsonb,
    translations jsonb DEFAULT '[]'::jsonb,
    sharing jsonb DEFAULT '[]'::jsonb,
    userid bigint
);


--
-- Name: programtempowner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programtempowner (
    programtempownerid bigint NOT NULL,
    programid bigint,
    trackedentityid bigint,
    validtill timestamp without time zone,
    userid bigint,
    reason character varying(50000)
);


--
-- Name: programtempownershipaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programtempownershipaudit (
    programtempownershipauditid integer NOT NULL,
    programid bigint,
    trackedentityid bigint,
    created timestamp without time zone,
    accessedby character varying(255),
    reason character varying(50000)
);


--
-- Name: pushanalysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pushanalysis (
    pushanalysisid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(255) NOT NULL,
    title character varying(255),
    message text,
    enabled boolean NOT NULL,
    schedulingdayoffrequency integer,
    schedulingfrequency bytea,
    dashboard bigint NOT NULL
);


--
-- Name: pushanalysisrecipientusergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pushanalysisrecipientusergroups (
    usergroupid bigint NOT NULL,
    elt bigint NOT NULL
);


--
-- Name: relationship; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relationship (
    relationshipid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    style jsonb,
    relationshiptypeid bigint NOT NULL,
    from_relationshipitemid integer,
    to_relationshipitemid integer,
    key character varying NOT NULL,
    inverted_key character varying NOT NULL,
    deleted boolean DEFAULT false,
    createdatclient timestamp without time zone
);


--
-- Name: relationshipconstraint; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relationshipconstraint (
    relationshipconstraintid integer NOT NULL,
    entity character varying(255),
    trackedentitytypeid bigint,
    programid bigint,
    programstageid bigint,
    dataview jsonb
);


--
-- Name: relationshipitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relationshipitem (
    relationshipitemid integer NOT NULL,
    relationshipid bigint,
    trackedentityid bigint,
    enrollmentid bigint,
    eventid bigint
);


--
-- Name: relationshiptype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relationshiptype (
    relationshiptypeid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description character varying(255),
    from_relationshipconstraintid integer,
    to_relationshipconstraintid integer,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    bidirectional boolean NOT NULL,
    fromtoname character varying(255) NOT NULL,
    tofromname character varying(255),
    sharing jsonb DEFAULT '{}'::jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    referral boolean DEFAULT false NOT NULL
);


--
-- Name: relativeperiods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relativeperiods (
    relativeperiodsid integer NOT NULL,
    thisday boolean NOT NULL,
    yesterday boolean NOT NULL,
    last3days boolean NOT NULL,
    last7days boolean NOT NULL,
    last14days boolean NOT NULL,
    thismonth boolean NOT NULL,
    lastmonth boolean NOT NULL,
    thisbimonth boolean NOT NULL,
    lastbimonth boolean NOT NULL,
    thisquarter boolean NOT NULL,
    lastquarter boolean NOT NULL,
    thissixmonth boolean NOT NULL,
    lastsixmonth boolean NOT NULL,
    weeksthisyear boolean,
    monthsthisyear boolean NOT NULL,
    bimonthsthisyear boolean,
    quartersthisyear boolean NOT NULL,
    thisyear boolean NOT NULL,
    monthslastyear boolean NOT NULL,
    quarterslastyear boolean NOT NULL,
    lastyear boolean NOT NULL,
    last5years boolean NOT NULL,
    last12months boolean NOT NULL,
    last6months boolean NOT NULL,
    last3months boolean NOT NULL,
    last6bimonths boolean NOT NULL,
    last4quarters boolean NOT NULL,
    last2sixmonths boolean NOT NULL,
    thisfinancialyear boolean NOT NULL,
    lastfinancialyear boolean NOT NULL,
    last5financialyears boolean NOT NULL,
    thisweek boolean NOT NULL,
    lastweek boolean NOT NULL,
    thisbiweek boolean,
    lastbiweek boolean,
    last4weeks boolean NOT NULL,
    last4biweeks boolean,
    last12weeks boolean NOT NULL,
    last52weeks boolean NOT NULL,
    last30days boolean NOT NULL,
    last60days boolean NOT NULL,
    last90days boolean NOT NULL,
    last180days boolean NOT NULL,
    last10years boolean NOT NULL,
    last10financialyears boolean NOT NULL
);


--
-- Name: report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report (
    reportid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    type character varying(50),
    designcontent text,
    relativeperiodsid integer,
    paramreportingmonth boolean,
    paramorganisationunit boolean,
    cachestrategy character varying(40),
    externalaccess boolean,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    visualizationid bigint,
    sharing jsonb DEFAULT '{}'::jsonb,
    relativeperiods jsonb
);


--
-- Name: reservedvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reservedvalue (
    reservedvalueid integer NOT NULL,
    expirydate timestamp without time zone NOT NULL,
    created timestamp without time zone NOT NULL,
    ownerobject character varying(255),
    owneruid character varying(255),
    key character varying(255),
    value character varying(255)
);


--
-- Name: reservedvalue_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reservedvalue_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: route; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.route (
    routeid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    disabled boolean NOT NULL,
    url text NOT NULL,
    headers jsonb DEFAULT '{}'::jsonb,
    auth jsonb DEFAULT '{}'::jsonb,
    authorities jsonb DEFAULT '[]'::jsonb,
    userid bigint,
    translations jsonb DEFAULT '[]'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    attributevalues jsonb,
    responsetimeoutseconds integer DEFAULT 5 NOT NULL,
    CONSTRAINT route_responsetimeoutseconds_check CHECK (((responsetimeoutseconds > 0) AND (responsetimeoutseconds <= 60)))
);


--
-- Name: section; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.section (
    sectionid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    datasetid bigint NOT NULL,
    sortorder integer NOT NULL,
    showrowtotals boolean,
    showcolumntotals boolean,
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    disabledataelementautogroup boolean DEFAULT false,
    displayoptions jsonb DEFAULT '{}'::jsonb
);


--
-- Name: sectiondataelements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sectiondataelements (
    sectionid bigint NOT NULL,
    sort_order integer NOT NULL,
    dataelementid bigint NOT NULL
);


--
-- Name: sectiongreyedfields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sectiongreyedfields (
    sectionid bigint NOT NULL,
    dataelementoperandid bigint NOT NULL
);


--
-- Name: sectionindicators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sectionindicators (
    sectionid bigint NOT NULL,
    sort_order integer NOT NULL,
    indicatorid bigint NOT NULL
);


--
-- Name: sequentialnumbercounter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sequentialnumbercounter (
    id integer NOT NULL,
    owneruid character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    counter integer
);


--
-- Name: series; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.series (
    seriesid bigint NOT NULL,
    series character varying(255) NOT NULL,
    axis integer NOT NULL
);


--
-- Name: smscodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smscodes (
    smscodeid integer NOT NULL,
    code character varying(255),
    formula text,
    compulsory boolean,
    dataelementid bigint,
    trackedentityattributeid bigint,
    optionid bigint
);


--
-- Name: smscommandcodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smscommandcodes (
    id bigint NOT NULL,
    codeid integer NOT NULL
);


--
-- Name: smscommands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smscommands (
    smscommandid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    name text,
    parsertype integer,
    separatorkey text,
    codeseparator text,
    defaultmessage text,
    receivedmessage text,
    wrongformatmessage text,
    nousermessage text,
    morethanoneorgunitmessage text,
    successmessage text,
    currentperiodusedforreporting boolean,
    completenessmethod text,
    datasetid bigint,
    usergroupid bigint,
    programid bigint,
    programstageid bigint
);


--
-- Name: smscommandspecialcharacters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smscommandspecialcharacters (
    smscommandid bigint NOT NULL,
    specialcharacterid integer NOT NULL
);


--
-- Name: smsspecialcharacter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smsspecialcharacter (
    specialcharacterid integer NOT NULL,
    name text,
    value text
);


--
-- Name: sqlview; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sqlview (
    sqlviewid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    sqlquery text NOT NULL,
    type character varying(40) NOT NULL,
    cachestrategy character varying(40) NOT NULL,
    externalaccess boolean,
    userid bigint,
    publicaccess character varying(8),
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: systemsetting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.systemsetting (
    systemsettingid bigint NOT NULL,
    name character varying(255) NOT NULL,
    value text,
    translations jsonb
);


--
-- Name: tablehook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tablehook (
    analyticstablehookid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(255) NOT NULL,
    analyticstablephase character varying(50) NOT NULL,
    resourcetabletype character varying(50),
    analyticstabletype character varying(50),
    sql text NOT NULL
);


--
-- Name: trackedentity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentity (
    trackedentityid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    createdatclient timestamp without time zone,
    lastupdatedatclient timestamp without time zone,
    inactive boolean DEFAULT false NOT NULL,
    deleted boolean NOT NULL,
    lastsynchronized timestamp without time zone DEFAULT to_timestamp((0)::double precision) NOT NULL,
    featuretype character varying(50),
    coordinates text,
    organisationunitid bigint NOT NULL,
    trackedentitytypeid bigint,
    geometry public.geometry,
    storedby character varying(255),
    createdbyuserinfo jsonb,
    lastupdatedbyuserinfo jsonb,
    potentialduplicate boolean DEFAULT false
);


--
-- Name: trackedentityattribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattribute (
    trackedentityattributeid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname text,
    valuetype character varying(36) NOT NULL,
    aggregationtype character varying(40) NOT NULL,
    optionsetid bigint,
    inherit boolean,
    expression character varying(255),
    displayonvisitschedule boolean,
    sortorderinvisitschedule integer,
    displayinlistnoprogram boolean,
    sortorderinlistnoprogram integer,
    confidential boolean,
    uniquefield boolean,
    generated boolean,
    pattern character varying(255),
    textpattern jsonb,
    style jsonb,
    orgunitscope boolean,
    skipsynchronization boolean NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    fieldmask character varying(255),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: trackedentityattributedimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributedimension (
    trackedentityattributedimensionid integer NOT NULL,
    trackedentityattributeid bigint,
    legendsetid bigint,
    filter text
);


--
-- Name: trackedentityattributelegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributelegendsets (
    trackedentityattributeid bigint NOT NULL,
    sort_order integer NOT NULL,
    legendsetid bigint NOT NULL
);


--
-- Name: trackedentityattributevalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributevalue (
    trackedentityid bigint NOT NULL,
    trackedentityattributeid bigint NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    value character varying(1200),
    encryptedvalue character varying(50000),
    storedby character varying(255)
);


--
-- Name: trackedentityattributevalueaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributevalueaudit (
    trackedentityattributevalueauditid bigint NOT NULL,
    trackedentityid bigint,
    trackedentityattributeid bigint,
    value character varying(50000),
    encryptedvalue character varying(50000),
    created timestamp without time zone,
    modifiedby character varying(255),
    audittype character varying(100) NOT NULL
);


--
-- Name: trackedentityaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityaudit (
    trackedentityauditid bigint NOT NULL,
    trackedentity character varying(255),
    created timestamp without time zone,
    accessedby character varying(255),
    audittype character varying(100) NOT NULL,
    comment character varying(50000)
);


--
-- Name: trackedentitydataelementdimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitydataelementdimension (
    trackedentitydataelementdimensionid integer NOT NULL,
    dataelementid bigint,
    legendsetid bigint,
    filter text,
    programstageid bigint
);


--
-- Name: trackedentitydatavalueaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitydatavalueaudit (
    trackedentitydatavalueauditid bigint NOT NULL,
    eventid bigint,
    dataelementid bigint,
    value character varying(50000),
    created timestamp without time zone,
    providedelsewhere boolean,
    modifiedby character varying(255),
    audittype character varying(100) NOT NULL
);


--
-- Name: trackedentitydatavalueaudit_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trackedentitydatavalueaudit_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trackedentityfilter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityfilter (
    trackedentityfilterid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description character varying(255),
    sortorder integer,
    style jsonb,
    programid bigint NOT NULL,
    eventfilters jsonb,
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb,
    userid bigint,
    entityquerycriteria jsonb DEFAULT '{}'::jsonb
);


--
-- Name: trackedentityinstance_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trackedentityinstance_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trackedentityinstanceaudit_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trackedentityinstanceaudit_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trackedentityprogramindicatordimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityprogramindicatordimension (
    trackedentityprogramindicatordimensionid integer NOT NULL,
    programindicatorid bigint,
    legendsetid bigint,
    filter text
);


--
-- Name: trackedentityprogramowner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityprogramowner (
    trackedentityprogramownerid integer NOT NULL,
    trackedentityid bigint,
    programid bigint NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    organisationunitid bigint,
    createdby character varying(255) NOT NULL
);


--
-- Name: trackedentitytype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitytype (
    trackedentitytypeid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    formname text,
    style jsonb,
    minattributesrequiredtosearch integer,
    maxteicounttoreturn integer,
    allowauditlog boolean,
    userid bigint,
    publicaccess character varying(8),
    featuretype character varying(255),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: trackedentitytypeattribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitytypeattribute (
    trackedentitytypeattributeid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    trackedentitytypeid bigint,
    trackedentityattributeid bigint NOT NULL,
    displayinlist boolean,
    mandatory boolean,
    searchable boolean,
    sort_order integer
);


--
-- Name: userapps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userapps (
    userinfoid bigint NOT NULL,
    sort_order integer NOT NULL,
    app character varying(255)
);


--
-- Name: userdatavieworgunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userdatavieworgunits (
    userinfoid bigint NOT NULL,
    organisationunitid bigint NOT NULL
);


--
-- Name: usergroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroup (
    usergroupid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    uuid uuid,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: usergroupmanaged; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroupmanaged (
    managedbygroupid bigint NOT NULL,
    managedgroupid bigint NOT NULL
);


--
-- Name: usergroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroupmembers (
    userid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


--
-- Name: userinfo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userinfo (
    userinfoid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    lastupdated timestamp without time zone NOT NULL,
    created timestamp without time zone NOT NULL,
    surname character varying(160) NOT NULL,
    firstname character varying(160) NOT NULL,
    email character varying(160),
    phonenumber character varying(80),
    jobtitle character varying(160),
    introduction text,
    gender character varying(50),
    birthday date,
    nationality character varying(160),
    employer character varying(160),
    education text,
    interests text,
    languages text,
    welcomemessage text,
    lastcheckedinterpretations timestamp without time zone,
    whatsapp character varying(255),
    skype character varying(255),
    facebookmessenger character varying(255),
    telegram character varying(255),
    twitter character varying(255),
    avatar bigint,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    dataviewmaxorgunitlevel integer,
    lastupdatedby bigint,
    creatoruserid bigint,
    username character varying(255),
    password character varying(60),
    secret text,
    externalauth boolean,
    openid text,
    ldapid text,
    passwordlastupdated timestamp without time zone,
    lastlogin timestamp without time zone,
    restoretoken character varying(255),
    restoreexpiry timestamp without time zone,
    selfregistered boolean,
    invitation boolean,
    disabled boolean,
    uuid uuid,
    accountexpiry timestamp without time zone,
    idtoken character varying(255)
);


--
-- Name: userkeyjsonvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userkeyjsonvalue (
    userkeyjsonvalueid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    userid bigint NOT NULL,
    namespace character varying(255) NOT NULL,
    userkey character varying(255) NOT NULL,
    encrypted_value character varying(255),
    encrypted boolean,
    jbvalue jsonb
);


--
-- Name: usermembership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usermembership (
    organisationunitid bigint NOT NULL,
    userinfoid bigint NOT NULL
);


--
-- Name: usermessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usermessage (
    usermessageid integer NOT NULL,
    usermessagekey character varying(255),
    userid bigint NOT NULL,
    isread boolean NOT NULL,
    isfollowup boolean
);


--
-- Name: usermessage_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usermessage_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userrole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userrole (
    userroleid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description character varying(255),
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: userroleauthorities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userroleauthorities (
    userroleid bigint NOT NULL,
    authority character varying(255)
);

ALTER TABLE ONLY public.userroleauthorities REPLICA IDENTITY FULL;


--
-- Name: userrolemembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userrolemembers (
    userroleid bigint NOT NULL,
    userid bigint NOT NULL
);


--
-- Name: userrolerestrictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userrolerestrictions (
    userroleid bigint NOT NULL,
    restriction character varying(255)
);


--
-- Name: users_catdimensionconstraints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_catdimensionconstraints (
    userid bigint NOT NULL,
    dataelementcategoryid bigint NOT NULL
);


--
-- Name: users_cogsdimensionconstraints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_cogsdimensionconstraints (
    userid bigint NOT NULL,
    categoryoptiongroupsetid bigint NOT NULL
);


--
-- Name: usersetting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usersetting (
    userinfoid bigint NOT NULL,
    name character varying(255) NOT NULL,
    value bytea
);


--
-- Name: userteisearchorgunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userteisearchorgunits (
    userinfoid bigint NOT NULL,
    organisationunitid bigint NOT NULL
);


--
-- Name: validationnotificationtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationnotificationtemplate (
    validationnotificationtemplateid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    subjecttemplate character varying(100),
    messagetemplate text,
    notifyusersinhierarchyonly boolean,
    sendstrategy character varying(50) NOT NULL,
    translations jsonb DEFAULT '[]'::jsonb
);


--
-- Name: validationnotificationtemplate_recipientusergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationnotificationtemplate_recipientusergroups (
    validationnotificationtemplateid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


--
-- Name: validationnotificationtemplatevalidationrules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationnotificationtemplatevalidationrules (
    validationnotificationtemplateid bigint NOT NULL,
    validationruleid bigint NOT NULL
);


--
-- Name: validationresult; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationresult (
    validationresultid bigint NOT NULL,
    created timestamp without time zone NOT NULL,
    leftsidevalue double precision,
    rightsidevalue double precision,
    validationruleid bigint,
    periodid bigint,
    organisationunitid bigint,
    attributeoptioncomboid bigint,
    dayinperiod integer,
    notificationsent boolean
);


--
-- Name: validationrule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationrule (
    validationruleid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    instruction text,
    importance character varying(50),
    operator character varying(255) NOT NULL,
    leftexpressionid bigint,
    rightexpressionid bigint,
    skipformvalidation boolean,
    periodtypeid integer NOT NULL,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: validationrulegroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationrulegroup (
    validationrulegroupid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby bigint,
    name character varying(230) NOT NULL,
    description text,
    userid bigint,
    publicaccess character varying(8),
    translations jsonb,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    sharing jsonb DEFAULT '{}'::jsonb
);


--
-- Name: validationrulegroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationrulegroupmembers (
    validationgroupid bigint NOT NULL,
    validationruleid bigint NOT NULL
);


--
-- Name: validationruleorganisationunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationruleorganisationunitlevels (
    validationruleid bigint NOT NULL,
    organisationunitlevel integer
);

ALTER TABLE ONLY public.validationruleorganisationunitlevels REPLICA IDENTITY FULL;


--
-- Name: version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.version (
    versionid bigint NOT NULL,
    versionkey character varying(230) NOT NULL,
    versionvalue character varying(255)
);


--
-- Name: visualization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization (
    visualizationid bigint NOT NULL,
    uid character varying(11) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    code character varying(50),
    title character varying(255),
    subtitle character varying(255),
    description text,
    created timestamp without time zone,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    sortorder integer,
    toplimit integer,
    userid bigint,
    userorgunittype character varying(20),
    publicaccess character varying(8),
    displaydensity character varying(255),
    fontsize character varying(255),
    relativeperiodsid integer,
    digitgroupseparator character varying(255),
    legendsetid bigint,
    legenddisplaystyle character varying(40),
    legenddisplaystrategy character varying(40),
    aggregationtype character varying(255),
    regressiontype character varying(40),
    targetlinevalue double precision,
    targetlinelabel character varying(255),
    rangeaxislabel character varying(255),
    rangeaxismaxvalue double precision,
    rangeaxissteps integer,
    rangeaxisdecimals integer,
    rangeaxisminvalue double precision,
    domainaxislabel character varying(255),
    baselinevalue double precision,
    baselinelabel character varying(255),
    numbertype character varying(40),
    measurecriteria character varying(255),
    hideemptyrowitems character varying(40),
    percentstackedvalues boolean,
    nospacebetweencolumns boolean,
    regression boolean,
    externalaccess boolean,
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    paramreportingperiod boolean,
    paramorganisationunit boolean,
    paramparentorganisationunit boolean,
    paramgrandparentorganisationunit boolean,
    rowtotals boolean,
    coltotals boolean,
    cumulative boolean,
    rowsubtotals boolean,
    colsubtotals boolean,
    completedonly boolean,
    skiprounding boolean,
    showdimensionlabels boolean,
    hidetitle boolean,
    hidesubtitle boolean,
    hidelegend boolean,
    hideemptycolumns boolean,
    hideemptyrows boolean,
    showhierarchy boolean,
    showdata boolean,
    lastupdatedby bigint,
    lastupdated timestamp without time zone,
    favorites jsonb,
    subscribers jsonb,
    translations jsonb,
    series jsonb,
    fontstyle jsonb,
    colorset character varying(255),
    sharing jsonb DEFAULT '{}'::jsonb,
    outlieranalysis jsonb,
    fixcolumnheaders boolean NOT NULL,
    fixrowheaders boolean NOT NULL,
    attributevalues jsonb DEFAULT '{}'::jsonb,
    serieskey jsonb,
    axes jsonb,
    legendshowkey boolean,
    icons jsonb DEFAULT '[]'::jsonb,
    sorting jsonb DEFAULT '[]'::jsonb,
    relativeperiods jsonb
);


--
-- Name: visualization_axis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_axis (
    visualizationid bigint NOT NULL,
    sort_order integer NOT NULL,
    axisid bigint NOT NULL
);


--
-- Name: visualization_categorydimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_categorydimensions (
    visualizationid bigint NOT NULL,
    categorydimensionid integer NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: visualization_categoryoptiongroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_categoryoptiongroupsetdimensions (
    visualizationid bigint NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupsetdimensionid integer NOT NULL
);


--
-- Name: visualization_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_columns (
    visualizationid bigint NOT NULL,
    dimension character varying(255),
    sort_order integer NOT NULL
);


--
-- Name: visualization_datadimensionitems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_datadimensionitems (
    visualizationid bigint NOT NULL,
    datadimensionitemid integer NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: visualization_dataelementgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_dataelementgroupsetdimensions (
    visualizationid bigint NOT NULL,
    sort_order integer NOT NULL,
    dataelementgroupsetdimensionid integer NOT NULL
);


--
-- Name: visualization_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_filters (
    visualizationid bigint NOT NULL,
    dimension character varying(255),
    sort_order integer NOT NULL
);


--
-- Name: visualization_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_itemorgunitgroups (
    visualizationid bigint NOT NULL,
    orgunitgroupid bigint NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: visualization_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_organisationunits (
    visualizationid bigint NOT NULL,
    organisationunitid bigint NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: visualization_orgunitgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_orgunitgroupsetdimensions (
    visualizationid bigint NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupsetdimensionid integer NOT NULL
);


--
-- Name: visualization_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_orgunitlevels (
    visualizationid bigint NOT NULL,
    orgunitlevel integer,
    sort_order integer NOT NULL
);


--
-- Name: visualization_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_periods (
    visualizationid bigint NOT NULL,
    periodid bigint NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: visualization_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_rows (
    visualizationid bigint NOT NULL,
    dimension character varying(255),
    sort_order integer NOT NULL
);


--
-- Name: visualization_yearlyseries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visualization_yearlyseries (
    visualizationid bigint NOT NULL,
    sort_order integer NOT NULL,
    yearlyseries character varying(255)
);


--
-- Name: audit auditid; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit ALTER COLUMN auditid SET DEFAULT nextval('public.audit_auditid_seq'::regclass);


--
-- Data for Name: aggregatedataexchange; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aggregatedataexchange (aggregatedataexchangeid, uid, code, created, userid, lastupdated, lastupdatedby, translations, sharing, attributevalues, name, source, target) FROM stdin;
\.


--
-- Data for Name: api_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_token (apitokenid, uid, code, created, lastupdated, lastupdatedby, createdby, version, type, expire, key, attributes, sharing) FROM stdin;
\.


--
-- Data for Name: attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attribute (attributeid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, valuetype, mandatory, isunique, sortorder, optionsetid, userid, publicaccess, translations, sharing, objecttypes) FROM stdin;
\.


--
-- Data for Name: attributevalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attributevalue (attributevalueid, created, lastupdated, value, attributeid) FROM stdin;
\.


--
-- Data for Name: audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit (auditid, audittype, auditscope, createdat, createdby, klass, uid, code, attributes, data) FROM stdin;
\.


--
-- Data for Name: axis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.axis (axisid, dimensionalitem, axis) FROM stdin;
\.


--
-- Data for Name: categories_categoryoptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories_categoryoptions (categoryid, sort_order, categoryoptionid) FROM stdin;
23	1	22
\.


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.category (categoryid, uid, code, created, lastupdated, lastupdatedby, name, datadimensiontype, datadimension, userid, publicaccess, translations, attributevalues, sharing, shortname, description) FROM stdin;
23	GLevLNI9wkl	default	2026-04-18 15:34:47.567	2026-04-18 15:34:47.577	\N	default	DISAGGREGATION	f	\N	\N	[]	{}	{"owner": "system-process", "users": {}, "public": "rw------", "external": false, "userGroups": {}}	default	\N
\.


--
-- Data for Name: categorycombo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorycombo (categorycomboid, uid, code, created, lastupdated, lastupdatedby, name, datadimensiontype, skiptotal, userid, publicaccess, translations, sharing) FROM stdin;
24	bjDvmb4bfuf	default	2026-04-18 15:34:47.567	2026-04-18 15:34:47.568	\N	default	DISAGGREGATION	f	\N	\N	[]	{"owner": "system-process", "users": {}, "public": "rw------", "external": false, "userGroups": {}}
\.


--
-- Data for Name: categorycombos_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorycombos_categories (categoryid, sort_order, categorycomboid) FROM stdin;
23	1	24
\.


--
-- Data for Name: categorycombos_optioncombos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorycombos_optioncombos (categoryoptioncomboid, categorycomboid) FROM stdin;
25	24
\.


--
-- Data for Name: categorydimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorydimension (categorydimensionid, categoryid) FROM stdin;
\.


--
-- Data for Name: categorydimension_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorydimension_items (categorydimensionid, sort_order, categoryoptionid) FROM stdin;
\.


--
-- Data for Name: categoryoption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoption (categoryoptionid, uid, code, created, lastupdated, lastupdatedby, name, shortname, startdate, enddate, style, userid, publicaccess, translations, formname, attributevalues, sharing, description) FROM stdin;
22	xYerKDKCefk	default	2026-04-18 15:34:47.566	2026-04-18 15:34:47.568	\N	default	default	\N	\N	\N	\N	\N	[]	\N	{}	{"owner": "system-process", "users": {}, "public": "rwrw----", "external": false, "userGroups": {}}	\N
\.


--
-- Data for Name: categoryoption_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoption_organisationunits (organisationunitid, categoryoptionid) FROM stdin;
\.


--
-- Data for Name: categoryoptioncombo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptioncombo (categoryoptioncomboid, uid, code, created, lastupdated, lastupdatedby, name, ignoreapproval, translations, attributevalues) FROM stdin;
25	HllvX50cXC0	default	2026-04-18 15:34:47.568	2026-04-18 15:34:47.568	\N	default	f	[]	{}
\.


--
-- Data for Name: categoryoptioncombos_categoryoptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptioncombos_categoryoptions (categoryoptioncomboid, categoryoptionid) FROM stdin;
25	22
\.


--
-- Data for Name: categoryoptiongroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroup (categoryoptiongroupid, uid, code, created, lastupdated, lastupdatedby, name, shortname, datadimensiontype, userid, publicaccess, translations, attributevalues, sharing, description) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupmembers (categoryoptiongroupid, categoryoptionid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupset (categoryoptiongroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, datadimension, datadimensiontype, userid, publicaccess, translations, attributevalues, sharing, shortname) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupsetdimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupsetdimension (categoryoptiongroupsetdimensionid, categoryoptiongroupsetid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupsetdimension_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupsetdimension_items (categoryoptiongroupsetdimensionid, sort_order, categoryoptiongroupid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupsetmembers (categoryoptiongroupid, categoryoptiongroupsetid, sort_order) FROM stdin;
\.


--
-- Data for Name: completedatasetregistration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.completedatasetregistration (datasetid, periodid, sourceid, attributeoptioncomboid, date, storedby, lastupdatedby, lastupdated, completed) FROM stdin;
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configuration (configurationid, systemid, feedbackrecipientsid, offlineorgunitlevelid, infrastructuralindicatorsid, infrastructuraldataelementsid, infrastructuralperiodtypeid, selfregistrationrole, selfregistrationorgunit, facilityorgunitgroupset, facilityorgunitlevel, systemupdatenotificationrecipientsid) FROM stdin;
26	2f2ba1c7-40a0-4249-bb85-8ac19f847028	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: configuration_corswhitelist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configuration_corswhitelist (configurationid, corswhitelist) FROM stdin;
\.


--
-- Data for Name: constant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.constant (constantid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, value, userid, publicaccess, translations, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: dashboard; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard (dashboardid, uid, code, created, lastupdated, lastupdatedby, name, description, userid, externalaccess, publicaccess, favorites, translations, sharing, restrictfilters, allowedfilters, layout, itemconfig) FROM stdin;
\.


--
-- Data for Name: dashboard_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_items (dashboardid, sort_order, dashboarditemid) FROM stdin;
\.


--
-- Data for Name: dashboarditem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarditem (dashboarditemid, uid, code, created, lastupdated, lastupdatedby, eventchartid, mapid, textcontent, messages, appkey, shape, x, y, height, width, eventreport, translations, visualizationid, eventvisualizationid) FROM stdin;
\.


--
-- Data for Name: dashboarditem_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarditem_reports (dashboarditemid, sort_order, reportid) FROM stdin;
\.


--
-- Data for Name: dashboarditem_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarditem_resources (dashboarditemid, sort_order, resourceid) FROM stdin;
\.


--
-- Data for Name: dashboarditem_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarditem_users (dashboarditemid, sort_order, userid) FROM stdin;
\.


--
-- Data for Name: dataapproval; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapproval (dataapprovalid, dataapprovallevelid, workflowid, periodid, organisationunitid, attributeoptioncomboid, accepted, created, creator, lastupdated, lastupdatedby) FROM stdin;
\.


--
-- Data for Name: dataapprovalaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalaudit (dataapprovalauditid, levelid, workflowid, periodid, organisationunitid, attributeoptioncomboid, action, created, creator) FROM stdin;
\.


--
-- Data for Name: dataapprovallevel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovallevel (dataapprovallevelid, uid, code, created, lastupdated, lastupdatedby, name, level, orgunitlevel, categoryoptiongroupsetid, userid, publicaccess, translations, sharing) FROM stdin;
\.


--
-- Data for Name: dataapprovalworkflow; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalworkflow (workflowid, uid, code, created, lastupdated, lastupdatedby, name, periodtypeid, categorycomboid, userid, publicaccess, translations, sharing) FROM stdin;
\.


--
-- Data for Name: dataapprovalworkflowlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalworkflowlevels (workflowid, dataapprovallevelid) FROM stdin;
\.


--
-- Data for Name: datadimensionitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datadimensionitem (datadimensionitemid, indicatorid, dataelementid, dataelementoperand_dataelementid, dataelementoperand_categoryoptioncomboid, datasetid, metric, programindicatorid, programdataelement_programid, programdataelement_dataelementid, programattribute_programid, programattribute_attributeid, expressiondimensionitemid) FROM stdin;
\.


--
-- Data for Name: dataelement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelement (dataelementid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, style, valuetype, domaintype, aggregationtype, categorycomboid, url, zeroissignificant, optionsetid, commentoptionsetid, userid, publicaccess, fieldmask, translations, attributevalues, sharing, valuetypeoptions) FROM stdin;
\.


--
-- Data for Name: dataelementaggregationlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementaggregationlevels (dataelementid, sort_order, aggregationlevel) FROM stdin;
\.


--
-- Data for Name: dataelementgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroup (dataelementgroupid, uid, code, created, lastupdated, lastupdatedby, name, shortname, userid, publicaccess, translations, attributevalues, description, sharing) FROM stdin;
\.


--
-- Data for Name: dataelementgroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupmembers (dataelementid, dataelementgroupid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupset (dataelementgroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, compulsory, datadimension, userid, publicaccess, translations, attributevalues, sharing, shortname) FROM stdin;
\.


--
-- Data for Name: dataelementgroupsetdimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupsetdimension (dataelementgroupsetdimensionid, dataelementgroupsetid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupsetdimension_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupsetdimension_items (dataelementgroupsetdimensionid, sort_order, dataelementgroupid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupsetmembers (dataelementgroupsetid, sort_order, dataelementgroupid) FROM stdin;
\.


--
-- Data for Name: dataelementlegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementlegendsets (dataelementid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: dataelementoperand; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementoperand (dataelementoperandid, dataelementid, categoryoptioncomboid) FROM stdin;
\.


--
-- Data for Name: dataentryform; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataentryform (dataentryformid, uid, code, created, lastupdated, lastupdatedby, name, style, htmlcode, format, translations) FROM stdin;
\.


--
-- Data for Name: datainputperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datainputperiod (datainputperiodid, periodid, openingdate, closingdate, datasetid) FROM stdin;
\.


--
-- Data for Name: dataset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataset (datasetid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, style, periodtypeid, categorycomboid, mobile, version, expirydays, timelydays, notifycompletinguser, workflowid, openfutureperiods, fieldcombinationrequired, validcompleteonly, novaluerequirescomment, skipoffline, dataelementdecoration, renderastabs, renderhorizontally, compulsoryfieldscompleteonly, userid, publicaccess, dataentryform, notificationrecipients, translations, attributevalues, openperiodsaftercoenddate, sharing) FROM stdin;
\.


--
-- Data for Name: datasetelement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetelement (datasetelementid, datasetid, dataelementid, categorycomboid) FROM stdin;
\.


--
-- Data for Name: datasetindicators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetindicators (indicatorid, datasetid) FROM stdin;
\.


--
-- Data for Name: datasetlegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetlegendsets (datasetid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: datasetnotification_datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetnotification_datasets (datasetnotificationtemplateid, datasetid) FROM stdin;
\.


--
-- Data for Name: datasetnotificationtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetnotificationtemplate (datasetnotificationtemplateid, uid, code, created, lastupdated, lastupdatedby, name, subjecttemplate, messagetemplate, relativescheduleddays, notifyparentorganisationunitonly, notifyusersinhierarchyonly, sendstrategy, usergroupid, datasetnotificationtrigger, notificationrecipienttype, translations) FROM stdin;
\.


--
-- Data for Name: datasetnotificationtemplate_deliverychannel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetnotificationtemplate_deliverychannel (datasetnotificationtemplateid, deliverychannel) FROM stdin;
\.


--
-- Data for Name: datasetoperands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetoperands (datasetid, dataelementoperandid) FROM stdin;
\.


--
-- Data for Name: datasetsource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetsource (sourceid, datasetid) FROM stdin;
\.


--
-- Data for Name: datastatistics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datastatistics (statisticsid, uid, code, created, lastupdated, lastupdatedby, mapviews, eventreportviews, eventchartviews, dashboardviews, datasetreportviews, active_users, totalviews, maps, eventreports, eventcharts, dashboards, indicators, datavalues, users, visualizationviews, visualizations, passivedashboardviews, eventvisualizationviews, eventvisualizations) FROM stdin;
\.


--
-- Data for Name: datastatisticsevent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datastatisticsevent (eventid, eventtype, "timestamp", username, favoriteuid) FROM stdin;
\.


--
-- Data for Name: datavalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datavalue (dataelementid, periodid, sourceid, categoryoptioncomboid, attributeoptioncomboid, value, storedby, created, lastupdated, comment, followup, deleted) FROM stdin;
\.


--
-- Data for Name: datavalueaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datavalueaudit (datavalueauditid, dataelementid, periodid, organisationunitid, categoryoptioncomboid, attributeoptioncomboid, value, created, modifiedby, audittype) FROM stdin;
\.


--
-- Data for Name: deletedobject; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deletedobject (deletedobjectid, klass, uid, code, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (documentid, uid, code, created, lastupdated, lastupdatedby, name, url, fileresource, external, contenttype, attachment, externalaccess, userid, publicaccess, translations, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: enrollment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enrollment (enrollmentid, uid, created, lastupdated, createdatclient, lastupdatedatclient, occurreddate, enrollmentdate, completeddate, followup, completedby, deleted, storedby, status, trackedentityid, programid, organisationunitid, geometry, createdbyuserinfo, lastupdatedbyuserinfo) FROM stdin;
\.


--
-- Data for Name: enrollment_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enrollment_notes (enrollmentid, sort_order, noteid) FROM stdin;
\.


--
-- Data for Name: event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event (eventid, uid, code, created, lastupdated, createdatclient, lastupdatedatclient, lastsynchronized, enrollmentid, programstageid, attributeoptioncomboid, deleted, storedby, scheduleddate, occurreddate, organisationunitid, status, completedby, completeddate, geometry, eventdatavalues, assigneduserid, createdbyuserinfo, lastupdatedbyuserinfo) FROM stdin;
\.


--
-- Data for Name: event_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_notes (eventid, sort_order, noteid) FROM stdin;
\.


--
-- Data for Name: eventchart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart (eventchartid, uid, code, created, lastupdated, lastupdatedby, name, description, relativeperiodsid, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, programid, programstageid, startdate, enddate, dataelementvaluedimensionid, attributevaluedimensionid, aggregationtype, completedonly, timefield, title, subtitle, hidetitle, hidesubtitle, type, showdata, hideemptyrowitems, hidenadata, programstatus, eventstatus, percentstackedvalues, cumulativevalues, rangeaxismaxvalue, rangeaxisminvalue, rangeaxissteps, rangeaxisdecimals, outputtype, collapsedatadimensions, domainaxislabel, rangeaxislabel, hidelegend, nospacebetweencolumns, regressiontype, targetlinevalue, targetlinelabel, baselinevalue, baselinelabel, sortorder, externalaccess, userid, publicaccess, favorites, subscribers, translations, orgunitfield, userorgunittype, sharing, attributevalues) FROM stdin;
\.


--
-- Data for Name: eventchart_attributedimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_attributedimensions (eventchartid, sort_order, trackedentityattributedimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_categorydimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_categorydimensions (eventchartid, sort_order, categorydimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_categoryoptiongroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_categoryoptiongroupsetdimensions (eventchartid, sort_order, categoryoptiongroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_columns (eventchartid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventchart_dataelementdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_dataelementdimensions (eventchartid, sort_order, trackedentitydataelementdimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_filters (eventchartid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventchart_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_itemorgunitgroups (eventchartid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: eventchart_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_organisationunits (eventchartid, sort_order, organisationunitid) FROM stdin;
\.


--
-- Data for Name: eventchart_orgunitgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_orgunitgroupsetdimensions (eventchartid, sort_order, orgunitgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_orgunitlevels (eventchartid, sort_order, orgunitlevel) FROM stdin;
\.


--
-- Data for Name: eventchart_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_periods (eventchartid, sort_order, periodid) FROM stdin;
\.


--
-- Data for Name: eventchart_programindicatordimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_programindicatordimensions (eventchartid, sort_order, trackedentityprogramindicatordimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_rows (eventchartid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventfilter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventfilter (eventfilterid, uid, created, lastupdated, lastupdatedby, name, description, program, programstage, eventquerycriteria, userid, publicaccess, sharing, translations) FROM stdin;
\.


--
-- Data for Name: eventhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventhook (eventhookid, uid, code, disabled, created, userid, lastupdated, lastupdatedby, description, translations, attributevalues, sharing, name, source, targets) FROM stdin;
\.


--
-- Data for Name: eventreport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport (eventreportid, uid, code, created, lastupdated, lastupdatedby, name, description, relativeperiodsid, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, programid, programstageid, startdate, enddate, dataelementvaluedimensionid, attributevaluedimensionid, aggregationtype, completedonly, timefield, title, subtitle, hidetitle, hidesubtitle, datatype, rowtotals, coltotals, rowsubtotals, colsubtotals, hideemptyrows, hidenadata, showhierarchy, outputtype, collapsedatadimensions, showdimensionlabels, digitgroupseparator, displaydensity, fontsize, programstatus, eventstatus, sortorder, toplimit, externalaccess, userid, publicaccess, favorites, subscribers, translations, orgunitfield, userorgunittype, sharing, attributevalues, simpledimensions) FROM stdin;
\.


--
-- Data for Name: eventreport_attributedimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_attributedimensions (eventreportid, sort_order, trackedentityattributedimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_categorydimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_categorydimensions (eventreportid, sort_order, categorydimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_categoryoptiongroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_categoryoptiongroupsetdimensions (eventreportid, sort_order, categoryoptiongroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_columns (eventreportid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventreport_dataelementdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_dataelementdimensions (eventreportid, sort_order, trackedentitydataelementdimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_filters (eventreportid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventreport_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_itemorgunitgroups (eventreportid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: eventreport_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_organisationunits (eventreportid, sort_order, organisationunitid) FROM stdin;
\.


--
-- Data for Name: eventreport_orgunitgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_orgunitgroupsetdimensions (eventreportid, sort_order, orgunitgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_orgunitlevels (eventreportid, sort_order, orgunitlevel) FROM stdin;
\.


--
-- Data for Name: eventreport_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_periods (eventreportid, sort_order, periodid) FROM stdin;
\.


--
-- Data for Name: eventreport_programindicatordimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_programindicatordimensions (eventreportid, sort_order, trackedentityprogramindicatordimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_rows (eventreportid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventvisualization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization (eventvisualizationid, uid, code, created, lastupdated, name, relativeperiodsid, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, externalaccess, userid, publicaccess, programid, programstageid, startdate, enddate, sortorder, toplimit, outputtype, dataelementvaluedimensionid, attributevaluedimensionid, aggregationtype, collapsedatadimensions, hidenadata, completedonly, description, title, lastupdatedby, subtitle, hidetitle, hidesubtitle, programstatus, eventstatus, favorites, subscribers, timefield, translations, orgunitfield, userorgunittype, sharing, attributevalues, type, showdata, rangeaxismaxvalue, rangeaxisminvalue, rangeaxissteps, rangeaxisdecimals, domainaxislabel, rangeaxislabel, hidelegend, targetlinevalue, targetlinelabel, baselinevalue, baselinelabel, regressiontype, hideemptyrowitems, percentstackedvalues, cumulativevalues, nospacebetweencolumns, datatype, hideemptyrows, digitgroupseparator, displaydensity, fontsize, showhierarchy, rowtotals, coltotals, showdimensionlabels, rowsubtotals, colsubtotals, legacy, simpledimensions, eventrepetitions, legendsetid, legenddisplaystrategy, legenddisplaystyle, legendshowkey, sorting, skiprounding, trackedentitytypeid, relativeperiods) FROM stdin;
\.


--
-- Data for Name: eventvisualization_attributedimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_attributedimensions (eventvisualizationid, trackedentityattributedimensionid, sort_order) FROM stdin;
\.


--
-- Data for Name: eventvisualization_categorydimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_categorydimensions (eventvisualizationid, sort_order, categorydimensionid) FROM stdin;
\.


--
-- Data for Name: eventvisualization_categoryoptiongroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_categoryoptiongroupsetdimensions (eventvisualizationid, sort_order, categoryoptiongroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventvisualization_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_columns (eventvisualizationid, dimension, sort_order) FROM stdin;
\.


--
-- Data for Name: eventvisualization_dataelementdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_dataelementdimensions (eventvisualizationid, trackedentitydataelementdimensionid, sort_order) FROM stdin;
\.


--
-- Data for Name: eventvisualization_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_filters (eventvisualizationid, dimension, sort_order) FROM stdin;
\.


--
-- Data for Name: eventvisualization_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_itemorgunitgroups (eventvisualizationid, orgunitgroupid, sort_order) FROM stdin;
\.


--
-- Data for Name: eventvisualization_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_organisationunits (eventvisualizationid, organisationunitid, sort_order) FROM stdin;
\.


--
-- Data for Name: eventvisualization_orgunitgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_orgunitgroupsetdimensions (eventvisualizationid, sort_order, orgunitgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventvisualization_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_orgunitlevels (eventvisualizationid, orgunitlevel, sort_order) FROM stdin;
\.


--
-- Data for Name: eventvisualization_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_periods (eventvisualizationid, periodid, sort_order) FROM stdin;
\.


--
-- Data for Name: eventvisualization_programindicatordimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_programindicatordimensions (eventvisualizationid, trackedentityprogramindicatordimensionid, sort_order) FROM stdin;
\.


--
-- Data for Name: eventvisualization_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventvisualization_rows (eventvisualizationid, dimension, sort_order) FROM stdin;
\.


--
-- Data for Name: expression; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expression (expressionid, description, expression, slidingwindow, missingvaluestrategy, translations) FROM stdin;
\.


--
-- Data for Name: expressiondimensionitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expressiondimensionitem (expressiondimensionitemid, code, name, shortname, formname, expression, description, missingvaluestrategy, slidingwindow, lastupdated, uid, created, userid, publicaccess, lastupdatedby, translations, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: externalfileresource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.externalfileresource (externalfileresourceid, uid, code, created, lastupdated, lastupdatedby, accesstoken, expires, fileresourceid) FROM stdin;
\.


--
-- Data for Name: externalmaplayer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.externalmaplayer (externalmaplayerid, uid, code, created, lastupdated, lastupdatedby, name, attribution, url, legendseturl, maplayerposition, layers, imageformat, mapservice, legendsetid, userid, publicaccess, sharing, translations) FROM stdin;
\.


--
-- Data for Name: externalnotificationlogentry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.externalnotificationlogentry (externalnotificationlogentryid, uid, created, lastupdated, lastsentat, retries, key, templateuid, allowmultiple, triggerby) FROM stdin;
\.


--
-- Data for Name: fileresource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fileresource (fileresourceid, uid, code, created, lastupdated, lastupdatedby, name, contenttype, contentlength, contentmd5, storagekey, isassigned, domain, userid, hasmultiplestoragefiles, fileresourceowner) FROM stdin;
65	DWgRqUASKu4	\N	2026-04-18 15:35:20.093	2026-04-18 15:35:20.13	\N	icon_2g_positive	image/svg+xml	3823	a8ed82a81639b539c604a5bff1c98bb2	icon/2g_positive	t	ICON	\N	f	\N
66	F6ykZAZNK0Z	\N	2026-04-18 15:35:20.138	2026-04-18 15:35:20.145	\N	icon_2g_negative	image/svg+xml	3630	501ad914de2e01acb65a3ccfcb5f93d4	icon/2g_negative	t	ICON	\N	f	\N
67	zTXYYVvSkuV	\N	2026-04-18 15:35:20.149	2026-04-18 15:35:20.152	\N	icon_2g_outline	image/svg+xml	3992	2bd17284dbd02e1205a72201638f8ce6	icon/2g_outline	t	ICON	\N	f	\N
68	TqeorGzIwan	\N	2026-04-18 15:35:20.155	2026-04-18 15:35:20.159	\N	icon_3g_positive	image/svg+xml	4005	2627044e679d11037d93941668890b0a	icon/3g_positive	t	ICON	\N	f	\N
69	S7oDHLheO21	\N	2026-04-18 15:35:20.164	2026-04-18 15:35:20.168	\N	icon_3g_negative	image/svg+xml	3837	ea4f582c28da80004dcc938474399a95	icon/3g_negative	t	ICON	\N	f	\N
70	gKgDC3tLIN9	\N	2026-04-18 15:35:20.172	2026-04-18 15:35:20.176	\N	icon_3g_outline	image/svg+xml	4193	5f370083caffdb90012bc6c3f3d85284	icon/3g_outline	t	ICON	\N	f	\N
71	q1SdCliOVgK	\N	2026-04-18 15:35:20.179	2026-04-18 15:35:20.183	\N	icon_4x4_positive	image/svg+xml	3067	76481d2defc0e7358f71e7d34634c81e	icon/4x4_positive	t	ICON	\N	f	\N
72	iMxbxX730Jw	\N	2026-04-18 15:35:20.186	2026-04-18 15:35:20.189	\N	icon_4x4_negative	image/svg+xml	2943	9690749f12c330dbbc0392c3e04864da	icon/4x4_negative	t	ICON	\N	f	\N
73	c8CNSeJ6kRw	\N	2026-04-18 15:35:20.192	2026-04-18 15:35:20.196	\N	icon_4x4_outline	image/svg+xml	4311	f58ad7d11bbc30be97b80f333acf310b	icon/4x4_outline	t	ICON	\N	f	\N
74	wFE2dHuOrgp	\N	2026-04-18 15:35:20.199	2026-04-18 15:35:20.203	\N	icon_agriculture_positive	image/svg+xml	2524	a97cfcec76c1b2d3d86d8fbf82719cf3	icon/agriculture_positive	t	ICON	\N	f	\N
75	BInX7niGRMp	\N	2026-04-18 15:35:20.206	2026-04-18 15:35:20.209	\N	icon_agriculture_negative	image/svg+xml	2497	a53ee2351f5e85d7ea9cfe8d8ba673c7	icon/agriculture_negative	t	ICON	\N	f	\N
76	BgyxGFZUHMW	\N	2026-04-18 15:35:20.211	2026-04-18 15:35:20.215	\N	icon_agriculture_outline	image/svg+xml	7004	93f203b1e77c48dc635ca7e2d4641c1c	icon/agriculture_outline	t	ICON	\N	f	\N
77	bsm46kOPCdD	\N	2026-04-18 15:35:20.218	2026-04-18 15:35:20.221	\N	icon_agriculture_worker_positive	image/svg+xml	2082	c866ec207b304454f515ef00e944740a	icon/agriculture_worker_positive	t	ICON	\N	f	\N
78	lQ9DkVSmzTF	\N	2026-04-18 15:35:20.224	2026-04-18 15:35:20.228	\N	icon_agriculture_worker_negative	image/svg+xml	1971	1e51975baa085ff2135baadf548c1d20	icon/agriculture_worker_negative	t	ICON	\N	f	\N
79	CUqZyayvJ4Z	\N	2026-04-18 15:35:20.231	2026-04-18 15:35:20.239	\N	icon_agriculture_worker_outline	image/svg+xml	3821	15a69a4dfae865e7dfdbb064605d28a2	icon/agriculture_worker_outline	t	ICON	\N	f	\N
80	kQeEp6LektL	\N	2026-04-18 15:35:20.243	2026-04-18 15:35:20.251	\N	icon_alert_positive	image/svg+xml	397	ad1a83e46fb2ff038b50d2adc031c722	icon/alert_positive	t	ICON	\N	f	\N
81	NyJrGjOazXV	\N	2026-04-18 15:35:20.256	2026-04-18 15:35:20.26	\N	icon_alert_negative	image/svg+xml	424	e5c240719005cb7682cb79218c49df8e	icon/alert_negative	t	ICON	\N	f	\N
82	EiiEpkCu50P	\N	2026-04-18 15:35:20.263	2026-04-18 15:35:20.267	\N	icon_alert_outline	image/svg+xml	388	4aa7bf22d7b3274d5572918580dfe260	icon/alert_outline	t	ICON	\N	f	\N
83	v7jxiXN7JA4	\N	2026-04-18 15:35:20.273	2026-04-18 15:35:20.278	\N	icon_alert_circle_positive	image/svg+xml	533	617d84029be71017bd1b07776cc063c4	icon/alert_circle_positive	t	ICON	\N	f	\N
84	PAqMO94symj	\N	2026-04-18 15:35:20.282	2026-04-18 15:35:20.286	\N	icon_alert_circle_negative	image/svg+xml	781	8414e39ca5aa441ea65b76b85cab0e42	icon/alert_circle_negative	t	ICON	\N	f	\N
85	CB1bEvosryb	\N	2026-04-18 15:35:20.29	2026-04-18 15:35:20.295	\N	icon_alert_circle_outline	image/svg+xml	701	6a527c66733443abe669642f9f887b75	icon/alert_circle_outline	t	ICON	\N	f	\N
86	nqSGVcAzRmt	\N	2026-04-18 15:35:20.299	2026-04-18 15:35:20.304	\N	icon_alert_triangle_positive	image/svg+xml	744	5fc93a237be4083af71581f7b9936dfd	icon/alert_triangle_positive	t	ICON	\N	f	\N
87	ACxuA1C2Elv	\N	2026-04-18 15:35:20.309	2026-04-18 15:35:20.314	\N	icon_alert_triangle_negative	image/svg+xml	776	38bd5c56d0228dcacb4a18f8cc946d34	icon/alert_triangle_negative	t	ICON	\N	f	\N
88	eAZLl6iXcWP	\N	2026-04-18 15:35:20.319	2026-04-18 15:35:20.323	\N	icon_alert_triangle_outline	image/svg+xml	882	5216cbcf6eb980a7d935987c13e6a5a7	icon/alert_triangle_outline	t	ICON	\N	f	\N
89	fHAT8dXLBli	\N	2026-04-18 15:35:20.326	2026-04-18 15:35:20.331	\N	icon_ambulance_positive	image/svg+xml	1645	7250aff15874ab64354e02713656adcd	icon/ambulance_positive	t	ICON	\N	f	\N
90	d6Ui3RO46mP	\N	2026-04-18 15:35:20.335	2026-04-18 15:35:20.339	\N	icon_ambulance_negative	image/svg+xml	1601	d99b139fdbb7a7f41894c72df8c18728	icon/ambulance_negative	t	ICON	\N	f	\N
91	AA7KhjY3ict	\N	2026-04-18 15:35:20.343	2026-04-18 15:35:20.348	\N	icon_ambulance_outline	image/svg+xml	1813	ecd503f35108f58e157cc7c736a61030	icon/ambulance_outline	t	ICON	\N	f	\N
92	EonUO3pVDW1	\N	2026-04-18 15:35:20.351	2026-04-18 15:35:20.356	\N	icon_ambulatory_clinic_positive	image/svg+xml	524	9df79e5f40a8ea76c02f40d17604fe5e	icon/ambulatory_clinic_positive	t	ICON	\N	f	\N
93	X4vdpXLlKBn	\N	2026-04-18 15:35:20.361	2026-04-18 15:35:20.367	\N	icon_ambulatory_clinic_negative	image/svg+xml	633	c6fb8b4a0dcaff7bfe7e85f5adc40226	icon/ambulatory_clinic_negative	t	ICON	\N	f	\N
94	wkbaPgJbQF0	\N	2026-04-18 15:35:20.37	2026-04-18 15:35:20.374	\N	icon_ambulatory_clinic_outline	image/svg+xml	884	ad7b6a61dcf37ac9b50ea0c8ca295f54	icon/ambulatory_clinic_outline	t	ICON	\N	f	\N
95	vcXer6qeyRZ	\N	2026-04-18 15:35:20.377	2026-04-18 15:35:20.381	\N	icon_ancv_positive	image/svg+xml	2398	cd75d4aa0e80379e02584e7d65c3627c	icon/ancv_positive	t	ICON	\N	f	\N
96	lIX6hw3GOzC	\N	2026-04-18 15:35:20.384	2026-04-18 15:35:20.391	\N	icon_ancv_negative	image/svg+xml	6192	074f99d794fda73f7fd701dca133c80f	icon/ancv_negative	t	ICON	\N	f	\N
97	F1NtBdlYzrk	\N	2026-04-18 15:35:20.394	2026-04-18 15:35:20.398	\N	icon_ancv_outline	image/svg+xml	3368	d1c21d9ccd4e201bef46aa5ca0499016	icon/ancv_outline	t	ICON	\N	f	\N
98	hgsjLOOlpYp	\N	2026-04-18 15:35:20.401	2026-04-18 15:35:20.405	\N	icon_baby_female_0203m_positive	image/svg+xml	913	4fb3abd5a88bb10b1ad1c07e652d11ab	icon/baby_female_0203m_positive	t	ICON	\N	f	\N
99	d1eVolwc282	\N	2026-04-18 15:35:20.408	2026-04-18 15:35:20.412	\N	icon_baby_female_0203m_negative	image/svg+xml	860	d3c686dc8a2ca14bdfb8b1b989bca137	icon/baby_female_0203m_negative	t	ICON	\N	f	\N
100	u9Fhlg7Ro09	\N	2026-04-18 15:35:20.415	2026-04-18 15:35:20.419	\N	icon_baby_female_0203m_outline	image/svg+xml	1819	ae039d385a73c16d9d91d2a212238031	icon/baby_female_0203m_outline	t	ICON	\N	f	\N
101	pzSAGAFUvGA	\N	2026-04-18 15:35:20.423	2026-04-18 15:35:20.427	\N	icon_baby_female_0306m_positive	image/svg+xml	1698	171a56aa67fd4ef031304f928bbc89ef	icon/baby_female_0306m_positive	t	ICON	\N	f	\N
102	tjhU0jx6K0a	\N	2026-04-18 15:35:20.429	2026-04-18 15:35:20.433	\N	icon_baby_female_0306m_negative	image/svg+xml	1177	5d8ac509b7127a402e556a5090ead003	icon/baby_female_0306m_negative	t	ICON	\N	f	\N
103	AY0JFehqSaX	\N	2026-04-18 15:35:20.436	2026-04-18 15:35:20.44	\N	icon_baby_female_0306m_outline	image/svg+xml	2679	117b06f763fd3d22a3dc96eed237c784	icon/baby_female_0306m_outline	t	ICON	\N	f	\N
104	HnTGK4FDkjJ	\N	2026-04-18 15:35:20.443	2026-04-18 15:35:20.447	\N	icon_baby_female_0609m_positive	image/svg+xml	2679	d143e67855013aba5214bbd79e529732	icon/baby_female_0609m_positive	t	ICON	\N	f	\N
189	UDUSvup81f5	\N	2026-04-18 15:35:20.888	2026-04-18 15:35:20.893	\N	icon_boy_0105y_negative	image/svg+xml	1086	c83d295c001101948676fe2d906c392b	icon/boy_0105y_negative	t	ICON	\N	f	\N
105	U7sEXxIGwkP	\N	2026-04-18 15:35:20.45	2026-04-18 15:35:20.455	\N	icon_baby_female_0609m_negative	image/svg+xml	2055	fedd203c2aa57cd28a6322378097e2fe	icon/baby_female_0609m_negative	t	ICON	\N	f	\N
106	gkMAY7MOBfY	\N	2026-04-18 15:35:20.458	2026-04-18 15:35:20.462	\N	icon_baby_female_0609m_outline	image/svg+xml	4646	7ce7efc75a80a73e5008bcfcda38f12b	icon/baby_female_0609m_outline	t	ICON	\N	f	\N
107	Ilku7xGotTT	\N	2026-04-18 15:35:20.465	2026-04-18 15:35:20.469	\N	icon_baby_male_0203m_positive	image/svg+xml	764	202d9ecc072ee42fc139d831449dfe66	icon/baby_male_0203m_positive	t	ICON	\N	f	\N
108	mOxQRuXfcce	\N	2026-04-18 15:35:20.471	2026-04-18 15:35:20.474	\N	icon_baby_male_0203m_negative	image/svg+xml	772	2330fa172da8085b902aac4465636325	icon/baby_male_0203m_negative	t	ICON	\N	f	\N
109	d86Rd0fXjXH	\N	2026-04-18 15:35:20.476	2026-04-18 15:35:20.478	\N	icon_baby_male_0203m_outline	image/svg+xml	1672	769f1f15a0e10941b006ec2bcceae651	icon/baby_male_0203m_outline	t	ICON	\N	f	\N
110	BqovI4URNzk	\N	2026-04-18 15:35:20.481	2026-04-18 15:35:20.484	\N	icon_baby_male_0306m_positive	image/svg+xml	1387	bc04100984c63c9f8ccef207bf849c2a	icon/baby_male_0306m_positive	t	ICON	\N	f	\N
111	BcSp8ufI8W8	\N	2026-04-18 15:35:20.485	2026-04-18 15:35:20.488	\N	icon_baby_male_0306m_negative	image/svg+xml	1150	6fb54916a66edc3927f915a956e13b81	icon/baby_male_0306m_negative	t	ICON	\N	f	\N
112	J2svuJuFE6s	\N	2026-04-18 15:35:20.489	2026-04-18 15:35:20.492	\N	icon_baby_male_0306m_outline	image/svg+xml	2424	69f03191d52002981dc6073888a7b96c	icon/baby_male_0306m_outline	t	ICON	\N	f	\N
113	aWQ9nowaZV2	\N	2026-04-18 15:35:20.494	2026-04-18 15:35:20.497	\N	icon_baby_male_0609m_positive	image/svg+xml	2375	232c1fee90f315dc2b938261a5e4d85f	icon/baby_male_0609m_positive	t	ICON	\N	f	\N
114	GCEpDzIFIyE	\N	2026-04-18 15:35:20.499	2026-04-18 15:35:20.501	\N	icon_baby_male_0609m_negative	image/svg+xml	2012	addd517fb04131f56f6b30774ae37806	icon/baby_male_0609m_negative	t	ICON	\N	f	\N
115	WDwofr9S51j	\N	2026-04-18 15:35:20.503	2026-04-18 15:35:20.506	\N	icon_baby_male_0609m_outline	image/svg+xml	4446	6bad4dee85190b8d017ead0de2f83c26	icon/baby_male_0609m_outline	t	ICON	\N	f	\N
116	lOlriSNnFCq	\N	2026-04-18 15:35:20.508	2026-04-18 15:35:20.511	\N	icon_basic_motorcycle_positive	image/svg+xml	1820	7c81301b30e2847eaa79803650ccde22	icon/basic_motorcycle_positive	t	ICON	\N	f	\N
117	jKxuAZvmoJc	\N	2026-04-18 15:35:20.513	2026-04-18 15:35:20.516	\N	icon_basic_motorcycle_negative	image/svg+xml	1744	826e8242f8954db49795491c8ed1d974	icon/basic_motorcycle_negative	t	ICON	\N	f	\N
118	CYnfcBdSQa5	\N	2026-04-18 15:35:20.518	2026-04-18 15:35:20.521	\N	icon_basic_motorcycle_outline	image/svg+xml	1865	3453508fa87256f4ddc2f834f64c07b8	icon/basic_motorcycle_outline	t	ICON	\N	f	\N
119	Li7zJ0zKLLM	\N	2026-04-18 15:35:20.523	2026-04-18 15:35:20.526	\N	icon_bike_positive	image/svg+xml	1511	619d56d4f1bff21f9dc68183497e8daf	icon/bike_positive	t	ICON	\N	f	\N
120	TBjuh6fWT5d	\N	2026-04-18 15:35:20.528	2026-04-18 15:35:20.53	\N	icon_bike_negative	image/svg+xml	1555	ab297cb4b2dfb327af97a18f8d751d23	icon/bike_negative	t	ICON	\N	f	\N
121	Te21T0orrtD	\N	2026-04-18 15:35:20.532	2026-04-18 15:35:20.535	\N	icon_bike_outline	image/svg+xml	1511	619d56d4f1bff21f9dc68183497e8daf	icon/bike_outline	t	ICON	\N	f	\N
122	lApuLcZlbfj	\N	2026-04-18 15:35:20.538	2026-04-18 15:35:20.541	\N	icon_bills_positive	image/svg+xml	1974	0920eb8e7b4cda5cfb73b8302da519b1	icon/bills_positive	t	ICON	\N	f	\N
123	bIVqNr8XReh	\N	2026-04-18 15:35:20.543	2026-04-18 15:35:20.546	\N	icon_bills_negative	image/svg+xml	1887	e4c5a12beed2e4efd239eb542de8c970	icon/bills_negative	t	ICON	\N	f	\N
124	XF6s1NmfGvV	\N	2026-04-18 15:35:20.547	2026-04-18 15:35:20.55	\N	icon_bills_outline	image/svg+xml	2133	4f4fec1a2bcb3c26c3899ae5da770856	icon/bills_outline	t	ICON	\N	f	\N
125	fhTkwNYp4RK	\N	2026-04-18 15:35:20.553	2026-04-18 15:35:20.555	\N	icon_blister_pills_oval_x1_positive	image/svg+xml	1484	e590423ca248417bc81f3cbb44ee3f1a	icon/blister_pills_oval_x1_positive	t	ICON	\N	f	\N
126	yos8WMCOXVt	\N	2026-04-18 15:35:20.558	2026-04-18 15:35:20.56	\N	icon_blister_pills_oval_x1_negative	image/svg+xml	1526	b902d835a0f095edb982f45ded725333	icon/blister_pills_oval_x1_negative	t	ICON	\N	f	\N
127	ZRU57NjGxeW	\N	2026-04-18 15:35:20.562	2026-04-18 15:35:20.565	\N	icon_blister_pills_oval_x1_outline	image/svg+xml	1392	c60b1a29e3b96db76a5b06aa86b25011	icon/blister_pills_oval_x1_outline	t	ICON	\N	f	\N
128	EBtcrjQmRKt	\N	2026-04-18 15:35:20.567	2026-04-18 15:35:20.571	\N	icon_blister_pills_oval_x14_positive	image/svg+xml	6081	3e3dfa2a5310a7b115bd87c4ad96b29e	icon/blister_pills_oval_x14_positive	t	ICON	\N	f	\N
129	H9xNvpZnEFK	\N	2026-04-18 15:35:20.573	2026-04-18 15:35:20.577	\N	icon_blister_pills_oval_x14_negative	image/svg+xml	6395	e5ddd4796b7c49f26bd9f8d7dc4be9fb	icon/blister_pills_oval_x14_negative	t	ICON	\N	f	\N
131	Qu3y3el1yM7	\N	2026-04-18 15:35:20.584	2026-04-18 15:35:20.587	\N	icon_blister_pills_oval_x16_positive	image/svg+xml	5087	9717fcae6af36fb47c18d27821927d28	icon/blister_pills_oval_x16_positive	t	ICON	\N	f	\N
132	qlzYKfQrW3V	\N	2026-04-18 15:35:20.589	2026-04-18 15:35:20.591	\N	icon_blister_pills_oval_x16_negative	image/svg+xml	5940	b67f248bc5f205b0ed23599378e39e6d	icon/blister_pills_oval_x16_negative	t	ICON	\N	f	\N
133	vhYOj0JGMO2	\N	2026-04-18 15:35:20.594	2026-04-18 15:35:20.597	\N	icon_blister_pills_oval_x16_outline	image/svg+xml	5415	d0b044f2f85b69ebdd08eb62a5b4100e	icon/blister_pills_oval_x16_outline	t	ICON	\N	f	\N
134	tsBAouZtx0q	\N	2026-04-18 15:35:20.598	2026-04-18 15:35:20.601	\N	icon_blister_pills_oval_x4_positive	image/svg+xml	2195	e1fbc3bbf54ec04c250cf8f2fb5e1240	icon/blister_pills_oval_x4_positive	t	ICON	\N	f	\N
136	TnKxPsrC8Zl	\N	2026-04-18 15:35:20.608	2026-04-18 15:35:20.61	\N	icon_blister_pills_oval_x4_outline	image/svg+xml	2187	514c13154b637bb05801be3dd1546b25	icon/blister_pills_oval_x4_outline	t	ICON	\N	f	\N
137	k7LhRBsho1M	\N	2026-04-18 15:35:20.612	2026-04-18 15:35:20.615	\N	icon_blister_pills_round_x1_positive	image/svg+xml	1366	282e29646cf0b0199f281cb75254687e	icon/blister_pills_round_x1_positive	t	ICON	\N	f	\N
138	zW7YR8ve7TN	\N	2026-04-18 15:35:20.616	2026-04-18 15:35:20.619	\N	icon_blister_pills_round_x1_negative	image/svg+xml	1410	99bfdb129458b5d3e88450be603360f9	icon/blister_pills_round_x1_negative	t	ICON	\N	f	\N
139	whJrp0pwdja	\N	2026-04-18 15:35:20.62	2026-04-18 15:35:20.624	\N	icon_blister_pills_round_x1_outline	image/svg+xml	1274	773906a4e026dbf282056bd6516efa5d	icon/blister_pills_round_x1_outline	t	ICON	\N	f	\N
143	OImfurFEb6W	\N	2026-04-18 15:35:20.64	2026-04-18 15:35:20.643	\N	icon_blister_pills_round_x16_positive	image/svg+xml	3299	1653d3fe860d1ef3b290d961d025a724	icon/blister_pills_round_x16_positive	t	ICON	\N	f	\N
144	LaUDo4INEM5	\N	2026-04-18 15:35:20.645	2026-04-18 15:35:20.648	\N	icon_blister_pills_round_x16_negative	image/svg+xml	3763	9c31435588d74b3c1155ad0b3ff52a41	icon/blister_pills_round_x16_negative	t	ICON	\N	f	\N
203	WAu6Qmnjut6	\N	2026-04-18 15:35:20.986	2026-04-18 15:35:20.988	\N	icon_cardiogram_e_positive	image/svg+xml	1067	7092e1f6774ec7350bd59ed591cdfe28	icon/cardiogram_e_positive	t	ICON	\N	f	\N
210	nWgpWUQNMMd	\N	2026-04-18 15:35:21.021	2026-04-18 15:35:21.023	\N	icon_child_care_negative	image/svg+xml	2175	d676d0861dd6b4372ac4d10d27e29259	icon/child_care_negative	t	ICON	\N	f	\N
211	oD9PtKfYRY8	\N	2026-04-18 15:35:21.025	2026-04-18 15:35:21.028	\N	icon_child_care_outline	image/svg+xml	6974	63de0b1b92fec3a13455741810f758a2	icon/child_care_outline	t	ICON	\N	f	\N
130	YpcVL8Rg4PI	\N	2026-04-18 15:35:20.579	2026-04-18 15:35:20.582	\N	icon_blister_pills_oval_x14_outline	image/svg+xml	6640	ce0978d0d41dae34291d29a4af35ea96	icon/blister_pills_oval_x14_outline	t	ICON	\N	f	\N
135	XzPcQxWzabH	\N	2026-04-18 15:35:20.602	2026-04-18 15:35:20.605	\N	icon_blister_pills_oval_x4_negative	image/svg+xml	2315	456e1e6d5608bc6b44f9482c7d152e1f	icon/blister_pills_oval_x4_negative	t	ICON	\N	f	\N
140	l0EvIvt69XH	\N	2026-04-18 15:35:20.626	2026-04-18 15:35:20.629	\N	icon_blister_pills_round_x14_positive	image/svg+xml	5071	157caa9ab256733b4417a725b1a962eb	icon/blister_pills_round_x14_positive	t	ICON	\N	f	\N
141	kmDeF9x2SUI	\N	2026-04-18 15:35:20.63	2026-04-18 15:35:20.633	\N	icon_blister_pills_round_x14_negative	image/svg+xml	4815	510d509ef4678aaf81e7e4e8d104c472	icon/blister_pills_round_x14_negative	t	ICON	\N	f	\N
142	j4bscvy2NWE	\N	2026-04-18 15:35:20.636	2026-04-18 15:35:20.639	\N	icon_blister_pills_round_x14_outline	image/svg+xml	6124	4fa77622d03a02efe864e94cb79b7162	icon/blister_pills_round_x14_outline	t	ICON	\N	f	\N
145	unuhZkecCHb	\N	2026-04-18 15:35:20.65	2026-04-18 15:35:20.653	\N	icon_blister_pills_round_x16_outline	image/svg+xml	3803	1339f79cb7649c0868f2d2faf46cab94	icon/blister_pills_round_x16_outline	t	ICON	\N	f	\N
146	de8FBeUsxtz	\N	2026-04-18 15:35:20.655	2026-04-18 15:35:20.671	\N	icon_blister_pills_round_x4_positive	image/svg+xml	1723	5b40c0c6c90cb00365620fdc59a4fdc8	icon/blister_pills_round_x4_positive	t	ICON	\N	f	\N
147	OXOfGP6tRaE	\N	2026-04-18 15:35:20.683	2026-04-18 15:35:20.692	\N	icon_blister_pills_round_x4_negative	image/svg+xml	1851	01292de6641627a973ce12c592b52686	icon/blister_pills_round_x4_negative	t	ICON	\N	f	\N
148	h6VktlSKL87	\N	2026-04-18 15:35:20.697	2026-04-18 15:35:20.699	\N	icon_blister_pills_round_x4_outline	image/svg+xml	1715	c9cfaf724199b26ba4ab14488b5360ed	icon/blister_pills_round_x4_outline	t	ICON	\N	f	\N
149	zXf5LEe9emo	\N	2026-04-18 15:35:20.702	2026-04-18 15:35:20.704	\N	icon_blood_a_n_positive	image/svg+xml	1729	659c14090d1b4c80affe8c281cb70cb6	icon/blood_a_n_positive	t	ICON	\N	f	\N
150	QfXtLVZd3Yy	\N	2026-04-18 15:35:20.705	2026-04-18 15:35:20.707	\N	icon_blood_a_n_negative	image/svg+xml	1618	7e70d2f8b39a288ddcd27fa93ee15a87	icon/blood_a_n_negative	t	ICON	\N	f	\N
151	oZvSqz0N89h	\N	2026-04-18 15:35:20.709	2026-04-18 15:35:20.711	\N	icon_blood_a_n_outline	image/svg+xml	2152	d59a61e31154300c17d82ba449123c47	icon/blood_a_n_outline	t	ICON	\N	f	\N
152	GCHbeBXdiJj	\N	2026-04-18 15:35:20.713	2026-04-18 15:35:20.716	\N	icon_blood_a_p_positive	image/svg+xml	1844	a97ba06cabc80f831b0e3546f6b5508c	icon/blood_a_p_positive	t	ICON	\N	f	\N
153	hGib8Ns4dFs	\N	2026-04-18 15:35:20.718	2026-04-18 15:35:20.721	\N	icon_blood_a_p_negative	image/svg+xml	1751	9974290147c8df8267c4921a52af75af	icon/blood_a_p_negative	t	ICON	\N	f	\N
154	jt11she3I1T	\N	2026-04-18 15:35:20.723	2026-04-18 15:35:20.725	\N	icon_blood_a_p_outline	image/svg+xml	2156	3e610060fd69bffc467cc63d1d549b6a	icon/blood_a_p_outline	t	ICON	\N	f	\N
155	gFGQ4Gln4Jk	\N	2026-04-18 15:35:20.728	2026-04-18 15:35:20.73	\N	icon_blood_ab_n_positive	image/svg+xml	2219	3d49c14c58bd85ba0afa60c4c2942cf2	icon/blood_ab_n_positive	t	ICON	\N	f	\N
156	Ab52rrvSlQN	\N	2026-04-18 15:35:20.732	2026-04-18 15:35:20.734	\N	icon_blood_ab_n_negative	image/svg+xml	2112	14d8df03ff26050a6c1b3742d623c0e6	icon/blood_ab_n_negative	t	ICON	\N	f	\N
157	fFZdqsKMns2	\N	2026-04-18 15:35:20.736	2026-04-18 15:35:20.739	\N	icon_blood_ab_n_outline	image/svg+xml	2673	c1a239d2ce6b0321cc58401979680b99	icon/blood_ab_n_outline	t	ICON	\N	f	\N
158	qOYi2tlOW3w	\N	2026-04-18 15:35:20.741	2026-04-18 15:35:20.744	\N	icon_blood_ab_p_positive	image/svg+xml	2378	4aa2b4a145283c838f0cc2ecab061d17	icon/blood_ab_p_positive	t	ICON	\N	f	\N
159	nz6pOeQ9Wal	\N	2026-04-18 15:35:20.746	2026-04-18 15:35:20.749	\N	icon_blood_ab_p_negative	image/svg+xml	2236	22e7f3ad88350f46cfba33cdb702fd8b	icon/blood_ab_p_negative	t	ICON	\N	f	\N
160	AHHDdsAb8DS	\N	2026-04-18 15:35:20.751	2026-04-18 15:35:20.754	\N	icon_blood_ab_p_outline	image/svg+xml	2840	9fa21603f0a1f7cf37d96e2a1ba25357	icon/blood_ab_p_outline	t	ICON	\N	f	\N
161	zoRlKYgoKBV	\N	2026-04-18 15:35:20.756	2026-04-18 15:35:20.759	\N	icon_blood_b_n_positive	image/svg+xml	1605	9e693860171c2950c26c9851c6e6206c	icon/blood_b_n_positive	t	ICON	\N	f	\N
162	FXnyUdg6F8M	\N	2026-04-18 15:35:20.76	2026-04-18 15:35:20.762	\N	icon_blood_b_n_negative	image/svg+xml	1529	fac0a4eb47a667c88f4d5a143ac6e058	icon/blood_b_n_negative	t	ICON	\N	f	\N
163	sIvigj4S0Je	\N	2026-04-18 15:35:20.764	2026-04-18 15:35:20.766	\N	icon_blood_b_n_outline	image/svg+xml	2033	3c112b3fcd2b9489583bfbf4bffcc6ce	icon/blood_b_n_outline	t	ICON	\N	f	\N
164	nRWXjNRdNhF	\N	2026-04-18 15:35:20.767	2026-04-18 15:35:20.77	\N	icon_blood_b_p_positive	image/svg+xml	1774	e39b9b559344564b0c028ebaa035c5a0	icon/blood_b_p_positive	t	ICON	\N	f	\N
165	cilP4HtmlK8	\N	2026-04-18 15:35:20.772	2026-04-18 15:35:20.774	\N	icon_blood_b_p_negative	image/svg+xml	1690	6f19c535710336f8093e73694608ed6e	icon/blood_b_p_negative	t	ICON	\N	f	\N
166	ZscVqDSfawG	\N	2026-04-18 15:35:20.775	2026-04-18 15:35:20.778	\N	icon_blood_b_p_outline	image/svg+xml	2191	87cb2d617eda9450f19b44ee619defcd	icon/blood_b_p_outline	t	ICON	\N	f	\N
167	yzm7drfvkCC	\N	2026-04-18 15:35:20.779	2026-04-18 15:35:20.782	\N	icon_blood_o_n_positive	image/svg+xml	1457	75176cea5ff09482af04316f0bdfa1d9	icon/blood_o_n_positive	t	ICON	\N	f	\N
168	SlCFTwDjE9z	\N	2026-04-18 15:35:20.784	2026-04-18 15:35:20.786	\N	icon_blood_o_n_negative	image/svg+xml	1419	12cd510f5a08a2b7cf3e9043e39c5e86	icon/blood_o_n_negative	t	ICON	\N	f	\N
169	W8m9xKYvJm9	\N	2026-04-18 15:35:20.788	2026-04-18 15:35:20.79	\N	icon_blood_o_n_outline	image/svg+xml	1880	f55a4d6628c7d05415d90bc23d812159	icon/blood_o_n_outline	t	ICON	\N	f	\N
170	xj7iA7LixYO	\N	2026-04-18 15:35:20.792	2026-04-18 15:35:20.795	\N	icon_blood_o_p_positive	image/svg+xml	1621	5a302e326c73b22560cb322c5b3dc073	icon/blood_o_p_positive	t	ICON	\N	f	\N
171	FkUI4lU3WWG	\N	2026-04-18 15:35:20.796	2026-04-18 15:35:20.798	\N	icon_blood_o_p_negative	image/svg+xml	1535	34daf9d3b2be4c28d722de585d043283	icon/blood_o_p_negative	t	ICON	\N	f	\N
172	Ow6iu6Hm1f2	\N	2026-04-18 15:35:20.8	2026-04-18 15:35:20.802	\N	icon_blood_o_p_outline	image/svg+xml	2038	935db0ce61832ae9e8c3261a496f91ce	icon/blood_o_p_outline	t	ICON	\N	f	\N
173	RA663F2iaoU	\N	2026-04-18 15:35:20.803	2026-04-18 15:35:20.806	\N	icon_blood_pressure_positive	image/svg+xml	1046	8fd635fe01833d3cab39bde6e89f876a	icon/blood_pressure_positive	t	ICON	\N	f	\N
174	qWVzVaboBCq	\N	2026-04-18 15:35:20.808	2026-04-18 15:35:20.81	\N	icon_blood_pressure_negative	image/svg+xml	1005	284de80c6d4c6d199ad74859f54e671c	icon/blood_pressure_negative	t	ICON	\N	f	\N
175	ufGU4msRQGN	\N	2026-04-18 15:35:20.811	2026-04-18 15:35:20.813	\N	icon_blood_pressure_outline	image/svg+xml	2243	b50266ffae4ca28b56157681f811bd80	icon/blood_pressure_outline	t	ICON	\N	f	\N
176	snbWCLrPYgz	\N	2026-04-18 15:35:20.814	2026-04-18 15:35:20.817	\N	icon_blood_pressure_2_positive	image/svg+xml	2244	9fe695f1a8b8e86d00a37002b72f632a	icon/blood_pressure_2_positive	t	ICON	\N	f	\N
177	bjU6UxPJ9dZ	\N	2026-04-18 15:35:20.818	2026-04-18 15:35:20.82	\N	icon_blood_pressure_2_negative	image/svg+xml	2060	5fb833c4cb785cebb6abea16f0dc09ef	icon/blood_pressure_2_negative	t	ICON	\N	f	\N
178	L6SVqBnfzsK	\N	2026-04-18 15:35:20.822	2026-04-18 15:35:20.824	\N	icon_blood_pressure_2_outline	image/svg+xml	2823	34c34eaa784b12d5bf70ba1ff59bc068	icon/blood_pressure_2_outline	t	ICON	\N	f	\N
179	sTVDEc8Gwqk	\N	2026-04-18 15:35:20.826	2026-04-18 15:35:20.833	\N	icon_blood_pressure_monitor_positive	image/svg+xml	2164	728ef34ad35add86fdd14b07c2c8cb58	icon/blood_pressure_monitor_positive	t	ICON	\N	f	\N
180	zMjSd5Am4rh	\N	2026-04-18 15:35:20.838	2026-04-18 15:35:20.845	\N	icon_blood_pressure_monitor_negative	image/svg+xml	1991	048b97522b36bf40de425ef1e5f0843f	icon/blood_pressure_monitor_negative	t	ICON	\N	f	\N
181	PqYQ3Znrvj3	\N	2026-04-18 15:35:20.847	2026-04-18 15:35:20.849	\N	icon_blood_pressure_monitor_outline	image/svg+xml	2262	e06846ed6dfc0bb1f072d2a132a13b38	icon/blood_pressure_monitor_outline	t	ICON	\N	f	\N
182	DCe7QpfQaRB	\N	2026-04-18 15:35:20.851	2026-04-18 15:35:20.854	\N	icon_blood_rh_n_positive	image/svg+xml	1878	8022c0432a57f2ca552ebe04a555b5eb	icon/blood_rh_n_positive	t	ICON	\N	f	\N
183	mp2D3cDLGEA	\N	2026-04-18 15:35:20.855	2026-04-18 15:35:20.858	\N	icon_blood_rh_n_negative	image/svg+xml	1814	d1cf76d42b19505610968b11f1cde4be	icon/blood_rh_n_negative	t	ICON	\N	f	\N
184	hC5pUrKCwl4	\N	2026-04-18 15:35:20.859	2026-04-18 15:35:20.862	\N	icon_blood_rh_n_outline	image/svg+xml	2331	ccd40c36b688737bc9b76d02beacef4b	icon/blood_rh_n_outline	t	ICON	\N	f	\N
185	evvLxkYAolN	\N	2026-04-18 15:35:20.864	2026-04-18 15:35:20.867	\N	icon_blood_rh_p_positive	image/svg+xml	2004	d5f6ee2cd1102547ec70cbfc178cca4d	icon/blood_rh_p_positive	t	ICON	\N	f	\N
186	uTUCvYSu1ei	\N	2026-04-18 15:35:20.868	2026-04-18 15:35:20.871	\N	icon_blood_rh_p_negative	image/svg+xml	1934	f290e04caa895d93f547e38482192cbb	icon/blood_rh_p_negative	t	ICON	\N	f	\N
187	d7wYa31vf2S	\N	2026-04-18 15:35:20.872	2026-04-18 15:35:20.876	\N	icon_blood_rh_p_outline	image/svg+xml	2466	13848c6fc5d4597a140df3fc93a11980	icon/blood_rh_p_outline	t	ICON	\N	f	\N
188	B82KSMwIwD9	\N	2026-04-18 15:35:20.878	2026-04-18 15:35:20.884	\N	icon_boy_0105y_positive	image/svg+xml	1141	41e9a873544bf08368365348aca2058f	icon/boy_0105y_positive	t	ICON	\N	f	\N
190	liOBIdRPE5o	\N	2026-04-18 15:35:20.895	2026-04-18 15:35:20.903	\N	icon_boy_0105y_outline	image/svg+xml	2029	e57baa152cb42144ce8e15ac9ecda950	icon/boy_0105y_outline	t	ICON	\N	f	\N
191	vBjlvDNvAhB	\N	2026-04-18 15:35:20.904	2026-04-18 15:35:20.907	\N	icon_boy_1015y_positive	image/svg+xml	1941	e8f33f2ccf3b51af3a4fd0fcb7c139c2	icon/boy_1015y_positive	t	ICON	\N	f	\N
246	pPwkx44ZWBS	\N	2026-04-18 15:35:21.162	2026-04-18 15:35:21.165	\N	icon_clinical_f_negative	image/svg+xml	912	a0778ddc9df083afb228c1e48dd5c92e	icon/clinical_f_negative	t	ICON	\N	f	\N
256	msmkuws1SMn	\N	2026-04-18 15:35:21.23	2026-04-18 15:35:21.233	\N	icon_cold_chain_outline	image/svg+xml	2707	8c8a9335b2fda2d495809293c2ed787c	icon/cold_chain_outline	t	ICON	\N	f	\N
257	abPiLpKEd7O	\N	2026-04-18 15:35:21.237	2026-04-18 15:35:21.242	\N	icon_communication_positive	image/svg+xml	2344	e7aa9b77915bbea977965d9646faf382	icon/communication_positive	t	ICON	\N	f	\N
258	TaWDtrPBtjt	\N	2026-04-18 15:35:21.244	2026-04-18 15:35:21.251	\N	icon_communication_negative	image/svg+xml	2047	eeae577d0b0b2562f9658cb227401d1b	icon/communication_negative	t	ICON	\N	f	\N
262	OYSRQhjY5ZN	\N	2026-04-18 15:35:21.278	2026-04-18 15:35:21.284	\N	icon_cone_test_on_nets_outline	image/svg+xml	16823	f445e74fce936170c3c76b6ab379ae3e	icon/cone_test_on_nets_outline	t	ICON	\N	f	\N
263	XMeo8o5Q6XZ	\N	2026-04-18 15:35:21.286	2026-04-18 15:35:21.293	\N	icon_cone_test_on_walls_positive	image/svg+xml	6846	97a24b551fb86d48c09f713bc5597c96	icon/cone_test_on_walls_positive	t	ICON	\N	f	\N
264	GOfOOm8dS96	\N	2026-04-18 15:35:21.295	2026-04-18 15:35:21.301	\N	icon_cone_test_on_walls_negative	image/svg+xml	5702	8da89c9502078db8fad25567b7cdd6f6	icon/cone_test_on_walls_negative	t	ICON	\N	f	\N
265	bAshDh3Chh2	\N	2026-04-18 15:35:21.303	2026-04-18 15:35:21.305	\N	icon_cone_test_on_walls_outline	image/svg+xml	6715	78733b648190cb004ca27e3c3ea9a268	icon/cone_test_on_walls_outline	t	ICON	\N	f	\N
266	A76ZtH6M35O	\N	2026-04-18 15:35:21.307	2026-04-18 15:35:21.308	\N	icon_construction_positive	image/svg+xml	767	7780fb284a38ca1a37fbcbbc98505b47	icon/construction_positive	t	ICON	\N	f	\N
267	wasSayCIgLJ	\N	2026-04-18 15:35:21.31	2026-04-18 15:35:21.313	\N	icon_construction_negative	image/svg+xml	783	708310088a0e5e4ffe6c751f8f705ab2	icon/construction_negative	t	ICON	\N	f	\N
268	L94VoNmf1XR	\N	2026-04-18 15:35:21.315	2026-04-18 15:35:21.318	\N	icon_construction_outline	image/svg+xml	804	d9aaa20f31c6a02da95edf155c46e325	icon/construction_outline	t	ICON	\N	f	\N
269	YXtiWYzly19	\N	2026-04-18 15:35:21.319	2026-04-18 15:35:21.321	\N	icon_construction_worker_positive	image/svg+xml	2026	5c9f6d08d37eec82b9f570de9e475f70	icon/construction_worker_positive	t	ICON	\N	f	\N
273	vENbdAxER4w	\N	2026-04-18 15:35:21.341	2026-04-18 15:35:21.349	\N	icon_contact_support_negative	image/svg+xml	1401	9145e7b2c06b41fa7f8522e9838c7904	icon/contact_support_negative	t	ICON	\N	f	\N
274	lg9zoW03fOa	\N	2026-04-18 15:35:21.351	2026-04-18 15:35:21.356	\N	icon_contact_support_outline	image/svg+xml	1687	2587491e3f42432b5dd4ed5067f1ebea	icon/contact_support_outline	t	ICON	\N	f	\N
192	i02jHEPyrOo	\N	2026-04-18 15:35:20.911	2026-04-18 15:35:20.916	\N	icon_boy_1015y_negative	image/svg+xml	1408	40598e8124b4d8574c5046d9c5980ab6	icon/boy_1015y_negative	t	ICON	\N	f	\N
193	GFvwmHACT5D	\N	2026-04-18 15:35:20.92	2026-04-18 15:35:20.924	\N	icon_boy_1015y_outline	image/svg+xml	4994	74cc3b3e68f26a5c953e7ba64be6f205	icon/boy_1015y_outline	t	ICON	\N	f	\N
194	tEuT6A1C00J	\N	2026-04-18 15:35:20.928	2026-04-18 15:35:20.932	\N	icon_breeding_sites_positive	image/svg+xml	3541	52f37c7f0d14b0d44f206bb65a20f8c7	icon/breeding_sites_positive	t	ICON	\N	f	\N
195	liihPP47FOh	\N	2026-04-18 15:35:20.936	2026-04-18 15:35:20.943	\N	icon_breeding_sites_negative	image/svg+xml	3510	25f38dfa231bd3265e5e91f1cfe43fc1	icon/breeding_sites_negative	t	ICON	\N	f	\N
196	NOSB2kvw5F6	\N	2026-04-18 15:35:20.951	2026-04-18 15:35:20.955	\N	icon_breeding_sites_outline	image/svg+xml	5949	7e00d49f2101287a8f4e4f65b63e2f87	icon/breeding_sites_outline	t	ICON	\N	f	\N
197	zBr7EAh73ZQ	\N	2026-04-18 15:35:20.957	2026-04-18 15:35:20.959	\N	icon_calendar_positive	image/svg+xml	1916	f6f4c9ac868f0c8810bb438541be02ad	icon/calendar_positive	t	ICON	\N	f	\N
198	AhUxG5tykhE	\N	2026-04-18 15:35:20.961	2026-04-18 15:35:20.963	\N	icon_calendar_negative	image/svg+xml	1524	aa963c555080e0d08b6a37fe0b1a595f	icon/calendar_negative	t	ICON	\N	f	\N
199	s0SKF5YPoGh	\N	2026-04-18 15:35:20.966	2026-04-18 15:35:20.969	\N	icon_calendar_outline	image/svg+xml	2154	565cb0a705ac36efd985f63dd2eaf8a9	icon/calendar_outline	t	ICON	\N	f	\N
200	KEUDoENSUoC	\N	2026-04-18 15:35:20.971	2026-04-18 15:35:20.973	\N	icon_cardiogram_positive	image/svg+xml	954	5d223da8226bf1f330622ffb9f884020	icon/cardiogram_positive	t	ICON	\N	f	\N
201	mzYHoNoii0V	\N	2026-04-18 15:35:20.975	2026-04-18 15:35:20.978	\N	icon_cardiogram_negative	image/svg+xml	1079	70f04e9e44479b2e01ccb9c482f02d94	icon/cardiogram_negative	t	ICON	\N	f	\N
202	J8A5PPN3Bzh	\N	2026-04-18 15:35:20.981	2026-04-18 15:35:20.984	\N	icon_cardiogram_outline	image/svg+xml	1142	03429c144fae5a96a05657f8b41828cd	icon/cardiogram_outline	t	ICON	\N	f	\N
204	jriWSnAJYga	\N	2026-04-18 15:35:20.99	2026-04-18 15:35:20.992	\N	icon_cardiogram_e_negative	image/svg+xml	1111	4aa292dfe436f2d0363a4911eb40b97d	icon/cardiogram_e_negative	t	ICON	\N	f	\N
205	TQnHyz96gcl	\N	2026-04-18 15:35:20.994	2026-04-18 15:35:20.997	\N	icon_cardiogram_e_outline	image/svg+xml	1438	28db93598cb96dd1328fffa529ef55ce	icon/cardiogram_e_outline	t	ICON	\N	f	\N
206	EtY8omPDaID	\N	2026-04-18 15:35:21	2026-04-18 15:35:21.003	\N	icon_cervical_cancer_positive	image/svg+xml	1083	52de1377c1f96adec09da0c8a5dafe49	icon/cervical_cancer_positive	t	ICON	\N	f	\N
207	zBa5ElnaAK7	\N	2026-04-18 15:35:21.006	2026-04-18 15:35:21.009	\N	icon_cervical_cancer_negative	image/svg+xml	1172	3f8f166a55938fc027c5191a7224b6a4	icon/cervical_cancer_negative	t	ICON	\N	f	\N
208	ZIKRU3PL0C9	\N	2026-04-18 15:35:21.011	2026-04-18 15:35:21.014	\N	icon_cervical_cancer_outline	image/svg+xml	1386	064cdb803acac146c10b8d736865a22e	icon/cervical_cancer_outline	t	ICON	\N	f	\N
209	lpo8vP874T7	\N	2026-04-18 15:35:21.016	2026-04-18 15:35:21.02	\N	icon_child_care_positive	image/svg+xml	2222	6ae1f9f1889db743e8d77b22d2c1d504	icon/child_care_positive	t	ICON	\N	f	\N
212	yOXKDXupVVq	\N	2026-04-18 15:35:21.031	2026-04-18 15:35:21.033	\N	icon_child_program_positive	image/svg+xml	4023	4de9afc7215d8cb5acb060b4b2a03f2a	icon/child_program_positive	t	ICON	\N	f	\N
213	CLuMOY4IY0G	\N	2026-04-18 15:35:21.035	2026-04-18 15:35:21.038	\N	icon_child_program_negative	image/svg+xml	12351	a833aac3a483f9d8e7b65e5132fa6a04	icon/child_program_negative	t	ICON	\N	f	\N
214	R464vEHF3LN	\N	2026-04-18 15:35:21.039	2026-04-18 15:35:21.041	\N	icon_child_program_outline	image/svg+xml	5558	525a5a0f2fb8de20fcb888e038401b29	icon/child_program_outline	t	ICON	\N	f	\N
215	DdogCb71Zi9	\N	2026-04-18 15:35:21.043	2026-04-18 15:35:21.046	\N	icon_chills_positive	image/svg+xml	7362	b2797247ac1e38e5d0fc39bb4b97d22b	icon/chills_positive	t	ICON	\N	f	\N
216	yHDKv4hOE3M	\N	2026-04-18 15:35:21.047	2026-04-18 15:35:21.05	\N	icon_chills_negative	image/svg+xml	6825	b6613da68703cbf4d7c38374924a03ef	icon/chills_negative	t	ICON	\N	f	\N
217	svgBcm3kUAi	\N	2026-04-18 15:35:21.051	2026-04-18 15:35:21.054	\N	icon_chills_outline	image/svg+xml	7664	853dfe8973821d1d1dbfff3bc061bcae	icon/chills_outline	t	ICON	\N	f	\N
218	gJvMOP222IV	\N	2026-04-18 15:35:21.055	2026-04-18 15:35:21.058	\N	icon_cholera_positive	image/svg+xml	1554	66fa3218032b8492ab7861622ae3efd3	icon/cholera_positive	t	ICON	\N	f	\N
219	Z5zeZmeYWx3	\N	2026-04-18 15:35:21.06	2026-04-18 15:35:21.062	\N	icon_cholera_negative	image/svg+xml	1681	6eec03fc223a533769621f14c2c9e32c	icon/cholera_negative	t	ICON	\N	f	\N
220	sg7vSEWWo73	\N	2026-04-18 15:35:21.063	2026-04-18 15:35:21.065	\N	icon_cholera_outline	image/svg+xml	2120	d6ded6efab0232288c5dba79942645b5	icon/cholera_outline	t	ICON	\N	f	\N
221	ybDetagkP9o	\N	2026-04-18 15:35:21.067	2026-04-18 15:35:21.07	\N	icon_church_positive	image/svg+xml	522	8cb088b75ba1bd508178dc67afbc4d1a	icon/church_positive	t	ICON	\N	f	\N
222	P9lnyh02lQv	\N	2026-04-18 15:35:21.071	2026-04-18 15:35:21.074	\N	icon_church_negative	image/svg+xml	506	cfbf4ee239670ed9151376e057c8162c	icon/church_negative	t	ICON	\N	f	\N
223	BQfADayMyXX	\N	2026-04-18 15:35:21.075	2026-04-18 15:35:21.077	\N	icon_church_outline	image/svg+xml	907	b8e42f4dbeaaed63cf4ce223f83c976a	icon/church_outline	t	ICON	\N	f	\N
224	Tu0CmfSeNkx	\N	2026-04-18 15:35:21.078	2026-04-18 15:35:21.08	\N	icon_circle_large_positive	image/svg+xml	616	61b92686fd08bf49726b96dfe739d0ed	icon/circle_large_positive	t	ICON	\N	f	\N
225	dfvR5PRN0K4	\N	2026-04-18 15:35:21.082	2026-04-18 15:35:21.084	\N	icon_circle_large_negative	image/svg+xml	733	607355ce83a854fddc71d072f6308916	icon/circle_large_negative	t	ICON	\N	f	\N
226	Ft4XUONbwft	\N	2026-04-18 15:35:21.086	2026-04-18 15:35:21.088	\N	icon_circle_large_outline	image/svg+xml	397	ccc2a8e45ff14535c9abf615a7acc225	icon/circle_large_outline	t	ICON	\N	f	\N
227	uVqoc7ZK3H0	\N	2026-04-18 15:35:21.09	2026-04-18 15:35:21.092	\N	icon_circle_medium_positive	image/svg+xml	259	5d276e21ca12c53c5273bb35d2567fc2	icon/circle_medium_positive	t	ICON	\N	f	\N
234	WEeJ7p6TpnT	\N	2026-04-18 15:35:21.115	2026-04-18 15:35:21.118	\N	icon_city_negative	image/svg+xml	830	d2c6f2e23ffc3bdb5b8361c7cbabf340	icon/city_negative	t	ICON	\N	f	\N
235	UjRcUyGgOwt	\N	2026-04-18 15:35:21.119	2026-04-18 15:35:21.121	\N	icon_city_outline	image/svg+xml	1446	62cec2dec34f0d25d6facba2ec4669bf	icon/city_outline	t	ICON	\N	f	\N
236	qZZq6ah7DTF	\N	2026-04-18 15:35:21.122	2026-04-18 15:35:21.124	\N	icon_city_worker_positive	image/svg+xml	1069	89f2278c9e9c42e18ecf110037bc2cfb	icon/city_worker_positive	t	ICON	\N	f	\N
247	XyAdEYc0Hgk	\N	2026-04-18 15:35:21.167	2026-04-18 15:35:21.169	\N	icon_clinical_f_outline	image/svg+xml	1198	d049e6275a6635566a476ece11647e19	icon/clinical_f_outline	t	ICON	\N	f	\N
248	f0m9Zqwhp2v	\N	2026-04-18 15:35:21.171	2026-04-18 15:35:21.173	\N	icon_clinical_fe_positive	image/svg+xml	925	6abc3f22d46d59922e3740fe19c2327e	icon/clinical_fe_positive	t	ICON	\N	f	\N
249	UVaQopSLulj	\N	2026-04-18 15:35:21.174	2026-04-18 15:35:21.191	\N	icon_clinical_fe_negative	image/svg+xml	997	51f7b418812b993d1b257a93de0a2e9e	icon/clinical_fe_negative	t	ICON	\N	f	\N
228	lhjQZOrtynF	\N	2026-04-18 15:35:21.094	2026-04-18 15:35:21.096	\N	icon_circle_medium_negative	image/svg+xml	310	cfbf9a5e56aad16cc8e1a14b6acdf7a8	icon/circle_medium_negative	t	ICON	\N	f	\N
229	ogiFiBmPHmG	\N	2026-04-18 15:35:21.097	2026-04-18 15:35:21.099	\N	icon_circle_medium_outline	image/svg+xml	395	c2dceeba4bb0e5ade379dd1bf77618ab	icon/circle_medium_outline	t	ICON	\N	f	\N
230	FDhkaSMSK2z	\N	2026-04-18 15:35:21.101	2026-04-18 15:35:21.103	\N	icon_circle_small_positive	image/svg+xml	250	5918b59eb9082c8880a6619310502d74	icon/circle_small_positive	t	ICON	\N	f	\N
231	JQhMgAzlKFl	\N	2026-04-18 15:35:21.105	2026-04-18 15:35:21.107	\N	icon_circle_small_negative	image/svg+xml	306	c4b206f7eed88e8d4c66ae2870266b8d	icon/circle_small_negative	t	ICON	\N	f	\N
232	b9Avnd19iXE	\N	2026-04-18 15:35:21.108	2026-04-18 15:35:21.11	\N	icon_circle_small_outline	image/svg+xml	409	22c51e6d9093f1c8b1d67800a013a81c	icon/circle_small_outline	t	ICON	\N	f	\N
233	iAr3tT6GxAe	\N	2026-04-18 15:35:21.111	2026-04-18 15:35:21.113	\N	icon_city_positive	image/svg+xml	904	ab97978a7fae3a65f36e80fcb97f01d9	icon/city_positive	t	ICON	\N	f	\N
237	T0tsu2P9QkZ	\N	2026-04-18 15:35:21.125	2026-04-18 15:35:21.127	\N	icon_city_worker_negative	image/svg+xml	1174	7bb162a8012a5e663f4ecb81059fe1a2	icon/city_worker_negative	t	ICON	\N	f	\N
238	FBBTzOIqYWk	\N	2026-04-18 15:35:21.129	2026-04-18 15:35:21.132	\N	icon_city_worker_outline	image/svg+xml	1703	97ae4da68c43ee4c2f13de9f2f7198da	icon/city_worker_outline	t	ICON	\N	f	\N
239	RVszO6BSZFL	\N	2026-04-18 15:35:21.134	2026-04-18 15:35:21.136	\N	icon_clean_hands_positive	image/svg+xml	1325	bbf41be4ef822df3a25a1d231e9eb768	icon/clean_hands_positive	t	ICON	\N	f	\N
240	s76mUdraxBb	\N	2026-04-18 15:35:21.138	2026-04-18 15:35:21.14	\N	icon_clean_hands_negative	image/svg+xml	1291	39c8eead47509e9a4b27cec3c2088960	icon/clean_hands_negative	t	ICON	\N	f	\N
241	anwHkjlhxTL	\N	2026-04-18 15:35:21.142	2026-04-18 15:35:21.144	\N	icon_clean_hands_outline	image/svg+xml	3952	283697447c002456bc70e96ff7b7da0f	icon/clean_hands_outline	t	ICON	\N	f	\N
242	GioIUPUgqGj	\N	2026-04-18 15:35:21.146	2026-04-18 15:35:21.148	\N	icon_clinical_a_positive	image/svg+xml	562	59329699b965e1a12dc9458c5f79dc55	icon/clinical_a_positive	t	ICON	\N	f	\N
243	Nb79AImB1gr	\N	2026-04-18 15:35:21.15	2026-04-18 15:35:21.152	\N	icon_clinical_a_negative	image/svg+xml	572	467c9d9823d22c56200187d1d0b371a7	icon/clinical_a_negative	t	ICON	\N	f	\N
244	nGi7KiFajKA	\N	2026-04-18 15:35:21.153	2026-04-18 15:35:21.156	\N	icon_clinical_a_outline	image/svg+xml	946	056f4df857695cfa04b0c5aff01d8d52	icon/clinical_a_outline	t	ICON	\N	f	\N
245	WnMO7yqULMK	\N	2026-04-18 15:35:21.157	2026-04-18 15:35:21.16	\N	icon_clinical_f_positive	image/svg+xml	897	51023428befdbc7b0def177bfe372538	icon/clinical_f_positive	t	ICON	\N	f	\N
250	aBKYmhXgp29	\N	2026-04-18 15:35:21.194	2026-04-18 15:35:21.207	\N	icon_clinical_fe_outline	image/svg+xml	1326	8a3527532465a9eed8fa1e9140413c98	icon/clinical_fe_outline	t	ICON	\N	f	\N
251	p2cbKQrvB7r	\N	2026-04-18 15:35:21.209	2026-04-18 15:35:21.211	\N	icon_coins_positive	image/svg+xml	1992	52f7af05771ee07696419a7dd9ad0bda	icon/coins_positive	t	ICON	\N	f	\N
252	REXcqGQeUnX	\N	2026-04-18 15:35:21.212	2026-04-18 15:35:21.214	\N	icon_coins_negative	image/svg+xml	1233	dd769ea4e9e77c104f679e39c2574ad0	icon/coins_negative	t	ICON	\N	f	\N
253	pGJLOop7S3q	\N	2026-04-18 15:35:21.215	2026-04-18 15:35:21.218	\N	icon_coins_outline	image/svg+xml	1778	ea72e0890931c27cf4b3023828fe2f1f	icon/coins_outline	t	ICON	\N	f	\N
254	KiwS2lZeDUY	\N	2026-04-18 15:35:21.22	2026-04-18 15:35:21.222	\N	icon_cold_chain_positive	image/svg+xml	1718	6a45b0b15dd33f8ef477d18670fef669	icon/cold_chain_positive	t	ICON	\N	f	\N
255	AuJBgShvOsC	\N	2026-04-18 15:35:21.223	2026-04-18 15:35:21.225	\N	icon_cold_chain_negative	image/svg+xml	1520	913596d4c64b779033eeeacaffe91f79	icon/cold_chain_negative	t	ICON	\N	f	\N
259	X26Srhcui2Q	\N	2026-04-18 15:35:21.253	2026-04-18 15:35:21.256	\N	icon_communication_outline	image/svg+xml	2718	cd89f2d136d6757ed180b1d5c33d4f82	icon/communication_outline	t	ICON	\N	f	\N
260	Yruz4GRiZow	\N	2026-04-18 15:35:21.258	2026-04-18 15:35:21.265	\N	icon_cone_test_on_nets_positive	image/svg+xml	16967	cdccd289dda00df282ae25aaf2b7cc62	icon/cone_test_on_nets_positive	t	ICON	\N	f	\N
261	a6n7XjzgHjj	\N	2026-04-18 15:35:21.267	2026-04-18 15:35:21.274	\N	icon_cone_test_on_nets_negative	image/svg+xml	16983	56af3d39f785e61bb22631547b32a1e3	icon/cone_test_on_nets_negative	t	ICON	\N	f	\N
270	AJj35xOpI1J	\N	2026-04-18 15:35:21.324	2026-04-18 15:35:21.33	\N	icon_construction_worker_negative	image/svg+xml	1806	22731cdc833e9d029045109469b0e400	icon/construction_worker_negative	t	ICON	\N	f	\N
271	aZLjvlBxpCt	\N	2026-04-18 15:35:21.332	2026-04-18 15:35:21.334	\N	icon_construction_worker_outline	image/svg+xml	3204	f97b0e8efaa0704f1087521a779388b5	icon/construction_worker_outline	t	ICON	\N	f	\N
272	f2DKyiPhECR	\N	2026-04-18 15:35:21.335	2026-04-18 15:35:21.34	\N	icon_contact_support_positive	image/svg+xml	1284	8c4f10e04bdce6183b1071071a7a128a	icon/contact_support_positive	t	ICON	\N	f	\N
275	RdNURo80Vri	\N	2026-04-18 15:35:21.36	2026-04-18 15:35:21.37	\N	icon_contraceptive_diaphragm_positive	image/svg+xml	1338	0122fee854ea5130a163c5a58c7a6b2b	icon/contraceptive_diaphragm_positive	t	ICON	\N	f	\N
276	fEj1XR70FYV	\N	2026-04-18 15:35:21.373	2026-04-18 15:35:21.376	\N	icon_contraceptive_diaphragm_negative	image/svg+xml	1357	f5b030f14b222814c3e2d2b8fb14dc17	icon/contraceptive_diaphragm_negative	t	ICON	\N	f	\N
277	IuKQQ0q4bh4	\N	2026-04-18 15:35:21.378	2026-04-18 15:35:21.38	\N	icon_contraceptive_diaphragm_outline	image/svg+xml	2159	2118c7f3bddab4274f00d57bfa68889e	icon/contraceptive_diaphragm_outline	t	ICON	\N	f	\N
278	ytqXeAgeC9r	\N	2026-04-18 15:35:21.382	2026-04-18 15:35:21.384	\N	icon_contraceptive_injection_positive	image/svg+xml	2387	5407a11c331c6e115dc8cd519f6ca950	icon/contraceptive_injection_positive	t	ICON	\N	f	\N
279	lnx7bYZZoNn	\N	2026-04-18 15:35:21.386	2026-04-18 15:35:21.389	\N	icon_contraceptive_injection_negative	image/svg+xml	2397	6656cd3f607600b5b7d84074b6b4d797	icon/contraceptive_injection_negative	t	ICON	\N	f	\N
280	aJ9ZE6nvlVd	\N	2026-04-18 15:35:21.39	2026-04-18 15:35:21.393	\N	icon_contraceptive_injection_outline	image/svg+xml	2687	213b80a882b4bc1e8e55d5fa360e9180	icon/contraceptive_injection_outline	t	ICON	\N	f	\N
281	ZBZgpoZfno6	\N	2026-04-18 15:35:21.394	2026-04-18 15:35:21.396	\N	icon_contraceptive_patch_positive	image/svg+xml	3252	f8cfb99aee4c46d978ead995928a3ef3	icon/contraceptive_patch_positive	t	ICON	\N	f	\N
282	quMPOwESxa0	\N	2026-04-18 15:35:21.399	2026-04-18 15:35:21.401	\N	icon_contraceptive_patch_negative	image/svg+xml	3264	34189551a581337262fa2ea7e6487a23	icon/contraceptive_patch_negative	t	ICON	\N	f	\N
283	jZHiLcJQ6x7	\N	2026-04-18 15:35:21.402	2026-04-18 15:35:21.405	\N	icon_contraceptive_patch_outline	image/svg+xml	3918	9b28c4798393c775af616bfb7b55a0c1	icon/contraceptive_patch_outline	t	ICON	\N	f	\N
284	bDaXdVbZnKV	\N	2026-04-18 15:35:21.406	2026-04-18 15:35:21.409	\N	icon_contraceptive_voucher_positive	image/svg+xml	1289	c55d8261092eb16f2197b3b92e038f59	icon/contraceptive_voucher_positive	t	ICON	\N	f	\N
285	esWulWxvsgD	\N	2026-04-18 15:35:21.411	2026-04-18 15:35:21.413	\N	icon_contraceptive_voucher_negative	image/svg+xml	1442	f286f25244afcb1908ce5c6464482ebe	icon/contraceptive_voucher_negative	t	ICON	\N	f	\N
286	FY10fXnX3SU	\N	2026-04-18 15:35:21.415	2026-04-18 15:35:21.417	\N	icon_contraceptive_voucher_outline	image/svg+xml	1580	a33bdc48b3bc0a61e49b9524fcf720e1	icon/contraceptive_voucher_outline	t	ICON	\N	f	\N
287	aOl2nK0yShu	\N	2026-04-18 15:35:21.419	2026-04-18 15:35:21.421	\N	icon_copper_iud_positive	image/svg+xml	1090	5dbaf6e93ff4ede40204d6d53e099b75	icon/copper_iud_positive	t	ICON	\N	f	\N
288	TRaUg5o4g6n	\N	2026-04-18 15:35:21.423	2026-04-18 15:35:21.426	\N	icon_copper_iud_negative	image/svg+xml	918	d746fc50b017f0e8a956dabe2f2ebd83	icon/copper_iud_negative	t	ICON	\N	f	\N
289	c3REQ3RNnxo	\N	2026-04-18 15:35:21.427	2026-04-18 15:35:21.429	\N	icon_copper_iud_outline	image/svg+xml	1090	b350bdf1a3f7811fc6e490f4bc9a4b16	icon/copper_iud_outline	t	ICON	\N	f	\N
290	JXgqrxutbjk	\N	2026-04-18 15:35:21.431	2026-04-18 15:35:21.433	\N	icon_coughing_positive	image/svg+xml	3842	02aeee6e7f1139c0d7bd8c6a941f71f0	icon/coughing_positive	t	ICON	\N	f	\N
291	hc8qp2MOz0m	\N	2026-04-18 15:35:21.439	2026-04-18 15:35:21.44	\N	icon_coughing_negative	image/svg+xml	2947	ca8263dd64d9d30002133ff1b4bcfb01	icon/coughing_negative	t	ICON	\N	f	\N
292	M76VyTNcLFx	\N	2026-04-18 15:35:21.442	2026-04-18 15:35:21.444	\N	icon_coughing_outline	image/svg+xml	4083	5ffff294804499589fd9ab07435e2bd6	icon/coughing_outline	t	ICON	\N	f	\N
293	xn6HRdSQo43	\N	2026-04-18 15:35:21.445	2026-04-18 15:35:21.448	\N	icon_credit_card_positive	image/svg+xml	314	9b1b012082dd44190a601e475ecd29b3	icon/credit_card_positive	t	ICON	\N	f	\N
294	EDnTuDyZWaN	\N	2026-04-18 15:35:21.449	2026-04-18 15:35:21.452	\N	icon_credit_card_negative	image/svg+xml	329	d93af86671a369c095f71fe60f501dfc	icon/credit_card_negative	t	ICON	\N	f	\N
295	DZwQpeGLgv3	\N	2026-04-18 15:35:21.453	2026-04-18 15:35:21.456	\N	icon_credit_card_outline	image/svg+xml	438	8029730879269e9ed6aa1da97c851c2a	icon/credit_card_outline	t	ICON	\N	f	\N
296	w4JeDOVoikd	\N	2026-04-18 15:35:21.457	2026-04-18 15:35:21.46	\N	icon_cross_country_motorcycle_positive	image/svg+xml	2205	0dab4e86b2c8e4e4b4ba1e3c3cc7d440	icon/cross_country_motorcycle_positive	t	ICON	\N	f	\N
297	puirsluhlnm	\N	2026-04-18 15:35:21.461	2026-04-18 15:35:21.464	\N	icon_cross_country_motorcycle_negative	image/svg+xml	2060	4fbf1656d6141fbc7c9bbf602ccd607a	icon/cross_country_motorcycle_negative	t	ICON	\N	f	\N
298	Bp2qZyTaibu	\N	2026-04-18 15:35:21.465	2026-04-18 15:35:21.468	\N	icon_cross_country_motorcycle_outline	image/svg+xml	2046	4e63ea20debbc11ec24f76197b5ca42b	icon/cross_country_motorcycle_outline	t	ICON	\N	f	\N
299	fNFPByRibjj	\N	2026-04-18 15:35:21.47	2026-04-18 15:35:21.471	\N	icon_default_positive	image/svg+xml	1287	ce6e1540355bb4948e1b69017670ec97	icon/default_positive	t	ICON	\N	f	\N
300	XkIK1ZMQ5Ez	\N	2026-04-18 15:35:21.473	2026-04-18 15:35:21.475	\N	icon_default_negative	image/svg+xml	1408	3ae41732ebda0228c2069a3925809317	icon/default_negative	t	ICON	\N	f	\N
301	IncVtDBmfeu	\N	2026-04-18 15:35:21.476	2026-04-18 15:35:21.478	\N	icon_default_outline	image/svg+xml	1633	7691bd86874c6414edb565e45e88eb6a	icon/default_outline	t	ICON	\N	f	\N
302	ZNwfpSPsz6J	\N	2026-04-18 15:35:21.48	2026-04-18 15:35:21.483	\N	icon_dhis2_logo_positive	image/svg+xml	2163	580de4d2f18d5271534855428c94eb26	icon/dhis2_logo_positive	t	ICON	\N	f	\N
303	qpDkytN1Ohf	\N	2026-04-18 15:35:21.484	2026-04-18 15:35:21.486	\N	icon_dhis2_logo_negative	image/svg+xml	2191	f096d6dcbb593e5b3aa4a412277a95cc	icon/dhis2_logo_negative	t	ICON	\N	f	\N
304	He6F4WZRVp9	\N	2026-04-18 15:35:21.487	2026-04-18 15:35:21.49	\N	icon_dhis2_logo_outline	image/svg+xml	2163	580de4d2f18d5271534855428c94eb26	icon/dhis2_logo_outline	t	ICON	\N	f	\N
305	CLSkEpWmvoq	\N	2026-04-18 15:35:21.492	2026-04-18 15:35:21.495	\N	icon_diarrhea_positive	image/svg+xml	2705	b5cdfe2935f9488b7cd362c6a81879cc	icon/diarrhea_positive	t	ICON	\N	f	\N
306	HIzVUOnkfsN	\N	2026-04-18 15:35:21.497	2026-04-18 15:35:21.5	\N	icon_diarrhea_negative	image/svg+xml	2801	8f5d877dcca77261ea45d4fab67d8806	icon/diarrhea_negative	t	ICON	\N	f	\N
307	VM6W6alFYd1	\N	2026-04-18 15:35:21.502	2026-04-18 15:35:21.505	\N	icon_diarrhea_outline	image/svg+xml	3410	60f85225d4919f3575054a3d4a2908d5	icon/diarrhea_outline	t	ICON	\N	f	\N
308	fHdR1aTNGSH	\N	2026-04-18 15:35:21.506	2026-04-18 15:35:21.508	\N	icon_discriminating_concentration_bioassays_positive	image/svg+xml	4725	6bb983d6035f3b494b7194d04813b4b8	icon/discriminating_concentration_bioassays_positive	t	ICON	\N	f	\N
309	Neo7GeShXXB	\N	2026-04-18 15:35:21.51	2026-04-18 15:35:21.512	\N	icon_discriminating_concentration_bioassays_negative	image/svg+xml	4747	80ae299789aca3e9e9dd6d3951f87e73	icon/discriminating_concentration_bioassays_negative	t	ICON	\N	f	\N
310	yW6xjOdq2nS	\N	2026-04-18 15:35:21.513	2026-04-18 15:35:21.515	\N	icon_discriminating_concentration_bioassays_outline	image/svg+xml	5092	9e1c68ee98eb2244334053f183af4f37	icon/discriminating_concentration_bioassays_outline	t	ICON	\N	f	\N
311	EncaZ9bxPL8	\N	2026-04-18 15:35:21.517	2026-04-18 15:35:21.519	\N	icon_doctor_positive	image/svg+xml	2251	d77d9d3f522c30fe3447a34a0a408029	icon/doctor_positive	t	ICON	\N	f	\N
312	DLeOehjebaR	\N	2026-04-18 15:35:21.52	2026-04-18 15:35:21.522	\N	icon_doctor_negative	image/svg+xml	2310	8d42ac460e40d7bc849cda8c7ee077ad	icon/doctor_negative	t	ICON	\N	f	\N
313	qrOLxLJvM5d	\N	2026-04-18 15:35:21.524	2026-04-18 15:35:21.528	\N	icon_doctor_outline	image/svg+xml	2542	efe44083339adf8958bb69b61bebd24d	icon/doctor_outline	t	ICON	\N	f	\N
314	JAqxS9M3WJG	\N	2026-04-18 15:35:21.531	2026-04-18 15:35:21.535	\N	icon_domestic_worker_positive	image/svg+xml	4984	5add1a18abea894526061566a2eefc43	icon/domestic_worker_positive	t	ICON	\N	f	\N
315	EPQA60IR9OP	\N	2026-04-18 15:35:21.538	2026-04-18 15:35:21.543	\N	icon_domestic_worker_negative	image/svg+xml	4542	6e58838563a0d99ac909085f3b086f2e	icon/domestic_worker_negative	t	ICON	\N	f	\N
316	mCPucsgzwU0	\N	2026-04-18 15:35:21.545	2026-04-18 15:35:21.547	\N	icon_domestic_worker_outline	image/svg+xml	5274	5692618c2b0131b23223faf9439b8022	icon/domestic_worker_outline	t	ICON	\N	f	\N
317	ncO6mt0OCr7	\N	2026-04-18 15:35:21.548	2026-04-18 15:35:21.551	\N	icon_donkey_positive	image/svg+xml	1247	d0dcd43e9420fdd519a1035790b1afb6	icon/donkey_positive	t	ICON	\N	f	\N
318	cFWZryktpMs	\N	2026-04-18 15:35:21.552	2026-04-18 15:35:21.555	\N	icon_donkey_negative	image/svg+xml	1792	08d5ee57aa3d05241378345bded31bd0	icon/donkey_negative	t	ICON	\N	f	\N
319	eWSmuCA7gVO	\N	2026-04-18 15:35:21.556	2026-04-18 15:35:21.558	\N	icon_donkey_outline	image/svg+xml	1390	3779e91a27263ac6974b563ad6f3d5a7	icon/donkey_outline	t	ICON	\N	f	\N
320	r0GzRJSJDu7	\N	2026-04-18 15:35:21.56	2026-04-18 15:35:21.562	\N	icon_drone_positive	image/svg+xml	2498	13dc5015498fb77f06a43e73e2f72548	icon/drone_positive	t	ICON	\N	f	\N
321	C0z9DeFeQ0f	\N	2026-04-18 15:35:21.563	2026-04-18 15:35:21.566	\N	icon_drone_negative	image/svg+xml	2512	2b0d8baaa43e4a0815c63a2164693f72	icon/drone_negative	t	ICON	\N	f	\N
322	VKSUsMq6c6v	\N	2026-04-18 15:35:21.568	2026-04-18 15:35:21.571	\N	icon_drone_outline	image/svg+xml	3015	3054483f5ec1d7829b6d107a9bb65a31	icon/drone_outline	t	ICON	\N	f	\N
323	UrUA4NTVeaW	\N	2026-04-18 15:35:21.572	2026-04-18 15:35:21.575	\N	icon_eco_care_positive	image/svg+xml	824	4641120855566feedcd0d9b0e64ce476	icon/eco_care_positive	t	ICON	\N	f	\N
324	EmVfXABGXJX	\N	2026-04-18 15:35:21.576	2026-04-18 15:35:21.579	\N	icon_eco_care_negative	image/svg+xml	962	2360e2c5cc49a291c5f5c59089d8cb9f	icon/eco_care_negative	t	ICON	\N	f	\N
325	vZ2XziKMWpX	\N	2026-04-18 15:35:21.581	2026-04-18 15:35:21.583	\N	icon_eco_care_outline	image/svg+xml	3094	63aa8cb5ede762a0c16ea6a8633e0e38	icon/eco_care_outline	t	ICON	\N	f	\N
326	MG3j70OAp2Y	\N	2026-04-18 15:35:21.584	2026-04-18 15:35:21.587	\N	icon_elderly_positive	image/svg+xml	2773	a63288d6c4ac05cd7eabaed33760b1f0	icon/elderly_positive	t	ICON	\N	f	\N
327	qRQOthP0sxT	\N	2026-04-18 15:35:21.59	2026-04-18 15:35:21.593	\N	icon_elderly_negative	image/svg+xml	2915	d203bdf9caec64b39ecc98e690db4eee	icon/elderly_negative	t	ICON	\N	f	\N
328	i6s4BHCCfle	\N	2026-04-18 15:35:21.594	2026-04-18 15:35:21.596	\N	icon_elderly_outline	image/svg+xml	5656	70913e4a4fe8e7d818648aa89aebe028	icon/elderly_outline	t	ICON	\N	f	\N
329	Ov4iGmwx8EH	\N	2026-04-18 15:35:21.598	2026-04-18 15:35:21.6	\N	icon_electricity_positive	image/svg+xml	943	d2a479b75b7e9401401cb4ef4e84eac6	icon/electricity_positive	t	ICON	\N	f	\N
330	hyzuO2fN5hv	\N	2026-04-18 15:35:21.601	2026-04-18 15:35:21.603	\N	icon_electricity_negative	image/svg+xml	921	73a3979ac2d2d1651a0eb88b34200d7e	icon/electricity_negative	t	ICON	\N	f	\N
331	ed2TDvMzBvY	\N	2026-04-18 15:35:21.605	2026-04-18 15:35:21.607	\N	icon_electricity_outline	image/svg+xml	1609	9a1332521e247c04eb0e18e9944c0383	icon/electricity_outline	t	ICON	\N	f	\N
332	e9ekWBDgTuS	\N	2026-04-18 15:35:21.608	2026-04-18 15:35:21.61	\N	icon_emergency_post_positive	image/svg+xml	979	c62f1c155bbd3adeb10adeeb2281eab8	icon/emergency_post_positive	t	ICON	\N	f	\N
333	HkEWUQAvvrP	\N	2026-04-18 15:35:21.611	2026-04-18 15:35:21.613	\N	icon_emergency_post_negative	image/svg+xml	975	3990090760dec5a05002b6dabaf05405	icon/emergency_post_negative	t	ICON	\N	f	\N
334	bQFmXJDXN1B	\N	2026-04-18 15:35:21.615	2026-04-18 15:35:21.617	\N	icon_emergency_post_outline	image/svg+xml	1196	9c91dd51f293cf270837e42c00d1be81	icon/emergency_post_outline	t	ICON	\N	f	\N
335	VpsSfc3wrMW	\N	2026-04-18 15:35:21.618	2026-04-18 15:35:21.62	\N	icon_expectorate_positive	image/svg+xml	3272	ee99066b14fed1fb28ddb9e7de961f2a	icon/expectorate_positive	t	ICON	\N	f	\N
336	tbXjwr24vja	\N	2026-04-18 15:35:21.621	2026-04-18 15:35:21.623	\N	icon_expectorate_negative	image/svg+xml	2097	2665caef614727fca7f1b4a5088e0a2b	icon/expectorate_negative	t	ICON	\N	f	\N
341	MSm0t5AnhEt	\N	2026-04-18 15:35:21.647	2026-04-18 15:35:21.651	\N	icon_family_planning_positive	image/svg+xml	1986	e165fdf7d73a85ea36ee84a0146f5c75	icon/family_planning_positive	t	ICON	\N	f	\N
342	YVB6NbzC9iD	\N	2026-04-18 15:35:21.652	2026-04-18 15:35:21.655	\N	icon_family_planning_negative	image/svg+xml	1946	f9844b2a88036678c9547f9133a7552b	icon/family_planning_negative	t	ICON	\N	f	\N
343	fP8PGuiVfP7	\N	2026-04-18 15:35:21.657	2026-04-18 15:35:21.66	\N	icon_family_planning_outline	image/svg+xml	2530	28bcfd266366ff7b5e701c93a3556c78	icon/family_planning_outline	t	ICON	\N	f	\N
344	C1V48M1JsDJ	\N	2026-04-18 15:35:21.662	2026-04-18 15:35:21.666	\N	icon_female_and_male_positive	image/svg+xml	3002	c8697b273b7610eb3fe01a1345e09502	icon/female_and_male_positive	t	ICON	\N	f	\N
345	F2bdA2b3Us3	\N	2026-04-18 15:35:21.668	2026-04-18 15:35:21.671	\N	icon_female_and_male_negative	image/svg+xml	6850	341c2d6edc1546e10363b5a8354408da	icon/female_and_male_negative	t	ICON	\N	f	\N
346	QHUN9jC3iyX	\N	2026-04-18 15:35:21.672	2026-04-18 15:35:21.674	\N	icon_female_and_male_outline	image/svg+xml	5654	7660b3faf930d72fb6b31d4949fc6f39	icon/female_and_male_outline	t	ICON	\N	f	\N
347	QvPq7PgGUKm	\N	2026-04-18 15:35:21.675	2026-04-18 15:35:21.677	\N	icon_female_condom_positive	image/svg+xml	4026	8189e9d4ce1e6ecbf721e7844aad4f35	icon/female_condom_positive	t	ICON	\N	f	\N
348	kIhCHp6rzPp	\N	2026-04-18 15:35:21.678	2026-04-18 15:35:21.679	\N	icon_female_condom_negative	image/svg+xml	4006	875f5d63abc0f8545050f45d76ef83bc	icon/female_condom_negative	t	ICON	\N	f	\N
349	MYkERs8mEuK	\N	2026-04-18 15:35:21.681	2026-04-18 15:35:21.683	\N	icon_female_condom_outline	image/svg+xml	8645	2c69e2754a31ed8e225cdbad594fa94c	icon/female_condom_outline	t	ICON	\N	f	\N
350	ThuYX0BBBHt	\N	2026-04-18 15:35:21.685	2026-04-18 15:35:21.687	\N	icon_female_sex_worker_positive	image/svg+xml	2612	96ab7a973daa20e06cbf9c60867b85fc	icon/female_sex_worker_positive	t	ICON	\N	f	\N
351	XSy1eUV4Qbg	\N	2026-04-18 15:35:21.689	2026-04-18 15:35:21.691	\N	icon_female_sex_worker_negative	image/svg+xml	6513	c32a0950f6ec3e05218b321336adb538	icon/female_sex_worker_negative	t	ICON	\N	f	\N
352	ZuSiOJBLiy7	\N	2026-04-18 15:35:21.692	2026-04-18 15:35:21.694	\N	icon_female_sex_worker_outline	image/svg+xml	4147	e3531a0aa643cfafbaf172776fbabd8f	icon/female_sex_worker_outline	t	ICON	\N	f	\N
353	WdoRBAJtGhJ	\N	2026-04-18 15:35:21.695	2026-04-18 15:35:21.697	\N	icon_fetus_positive	image/svg+xml	3141	57f062d6a3d0835ae1845e2ad16ce88b	icon/fetus_positive	t	ICON	\N	f	\N
354	oaJqHLLCeKC	\N	2026-04-18 15:35:21.699	2026-04-18 15:35:21.702	\N	icon_fetus_negative	image/svg+xml	2988	b5f24608b0a9068da7dbeb45adce99f3	icon/fetus_negative	t	ICON	\N	f	\N
355	g5Ci0azbUpQ	\N	2026-04-18 15:35:21.703	2026-04-18 15:35:21.705	\N	icon_fetus_outline	image/svg+xml	13517	beefd100e8d56308ffd28424c9c261ce	icon/fetus_outline	t	ICON	\N	f	\N
356	LiisCN5CsN0	\N	2026-04-18 15:35:21.706	2026-04-18 15:35:21.708	\N	icon_fever_positive	image/svg+xml	1058	3d06ac48784a367300fd2933d8f8f8df	icon/fever_positive	t	ICON	\N	f	\N
357	FEOF6VYwYBY	\N	2026-04-18 15:35:21.709	2026-04-18 15:35:21.71	\N	icon_fever_negative	image/svg+xml	1047	5d6ce1e6ca695efb37b8fdf341ab809d	icon/fever_negative	t	ICON	\N	f	\N
358	MSONmS3JzhE	\N	2026-04-18 15:35:21.712	2026-04-18 15:35:21.714	\N	icon_fever_outline	image/svg+xml	2042	2a394299e6f67a3dc4cec45761c43460	icon/fever_outline	t	ICON	\N	f	\N
359	hUJycdqs78Z	\N	2026-04-18 15:35:21.715	2026-04-18 15:35:21.715	\N	icon_fever_2_positive	image/svg+xml	2092	af3c4282b5eb30f4235f8cd66fb1e08d	icon/fever_2_positive	t	ICON	\N	f	\N
337	kHDrRPV5Xyl	\N	2026-04-18 15:35:21.625	2026-04-18 15:35:21.628	\N	icon_expectorate_outline	image/svg+xml	3987	4d19009d82069ccd3aa3e74e7df0b291	icon/expectorate_outline	t	ICON	\N	f	\N
338	rxVUstwYHGR	\N	2026-04-18 15:35:21.63	2026-04-18 15:35:21.631	\N	icon_factory_worker_positive	image/svg+xml	2359	6ae9a16074f0a8d71bab639b2a115a23	icon/factory_worker_positive	t	ICON	\N	f	\N
339	VQTnNR7dkxo	\N	2026-04-18 15:35:21.633	2026-04-18 15:35:21.638	\N	icon_factory_worker_negative	image/svg+xml	2332	a122389f6edd890014a53cd0105ea60c	icon/factory_worker_negative	t	ICON	\N	f	\N
340	FqdW5FjPoVN	\N	2026-04-18 15:35:21.639	2026-04-18 15:35:21.643	\N	icon_factory_worker_outline	image/svg+xml	4602	8bc830216742b2bfbf3e169fe4f5a05b	icon/factory_worker_outline	t	ICON	\N	f	\N
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	2.30.0	Populate dhis2 schema if empty database	JDBC	org.hisp.dhis.db.migration.base.V2_30_0__Populate_dhis2_schema_if_empty_database	\N	dhis	2026-04-18 15:34:34.273802	820	t
2	2.31.1	Migrations for release v31	SQL	2.31/V2_31_1__Migrations_for_release_v31.sql	-271885416	dhis	2026-04-18 15:34:34.273802	152	t
3	2.31.2	Job configuration param to jsonb	JDBC	org.hisp.dhis.db.migration.v31.V2_31_2__Job_configuration_param_to_jsonb	\N	dhis	2026-04-18 15:34:34.273802	2	t
4	2.31.3	Program notification template to templateid	JDBC	org.hisp.dhis.db.migration.v31.V2_31_3__Program_notification_template_to_templateid	\N	dhis	2026-04-18 15:34:34.273802	2	t
5	2.31.4	Add defaults for validationstrategy	JDBC	org.hisp.dhis.db.migration.v31.V2_31_4__Add_defaults_for_validationstrategy	\N	dhis	2026-04-18 15:34:34.273802	0	t
6	2.31.5	Add new user role for new capture app	JDBC	org.hisp.dhis.db.migration.v31.V2_31_5__Add_new_user_role_for_new_capture_app	\N	dhis	2026-04-18 15:34:34.273802	0	t
7	2.31.6	Update default program access level to OPEN	SQL	2.31/V2_31_6__Update_default_program_access_level_to_OPEN.sql	389837453	dhis	2026-04-18 15:34:34.273802	0	t
8	2.31.7	Delete code klass unique constraint in deleted object	SQL	2.31/V2_31_7__Delete_code_klass_unique_constraint_in_deleted_object.sql	1445061512	dhis	2026-04-18 15:34:34.273802	1	t
9	2.31.9	Add user permissions for new data viz app	JDBC	org.hisp.dhis.db.migration.v31.V2_31_9__Add_user_permissions_for_new_data_viz_app	\N	dhis	2026-04-18 15:34:34.273802	0	t
10	2.31.10	Remove storagestatus column from fileresource table	SQL	2.31/V2_31_10__Remove_storagestatus_column_from_fileresource_table.sql	-1096225816	dhis	2026-04-18 15:34:34.273802	1	t
11	2.32.1	Org unit fields	SQL	2.32/V2_32_1__Org_unit_fields.sql	-1792150736	dhis	2026-04-18 15:34:34.273802	1	t
12	2.32.2	Complete data set registration fields	SQL	2.32/V2_32_2__Complete_data_set_registration_fields.sql	-1660385962	dhis	2026-04-18 15:34:34.273802	2	t
13	2.32.3	Program rule variable option code	SQL	2.32/V2_32_3__Program_rule_variable_option_code.sql	1675218695	dhis	2026-04-18 15:34:34.273802	0	t
14	2.32.4	Remove KafkaJob	SQL	2.32/V2_32_4__Remove_KafkaJob.sql	448507296	dhis	2026-04-18 15:34:34.273802	0	t
15	2.32.5	Remove program shortname constraint	SQL	2.32/V2_32_5__Remove_program_shortname_constraint.sql	623557658	dhis	2026-04-18 15:34:34.273802	1	t
16	2.32.6	Remove program approval workflow	SQL	2.32/V2_32_6__Remove_program_approval_workflow.sql	-665392634	dhis	2026-04-18 15:34:34.273802	0	t
17	2.32.7	Introduce jsonb eventdatavalues column	SQL	2.32/V2_32_7__Introduce_jsonb_eventdatavalues_column.sql	-161817378	dhis	2026-04-18 15:34:34.273802	7	t
18	2.32.8	OrgUnit geometry field	SQL	2.32/V2_32_8__OrgUnit_geometry_field.sql	2141862134	dhis	2026-04-18 15:34:34.273802	3	t
19	2.32.9	OrgUnitGroup geometry field	SQL	2.32/V2_32_9__OrgUnitGroup_geometry_field.sql	135519777	dhis	2026-04-18 15:34:34.273802	0	t
20	2.32.10	Use bigint for id columns	SQL	2.32/V2_32_10__Use_bigint_for_id_columns.sql	1959122901	dhis	2026-04-18 15:34:34.273802	2071	t
21	2.32.11	Remove TEI representative	SQL	2.32/V2_32_11__Remove_TEI_representative.sql	1168727321	dhis	2026-04-18 15:34:34.273802	0	t
22	2.32.12	Copy timestamp values into lastupdated field	SQL	2.32/V2_32_12__Copy_timestamp_values_into_lastupdated_field.sql	-1999611754	dhis	2026-04-18 15:34:34.273802	1	t
23	2.32.13	Add UserAssignment for Events	SQL	2.32/V2_32_13__Add_UserAssignment_for_Events.sql	-1769784669	dhis	2026-04-18 15:34:34.273802	2	t
24	2.32.14	Update relationshiptype bidirectional	SQL	2.32/V2_32_14__Update_relationshiptype_bidirectional.sql	-9899667	dhis	2026-04-18 15:34:34.273802	1	t
25	2.32.15	Add chart series	SQL	2.32/V2_32_15__Add_chart_series.sql	-1373861876	dhis	2026-04-18 15:34:34.273802	1	t
26	2.32.16	Assign Job Configuration UID	SQL	2.32/V2_32_16__Assign_Job_Configuration_UID.sql	1847518055	dhis	2026-04-18 15:34:34.273802	1	t
27	2.32.17	Separate sequence generators for highly used tables	SQL	2.32/V2_32_17__Separate_sequence_generators_for_highly_used_tables.sql	-590911677	dhis	2026-04-18 15:34:34.273802	7	t
28	2.32.18	PotentialDuplicate table	SQL	2.32/V2_32_18__PotentialDuplicate_table.sql	-1711695320	dhis	2026-04-18 15:34:34.273802	2	t
29	2.32.19	Create programstageinstancefilter table	SQL	2.32/V2_32_19__Create_programstageinstancefilter_table.sql	-1655494731	dhis	2026-04-18 15:34:34.273802	5	t
30	2.32.20	Create populate mapview filter dimension tables	SQL	2.32/V2_32_20__Create_populate_mapview_filter_dimension_tables.sql	1822920300	dhis	2026-04-18 15:34:34.273802	4	t
31	2.32.21	Create categories categoryoptions index	SQL	2.32/V2_32_21__Create_categories_categoryoptions_index.sql	-127279840	dhis	2026-04-18 15:34:34.273802	1	t
32	2.32.22	Migrate pie charts new format	SQL	2.32/V2_32_22__Migrate_pie_charts_new_format.sql	694570142	dhis	2026-04-18 15:34:34.273802	1	t
33	2.32.23	Migrate gauge charts new format	SQL	2.32/V2_32_23__Migrate_gauge_charts_new_format.sql	-1159638519	dhis	2026-04-18 15:34:34.273802	0	t
34	2.33.1	Job configuration job type column to varchar	JDBC	org.hisp.dhis.db.migration.v33.V2_33_1__Job_configuration_job_type_column_to_varchar	\N	dhis	2026-04-18 15:34:34.273802	6	t
35	2.33.2	Substitute job configurations with program data sync job type with new job configurations	SQL	2.33/V2_33_2__Substitute_job_configurations_with_program_data_sync_job_type_with_new_job_configurations.sql	-2120783418	dhis	2026-04-18 15:34:34.273802	3	t
36	2.33.3	Create cateogires categoryoptions index	SQL	2.33/V2_33_3__Create_cateogires_categoryoptions_index.sql	1407320962	dhis	2026-04-18 15:34:34.273802	1	t
37	2.33.4	Create categories categoryoptions index backport	SQL	2.33/V2_33_4__Create_categories_categoryoptions_index_backport.sql	722573432	dhis	2026-04-18 15:34:34.273802	0	t
38	2.33.5	Update job parameters with system setting values	JDBC	org.hisp.dhis.db.migration.v33.V2_33_5__Update_job_parameters_with_system_setting_values	\N	dhis	2026-04-18 15:34:34.273802	2	t
39	2.33.6	Set ptea attribute not null	SQL	2.33/V2_33_6__Set_ptea_attribute_not_null.sql	672673546	dhis	2026-04-18 15:34:34.273802	0	t
40	2.33.7	Set psde data element not null	SQL	2.33/V2_33_7__Set_psde_data_element_not_null.sql	-158490623	dhis	2026-04-18 15:34:34.273802	0	t
41	2.33.8	Drop tracked entity attribute program scope	SQL	2.33/V2_33_8__Drop_tracked_entity_attribute_program_scope.sql	1868872398	dhis	2026-04-18 15:34:34.273802	0	t
42	2.33.9	CategoryOption formname field	SQL	2.33/V2_33_9__CategoryOption_formname_field.sql	-517958816	dhis	2026-04-18 15:34:34.273802	0	t
43	2.33.10	Add hasMultiple flag in FileResource	SQL	2.33/V2_33_10__Add_hasMultiple_flag_in_FileResource.sql	-814072746	dhis	2026-04-18 15:34:34.273802	0	t
44	2.33.11	Add programstageid to trackedentitydataelementdimension	SQL	2.33/V2_33_11__Add_programstageid_to_trackedentitydataelementdimension.sql	1728506538	dhis	2026-04-18 15:34:34.273802	1	t
45	2.33.12	Add renderingstrategy to mapview	SQL	2.33/V2_33_12__Add_renderingstrategy_to_mapview.sql	15230967	dhis	2026-04-18 15:34:34.273802	0	t
46	2.33.13	Migrate text based system settings to use enums	JDBC	org.hisp.dhis.db.migration.v33.V2_33_13__Migrate_text_based_system_settings_to_use_enums	\N	dhis	2026-04-18 15:34:34.273802	1	t
47	2.33.14	Add translations for dataset section	SQL	2.33/V2_33_14__Add_translations_for_dataset_section.sql	-1792497106	dhis	2026-04-18 15:34:34.273802	0	t
48	2.33.15	Add jsonb attributevalues columns	SQL	2.33/V2_33_15__Add_jsonb_attributevalues_columns.sql	366047253	dhis	2026-04-18 15:34:34.273802	11	t
49	2.33.16	Mirgrate data to jsonb attributevalues columns	SQL	2.33/V2_33_16__Mirgrate_data_to_jsonb_attributevalues_columns.sql	-659978644	dhis	2026-04-18 15:34:34.273802	14	t
50	2.33.17	Introduce nextscheduledate for programstage	SQL	2.33/V2_33_17__Introduce_nextscheduledate_for_programstage.sql	2003578911	dhis	2026-04-18 15:34:34.273802	1	t
51	2.33.19	Drop trackedentitydatavalue table	SQL	2.33/V2_33_19__Drop_trackedentitydatavalue_table.sql	1765234989	dhis	2026-04-18 15:34:34.273802	1	t
52	2.34.1	Update program rule action with environments and evaluation time columns and default values	SQL	2.34/V2_34_1__Update_program_rule_action_with_environments_and_evaluation_time_columns_and_default_values.sql	1442270640	dhis	2026-04-18 15:34:34.273802	1	t
53	2.34.2	AddUserOrgUnitTypeColumn	SQL	2.34/V2_34_2__AddUserOrgUnitTypeColumn.sql	1056975172	dhis	2026-04-18 15:34:34.273802	1	t
54	2.34.3	RemoveOrphanProgramStageInstances	SQL	2.34/V2_34_3__RemoveOrphanProgramStageInstances.sql	-801139725	dhis	2026-04-18 15:34:34.273802	1	t
55	2.34.4	Fix case in predictor expressions	SQL	2.34/V2_34_4__Fix_case_in_predictor_expressions.sql	-1270735446	dhis	2026-04-18 15:34:34.273802	3	t
56	2.34.5	Convert job configuration binary columns into varchar data type	JDBC	org.hisp.dhis.db.migration.v34.V2_34_5__Convert_job_configuration_binary_columns_into_varchar_data_type	\N	dhis	2026-04-18 15:34:34.273802	4	t
57	2.34.6	Convert systemsetting value column from bytea to string	JDBC	org.hisp.dhis.db.migration.v34.V2_34_6__Convert_systemsetting_value_column_from_bytea_to_string	\N	dhis	2026-04-18 15:34:34.273802	2	t
58	2.34.7	Convert push analysis job parameters into list of string	JDBC	org.hisp.dhis.db.migration.v34.V2_34_7__Convert_push_analysis_job_parameters_into_list_of_string	\N	dhis	2026-04-18 15:34:34.273802	5	t
59	2.34.8	Create Audit Table	SQL	2.34/V2_34_8__Create_Audit_Table.sql	1297944788	dhis	2026-04-18 15:34:34.273802	1	t
60	2.34.9	Set embedded expressions nullable and unique	SQL	2.34/V2_34_9__Set_embedded_expressions_nullable_and_unique.sql	1515537010	dhis	2026-04-18 15:34:34.273802	3	t
61	2.34.10	Update gauge charts	SQL	2.34/V2_34_10__Update_gauge_charts.sql	1164588451	dhis	2026-04-18 15:34:34.273802	0	t
62	2.34.11	Remove unused system setting	SQL	2.34/V2_34_11__Remove_unused_system_setting.sql	1607170305	dhis	2026-04-18 15:34:34.273802	0	t
63	2.34.12	Add New Visualization Tables	SQL	2.34/V2_34_12__Add_New_Visualization_Tables.sql	1474252589	dhis	2026-04-18 15:34:34.273802	20	t
64	2.34.13	Migrate Data Into Visualization Tables	SQL	2.34/V2_34_13__Migrate_Data_Into_Visualization_Tables.sql	1483161664	dhis	2026-04-18 15:34:34.273802	8	t
65	2.34.14	Add delay column to jobconfiguration	SQL	2.34/V2_34_14__Add_delay_column_to_jobconfiguration.sql	1951404576	dhis	2026-04-18 15:34:34.273802	0	t
66	2.34.15	Remove continuousexecution column from jobconfiguration	SQL	2.34/V2_34_15__Remove_continuousexecution_column_from_jobconfiguration.sql	-1994369512	dhis	2026-04-18 15:34:34.273802	0	t
67	2.34.16	Add translations column into systemsetting table	SQL	2.34/V2_34_16__Add_translations_column_into_systemsetting_table.sql	932924626	dhis	2026-04-18 15:34:34.273802	0	t
68	2.34.17	Remove FKs and update authorities interpretations on Chart ReportTable Tables	SQL	2.34/V2_34_17__Remove_FKs_and_update_authorities_interpretations_on_Chart_ReportTable_Tables.sql	2112425239	dhis	2026-04-18 15:34:34.273802	64	t
69	2.34.18	Add default values for Visualization columns	SQL	2.34/V2_34_18__Add_default_values_for_Visualization_columns.sql	1280541517	dhis	2026-04-18 15:34:34.273802	0	t
70	2.34.20	Upgrade basemap from google to bing	SQL	2.34/V2_34_20__Upgrade_basemap_from_google_to_bing.sql	352864767	dhis	2026-04-18 15:34:34.273802	0	t
71	2.34.21	Update completedatasetregistration lastupdatedby	SQL	2.34/V2_34_21__Update_completedatasetregistration_lastupdatedby.sql	-254179127	dhis	2026-04-18 15:34:34.273802	0	t
72	2.35.1	Add teav btree index	JDBC	org.hisp.dhis.db.migration.v35.V2_35_1__Add_teav_btree_index	\N	dhis	2026-04-18 15:34:34.273802	2	t
73	2.35.2	Update data sync job parameters with system setting value	JDBC	org.hisp.dhis.db.migration.v35.V2_35_2__Update_data_sync_job_parameters_with_system_setting_value	\N	dhis	2026-04-18 15:34:34.273802	1	t
74	2.35.3	Add storedBy column for TEI	SQL	2.35/V2_35_3__Add_storedBy_column_for_TEI.sql	1233785778	dhis	2026-04-18 15:34:34.273802	0	t
75	2.35.4	Remove color set	SQL	2.35/V2_35_4__Remove_color_set.sql	-814290722	dhis	2026-04-18 15:34:34.273802	5	t
76	2.35.5	Add visualization series	SQL	2.35/V2_35_5__Add_visualization_series.sql	1415646944	dhis	2026-04-18 15:34:34.273802	0	t
77	2.35.6	Add Uuid Generator	SQL	2.35/V2_35_6__Add_Uuid_Generator.sql	-1220445013	dhis	2026-04-18 15:34:34.273802	0	t
78	2.35.7	Add Uuid User Columns	SQL	2.35/V2_35_7__Add_Uuid_User_Columns.sql	1407493979	dhis	2026-04-18 15:34:34.273802	1	t
79	2.35.8	Add mapview thematicmaptype	SQL	2.35/V2_35_8__Add_mapview_thematicmaptype.sql	-342517033	dhis	2026-04-18 15:34:34.273802	0	t
80	2.35.9	Add mapview nodatacolor	SQL	2.35/V2_35_9__Add_mapview_nodatacolor.sql	-2023434005	dhis	2026-04-18 15:34:34.273802	0	t
81	2.35.10	Add visualization fontstyle	SQL	2.35/V2_35_10__Add_visualization_fontstyle.sql	994671364	dhis	2026-04-18 15:34:34.273802	0	t
82	2.35.11	Add new Map View Event Status column	SQL	2.35/V2_35_11__Add_new_Map_View_Event_Status_column.sql	1656636221	dhis	2026-04-18 15:34:34.273802	0	t
83	2.35.12	Rename All AREA Type To STACKED AREA	SQL	2.35/V2_35_12__Rename_All_AREA_Type_To_STACKED_AREA.sql	-401862667	dhis	2026-04-18 15:34:34.273802	0	t
84	2.35.13	Add visualization colorset	SQL	2.35/V2_35_13__Add_visualization_colorset.sql	898327055	dhis	2026-04-18 15:34:34.273802	0	t
85	2.35.14	Add sequentialcounter procedure	SQL	2.35/V2_35_14__Add_sequentialcounter_procedure.sql	708322845	dhis	2026-04-18 15:34:34.273802	2	t
86	2.35.15	Add last x days relative periods	SQL	2.35/V2_35_15__Add_last_x_days_relative_periods.sql	-1999473993	dhis	2026-04-18 15:34:34.273802	2	t
87	2.35.16	Add description deg and indg	SQL	2.35/V2_35_16__Add_description_deg_and_indg.sql	909322188	dhis	2026-04-18 15:34:34.273802	0	t
88	2.35.17	Visualization Move Columns To Filters	JDBC	org.hisp.dhis.db.migration.v35.V2_35_17__Visualization_Move_Columns_To_Filters	\N	dhis	2026-04-18 15:34:34.273802	0	t
89	2.35.18	Add dataset openperiodsaftercoenddate	SQL	2.35/V2_35_18__Add_dataset_openperiodsaftercoenddate.sql	1212239503	dhis	2026-04-18 15:34:34.273802	0	t
90	2.35.19	Drop programinstanceaudit table	SQL	2.35/V2_35_19__Drop_programinstanceaudit_table.sql	613582783	dhis	2026-04-18 15:34:34.273802	1	t
91	2.35.20	Add uid column in sms table	SQL	2.35/V2_35_20__Add_uid_column_in_sms_table.sql	-411824369	dhis	2026-04-18 15:34:34.273802	4	t
92	2.35.21	Modify id in trackedentityattributevalueaudit to bigint	SQL	2.35/V2_35_21__Modify_id_in_trackedentityattributevalueaudit_to_bigint.sql	-1135812582	dhis	2026-04-18 15:34:34.273802	2	t
93	2.35.22	add sms authority to userauthoritygroups	JDBC	org.hisp.dhis.db.migration.v35.V2_35_22__add_sms_authority_to_userauthoritygroups	\N	dhis	2026-04-18 15:34:34.273802	0	t
226	2.40.13	Attribute flags as jsonb	SQL	2.40/V2_40_13__Attribute_flags_as_jsonb.sql	-371992100	dhis	2026-04-18 15:34:34.273802	8	t
94	2.36.1	normalize program rule variable names for duplicates	JDBC	org.hisp.dhis.db.migration.v36.V2_36_1__normalize_program_rule_variable_names_for_duplicates	\N	dhis	2026-04-18 15:34:34.273802	1	t
95	2.36.2	normalize program rule names for duplicates	JDBC	org.hisp.dhis.db.migration.v36.V2_36_2__normalize_program_rule_names_for_duplicates	\N	dhis	2026-04-18 15:34:34.273802	0	t
96	2.36.3	Add index for ou column on tei table	SQL	2.36/V2_36_3__Add_index_for_ou_column_on_tei_table.sql	-1430094831	dhis	2026-04-18 15:34:34.273802	0	t
97	2.36.4	Remove duplicate mappings from categoryoption to usergroups	JDBC	org.hisp.dhis.db.migration.v36.V2_36_4__Remove_duplicate_mappings_from_categoryoption_to_usergroups	\N	dhis	2026-04-18 15:34:34.273802	1	t
98	2.36.5	add template snapshot to program instance and remove fk	SQL	2.36/V2_36_5__add_template_snapshot_to_program_instance_and_remove_fk.sql	1578491962	dhis	2026-04-18 15:34:34.273802	1	t
99	2.36.6	Remove duplicate mappings from programstage to usergroups	JDBC	org.hisp.dhis.db.migration.v36.V2_36_6__Remove_duplicate_mappings_from_programstage_to_usergroups	\N	dhis	2026-04-18 15:34:34.273802	3	t
100	2.36.7	Add translations column into programruleaction table	SQL	2.36/V2_36_7__Add_translations_column_into_programruleaction_table.sql	-118790982	dhis	2026-04-18 15:34:34.273802	0	t
101	2.36.8	Add column object sharing	SQL	2.36/V2_36_8__Add_column_object_sharing.sql	-1388244525	dhis	2026-04-18 15:34:34.273802	16	t
102	2.36.9	Add custom jsonb functions for sharing	SQL	2.36/V2_36_9__Add_custom_jsonb_functions_for_sharing.sql	-1039846318	dhis	2026-04-18 15:34:34.273802	2	t
103	2.36.11	Migrate sharings to jsonb	JDBC	org.hisp.dhis.db.migration.v36.V2_36_11__Migrate_sharings_to_jsonb	\N	dhis	2026-04-18 15:34:34.273802	10	t
104	2.36.12	Add createdbyuserInfo lastupdatedbyuserinfo to ProgramStageInstance	SQL	2.36/V2_36_12__Add_createdbyuserInfo_lastupdatedbyuserinfo_to_ProgramStageInstance.sql	579880304	dhis	2026-04-18 15:34:34.273802	1	t
105	2.36.13	Add invitetoken and remove restorecode from users table	SQL	2.36/V2_36_13__Add_invitetoken_and_remove_restorecode_from_users_table.sql	322679304	dhis	2026-04-18 15:34:34.273802	0	t
106	2.36.14	Add programtempowner table	SQL	2.36/V2_36_14__Add_programtempowner_table.sql	1012506162	dhis	2026-04-18 15:34:34.273802	4	t
107	2.36.15	Remove skip zeros in analytics system setting	SQL	2.36/V2_36_15__Remove_skip_zeros_in_analytics_system_setting.sql	779697167	dhis	2026-04-18 15:34:34.273802	0	t
108	2.36.17	Remove referenced relationships from soft deleted events and enrollments	SQL	2.36/V2_36_17__Remove_referenced_relationships_from_soft_deleted_events_and_enrollments.sql	-453095978	dhis	2026-04-18 15:34:34.273802	1	t
109	2.36.19	Add outlier analysis column	SQL	2.36/V2_36_19__Add_outlier_analysis_column.sql	872124205	dhis	2026-04-18 15:34:34.273802	0	t
110	2.36.20	Drop legacy sharing tables	SQL	2.36/V2_36_20__Drop_legacy_sharing_tables.sql	-66347989	dhis	2026-04-18 15:34:34.273802	109	t
111	2.36.21	Add column account expiry into user credentials	SQL	2.36/V2_36_21__Add_column_account_expiry_into_user_credentials.sql	-1324085981	dhis	2026-04-18 15:34:34.273802	0	t
112	2.36.22	Add ComplexValueType jsonb column to data element	SQL	2.36/V2_36_22__Add_ComplexValueType_jsonb_column_to_data_element.sql	727752413	dhis	2026-04-18 15:34:34.273802	0	t
113	2.36.23	Add dashboard filterdimensions column	SQL	2.36/V2_36_23__Add_dashboard_filterdimensions_column.sql	-2059647539	dhis	2026-04-18 15:34:34.273802	1	t
114	2.36.24	Add data sharing to sqlview	JDBC	org.hisp.dhis.db.migration.v36.V2_36_24__Add_data_sharing_to_sqlview	\N	dhis	2026-04-18 15:34:34.273802	0	t
115	2.36.25	Add translation to program rule variable	SQL	2.36/V2_36_25__Add_translation_to_program_rule_variable.sql	642650539	dhis	2026-04-18 15:34:34.273802	0	t
116	2.36.26	Add column shortName	SQL	2.36/V2_36_26__Add_column_shortName.sql	409313924	dhis	2026-04-18 15:34:34.273802	1	t
117	2.36.27	Add unique shortName	JDBC	org.hisp.dhis.db.migration.v36.V2_36_27__Add_unique_shortName	\N	dhis	2026-04-18 15:34:34.273802	1	t
118	2.36.28	Add unique and not null to shortName	SQL	2.36/V2_36_28__Add_unique_and_not_null_to_shortName.sql	2081255715	dhis	2026-04-18 15:34:34.273802	2	t
119	2.36.29	Add indexes in relationshipitem and programinstance tables	SQL	2.36/V2_36_29__Add_indexes_in_relationshipitem_and_programinstance_tables.sql	1202153676	dhis	2026-04-18 15:34:34.273802	1	t
120	2.36.30	Add passivedashboardviews column to datastatistics table	SQL	2.36/V2_36_30__Add_passivedashboardviews_column_to_datastatistics_table.sql	-844989920	dhis	2026-04-18 15:34:34.273802	0	t
121	2.36.31	Add programid index in programintance table	SQL	2.36/V2_36_31__Add_programid_index_in_programintance_table.sql	2079795987	dhis	2026-04-18 15:34:34.273802	0	t
122	2.36.32	Add notificationtemplate column to programmessage table	SQL	2.36/V2_36_32__Add_notificationtemplate_column_to_programmessage_table.sql	-536283922	dhis	2026-04-18 15:34:34.273802	0	t
123	2.36.33	Add translations column to trackedEntityInstanceFilter table	SQL	2.36/V2_36_33__Add_translations_column_to_trackedEntityInstanceFilter_table.sql	152797532	dhis	2026-04-18 15:34:34.273802	0	t
124	2.37.1	Add Deferred Constraint to Interpretation Comments Table	SQL	2.37/V2_37_1__Add_Deferred_Constraint_to_Interpretation_Comments_Table.sql	360122688	dhis	2026-04-18 15:34:34.273802	1	t
125	2.37.2	Add index in tracker tables	SQL	2.37/V2_37_2__Add_index_in_tracker_tables.sql	-632008147	dhis	2026-04-18 15:34:34.273802	2	t
126	2.37.3	Update VISUALIZATION VIEW in datastatisticsevent table	SQL	2.37/V2_37_3__Update_VISUALIZATION_VIEW_in_datastatisticsevent_table.sql	-1588074185	dhis	2026-04-18 15:34:34.273802	0	t
127	2.37.4	Update ou path index	SQL	2.37/V2_37_4__Update_ou_path_index.sql	-1252262601	dhis	2026-04-18 15:34:34.273802	1	t
128	2.37.5	Add sendrepeatable column	SQL	2.37/V2_37_5__Add_sendrepeatable_column.sql	102006350	dhis	2026-04-18 15:34:34.273802	1	t
129	2.37.6	Clean trackedentitytypeattribute null foreign keys	SQL	2.37/V2_37_6__Clean_trackedentitytypeattribute_null_foreign_keys.sql	-1039541605	dhis	2026-04-18 15:34:34.273802	0	t
130	2.37.7	Fix negative sort orders in visualization rows columns	SQL	2.37/V2_37_7__Fix_negative_sort_orders_in_visualization_rows_columns.sql	1504013881	dhis	2026-04-18 15:34:34.273802	0	t
131	2.37.8	Add translations column into externalmaplayer table	SQL	2.37/V2_37_8__Add_translations_column_into_externalmaplayer_table.sql	-1415477344	dhis	2026-04-18 15:34:34.273802	0	t
132	2.37.9	Add last10years column into relativeperiods table	SQL	2.37/V2_37_9__Add_last10years_column_into_relativeperiods_table.sql	724938640	dhis	2026-04-18 15:34:34.273802	1	t
133	2.37.10	Add createdbyuserInfo lastupdatedbyuserinfo to ProgramInstance and TrackedEntityInstance	SQL	2.37/V2_37_10__Add_createdbyuserInfo_lastupdatedbyuserinfo_to_ProgramInstance_and_TrackedEntityInstance.sql	1261700433	dhis	2026-04-18 15:34:34.273802	1	t
134	2.37.11	Add last10financialyears column into relativeperiods table	SQL	2.37/V2_37_11__Add_last10financialyears_column_into_relativeperiods_table.sql	1282517200	dhis	2026-04-18 15:34:34.273802	0	t
135	2.37.12	Add translations column into notification template tables	SQL	2.37/V2_37_12__Add_translations_column_into_notification_template_tables.sql	-1659359413	dhis	2026-04-18 15:34:34.273802	1	t
227	2.40.14	Add table route	SQL	2.40/V2_40_14__Add_table_route.sql	-1724517248	dhis	2026-04-18 15:34:34.273802	2	t
136	2.37.13	Update programstageinstance status visited to active	SQL	2.37/V2_37_13__Update_programstageinstance_status_visited_to_active.sql	-973792171	dhis	2026-04-18 15:34:34.273802	0	t
137	2.37.14	Add image column into organisationunit table	SQL	2.37/V2_37_14__Add_image_column_into_organisationunit_table.sql	-984761768	dhis	2026-04-18 15:34:34.273802	1	t
138	2.37.15	Delete REMOVE EXPIRED RESERVED VALUES Job	SQL	2.37/V2_37_15__Delete_REMOVE_EXPIRED_RESERVED_VALUES_Job.sql	1254233743	dhis	2026-04-18 15:34:34.273802	0	t
139	2.37.16	Add REPLICA IDENTITY on tables without primary key	SQL	2.37/V2_37_16__Add_REPLICA_IDENTITY_on_tables_without_primary_key.sql	1441434802	dhis	2026-04-18 15:34:34.273802	2	t
140	2.37.17	Remove Chart and ReportTable	SQL	2.37/V2_37_17__Remove_Chart_and_ReportTable.sql	172668348	dhis	2026-04-18 15:34:34.273802	21	t
141	2.37.19	Migrate DataApproval id column to long	SQL	2.37/V2_37_19__Migrate_DataApproval_id_column_to_long.sql	-1365726151	dhis	2026-04-18 15:34:34.273802	3	t
142	2.37.22	Add ApiToken Table	SQL	2.37/V2_37_22__Add_ApiToken_Table.sql	1145880603	dhis	2026-04-18 15:34:34.273802	1	t
143	2.37.23	Add Potential Duplicate Flag To Tei	SQL	2.37/V2_37_23__Add_Potential_Duplicate_Flag_To_Tei.sql	851086003	dhis	2026-04-18 15:34:34.273802	1	t
144	2.37.24	Potential Duplicate Not Null teiB	SQL	2.37/V2_37_24__Potential_Duplicate_Not_Null_teiB.sql	-1024904053	dhis	2026-04-18 15:34:34.273802	0	t
145	2.37.25	Add disableDataElementAutoGroup column to section	SQL	2.37/V2_37_25__Add_disableDataElementAutoGroup_column_to_section.sql	-1436505888	dhis	2026-04-18 15:34:34.273802	0	t
146	2.37.26	Add Fix Columns in Visualization	SQL	2.37/V2_37_26__Add_Fix_Columns_in_Visualization.sql	-1774834607	dhis	2026-04-18 15:34:34.273802	1	t
147	2.37.27	Add ou move auth for roles with add auth	SQL	2.37/V2_37_27__Add_ou_move_auth_for_roles_with_add_auth.sql	1494537377	dhis	2026-04-18 15:34:34.273802	0	t
148	2.37.28	Add Layout And ItemConfig Columns Dashboard	SQL	2.37/V2_37_28__Add_Layout_And_ItemConfig_Columns_Dashboard.sql	605594794	dhis	2026-04-18 15:34:34.273802	0	t
149	2.37.29	Add translations column expression table	SQL	2.37/V2_37_29__Add_translations_column_expression_table.sql	1650968076	dhis	2026-04-18 15:34:34.273802	0	t
150	2.37.30	Add translations column predictor table	SQL	2.37/V2_37_30__Add_translations_column_predictor_table.sql	-1914085880	dhis	2026-04-18 15:34:34.273802	0	t
151	2.37.31	drop legacy translation table	SQL	2.37/V2_37_31__drop_legacy_translation_table.sql	1797982545	dhis	2026-04-18 15:34:34.273802	1	t
152	2.37.32	Add mapview organisationunitcolor	SQL	2.37/V2_37_32__Add_mapview_organisationunitcolor.sql	294320773	dhis	2026-04-18 15:34:34.273802	0	t
153	2.37.33	Add facility org unit group set level	SQL	2.37/V2_37_33__Add_facility_org_unit_group_set_level.sql	1604493704	dhis	2026-04-18 15:34:34.273802	2	t
154	2.37.34	Add programstagedataelement skipanalytics	SQL	2.37/V2_37_34__Add_programstagedataelement_skipanalytics.sql	133661822	dhis	2026-04-18 15:34:34.273802	0	t
155	2.37.35	Update Potential Duplicate	SQL	2.37/V2_37_35__Update_Potential_Duplicate.sql	-401039672	dhis	2026-04-18 15:34:34.273802	2	t
156	2.37.36	Add userinfo dataviewmaxorganisationunitlevel	SQL	2.37/V2_37_36__Add_userinfo_dataviewmaxorganisationunitlevel.sql	410522857	dhis	2026-04-18 15:34:34.273802	0	t
157	2.38.1	Add column shortName to group sets	SQL	2.38/V2_38_1__Add_column_shortName_to_group_sets.sql	-1387216343	dhis	2026-04-18 15:34:34.273802	0	t
158	2.38.2	Add unique shortName to group sets	JDBC	org.hisp.dhis.db.migration.v38.V2_38_2__Add_unique_shortName_to_group_sets	\N	dhis	2026-04-18 15:34:34.273802	0	t
159	2.38.3	Add unique and not null to group sets shortName	SQL	2.38/V2_38_3__Add_unique_and_not_null_to_group_sets_shortName.sql	1426970789	dhis	2026-04-18 15:34:34.273802	2	t
160	2.38.4	add columns for last updated to data approval	SQL	2.38/V2_38_4__add_columns_for_last_updated_to_data_approval.sql	1475655259	dhis	2026-04-18 15:34:34.273802	2	t
161	2.38.5	Add indexes to tei and psi table to improve tei querying	SQL	2.38/V2_38_5__Add_indexes_to_tei_and_psi_table_to_improve_tei_querying.sql	-1111194101	dhis	2026-04-18 15:34:34.273802	1	t
162	2.38.6	Add attributes for analytical objects	SQL	2.38/V2_38_6__Add_attributes_for_analytical_objects.sql	-607674042	dhis	2026-04-18 15:34:34.273802	3	t
163	2.38.7	Add metadata proposals	SQL	2.38/V2_38_7__Add_metadata_proposals.sql	-259450861	dhis	2026-04-18 15:34:34.273802	2	t
164	2.38.8	Remove legacy attributevalues tables	SQL	2.38/V2_38_8__Remove_legacy_attributevalues_tables.sql	-64391883	dhis	2026-04-18 15:34:34.273802	37	t
165	2.38.9	Add aggregated keys for relationships	SQL	2.38/V2_38_9__Add_aggregated_keys_for_relationships.sql	1315182340	dhis	2026-04-18 15:34:34.273802	3	t
166	2.38.10	Remove unused visualization columns and table	SQL	2.38/V2_38_10__Remove_unused_visualization_columns_and_table.sql	927205008	dhis	2026-04-18 15:34:34.273802	0	t
167	2.38.11	Add Event Visualization Tables	SQL	2.38/V2_38_11__Add_Event_Visualization_Tables.sql	-1580409640	dhis	2026-04-18 15:34:34.273802	16	t
168	2.38.12	Migrate Data Into Event Visualization Tables	SQL	2.38/V2_38_12__Migrate_Data_Into_Event_Visualization_Tables.sql	709144537	dhis	2026-04-18 15:34:34.273802	11	t
169	2.38.14	Add program opendaysaftercoenddate	SQL	2.38/V2_38_14__Add_program_opendaysaftercoenddate.sql	1388772325	dhis	2026-04-18 15:34:34.273802	0	t
170	2.38.15	Add index trackedentityprogramowner program orgunit	SQL	2.38/V2_38_15__Add_index_trackedentityprogramowner_program_orgunit.sql	-1387268405	dhis	2026-04-18 15:34:34.273802	0	t
171	2.38.16	Add includedescendantorgunits to predictor	SQL	2.38/V2_38_16__Add_includedescendantorgunits_to_predictor.sql	366407674	dhis	2026-04-18 15:34:34.273802	1	t
172	2.38.17	Add notnull constraint for sqlview type and cachestrategy	SQL	2.38/V2_38_17__Add_notnull_constraint_for_sqlview_type_and_cachestrategy.sql	1657855816	dhis	2026-04-18 15:34:34.273802	1	t
173	2.38.18	Add simpleDimension column into eventVisualization	SQL	2.38/V2_38_18__Add_simpleDimension_column_into_eventVisualization.sql	-881726168	dhis	2026-04-18 15:34:34.273802	0	t
174	2.38.19	Add ValueType column into programrulevariable	SQL	2.38/V2_38_19__Add_ValueType_column_into_programrulevariable.sql	1964969230	dhis	2026-04-18 15:34:34.273802	1	t
175	2.38.20	Script to rename column programid in programstageusergroupaccesses moved to 2 36 6 and this script updates constraint in programstageinstance	SQL	2.38/V2_38_20__Script_to_rename_column_programid_in_programstageusergroupaccesses_moved_to_2_36_6_and_this_script_updates_constraint_in_programstageinstance.sql	-531235053	dhis	2026-04-18 15:34:34.273802	1	t
176	2.38.21	Add eventRepetition column into eventVisualization	SQL	2.38/V2_38_21__Add_eventRepetition_column_into_eventVisualization.sql	-1283959480	dhis	2026-04-18 15:34:34.273802	0	t
177	2.38.22	Remove mistake of duplicated FK in visualization organisationunits	SQL	2.38/V2_38_22__Remove_mistake_of_duplicated_FK_in_visualization_organisationunits.sql	-1920368903	dhis	2026-04-18 15:34:34.273802	0	t
178	2.38.24	Set ProgramStage NotNull	SQL	2.38/V2_38_24__Set_ProgramStage_NotNull.sql	-391546467	dhis	2026-04-18 15:34:34.273802	0	t
179	2.38.25	Add messageId messageConversation	SQL	2.38/V2_38_25__Add_messageId_messageConversation.sql	61180192	dhis	2026-04-18 15:34:34.273802	1	t
180	2.38.26	Add Feedback recipients to configuration	SQL	2.38/V2_38_26__Add_Feedback_recipients_to_configuration.sql	829440205	dhis	2026-04-18 15:34:34.273802	1	t
181	2.38.27	Add sharing column to trackedentityinstancefilter	SQL	2.38/V2_38_27__Add_sharing_column_to_trackedentityinstancefilter.sql	180461158	dhis	2026-04-18 15:34:34.273802	0	t
182	2.38.28	add column to relationshipconstraint table	SQL	2.38/V2_38_28__add_column_to_relationshipconstraint_table.sql	-1687584821	dhis	2026-04-18 15:34:34.273802	148	t
183	2.38.31	Add createdby userid column to trackedentityinstancefilter	SQL	2.38/V2_38_31__Add_createdby_userid_column_to_trackedentityinstancefilter.sql	1978277139	dhis	2026-04-18 15:34:34.273802	2	t
184	2.38.32	Add new user role for analytics explain endpoint	JDBC	org.hisp.dhis.db.migration.v38.V2_38_32__Add_new_user_role_for_analytics_explain_endpoint	\N	dhis	2026-04-18 15:34:34.273802	0	t
185	2.38.33	Drop Legacy Constraints EventReport EventChart	SQL	2.38/V2_38_33__Drop_Legacy_Constraints_EventReport_EventChart.sql	197751156	dhis	2026-04-18 15:34:34.273802	19	t
186	2.38.34	Migrate users to userinfo	SQL	2.38/V2_38_34__Migrate_users_to_userinfo.sql	-1002422487	dhis	2026-04-18 15:34:34.273802	21	t
187	2.38.35	Migrate user to userinfo	JDBC	org.hisp.dhis.db.migration.v38.V2_38_35__Migrate_user_to_userinfo	\N	dhis	2026-04-18 15:34:34.273802	1	t
188	2.38.36	Drop users table	SQL	2.38/V2_38_36__Drop_users_table.sql	1589664013	dhis	2026-04-18 15:34:34.273802	6	t
189	2.38.37	Add entityquerycriteria column to trackedentityinstancefilter	JDBC	org.hisp.dhis.db.migration.v38.V2_38_37__Add_entityquerycriteria_column_to_trackedentityinstancefilter	\N	dhis	2026-04-18 15:34:34.273802	2	t
190	2.38.38	Updates Sms Config	SQL	2.38/V2_38_38__Updates_Sms_Config.sql	1358863470	dhis	2026-04-18 15:34:34.273802	0	t
191	2.38.39	Add organisationUnitCoordinateField column to mapView table	SQL	2.38/V2_38_39__Add_organisationUnitCoordinateField_column_to_mapView_table.sql	452220890	dhis	2026-04-18 15:34:34.273802	0	t
192	2.38.41	Add coc fk in smscode	SQL	2.38/V2_38_41__Add_coc_fk_in_smscode.sql	482752321	dhis	2026-04-18 15:34:34.273802	3	t
193	2.39.1	Add index to reserved value	SQL	2.39/V2_39_1__Add_index_to_reserved_value.sql	937741164	dhis	2026-04-18 15:34:34.273802	1	t
194	2.39.2	Add jsonb columns into visualization table fix	SQL	2.39/V2_39_2__Add_jsonb_columns_into_visualization_table_fix.sql	584602855	dhis	2026-04-18 15:34:34.273802	5	t
195	2.39.3	New Columns in Visualization	SQL	2.39/V2_39_3__New_Columns_in_Visualization.sql	-189516872	dhis	2026-04-18 15:34:34.273802	3	t
196	2.39.4	Rename Column in Visualization	SQL	2.39/V2_39_4__Rename_Column_in_Visualization.sql	762438058	dhis	2026-04-18 15:34:34.273802	2	t
197	2.39.5	Add column shortName to predictor table	SQL	2.39/V2_39_5__Add_column_shortName_to_predictor_table.sql	812742577	dhis	2026-04-18 15:34:34.273802	0	t
198	2.39.6	Add unique shortName to predictors	JDBC	org.hisp.dhis.db.migration.v39.V2_39_6__Add_unique_shortName_to_predictors	\N	dhis	2026-04-18 15:34:34.273802	0	t
199	2.39.7	Add unique and not null to predictor shortName	SQL	2.39/V2_39_7__Add_unique_and_not_null_to_predictor_shortName.sql	-763416647	dhis	2026-04-18 15:34:34.273802	1	t
200	2.39.8	Add soft delete feature relationship	SQL	2.39/V2_39_8__Add_soft_delete_feature_relationship.sql	1063079188	dhis	2026-04-18 15:34:34.273802	4	t
201	2.39.9	Add column attributevalues to relationshiptype	SQL	2.39/V2_39_9__Add_column_attributevalues_to_relationshiptype.sql	1479901531	dhis	2026-04-18 15:34:34.273802	0	t
202	2.39.10	Update programstageid in relationshipconstraint	SQL	2.39/V2_39_10__Update_programstageid_in_relationshipconstraint.sql	675482031	dhis	2026-04-18 15:34:34.273802	0	t
203	2.39.11	Add LegendSet Column Into EV	SQL	2.39/V2_39_11__Add_LegendSet_Column_Into_EV.sql	-1690774397	dhis	2026-04-18 15:34:34.273802	3	t
204	2.39.13	Potential Duplicate Update ALL Status	SQL	2.39/V2_39_13__Potential_Duplicate_Update_ALL_Status.sql	1579009756	dhis	2026-04-18 15:34:34.273802	0	t
205	2.39.14	Add referral column to relationshiptype	SQL	2.39/V2_39_14__Add_referral_column_to_relationshiptype.sql	285112607	dhis	2026-04-18 15:34:34.273802	1	t
206	2.39.15	Add owner Column Info fileresource table	SQL	2.39/V2_39_15__Add_owner_Column_Info_fileresource_table.sql	-2019617456	dhis	2026-04-18 15:34:34.273802	0	t
207	2.39.16	Add referral parameter to program stage	SQL	2.39/V2_39_16__Add_referral_parameter_to_program_stage.sql	-1564279552	dhis	2026-04-18 15:34:34.273802	1	t
208	2.39.17	Add missing programinstance rows for programs without registration	JDBC	org.hisp.dhis.db.migration.v39.V2_39_17__Add_missing_programinstance_rows_for_programs_without_registration	\N	dhis	2026-04-18 15:34:34.273802	1	t
209	2.39.18	add aggregatedataexchange table	SQL	2.39/V2_39_18__add_aggregatedataexchange_table.sql	1325481296	dhis	2026-04-18 15:34:34.273802	4	t
210	2.39.19	update column dataview in relationshipconstraint table	SQL	2.39/V2_39_19__update_column_dataview_in_relationshipconstraint_table.sql	1337733960	dhis	2026-04-18 15:34:34.273802	3	t
211	2.39.21	Add description optiongroup	SQL	2.39/V2_39_21__Add_description_optiongroup.sql	848939189	dhis	2026-04-18 15:34:34.273802	0	t
212	2.39.22	Update Fileresource fileresourceowner	SQL	2.39/V2_39_22__Update_Fileresource_fileresourceowner.sql	861472802	dhis	2026-04-18 15:34:34.273802	0	t
213	2.39.23	Add description column to category option	SQL	2.39/V2_39_23__Add_description_column_to_category_option.sql	-1310434734	dhis	2026-04-18 15:34:34.273802	0	t
214	2.40.1	Create table expression dimension item	SQL	2.40/V2_40_1__Create_table_expression_dimension_item.sql	672054501	dhis	2026-04-18 15:34:34.273802	2	t
215	2.40.2	Add column datadimensionitem	SQL	2.40/V2_40_2__Add_column_datadimensionitem.sql	-1378431554	dhis	2026-04-18 15:34:34.273802	1	t
216	2.40.3	Add description column to cateory and category option group	SQL	2.40/V2_40_3__Add_description_column_to_cateory_and_category_option_group.sql	-1851413321	dhis	2026-04-18 15:34:34.273802	0	t
217	2.40.4	Add queue columns to jobconfiguration	SQL	2.40/V2_40_4__Add_queue_columns_to_jobconfiguration.sql	1210305658	dhis	2026-04-18 15:34:34.273802	0	t
218	2.40.5	add evenhook table	SQL	2.40/V2_40_5__add_evenhook_table.sql	1176950459	dhis	2026-04-18 15:34:34.273802	3	t
219	2.40.6	Add programindicator column orgunitfield	SQL	2.40/V2_40_6__Add_programindicator_column_orgunitfield.sql	660954253	dhis	2026-04-18 15:34:34.273802	0	t
220	2.40.7	Drop column twoFA userinfo	SQL	2.40/V2_40_7__Drop_column_twoFA_userinfo.sql	1584513675	dhis	2026-04-18 15:34:34.273802	0	t
221	2.40.8	Create table userrolerestrictions	SQL	2.40/V2_40_8__Create_table_userrolerestrictions.sql	421366934	dhis	2026-04-18 15:34:34.273802	0	t
222	2.40.9	Add labeltemplate column into mapview	SQL	2.40/V2_40_9__Add_labeltemplate_column_into_mapview.sql	-387896597	dhis	2026-04-18 15:34:34.273802	0	t
223	2.40.10	Add description column to optionset	SQL	2.40/V2_40_10__Add_description_column_to_optionset.sql	165718163	dhis	2026-04-18 15:34:34.273802	0	t
224	2.40.11	Add description column to org unit group	SQL	2.40/V2_40_11__Add_description_column_to_org_unit_group.sql	-1272094936	dhis	2026-04-18 15:34:34.273802	0	t
225	2.40.12	Add icon column to visualization	SQL	2.40/V2_40_12__Add_icon_column_to_visualization.sql	-381531891	dhis	2026-04-18 15:34:34.273802	0	t
228	2.40.15	Create table program stage working list	SQL	2.40/V2_40_15__Create_table_program_stage_working_list.sql	665646183	dhis	2026-04-18 15:34:34.273802	1	t
229	2.40.16	Unique non null short names	JDBC	org.hisp.dhis.db.migration.v40.V2_40_16__Unique_non_null_short_names	\N	dhis	2026-04-18 15:34:34.273802	1	t
230	2.40.17	Unique non null short names	SQL	2.40/V2_40_17__Unique_non_null_short_names.sql	417095396	dhis	2026-04-18 15:34:34.273802	5	t
231	2.40.18	Remove unique index openid users table	SQL	2.40/V2_40_18__Remove_unique_index_openid_users_table.sql	244662096	dhis	2026-04-18 15:34:34.273802	1	t
232	2.40.19	Remove table trackedentityattributegroup	SQL	2.40/V2_40_19__Remove_table_trackedentityattributegroup.sql	1421478961	dhis	2026-04-18 15:34:34.273802	3	t
233	2.40.21	Update shortname in expressiondimensionitem	SQL	2.40/V2_40_21__Update_shortname_in_expressiondimensionitem.sql	2116053949	dhis	2026-04-18 15:34:34.273802	1	t
234	2.40.24	Update job configuration job parameters	SQL	2.40/V2_40_24__Update_job_configuration_job_parameters.sql	1494635687	dhis	2026-04-18 15:34:34.273802	1	t
235	2.41.1	Merge add delete authorities	SQL	2.41/V2_41_1__Merge_add_delete_authorities.sql	735038974	dhis	2026-04-18 15:34:34.273802	0	t
236	2.41.2	Create table icon	SQL	2.41/V2_41_2__Create_table_icon.sql	391816887	dhis	2026-04-18 15:34:34.273802	3	t
237	2.41.3	Add lock exception created column	SQL	2.41/V2_41_3__Add_lock_exception_created_column.sql	-1188254631	dhis	2026-04-18 15:34:34.273802	0	t
238	2.41.5	Remove nextexecutiontime column from jobconfiguration	SQL	2.41/V2_41_5__Remove_nextexecutiontime_column_from_jobconfiguration.sql	276961416	dhis	2026-04-18 15:34:34.273802	0	t
239	2.41.6	Unique code within each optionset	SQL	2.41/V2_41_6__Unique_code_within_each_optionset.sql	1597528925	dhis	2026-04-18 15:34:34.273802	1	t
240	2.41.7	Add index in table datasetsource	SQL	2.41/V2_41_7__Add_index_in_table_datasetsource.sql	853197400	dhis	2026-04-18 15:34:34.273802	0	t
241	2.41.10	Add missing uid indexes all tables	SQL	2.41/V2_41_10__Add_missing_uid_indexes_all_tables.sql	-1017936897	dhis	2026-04-18 15:34:34.273802	38	t
242	2.41.15	Add executedby column to job configuration	SQL	2.41/V2_41_15__Add_executedby_column_to_job_configuration.sql	1742027809	dhis	2026-04-18 15:34:34.273802	0	t
243	2.41.16	Fix hibernate validate ddl	SQL	2.41/V2_41_16__Fix_hibernate_validate_ddl.sql	1533808729	dhis	2026-04-18 15:34:34.273802	2	t
244	2.41.17	Add sorting to eventvisualization	SQL	2.41/V2_41_17__Add_sorting_to_eventvisualization.sql	1975740290	dhis	2026-04-18 15:34:34.273802	0	t
245	2.41.18	Unique dashboard code column	JDBC	org.hisp.dhis.db.migration.v41.V2_41_18__Unique_dashboard_code_column	\N	dhis	2026-04-18 15:34:34.273802	0	t
246	2.41.19	Unique dashboard code column	SQL	2.41/V2_41_19__Unique_dashboard_code_column.sql	-1457961032	dhis	2026-04-18 15:34:34.273802	0	t
247	2.41.20	ProgramStageInstanceToEvent	SQL	2.41/V2_41_20__ProgramStageInstanceToEvent.sql	2070679376	dhis	2026-04-18 15:34:34.273802	13	t
248	2.41.21	Drop jobconfiguration leaderonlyjob column	SQL	2.41/V2_41_21__Drop_jobconfiguration_leaderonlyjob_column.sql	671695215	dhis	2026-04-18 15:34:34.273802	0	t
249	2.41.22	jobconfiguration db sync	SQL	2.41/V2_41_22__jobconfiguration_db_sync.sql	-610599853	dhis	2026-04-18 15:34:34.273802	2	t
250	2.41.23	ProgramInstanceToEnrollment	SQL	2.41/V2_41_23__ProgramInstanceToEnrollment.sql	22681022	dhis	2026-04-18 15:34:34.273802	11	t
251	2.41.24	TrackedEntityInstanceToTrackedEntity	SQL	2.41/V2_41_24__TrackedEntityInstanceToTrackedEntity.sql	-2136244032	dhis	2026-04-18 15:34:34.273802	20	t
252	2.41.25	RenameTeiInTableColumns	SQL	2.41/V2_41_25__RenameTeiInTableColumns.sql	323903867	dhis	2026-04-18 15:34:34.273802	3	t
253	2.41.26	DropUnusedTables	SQL	2.41/V2_41_26__DropUnusedTables.sql	732311437	dhis	2026-04-18 15:34:34.273802	2	t
254	2.41.27	Add skip rounding to eventvisualization	SQL	2.41/V2_41_27__Add_skip_rounding_to_eventvisualization.sql	1405318974	dhis	2026-04-18 15:34:34.273802	0	t
255	2.41.28	RenameTrackedEntiyCommentToNote	SQL	2.41/V2_41_28__RenameTrackedEntiyCommentToNote.sql	-202398460	dhis	2026-04-18 15:34:34.273802	7	t
256	2.41.29	Multi program eventvisualization	SQL	2.41/V2_41_29__Multi_program_eventvisualization.sql	-1445956582	dhis	2026-04-18 15:34:34.273802	2	t
257	2.41.30	Rename DataElementCategoryOption to CategoryOption	SQL	2.41/V2_41_30__Rename_DataElementCategoryOption_to_CategoryOption.sql	1985293945	dhis	2026-04-18 15:34:34.273802	0	t
258	2.41.31	Add createdatclient to relationship	SQL	2.41/V2_41_31__Add_createdatclient_to_relationship.sql	-298866987	dhis	2026-04-18 15:34:34.273802	0	t
259	2.41.32	job configuation errors in db	SQL	2.41/V2_41_32__job_configuation_errors_in_db.sql	-1289742452	dhis	2026-04-18 15:34:34.273802	0	t
260	2.41.33	Update event status visited to active	SQL	2.41/V2_41_33__Update_event_status_visited_to_active.sql	-1650596508	dhis	2026-04-18 15:34:34.273802	0	t
261	2.41.34	job configuration rename	SQL	2.41/V2_41_34__job_configuration_rename.sql	-687024840	dhis	2026-04-18 15:34:34.273802	0	t
262	2.41.35	RenameDueDateToScheduledDateInEventTable	SQL	2.41/V2_41_35__RenameDueDateToScheduledDateInEventTable.sql	1364597111	dhis	2026-04-18 15:34:34.273802	1	t
263	2.41.36	RenameExecutionDateToOccurredDateInEventTable	SQL	2.41/V2_41_36__RenameExecutionDateToOccurredDateInEventTable.sql	-1692786200	dhis	2026-04-18 15:34:34.273802	1	t
264	2.41.37	RenameEndDateToCompletedDateInEnrollmentTable	SQL	2.41/V2_41_37__RenameEndDateToCompletedDateInEnrollmentTable.sql	956369609	dhis	2026-04-18 15:34:34.273802	1	t
265	2.41.38	RenameIncidentDateToOccurredDateInEnrollmentTable	SQL	2.41/V2_41_38__RenameIncidentDateToOccurredDateInEnrollmentTable.sql	-2107768510	dhis	2026-04-18 15:34:34.273802	1	t
266	2.41.39	Create jsonb function search translations token	SQL	2.41/V2_41_39__Create_jsonb_function_search_translations_token.sql	342546742	dhis	2026-04-18 15:34:34.273802	0	t
267	2.41.41	Fix Audit Type Case Sensitive	SQL	2.41/V2_41_41__Fix_Audit_Type_Case_Sensitive.sql	772859432	dhis	2026-04-18 15:34:34.273802	2	t
268	2.41.42	Add sorting to visualization	SQL	2.41/V2_41_42__Add_sorting_to_visualization.sql	1027045614	dhis	2026-04-18 15:34:34.273802	0	t
269	2.41.43	Configurable label	SQL	2.41/V2_41_43__Configurable_label.sql	-1383332054	dhis	2026-04-18 15:34:34.273802	2	t
270	2.41.44	fixes teta type mismatches	SQL	2.41/V2_41_44__fixes_teta_type_mismatches.sql	634532099	dhis	2026-04-18 15:34:34.273802	2	t
271	2.41.45	More Configurable label	SQL	2.41/V2_41_45__More_Configurable_label.sql	-766685657	dhis	2026-04-18 15:34:34.273802	1	t
272	2.41.46	add section config fields	SQL	2.41/V2_41_46__add_section_config_fields.sql	1307022874	dhis	2026-04-18 15:34:34.273802	0	t
273	2.41.48	Alter trackedentity inactive not null	SQL	2.41/V2_41_48__Alter_trackedentity_inactive_not_null.sql	-1173682314	dhis	2026-04-18 15:34:34.273802	0	t
274	2.41.49	Update api token tokentype	SQL	2.41/V2_41_49__Update_api_token_tokentype.sql	129949388	dhis	2026-04-18 15:34:34.273802	0	t
275	2.41.50	Update dataset timliness to double	SQL	2.41/V2_41_50__Update_dataset_timliness_to_double.sql	1719283518	dhis	2026-04-18 15:34:34.273802	2	t
276	2.41.52	Add new column into visualization and migrate relative periods	JDBC	org.hisp.dhis.db.migration.v41.V2_41_52__Add_new_column_into_visualization_and_migrate_relative_periods	\N	dhis	2026-04-18 15:34:34.273802	5	t
277	2.41.53	create index program rule	SQL	2.41/V2_41_53__create_index_program_rule.sql	-1364475908	dhis	2026-04-18 15:34:34.273802	1	t
278	2.41.54	create lastupdated index event and enrollment	SQL	2.41/V2_41_54__create_lastupdated_index_event_and_enrollment.sql	221936222	dhis	2026-04-18 15:34:34.273802	1	t
279	2.41.55	alter primary key min max dataelement	SQL	2.41/V2_41_55__alter_primary_key_min_max_dataelement.sql	2043207312	dhis	2026-04-18 15:34:34.273802	2	t
280	2.41.56	Add responsetimeout route	SQL	2.41/V2_41_56__Add_responsetimeout_route.sql	447267701	dhis	2026-04-18 15:34:34.273802	1	t
\.


--
-- Data for Name: i18nlocale; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.i18nlocale (i18nlocaleid, uid, code, created, lastupdated, lastupdatedby, name, locale) FROM stdin;
27	D0x2KkddQhU	\N	2026-04-18 15:34:47.621	2026-04-18 15:34:47.621	\N	Pashto	ps
28	bLpKGhgYPSE	\N	2026-04-18 15:34:47.622	2026-04-18 15:34:47.622	\N	Portuguese	pt
29	TevtB8SYSmG	\N	2026-04-18 15:34:47.622	2026-04-18 15:34:47.622	\N	Tajik	tg
30	TeI05FHBC0J	\N	2026-04-18 15:34:47.622	2026-04-18 15:34:47.622	\N	Gujarati	gu
31	mSSg1TV1xYZ	\N	2026-04-18 15:34:47.622	2026-04-18 15:34:47.622	\N	Bislama	bi
32	EVlHktchZsv	\N	2026-04-18 15:34:47.623	2026-04-18 15:34:47.623	\N	German	de
33	H6DJ0SxgQ3T	\N	2026-04-18 15:34:47.623	2026-04-18 15:34:47.623	\N	Khmer	km
34	AQJCAFQ8x2V	\N	2026-04-18 15:34:47.623	2026-04-18 15:34:47.623	\N	Persian	fa
35	BOcAkknSU3H	\N	2026-04-18 15:34:47.623	2026-04-18 15:34:47.623	\N	Italian	it
36	iQS7ZN3wWMR	\N	2026-04-18 15:34:47.624	2026-04-18 15:34:47.624	\N	Russian	ru
37	wohveMRuaKa	\N	2026-04-18 15:34:47.624	2026-04-18 15:34:47.624	\N	Kinyarwanda	rw
38	N4Vls5pZy5D	\N	2026-04-18 15:34:47.624	2026-04-18 15:34:47.624	\N	Vietnamese	vi
39	VeMEXK0LHPb	\N	2026-04-18 15:34:47.624	2026-04-18 15:34:47.624	\N	Chinese	zh
40	IfqYvikrsdF	\N	2026-04-18 15:34:47.624	2026-04-18 15:34:47.624	\N	Hindi	hi
41	r6veRQ44nxN	\N	2026-04-18 15:34:47.624	2026-04-18 15:34:47.624	\N	French	fr
42	xXQb2ARTbNn	\N	2026-04-18 15:34:47.625	2026-04-18 15:34:47.625	\N	Afrikaans	af
43	gnGyBJQmG7h	\N	2026-04-18 15:34:47.625	2026-04-18 15:34:47.625	\N	Dzongkha	dz
44	NrLIsfjus9E	\N	2026-04-18 15:34:47.625	2026-04-18 15:34:47.625	\N	Burmese	my
45	J4dS0SQ42n2	\N	2026-04-18 15:34:47.625	2026-04-18 15:34:47.625	\N	Amharic	am
46	PYK6AqPkOts	\N	2026-04-18 15:34:47.626	2026-04-18 15:34:47.626	\N	Nepali	ne
47	ZG2jbEqT0L5	\N	2026-04-18 15:34:47.626	2026-04-18 15:34:47.626	\N	Arabic	ar
48	e9Fz9cFTbcw	\N	2026-04-18 15:34:47.626	2026-04-18 15:34:47.626	\N	Lao	lo
49	IbHmj9x4ey0	\N	2026-04-18 15:34:47.626	2026-04-18 15:34:47.626	\N	Swahili	sw
50	H1BVbgaEhh7	\N	2026-04-18 15:34:47.626	2026-04-18 15:34:47.626	\N	Dutch	nl
51	XxaPUI5R6Nv	\N	2026-04-18 15:34:47.627	2026-04-18 15:34:47.627	\N	English	en
52	lXbi7MwSBgw	\N	2026-04-18 15:34:47.627	2026-04-18 15:34:47.627	\N	Norwegian	no
53	ac4yTfuXC3R	\N	2026-04-18 15:34:47.627	2026-04-18 15:34:47.627	\N	Indonesian	id
54	K7vsku1lNEU	\N	2026-04-18 15:34:47.627	2026-04-18 15:34:47.627	\N	Spanish	es
\.


--
-- Data for Name: icon; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.icon (iconkey, fileresourceid, description, keywords, created, lastupdated, createdby, custom) FROM stdin;
2g_positive	65		[]	2026-04-18 15:35:20.137592	2026-04-18 15:35:20.137592	\N	f
2g_negative	66		[]	2026-04-18 15:35:20.148285	2026-04-18 15:35:20.148285	\N	f
2g_outline	67		[]	2026-04-18 15:35:20.154274	2026-04-18 15:35:20.154274	\N	f
3g_positive	68		[]	2026-04-18 15:35:20.162614	2026-04-18 15:35:20.162614	\N	f
3g_negative	69		[]	2026-04-18 15:35:20.171434	2026-04-18 15:35:20.171434	\N	f
3g_outline	70		[]	2026-04-18 15:35:20.178345	2026-04-18 15:35:20.178345	\N	f
4x4_positive	71		[]	2026-04-18 15:35:20.185791	2026-04-18 15:35:20.185791	\N	f
4x4_negative	72		[]	2026-04-18 15:35:20.191874	2026-04-18 15:35:20.191874	\N	f
4x4_outline	73		[]	2026-04-18 15:35:20.198592	2026-04-18 15:35:20.198592	\N	f
agriculture_positive	74		["agriculture"]	2026-04-18 15:35:20.205412	2026-04-18 15:35:20.205412	\N	f
agriculture_negative	75		["agriculture"]	2026-04-18 15:35:20.210981	2026-04-18 15:35:20.210981	\N	f
agriculture_outline	76		["agriculture"]	2026-04-18 15:35:20.217328	2026-04-18 15:35:20.217328	\N	f
agriculture_worker_positive	77		["agriculture", "worker"]	2026-04-18 15:35:20.223522	2026-04-18 15:35:20.223522	\N	f
agriculture_worker_negative	78		["agriculture", "worker"]	2026-04-18 15:35:20.230456	2026-04-18 15:35:20.230456	\N	f
agriculture_worker_outline	79		["agriculture", "worker"]	2026-04-18 15:35:20.242646	2026-04-18 15:35:20.242646	\N	f
alert_positive	80		[]	2026-04-18 15:35:20.254014	2026-04-18 15:35:20.254014	\N	f
alert_negative	81		[]	2026-04-18 15:35:20.263042	2026-04-18 15:35:20.263042	\N	f
alert_outline	82		[]	2026-04-18 15:35:20.271973	2026-04-18 15:35:20.271973	\N	f
alert_circle_positive	83		[]	2026-04-18 15:35:20.281564	2026-04-18 15:35:20.281564	\N	f
alert_circle_negative	84		[]	2026-04-18 15:35:20.289488	2026-04-18 15:35:20.289488	\N	f
alert_circle_outline	85		[]	2026-04-18 15:35:20.298276	2026-04-18 15:35:20.298276	\N	f
alert_triangle_positive	86		[]	2026-04-18 15:35:20.308007	2026-04-18 15:35:20.308007	\N	f
alert_triangle_negative	87		[]	2026-04-18 15:35:20.317317	2026-04-18 15:35:20.317317	\N	f
alert_triangle_outline	88		[]	2026-04-18 15:35:20.326026	2026-04-18 15:35:20.326026	\N	f
ambulance_positive	89		["transport", "ambulance"]	2026-04-18 15:35:20.334145	2026-04-18 15:35:20.334145	\N	f
ambulance_negative	90		["transport", "ambulance"]	2026-04-18 15:35:20.342107	2026-04-18 15:35:20.342107	\N	f
ambulance_outline	91		["transport", "ambulance"]	2026-04-18 15:35:20.350675	2026-04-18 15:35:20.350675	\N	f
ambulatory_clinic_positive	92		["refer", "health", "ambulatory"]	2026-04-18 15:35:20.360264	2026-04-18 15:35:20.360264	\N	f
ambulatory_clinic_negative	93		["refer", "health", "ambulatory"]	2026-04-18 15:35:20.369708	2026-04-18 15:35:20.369708	\N	f
ambulatory_clinic_outline	94		["refer", "health", "ambulatory"]	2026-04-18 15:35:20.376983	2026-04-18 15:35:20.376983	\N	f
ancv_positive	95	ANC visit	[]	2026-04-18 15:35:20.384046	2026-04-18 15:35:20.384046	\N	f
ancv_negative	96	ANC visit	[]	2026-04-18 15:35:20.393791	2026-04-18 15:35:20.393791	\N	f
ancv_outline	97	ANC visit	[]	2026-04-18 15:35:20.400682	2026-04-18 15:35:20.400682	\N	f
baby_female_0203m_positive	98		["2-3 months", "baby", "male", "pediatric"]	2026-04-18 15:35:20.407115	2026-04-18 15:35:20.407115	\N	f
baby_female_0203m_negative	99		["2-3 months", "baby", "male", "pediatric"]	2026-04-18 15:35:20.41411	2026-04-18 15:35:20.41411	\N	f
baby_female_0203m_outline	100		["2-3 months", "baby", "male", "pediatric"]	2026-04-18 15:35:20.422396	2026-04-18 15:35:20.422396	\N	f
baby_female_0306m_positive	101		["3-6 months", "baby", "male", "pediatric"]	2026-04-18 15:35:20.42922	2026-04-18 15:35:20.42922	\N	f
baby_female_0306m_negative	102		["3-6 months", "baby", "male", "pediatric"]	2026-04-18 15:35:20.435504	2026-04-18 15:35:20.435504	\N	f
baby_female_0306m_outline	103		["3-6 months", "baby", "male", "pediatric"]	2026-04-18 15:35:20.442598	2026-04-18 15:35:20.442598	\N	f
baby_female_0609m_positive	104		["baby", "6-9 months", "male", "pediatric"]	2026-04-18 15:35:20.449893	2026-04-18 15:35:20.449893	\N	f
baby_female_0609m_negative	105		["baby", "6-9 months", "male", "pediatric"]	2026-04-18 15:35:20.457624	2026-04-18 15:35:20.457624	\N	f
baby_female_0609m_outline	106		["baby", "6-9 months", "male", "pediatric"]	2026-04-18 15:35:20.464695	2026-04-18 15:35:20.464695	\N	f
baby_male_0203m_positive	107		["2-3 months", "baby", "female", "pediatric"]	2026-04-18 15:35:20.47102	2026-04-18 15:35:20.47102	\N	f
baby_male_0203m_negative	108		["2-3 months", "baby", "female", "pediatric"]	2026-04-18 15:35:20.475795	2026-04-18 15:35:20.475795	\N	f
baby_male_0203m_outline	109		["2-3 months", "baby", "female", "pediatric"]	2026-04-18 15:35:20.480725	2026-04-18 15:35:20.480725	\N	f
baby_male_0306m_positive	110		["3-6 months", "baby", "female", "pediatric"]	2026-04-18 15:35:20.485377	2026-04-18 15:35:20.485377	\N	f
baby_male_0306m_negative	111		["3-6 months", "baby", "female", "pediatric"]	2026-04-18 15:35:20.489456	2026-04-18 15:35:20.489456	\N	f
baby_male_0306m_outline	112		["3-6 months", "baby", "female", "pediatric"]	2026-04-18 15:35:20.493466	2026-04-18 15:35:20.493466	\N	f
baby_male_0609m_positive	113		["baby", "female", "6-9 months", "pediatric"]	2026-04-18 15:35:20.49851	2026-04-18 15:35:20.49851	\N	f
baby_male_0609m_negative	114		["baby", "female", "6-9 months", "pediatric"]	2026-04-18 15:35:20.503026	2026-04-18 15:35:20.503026	\N	f
baby_male_0609m_outline	115		["baby", "female", "6-9 months", "pediatric"]	2026-04-18 15:35:20.507888	2026-04-18 15:35:20.507888	\N	f
basic_motorcycle_positive	116		["motorcycle", "transport"]	2026-04-18 15:35:20.513137	2026-04-18 15:35:20.513137	\N	f
basic_motorcycle_negative	117		["motorcycle", "transport"]	2026-04-18 15:35:20.517727	2026-04-18 15:35:20.517727	\N	f
basic_motorcycle_outline	118		["motorcycle", "transport"]	2026-04-18 15:35:20.522585	2026-04-18 15:35:20.522585	\N	f
bike_positive	119		["transport", "bike"]	2026-04-18 15:35:20.527677	2026-04-18 15:35:20.527677	\N	f
bike_negative	120		["transport", "bike"]	2026-04-18 15:35:20.532181	2026-04-18 15:35:20.532181	\N	f
bike_outline	121		["transport", "bike"]	2026-04-18 15:35:20.537582	2026-04-18 15:35:20.537582	\N	f
bills_positive	122	Bills	["money", "buck", "bank notes", "currency", "bills"]	2026-04-18 15:35:20.542614	2026-04-18 15:35:20.542614	\N	f
bills_negative	123	Bills	["money", "buck", "bank notes", "currency", "bills"]	2026-04-18 15:35:20.547381	2026-04-18 15:35:20.547381	\N	f
bills_outline	124	Bills	["money", "buck", "bank notes", "currency", "bills"]	2026-04-18 15:35:20.552069	2026-04-18 15:35:20.552069	\N	f
blister_pills_oval_x1_positive	125		["treatment", "pills", "1", "blister", "oval"]	2026-04-18 15:35:20.557408	2026-04-18 15:35:20.557408	\N	f
blister_pills_oval_x1_negative	126		["treatment", "pills", "1", "blister", "oval"]	2026-04-18 15:35:20.561891	2026-04-18 15:35:20.561891	\N	f
blister_pills_oval_x1_outline	127		["treatment", "pills", "1", "blister", "oval"]	2026-04-18 15:35:20.566945	2026-04-18 15:35:20.566945	\N	f
blister_pills_oval_x14_positive	128		["treatment", "pills", "14", "blister", "oval"]	2026-04-18 15:35:20.572672	2026-04-18 15:35:20.572672	\N	f
blister_pills_oval_x14_negative	129		["treatment", "pills", "14", "blister", "oval"]	2026-04-18 15:35:20.578599	2026-04-18 15:35:20.578599	\N	f
blister_pills_oval_x14_outline	130		["treatment", "pills", "14", "blister", "oval"]	2026-04-18 15:35:20.584311	2026-04-18 15:35:20.584311	\N	f
blister_pills_oval_x16_positive	131		["treatment", "pills", "16", "blister", "oval"]	2026-04-18 15:35:20.588907	2026-04-18 15:35:20.588907	\N	f
blister_pills_oval_x16_negative	132		["treatment", "pills", "16", "blister", "oval"]	2026-04-18 15:35:20.593357	2026-04-18 15:35:20.593357	\N	f
blister_pills_oval_x16_outline	133		["treatment", "pills", "16", "blister", "oval"]	2026-04-18 15:35:20.59826	2026-04-18 15:35:20.59826	\N	f
blister_pills_oval_x4_negative	135		["treatment", "pills", "4", "blister", "oval"]	2026-04-18 15:35:20.607679	2026-04-18 15:35:20.607679	\N	f
blister_pills_oval_x4_outline	136		["treatment", "pills", "4", "blister", "oval"]	2026-04-18 15:35:20.611868	2026-04-18 15:35:20.611868	\N	f
blister_pills_round_x1_positive	137		["treatment", "pills", "1", "round", "blister"]	2026-04-18 15:35:20.61636	2026-04-18 15:35:20.61636	\N	f
blister_pills_round_x1_negative	138		["treatment", "pills", "1", "round", "blister"]	2026-04-18 15:35:20.620431	2026-04-18 15:35:20.620431	\N	f
blister_pills_round_x14_outline	142		["treatment", "pills", "14", "round", "blister"]	2026-04-18 15:35:20.640237	2026-04-18 15:35:20.640237	\N	f
blister_pills_round_x16_positive	143		["treatment", "pills", "round", "16", "blister"]	2026-04-18 15:35:20.64476	2026-04-18 15:35:20.64476	\N	f
blister_pills_round_x4_positive	146		["treatment", "pills", "round", "4", "blister"]	2026-04-18 15:35:20.682671	2026-04-18 15:35:20.682671	\N	f
blood_a_p_outline	154		["a", "hematology", "positive", "blood"]	2026-04-18 15:35:20.727882	2026-04-18 15:35:20.727882	\N	f
blood_ab_n_positive	155		["ab", "hematology", "negative", "blood"]	2026-04-18 15:35:20.73208	2026-04-18 15:35:20.73208	\N	f
blood_ab_n_negative	156		["ab", "hematology", "negative", "blood"]	2026-04-18 15:35:20.735978	2026-04-18 15:35:20.735978	\N	f
blood_ab_n_outline	157		["ab", "hematology", "negative", "blood"]	2026-04-18 15:35:20.741266	2026-04-18 15:35:20.741266	\N	f
blood_ab_p_outline	160		["ab", "hematology", "positive", "blood"]	2026-04-18 15:35:20.755913	2026-04-18 15:35:20.755913	\N	f
blood_b_n_positive	161		["hematology", "b", "negative", "blood"]	2026-04-18 15:35:20.760236	2026-04-18 15:35:20.760236	\N	f
blood_b_n_negative	162		["hematology", "b", "negative", "blood"]	2026-04-18 15:35:20.763807	2026-04-18 15:35:20.763807	\N	f
blood_b_n_outline	163		["hematology", "b", "negative", "blood"]	2026-04-18 15:35:20.767284	2026-04-18 15:35:20.767284	\N	f
blood_b_p_positive	164		["hematology", "b", "positive", "blood"]	2026-04-18 15:35:20.771563	2026-04-18 15:35:20.771563	\N	f
blood_b_p_negative	165		["hematology", "b", "positive", "blood"]	2026-04-18 15:35:20.775491	2026-04-18 15:35:20.775491	\N	f
blood_b_p_outline	166		["hematology", "b", "positive", "blood"]	2026-04-18 15:35:20.779058	2026-04-18 15:35:20.779058	\N	f
blood_o_n_positive	167		["hematology", "negative", "blood", "o"]	2026-04-18 15:35:20.783947	2026-04-18 15:35:20.783947	\N	f
blood_pressure_monitor_negative	180		["pressure", "blood"]	2026-04-18 15:35:20.84664	2026-04-18 15:35:20.84664	\N	f
blood_rh_n_positive	182		["hematology", "negative", "rh", "blood"]	2026-04-18 15:35:20.855156	2026-04-18 15:35:20.855156	\N	f
blood_rh_n_negative	183		["hematology", "negative", "rh", "blood"]	2026-04-18 15:35:20.859297	2026-04-18 15:35:20.859297	\N	f
boy_0105y_negative	189		["1-5 Yrs", "boy"]	2026-04-18 15:35:20.895451	2026-04-18 15:35:20.895451	\N	f
boy_0105y_outline	190		["1-5 Yrs", "boy"]	2026-04-18 15:35:20.904309	2026-04-18 15:35:20.904309	\N	f
cardiogram_outline	202	Cardiogram card	["medical history"]	2026-04-18 15:35:20.985691	2026-04-18 15:35:20.985691	\N	f
child_care_positive	209	Children	["toddler", "kid", "baby", "care", "child"]	2026-04-18 15:35:21.021193	2026-04-18 15:35:21.021193	\N	f
child_care_negative	210	Children	["toddler", "kid", "baby", "care", "child"]	2026-04-18 15:35:21.025037	2026-04-18 15:35:21.025037	\N	f
circle_medium_positive	227		[]	2026-04-18 15:35:21.093777	2026-04-18 15:35:21.093777	\N	f
circle_medium_negative	228		[]	2026-04-18 15:35:21.097273	2026-04-18 15:35:21.097273	\N	f
circle_medium_outline	229		[]	2026-04-18 15:35:21.101	2026-04-18 15:35:21.101	\N	f
circle_small_positive	230		[]	2026-04-18 15:35:21.104849	2026-04-18 15:35:21.104849	\N	f
circle_small_negative	231		[]	2026-04-18 15:35:21.10799	2026-04-18 15:35:21.10799	\N	f
circle_small_outline	232		[]	2026-04-18 15:35:21.111281	2026-04-18 15:35:21.111281	\N	f
city_worker_positive	236		["city worker", "worker"]	2026-04-18 15:35:21.125119	2026-04-18 15:35:21.125119	\N	f
city_worker_negative	237		["city worker", "worker"]	2026-04-18 15:35:21.12951	2026-04-18 15:35:21.12951	\N	f
city_worker_outline	238		["city worker", "worker"]	2026-04-18 15:35:21.133542	2026-04-18 15:35:21.133542	\N	f
clean_hands_positive	239	Clean hands	["washing", "hands", "sanitizer", "clean", "soap"]	2026-04-18 15:35:21.137679	2026-04-18 15:35:21.137679	\N	f
clean_hands_negative	240	Clean hands	["washing", "hands", "sanitizer", "clean", "soap"]	2026-04-18 15:35:21.141518	2026-04-18 15:35:21.141518	\N	f
clean_hands_outline	241	Clean hands	["washing", "hands", "sanitizer", "clean", "soap"]	2026-04-18 15:35:21.145748	2026-04-18 15:35:21.145748	\N	f
clinical_a_positive	242	Clinical analysis	[]	2026-04-18 15:35:21.149578	2026-04-18 15:35:21.149578	\N	f
clinical_a_negative	243	Clinical analysis	[]	2026-04-18 15:35:21.15309	2026-04-18 15:35:21.15309	\N	f
clinical_a_outline	244	Clinical analysis	[]	2026-04-18 15:35:21.157263	2026-04-18 15:35:21.157263	\N	f
clinical_f_positive	245	Clinical file	["Clinical file", "medical history", "diagnosis test", "patient record"]	2026-04-18 15:35:21.161567	2026-04-18 15:35:21.161567	\N	f
blister_pills_oval_x4_positive	134		["treatment", "pills", "4", "blister", "oval"]	2026-04-18 15:35:20.602324	2026-04-18 15:35:20.602324	\N	f
blister_pills_round_x1_outline	139		["treatment", "pills", "1", "round", "blister"]	2026-04-18 15:35:20.625669	2026-04-18 15:35:20.625669	\N	f
blister_pills_round_x14_positive	140		["treatment", "pills", "14", "round", "blister"]	2026-04-18 15:35:20.630162	2026-04-18 15:35:20.630162	\N	f
blister_pills_round_x14_negative	141		["treatment", "pills", "14", "round", "blister"]	2026-04-18 15:35:20.635486	2026-04-18 15:35:20.635486	\N	f
blister_pills_round_x16_negative	144		["treatment", "pills", "round", "16", "blister"]	2026-04-18 15:35:20.649885	2026-04-18 15:35:20.649885	\N	f
blister_pills_round_x16_outline	145		["treatment", "pills", "round", "16", "blister"]	2026-04-18 15:35:20.654984	2026-04-18 15:35:20.654984	\N	f
blister_pills_round_x4_negative	147		["treatment", "pills", "round", "4", "blister"]	2026-04-18 15:35:20.69423	2026-04-18 15:35:20.69423	\N	f
blister_pills_round_x4_outline	148		["treatment", "pills", "round", "4", "blister"]	2026-04-18 15:35:20.701236	2026-04-18 15:35:20.701236	\N	f
blood_a_n_positive	149		["a", "hematology", "negative", "blood"]	2026-04-18 15:35:20.705442	2026-04-18 15:35:20.705442	\N	f
blood_a_n_negative	150		["a", "hematology", "negative", "blood"]	2026-04-18 15:35:20.708992	2026-04-18 15:35:20.708992	\N	f
blood_a_n_outline	151		["a", "hematology", "negative", "blood"]	2026-04-18 15:35:20.712816	2026-04-18 15:35:20.712816	\N	f
blood_a_p_positive	152		["a", "hematology", "positive", "blood"]	2026-04-18 15:35:20.717701	2026-04-18 15:35:20.717701	\N	f
blood_a_p_negative	153		["a", "hematology", "positive", "blood"]	2026-04-18 15:35:20.722569	2026-04-18 15:35:20.722569	\N	f
blood_ab_p_positive	158		["ab", "hematology", "positive", "blood"]	2026-04-18 15:35:20.745975	2026-04-18 15:35:20.745975	\N	f
blood_ab_p_negative	159		["ab", "hematology", "positive", "blood"]	2026-04-18 15:35:20.750817	2026-04-18 15:35:20.750817	\N	f
blood_o_n_negative	168		["hematology", "negative", "blood", "o"]	2026-04-18 15:35:20.787916	2026-04-18 15:35:20.787916	\N	f
blood_o_n_outline	169		["hematology", "negative", "blood", "o"]	2026-04-18 15:35:20.791774	2026-04-18 15:35:20.791774	\N	f
blood_o_p_positive	170		["hematology", "positive", "blood", "o"]	2026-04-18 15:35:20.796051	2026-04-18 15:35:20.796051	\N	f
blood_o_p_negative	171		["hematology", "positive", "blood", "o"]	2026-04-18 15:35:20.799296	2026-04-18 15:35:20.799296	\N	f
blood_o_p_outline	172		["hematology", "positive", "blood", "o"]	2026-04-18 15:35:20.803517	2026-04-18 15:35:20.803517	\N	f
blood_pressure_positive	173		["Blood Pressure"]	2026-04-18 15:35:20.807741	2026-04-18 15:35:20.807741	\N	f
blood_pressure_negative	174		["Blood Pressure"]	2026-04-18 15:35:20.810971	2026-04-18 15:35:20.810971	\N	f
blood_pressure_outline	175		["Blood Pressure"]	2026-04-18 15:35:20.814352	2026-04-18 15:35:20.814352	\N	f
blood_pressure_2_positive	176		["pressure", "blood"]	2026-04-18 15:35:20.818524	2026-04-18 15:35:20.818524	\N	f
blood_pressure_2_negative	177		["pressure", "blood"]	2026-04-18 15:35:20.821984	2026-04-18 15:35:20.821984	\N	f
blood_pressure_2_outline	178		["pressure", "blood"]	2026-04-18 15:35:20.825863	2026-04-18 15:35:20.825863	\N	f
blood_pressure_monitor_positive	179		["pressure", "blood"]	2026-04-18 15:35:20.837193	2026-04-18 15:35:20.837193	\N	f
blood_pressure_monitor_outline	181		["pressure", "blood"]	2026-04-18 15:35:20.850727	2026-04-18 15:35:20.850727	\N	f
blood_rh_n_outline	184		["hematology", "negative", "rh", "blood"]	2026-04-18 15:35:20.863623	2026-04-18 15:35:20.863623	\N	f
blood_rh_p_positive	185		["hematology", "rh", "positive", "blood"]	2026-04-18 15:35:20.868255	2026-04-18 15:35:20.868255	\N	f
blood_rh_p_negative	186		["hematology", "rh", "positive", "blood"]	2026-04-18 15:35:20.87234	2026-04-18 15:35:20.87234	\N	f
blood_rh_p_outline	187		["hematology", "rh", "positive", "blood"]	2026-04-18 15:35:20.87819	2026-04-18 15:35:20.87819	\N	f
boy_0105y_positive	188		["1-5 Yrs", "boy"]	2026-04-18 15:35:20.888236	2026-04-18 15:35:20.888236	\N	f
boy_1015y_positive	191		["boy", "10-15 Yrs"]	2026-04-18 15:35:20.910663	2026-04-18 15:35:20.910663	\N	f
boy_1015y_negative	192		["boy", "10-15 Yrs"]	2026-04-18 15:35:20.920476	2026-04-18 15:35:20.920476	\N	f
boy_1015y_outline	193		["boy", "10-15 Yrs"]	2026-04-18 15:35:20.927407	2026-04-18 15:35:20.927407	\N	f
breeding_sites_positive	194	Breeding sites	["pupa", "larva", "malaria", "mosquito", "reproduction"]	2026-04-18 15:35:20.935724	2026-04-18 15:35:20.935724	\N	f
breeding_sites_negative	195	Breeding sites	["pupa", "larva", "malaria", "mosquito", "reproduction"]	2026-04-18 15:35:20.950873	2026-04-18 15:35:20.950873	\N	f
breeding_sites_outline	196	Breeding sites	["pupa", "larva", "malaria", "mosquito", "reproduction"]	2026-04-18 15:35:20.956698	2026-04-18 15:35:20.956698	\N	f
calendar_positive	197		["calendar"]	2026-04-18 15:35:20.961109	2026-04-18 15:35:20.961109	\N	f
calendar_negative	198		["calendar"]	2026-04-18 15:35:20.966227	2026-04-18 15:35:20.966227	\N	f
calendar_outline	199		["calendar"]	2026-04-18 15:35:20.970792	2026-04-18 15:35:20.970792	\N	f
cardiogram_positive	200	Cardiogram card	["medical history"]	2026-04-18 15:35:20.975238	2026-04-18 15:35:20.975238	\N	f
cardiogram_negative	201	Cardiogram card	["medical history"]	2026-04-18 15:35:20.979797	2026-04-18 15:35:20.979797	\N	f
cardiogram_e_positive	203	Edit ardiogram card	["Cardiogram card", "cardiogram"]	2026-04-18 15:35:20.989672	2026-04-18 15:35:20.989672	\N	f
cardiogram_e_negative	204	Edit ardiogram card	["Cardiogram card", "cardiogram"]	2026-04-18 15:35:20.99355	2026-04-18 15:35:20.99355	\N	f
cardiogram_e_outline	205	Edit ardiogram card	["Cardiogram card", "cardiogram"]	2026-04-18 15:35:20.999302	2026-04-18 15:35:20.999302	\N	f
cervical_cancer_positive	206		["cervical", "cancer", "female"]	2026-04-18 15:35:21.00535	2026-04-18 15:35:21.00535	\N	f
cervical_cancer_negative	207		["cervical", "cancer", "female"]	2026-04-18 15:35:21.010929	2026-04-18 15:35:21.010929	\N	f
cervical_cancer_outline	208		["cervical", "cancer", "female"]	2026-04-18 15:35:21.016153	2026-04-18 15:35:21.016153	\N	f
child_care_outline	211	Children	["toddler", "kid", "baby", "care", "child"]	2026-04-18 15:35:21.030138	2026-04-18 15:35:21.030138	\N	f
child_program_positive	212	child program	[]	2026-04-18 15:35:21.035191	2026-04-18 15:35:21.035191	\N	f
child_program_negative	213	child program	[]	2026-04-18 15:35:21.039454	2026-04-18 15:35:21.039454	\N	f
child_program_outline	214	child program	[]	2026-04-18 15:35:21.042712	2026-04-18 15:35:21.042712	\N	f
chills_positive	215		["symptom", "chills", "patient", "diagnosis"]	2026-04-18 15:35:21.047357	2026-04-18 15:35:21.047357	\N	f
chills_negative	216		["symptom", "chills", "patient", "diagnosis"]	2026-04-18 15:35:21.051448	2026-04-18 15:35:21.051448	\N	f
chills_outline	217		["symptom", "chills", "patient", "diagnosis"]	2026-04-18 15:35:21.055043	2026-04-18 15:35:21.055043	\N	f
cholera_positive	218		["vibrio cholerae", "cholera"]	2026-04-18 15:35:21.0598	2026-04-18 15:35:21.0598	\N	f
cholera_negative	219		["vibrio cholerae", "cholera"]	2026-04-18 15:35:21.063322	2026-04-18 15:35:21.063322	\N	f
cholera_outline	220		["vibrio cholerae", "cholera"]	2026-04-18 15:35:21.066736	2026-04-18 15:35:21.066736	\N	f
church_positive	221		[]	2026-04-18 15:35:21.071454	2026-04-18 15:35:21.071454	\N	f
church_negative	222		[]	2026-04-18 15:35:21.075132	2026-04-18 15:35:21.075132	\N	f
church_outline	223		[]	2026-04-18 15:35:21.078131	2026-04-18 15:35:21.078131	\N	f
circle_large_positive	224		[]	2026-04-18 15:35:21.081902	2026-04-18 15:35:21.081902	\N	f
circle_large_negative	225		[]	2026-04-18 15:35:21.086074	2026-04-18 15:35:21.086074	\N	f
circle_large_outline	226		[]	2026-04-18 15:35:21.089584	2026-04-18 15:35:21.089584	\N	f
city_positive	233	City	["city", "house", "edifice", "building", "architecture"]	2026-04-18 15:35:21.115421	2026-04-18 15:35:21.115421	\N	f
city_negative	234	City	["city", "house", "edifice", "building", "architecture"]	2026-04-18 15:35:21.11892	2026-04-18 15:35:21.11892	\N	f
city_outline	235	City	["city", "house", "edifice", "building", "architecture"]	2026-04-18 15:35:21.122018	2026-04-18 15:35:21.122018	\N	f
contraceptive_diaphragm_positive	275		["female", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.372147	2026-04-18 15:35:21.372147	\N	f
contraceptive_diaphragm_negative	276		["female", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.377731	2026-04-18 15:35:21.377731	\N	f
contraceptive_diaphragm_outline	277		["female", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.382113	2026-04-18 15:35:21.382113	\N	f
contraceptive_injection_positive	278		["inyectable", "female", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.385761	2026-04-18 15:35:21.385761	\N	f
contraceptive_injection_negative	279		["inyectable", "female", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.390327	2026-04-18 15:35:21.390327	\N	f
contraceptive_injection_outline	280		["inyectable", "female", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.394264	2026-04-18 15:35:21.394264	\N	f
contraceptive_patch_positive	281		["female", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.398477	2026-04-18 15:35:21.398477	\N	f
contraceptive_patch_negative	282		["female", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.402275	2026-04-18 15:35:21.402275	\N	f
contraceptive_patch_outline	283		["female", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.40609	2026-04-18 15:35:21.40609	\N	f
contraceptive_voucher_positive	284	contraceptive voucher	[]	2026-04-18 15:35:21.41108	2026-04-18 15:35:21.41108	\N	f
contraceptive_voucher_negative	285	contraceptive voucher	[]	2026-04-18 15:35:21.415246	2026-04-18 15:35:21.415246	\N	f
contraceptive_voucher_outline	286	contraceptive voucher	[]	2026-04-18 15:35:21.41938	2026-04-18 15:35:21.41938	\N	f
copper_iud_positive	287		["copper iud", "copper", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.422741	2026-04-18 15:35:21.422741	\N	f
copper_iud_negative	288		["copper iud", "copper", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.427118	2026-04-18 15:35:21.427118	\N	f
copper_iud_outline	289		["copper iud", "copper", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.430832	2026-04-18 15:35:21.430832	\N	f
cross_country_motorcycle_positive	296		["motorcycle", "transport"]	2026-04-18 15:35:21.461241	2026-04-18 15:35:21.461241	\N	f
cross_country_motorcycle_negative	297		["motorcycle", "transport"]	2026-04-18 15:35:21.465234	2026-04-18 15:35:21.465234	\N	f
cross_country_motorcycle_outline	298		["motorcycle", "transport"]	2026-04-18 15:35:21.469713	2026-04-18 15:35:21.469713	\N	f
diarrhea_positive	305		["symptom", "patient", "diagnosis", "diarrhea"]	2026-04-18 15:35:21.496988	2026-04-18 15:35:21.496988	\N	f
drone_negative	321		[]	2026-04-18 15:35:21.567725	2026-04-18 15:35:21.567725	\N	f
drone_outline	322		[]	2026-04-18 15:35:21.572286	2026-04-18 15:35:21.572286	\N	f
eco_care_positive	323	Eco care	["eco", "world", "nature", "bio", "care"]	2026-04-18 15:35:21.57614	2026-04-18 15:35:21.57614	\N	f
eco_care_negative	324	Eco care	["eco", "world", "nature", "bio", "care"]	2026-04-18 15:35:21.580519	2026-04-18 15:35:21.580519	\N	f
expectorate_negative	336		["symptom", "diagnosis", "expectorate"]	2026-04-18 15:35:21.62475	2026-04-18 15:35:21.62475	\N	f
expectorate_outline	337		["symptom", "diagnosis", "expectorate"]	2026-04-18 15:35:21.629769	2026-04-18 15:35:21.629769	\N	f
factory_worker_positive	338		["factory", "worker"]	2026-04-18 15:35:21.632735	2026-04-18 15:35:21.632735	\N	f
factory_worker_negative	339		["factory", "worker"]	2026-04-18 15:35:21.639424	2026-04-18 15:35:21.639424	\N	f
clinical_f_negative	246	Clinical file	["Clinical file", "medical history", "diagnosis test", "patient record"]	2026-04-18 15:35:21.166752	2026-04-18 15:35:21.166752	\N	f
clinical_f_outline	247	Clinical file	["Clinical file", "medical history", "diagnosis test", "patient record"]	2026-04-18 15:35:21.170536	2026-04-18 15:35:21.170536	\N	f
clinical_fe_positive	248	Edit clinical file	["medical history", "diagnosis test"]	2026-04-18 15:35:21.174461	2026-04-18 15:35:21.174461	\N	f
clinical_fe_negative	249	Edit clinical file	["medical history", "diagnosis test"]	2026-04-18 15:35:21.194427	2026-04-18 15:35:21.194427	\N	f
clinical_fe_outline	250	Edit clinical file	["medical history", "diagnosis test"]	2026-04-18 15:35:21.208772	2026-04-18 15:35:21.208772	\N	f
coins_positive	251	Money	["wealth", "money", "payment", "cash"]	2026-04-18 15:35:21.212053	2026-04-18 15:35:21.212053	\N	f
coins_negative	252	Money	["wealth", "money", "payment", "cash"]	2026-04-18 15:35:21.215281	2026-04-18 15:35:21.215281	\N	f
coins_outline	253	Money	["wealth", "money", "payment", "cash"]	2026-04-18 15:35:21.219659	2026-04-18 15:35:21.219659	\N	f
cold_chain_positive	254		["cold", "cold chain"]	2026-04-18 15:35:21.222905	2026-04-18 15:35:21.222905	\N	f
cold_chain_negative	255		["cold", "cold chain"]	2026-04-18 15:35:21.226844	2026-04-18 15:35:21.226844	\N	f
cold_chain_outline	256		["cold", "cold chain"]	2026-04-18 15:35:21.236882	2026-04-18 15:35:21.236882	\N	f
communication_positive	257		["contact", "communication"]	2026-04-18 15:35:21.243501	2026-04-18 15:35:21.243501	\N	f
communication_negative	258		["contact", "communication"]	2026-04-18 15:35:21.252779	2026-04-18 15:35:21.252779	\N	f
communication_outline	259		["contact", "communication"]	2026-04-18 15:35:21.257662	2026-04-18 15:35:21.257662	\N	f
cone_test_on_nets_positive	260	Cone test on nets	["test", "nets", "malaria", "analysis", "cone"]	2026-04-18 15:35:21.267117	2026-04-18 15:35:21.267117	\N	f
cone_test_on_nets_negative	261	Cone test on nets	["test", "nets", "malaria", "analysis", "cone"]	2026-04-18 15:35:21.277292	2026-04-18 15:35:21.277292	\N	f
cone_test_on_nets_outline	262	Cone test on nets	["test", "nets", "malaria", "analysis", "cone"]	2026-04-18 15:35:21.28627	2026-04-18 15:35:21.28627	\N	f
cone_test_on_walls_positive	263	Cone test on walls	["test", "malaria", "analysis", "cone", "wall"]	2026-04-18 15:35:21.294871	2026-04-18 15:35:21.294871	\N	f
cone_test_on_walls_negative	264	Cone test on walls	["test", "malaria", "analysis", "cone", "wall"]	2026-04-18 15:35:21.302642	2026-04-18 15:35:21.302642	\N	f
cone_test_on_walls_outline	265	Cone test on walls	["test", "malaria", "analysis", "cone", "wall"]	2026-04-18 15:35:21.30668	2026-04-18 15:35:21.30668	\N	f
construction_positive	266		["infrastructure", "construction", "worker"]	2026-04-18 15:35:21.309855	2026-04-18 15:35:21.309855	\N	f
construction_negative	267		["infrastructure", "construction", "worker"]	2026-04-18 15:35:21.31458	2026-04-18 15:35:21.31458	\N	f
construction_outline	268		["infrastructure", "construction", "worker"]	2026-04-18 15:35:21.319002	2026-04-18 15:35:21.319002	\N	f
construction_worker_positive	269		["construction", "worker"]	2026-04-18 15:35:21.323709	2026-04-18 15:35:21.323709	\N	f
construction_worker_negative	270		["construction", "worker"]	2026-04-18 15:35:21.331465	2026-04-18 15:35:21.331465	\N	f
construction_worker_outline	271		["construction", "worker"]	2026-04-18 15:35:21.335107	2026-04-18 15:35:21.335107	\N	f
contact_support_positive	272	Contact support	["question", "contact", "support", "info"]	2026-04-18 15:35:21.341253	2026-04-18 15:35:21.341253	\N	f
contact_support_negative	273	Contact support	["question", "contact", "support", "info"]	2026-04-18 15:35:21.350589	2026-04-18 15:35:21.350589	\N	f
contact_support_outline	274	Contact support	["question", "contact", "support", "info"]	2026-04-18 15:35:21.359888	2026-04-18 15:35:21.359888	\N	f
coughing_positive	290		["symptom", "coughing", "diagnosis", "cough"]	2026-04-18 15:35:21.438322	2026-04-18 15:35:21.438322	\N	f
coughing_negative	291		["symptom", "coughing", "diagnosis", "cough"]	2026-04-18 15:35:21.441773	2026-04-18 15:35:21.441773	\N	f
coughing_outline	292		["symptom", "coughing", "diagnosis", "cough"]	2026-04-18 15:35:21.445545	2026-04-18 15:35:21.445545	\N	f
credit_card_positive	293	Credit card	["bank", "money", "credit", "debit", "card"]	2026-04-18 15:35:21.449228	2026-04-18 15:35:21.449228	\N	f
credit_card_negative	294	Credit card	["bank", "money", "credit", "debit", "card"]	2026-04-18 15:35:21.453403	2026-04-18 15:35:21.453403	\N	f
credit_card_outline	295	Credit card	["bank", "money", "credit", "debit", "card"]	2026-04-18 15:35:21.457117	2026-04-18 15:35:21.457117	\N	f
default_positive	299		["default"]	2026-04-18 15:35:21.472592	2026-04-18 15:35:21.472592	\N	f
default_negative	300		["default"]	2026-04-18 15:35:21.475988	2026-04-18 15:35:21.475988	\N	f
default_outline	301		["default"]	2026-04-18 15:35:21.479584	2026-04-18 15:35:21.479584	\N	f
dhis2_logo_positive	302	DHIS2	["dhis2", "logo", "DHIS"]	2026-04-18 15:35:21.484266	2026-04-18 15:35:21.484266	\N	f
dhis2_logo_negative	303	DHIS2	["dhis2", "logo", "DHIS"]	2026-04-18 15:35:21.48726	2026-04-18 15:35:21.48726	\N	f
dhis2_logo_outline	304	DHIS2	["dhis2", "logo", "DHIS"]	2026-04-18 15:35:21.491677	2026-04-18 15:35:21.491677	\N	f
diarrhea_negative	306		["symptom", "patient", "diagnosis", "diarrhea"]	2026-04-18 15:35:21.50163	2026-04-18 15:35:21.50163	\N	f
diarrhea_outline	307		["symptom", "patient", "diagnosis", "diarrhea"]	2026-04-18 15:35:21.506182	2026-04-18 15:35:21.506182	\N	f
discriminating_concentration_bioassays_positive	308	Discriminating concentration bioassays	["assay", "concentration", "analysis", "malaria", "mosquito"]	2026-04-18 15:35:21.509699	2026-04-18 15:35:21.509699	\N	f
discriminating_concentration_bioassays_negative	309	Discriminating concentration bioassays	["assay", "concentration", "analysis", "malaria", "mosquito"]	2026-04-18 15:35:21.513144	2026-04-18 15:35:21.513144	\N	f
discriminating_concentration_bioassays_outline	310	Discriminating concentration bioassays	["assay", "concentration", "analysis", "malaria", "mosquito"]	2026-04-18 15:35:21.516933	2026-04-18 15:35:21.516933	\N	f
doctor_positive	311	Doctor	["doctor", "medical person", "nurse", "health", "worker"]	2026-04-18 15:35:21.520503	2026-04-18 15:35:21.520503	\N	f
doctor_negative	312	Doctor	["doctor", "medical person", "nurse", "health", "worker"]	2026-04-18 15:35:21.523826	2026-04-18 15:35:21.523826	\N	f
doctor_outline	313	Doctor	["doctor", "medical person", "nurse", "health", "worker"]	2026-04-18 15:35:21.530511	2026-04-18 15:35:21.530511	\N	f
domestic_worker_positive	314		["domestic", "domestic worker"]	2026-04-18 15:35:21.537491	2026-04-18 15:35:21.537491	\N	f
domestic_worker_negative	315		["domestic", "domestic worker"]	2026-04-18 15:35:21.544656	2026-04-18 15:35:21.544656	\N	f
domestic_worker_outline	316		["domestic", "domestic worker"]	2026-04-18 15:35:21.548477	2026-04-18 15:35:21.548477	\N	f
donkey_positive	317		["donkey", "transport"]	2026-04-18 15:35:21.552053	2026-04-18 15:35:21.552053	\N	f
donkey_negative	318		["donkey", "transport"]	2026-04-18 15:35:21.555893	2026-04-18 15:35:21.555893	\N	f
donkey_outline	319		["donkey", "transport"]	2026-04-18 15:35:21.559585	2026-04-18 15:35:21.559585	\N	f
drone_positive	320		[]	2026-04-18 15:35:21.563032	2026-04-18 15:35:21.563032	\N	f
eco_care_outline	325	Eco care	["eco", "world", "nature", "bio", "care"]	2026-04-18 15:35:21.584354	2026-04-18 15:35:21.584354	\N	f
elderly_positive	326	Elderly	["person", "old", "aged", "aging", "people"]	2026-04-18 15:35:21.588809	2026-04-18 15:35:21.588809	\N	f
elderly_negative	327	Elderly	["person", "old", "aged", "aging", "people"]	2026-04-18 15:35:21.594075	2026-04-18 15:35:21.594075	\N	f
elderly_outline	328	Elderly	["person", "old", "aged", "aging", "people"]	2026-04-18 15:35:21.59775	2026-04-18 15:35:21.59775	\N	f
electricity_positive	329		["electricity"]	2026-04-18 15:35:21.601343	2026-04-18 15:35:21.601343	\N	f
electricity_negative	330		["electricity"]	2026-04-18 15:35:21.60471	2026-04-18 15:35:21.60471	\N	f
electricity_outline	331		["electricity"]	2026-04-18 15:35:21.608445	2026-04-18 15:35:21.608445	\N	f
emergency_post_positive	332		["emergency", "emergency post"]	2026-04-18 15:35:21.61154	2026-04-18 15:35:21.61154	\N	f
emergency_post_negative	333		["emergency", "emergency post"]	2026-04-18 15:35:21.615064	2026-04-18 15:35:21.615064	\N	f
emergency_post_outline	334		["emergency", "emergency post"]	2026-04-18 15:35:21.61842	2026-04-18 15:35:21.61842	\N	f
expectorate_positive	335		["symptom", "diagnosis", "expectorate"]	2026-04-18 15:35:21.62119	2026-04-18 15:35:21.62119	\N	f
factory_worker_outline	340		["factory", "worker"]	2026-04-18 15:35:21.646577	2026-04-18 15:35:21.646577	\N	f
family_planning_positive	341		["family planning", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.652357	2026-04-18 15:35:21.652357	\N	f
family_planning_negative	342		["family planning", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.656727	2026-04-18 15:35:21.656727	\N	f
family_planning_outline	343		["family planning", "contraception", "sexual", "reproductive"]	2026-04-18 15:35:21.662423	2026-04-18 15:35:21.662423	\N	f
female_and_male_positive	344	Female and Male adult	[]	2026-04-18 15:35:21.667733	2026-04-18 15:35:21.667733	\N	f
female_and_male_negative	345	Female and Male adult	[]	2026-04-18 15:35:21.672101	2026-04-18 15:35:21.672101	\N	f
female_and_male_outline	346	Female and Male adult	[]	2026-04-18 15:35:21.675004	2026-04-18 15:35:21.675004	\N	f
female_condom_positive	347		["female", "contraception", "sexual", "condom", "reproductive"]	2026-04-18 15:35:21.677844	2026-04-18 15:35:21.677844	\N	f
female_condom_negative	348		["female", "contraception", "sexual", "condom", "reproductive"]	2026-04-18 15:35:21.680638	2026-04-18 15:35:21.680638	\N	f
female_condom_outline	349		["female", "contraception", "sexual", "condom", "reproductive"]	2026-04-18 15:35:21.684881	2026-04-18 15:35:21.684881	\N	f
female_sex_worker_positive	350		["sex worker", "female"]	2026-04-18 15:35:21.688799	2026-04-18 15:35:21.688799	\N	f
female_sex_worker_negative	351		["sex worker", "female"]	2026-04-18 15:35:21.69201	2026-04-18 15:35:21.69201	\N	f
female_sex_worker_outline	352		["sex worker", "female"]	2026-04-18 15:35:21.694907	2026-04-18 15:35:21.694907	\N	f
fetus_positive	353		["baby", "not born"]	2026-04-18 15:35:21.699092	2026-04-18 15:35:21.699092	\N	f
fetus_negative	354		["baby", "not born"]	2026-04-18 15:35:21.703052	2026-04-18 15:35:21.703052	\N	f
fetus_outline	355		["baby", "not born"]	2026-04-18 15:35:21.706033	2026-04-18 15:35:21.706033	\N	f
fever_positive	356		["symptom", "fever", "diagnosis"]	2026-04-18 15:35:21.708929	2026-04-18 15:35:21.708929	\N	f
fever_negative	357		["symptom", "fever", "diagnosis"]	2026-04-18 15:35:21.712163	2026-04-18 15:35:21.712163	\N	f
fever_outline	358		["symptom", "fever", "diagnosis"]	2026-04-18 15:35:21.715561	2026-04-18 15:35:21.715561	\N	f
\.


--
-- Data for Name: incomingsms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incomingsms (id, originator, encoding, sentdate, receiveddate, text, gatewayid, status, parsed, statusmessage, userid, uid) FROM stdin;
\.


--
-- Data for Name: indicator; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicator (indicatorid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, annualized, decimals, indicatortypeid, numerator, numeratordescription, denominator, denominatordescription, url, style, aggregateexportcategoryoptioncombo, aggregateexportattributeoptioncombo, userid, publicaccess, translations, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: indicatorgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroup (indicatorgroupid, uid, code, created, lastupdated, lastupdatedby, name, userid, publicaccess, translations, attributevalues, description, sharing) FROM stdin;
\.


--
-- Data for Name: indicatorgroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupmembers (indicatorid, indicatorgroupid) FROM stdin;
\.


--
-- Data for Name: indicatorgroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupset (indicatorgroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, compulsory, userid, publicaccess, translations, sharing, shortname) FROM stdin;
\.


--
-- Data for Name: indicatorgroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupsetmembers (indicatorgroupid, indicatorgroupsetid, sort_order) FROM stdin;
\.


--
-- Data for Name: indicatorlegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorlegendsets (indicatorid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: indicatortype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatortype (indicatortypeid, uid, code, created, lastupdated, lastupdatedby, name, indicatorfactor, indicatornumber, translations) FROM stdin;
\.


--
-- Data for Name: intepretation_likedby; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.intepretation_likedby (interpretationid, userid) FROM stdin;
\.


--
-- Data for Name: interpretation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interpretation (interpretationid, uid, lastupdated, mapid, eventreportid, eventchartid, datasetid, periodid, organisationunitid, interpretationtext, created, likes, userid, publicaccess, mentions, visualizationid, sharing, eventvisualizationid) FROM stdin;
\.


--
-- Data for Name: interpretation_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interpretation_comments (interpretationid, sort_order, interpretationcommentid) FROM stdin;
\.


--
-- Data for Name: interpretationcomment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interpretationcomment (interpretationcommentid, uid, lastupdated, commenttext, mentions, userid, created) FROM stdin;
\.


--
-- Data for Name: jobconfiguration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobconfiguration (jobconfigurationid, uid, code, created, lastupdated, lastupdatedby, name, cronexpression, lastexecuted, enabled, jsonbjobparameters, jobtype, jobstatus, lastexecutedstatus, delay, queuename, queueposition, executedby, schedulingtype, lastalive, lastfinished, cancel, progress, errorcodes) FROM stdin;
55	DHIS2rocks1	\N	2026-04-18 15:35:00.072	2026-04-18 15:35:20.027249	\N	Housekeeping	\N	2026-04-18 15:35:20.027249	t	\N	HOUSEKEEPING	RUNNING	NOT_STARTED	20	\N	\N	\N	FIXED_DELAY	2026-04-18 15:35:20.027249	\N	f	\N	\N
56	D2datatrim8	\N	2026-04-18 15:35:20.041	2026-04-18 15:35:20.041	\N	Data value trim	0 0 1 ? * *	\N	t	\N	DATA_VALUE_TRIM	SCHEDULED	NOT_STARTED	\N	\N	\N	\N	CRON	\N	\N	f	\N	\N
57	YvAwAmrqAtN	\N	2026-04-18 15:35:20.041	2026-04-18 15:35:20.041	\N	Dataset notification	0 0 2 ? * *	\N	t	\N	DATA_SET_NOTIFICATION	SCHEDULED	NOT_STARTED	\N	\N	\N	\N	CRON	\N	\N	f	\N	\N
58	sHMedQF7VYa	\N	2026-04-18 15:35:20.041	2026-04-18 15:35:20.041	\N	Credentials expiry alert	0 0 2 ? * *	\N	t	\N	CREDENTIALS_EXPIRY_ALERT	SCHEDULED	NOT_STARTED	\N	\N	\N	\N	CRON	\N	\N	f	\N	\N
59	BFa3jDsbtdO	\N	2026-04-18 15:35:20.041	2026-04-18 15:35:20.041	\N	Data statistics	0 0 2 ? * *	\N	t	\N	DATA_STATISTICS	SCHEDULED	NOT_STARTED	\N	\N	\N	\N	CRON	\N	\N	f	\N	\N
60	pd6O228pqr0	\N	2026-04-18 15:35:20.042	2026-04-18 15:35:20.042	\N	File resource clean up	0 0 2 ? * *	\N	t	\N	FILE_RESOURCE_CLEANUP	SCHEDULED	NOT_STARTED	\N	\N	\N	\N	CRON	\N	\N	f	\N	\N
61	fUWM1At1TUx	\N	2026-04-18 15:35:20.042	2026-04-18 15:35:20.042	\N	User account expiry alert	0 0 2 ? * *	\N	t	\N	ACCOUNT_EXPIRY_ALERT	SCHEDULED	NOT_STARTED	\N	\N	\N	\N	CRON	\N	\N	f	\N	\N
62	Js3vHn2AVuG	\N	2026-04-18 15:35:20.042	2026-04-18 15:35:20.042	\N	Validation result notification	0 0 7 ? * *	\N	t	\N	VALIDATION_RESULTS_NOTIFICATION	SCHEDULED	NOT_STARTED	\N	\N	\N	\N	CRON	\N	\N	f	\N	\N
63	uwWCT2BMmlq	\N	2026-04-18 15:35:20.042	2026-04-18 15:35:20.042	\N	Remove expired or used reserved values	0 0 2 ? * *	\N	t	\N	REMOVE_USED_OR_EXPIRED_RESERVED_VALUES	SCHEDULED	NOT_STARTED	\N	\N	\N	\N	CRON	\N	\N	f	\N	\N
64	vt21671bgno	\N	2026-04-18 15:35:20.043	2026-04-18 15:35:20.043	\N	System version update check notification	10 35 4 ? * *	\N	t	\N	SYSTEM_VERSION_UPDATE_CHECK	SCHEDULED	NOT_STARTED	\N	\N	\N	\N	CRON	\N	\N	f	\N	\N
\.


--
-- Data for Name: keyjsonvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keyjsonvalue (keyjsonvalueid, uid, code, created, lastupdated, lastupdatedby, namespace, namespacekey, encrypted_value, encrypted, userid, publicaccess, jbvalue, sharing) FROM stdin;
\.


--
-- Data for Name: lockexception; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lockexception (lockexceptionid, organisationunitid, periodid, datasetid, created) FROM stdin;
\.


--
-- Data for Name: map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.map (mapid, uid, code, created, lastupdated, lastupdatedby, name, description, longitude, latitude, zoom, basemap, title, externalaccess, userid, publicaccess, favorites, subscribers, translations, sharing, attributevalues) FROM stdin;
\.


--
-- Data for Name: maplegend; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maplegend (maplegendid, uid, code, created, lastupdated, lastupdatedby, name, startvalue, endvalue, color, image, maplegendsetid, translations) FROM stdin;
\.


--
-- Data for Name: maplegendset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maplegendset (maplegendsetid, uid, code, created, lastupdated, lastupdatedby, name, symbolizer, userid, publicaccess, translations, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: mapmapviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapmapviews (mapid, sort_order, mapviewid) FROM stdin;
\.


--
-- Data for Name: mapview; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview (mapviewid, uid, code, created, lastupdated, lastupdatedby, description, layer, relativeperiodsid, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, aggregationtype, programid, programstageid, startdate, enddate, trackedentitytypeid, programstatus, followup, organisationunitselectionmode, method, classes, colorlow, colorhigh, colorscale, legendsetid, radiuslow, radiushigh, opacity, orgunitgroupsetid, arearadius, hidden, labels, labelfontsize, labelfontweight, labelfontstyle, labelfontcolor, eventclustering, eventcoordinatefield, eventpointcolor, eventpointradius, config, styledataitem, translations, renderingstrategy, userorgunittype, thematicmaptype, nodatacolor, eventstatus, organisationunitcolor, orgunitfield, labeltemplate, relativeperiods) FROM stdin;
\.


--
-- Data for Name: mapview_attributedimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_attributedimensions (mapviewid, sort_order, trackedentityattributedimensionid) FROM stdin;
\.


--
-- Data for Name: mapview_categorydimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_categorydimensions (mapviewid, categorydimensionid, sort_order) FROM stdin;
\.


--
-- Data for Name: mapview_categoryoptiongroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_categoryoptiongroupsetdimensions (mapviewid, sort_order, categoryoptiongroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: mapview_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_columns (mapviewid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: mapview_datadimensionitems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_datadimensionitems (mapviewid, sort_order, datadimensionitemid) FROM stdin;
\.


--
-- Data for Name: mapview_dataelementdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_dataelementdimensions (mapviewid, sort_order, trackedentitydataelementdimensionid) FROM stdin;
\.


--
-- Data for Name: mapview_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_filters (mapviewid, dimension, sort_order) FROM stdin;
\.


--
-- Data for Name: mapview_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_itemorgunitgroups (mapviewid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: mapview_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_organisationunits (mapviewid, sort_order, organisationunitid) FROM stdin;
\.


--
-- Data for Name: mapview_orgunitgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_orgunitgroupsetdimensions (mapviewid, sort_order, orgunitgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: mapview_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_orgunitlevels (mapviewid, sort_order, orgunitlevel) FROM stdin;
\.


--
-- Data for Name: mapview_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_periods (mapviewid, sort_order, periodid) FROM stdin;
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (messageid, uid, created, lastupdated, messagetext, internal, metadata, userid) FROM stdin;
\.


--
-- Data for Name: messageattachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messageattachments (messageid, fileresourceid) FROM stdin;
\.


--
-- Data for Name: messageconversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messageconversation (messageconversationid, uid, messagecount, created, lastupdated, subject, messagetype, priority, status, user_assigned, lastsenderid, lastmessage, userid, extmessageid) FROM stdin;
\.


--
-- Data for Name: messageconversation_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messageconversation_messages (messageconversationid, sort_order, messageid) FROM stdin;
\.


--
-- Data for Name: messageconversation_usermessages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messageconversation_usermessages (messageconversationid, usermessageid) FROM stdin;
\.


--
-- Data for Name: metadataproposal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metadataproposal (proposalid, uid, type, status, target, targetuid, created, createdby, change, comment, reason, finalised, finalisedby) FROM stdin;
\.


--
-- Data for Name: metadataversion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metadataversion (versionid, uid, code, created, lastupdated, lastupdatedby, name, versiontype, importdate, hashcode) FROM stdin;
\.


--
-- Data for Name: minmaxdataelement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.minmaxdataelement (minmaxdataelementid, sourceid, dataelementid, categoryoptioncomboid, minimumvalue, maximumvalue, generatedvalue) FROM stdin;
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note (noteid, uid, code, created, lastupdated, lastupdatedby, notetext, creator) FROM stdin;
\.


--
-- Data for Name: oauth2client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth2client (oauth2clientid, uid, code, created, lastupdated, lastupdatedby, name, cid, secret) FROM stdin;
\.


--
-- Data for Name: oauth2clientgranttypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth2clientgranttypes (oauth2clientid, sort_order, granttype) FROM stdin;
\.


--
-- Data for Name: oauth2clientredirecturis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth2clientredirecturis (oauth2clientid, sort_order, redirecturi) FROM stdin;
\.


--
-- Data for Name: oauth_access_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_access_token (token_id, token, authentication_id, user_name, client_id, authentication, refresh_token) FROM stdin;
\.


--
-- Data for Name: oauth_code; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_code (code, authentication) FROM stdin;
\.


--
-- Data for Name: oauth_refresh_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_refresh_token (token_id, token, authentication) FROM stdin;
\.


--
-- Data for Name: optiongroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroup (optiongroupid, uid, code, created, lastupdated, lastupdatedby, name, shortname, optionsetid, userid, publicaccess, translations, sharing, description) FROM stdin;
\.


--
-- Data for Name: optiongroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupmembers (optiongroupid, optionid) FROM stdin;
\.


--
-- Data for Name: optiongroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupset (optiongroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, datadimension, optionsetid, userid, publicaccess, translations, sharing) FROM stdin;
\.


--
-- Data for Name: optiongroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupsetmembers (optiongroupsetid, sort_order, optiongroupid) FROM stdin;
\.


--
-- Data for Name: optionset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionset (optionsetid, uid, code, created, lastupdated, lastupdatedby, name, valuetype, version, userid, publicaccess, translations, attributevalues, sharing, description) FROM stdin;
\.


--
-- Data for Name: optionvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionvalue (optionvalueid, uid, code, name, created, lastupdated, sort_order, description, formname, style, optionsetid, translations, attributevalues) FROM stdin;
\.


--
-- Data for Name: organisationunit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organisationunit (organisationunitid, uid, code, created, lastupdated, lastupdatedby, name, shortname, parentid, path, hierarchylevel, description, openingdate, closeddate, comment, url, contactperson, address, email, phonenumber, userid, translations, geometry, attributevalues, image) FROM stdin;
\.


--
-- Data for Name: orgunitgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroup (orgunitgroupid, uid, code, created, lastupdated, lastupdatedby, name, shortname, symbol, color, userid, publicaccess, translations, geometry, attributevalues, sharing, description) FROM stdin;
\.


--
-- Data for Name: orgunitgroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupmembers (organisationunitid, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupset (orgunitgroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, compulsory, includesubhierarchyinanalytics, datadimension, userid, publicaccess, translations, attributevalues, sharing, shortname) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsetdimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsetdimension (orgunitgroupsetdimensionid, orgunitgroupsetid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsetdimension_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsetdimension_items (orgunitgroupsetdimensionid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsetmembers (orgunitgroupsetid, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: orgunitlevel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitlevel (orgunitlevelid, uid, code, created, lastupdated, lastupdatedby, name, level, offlinelevels, translations) FROM stdin;
\.


--
-- Data for Name: outbound_sms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbound_sms (id, date, message, status, sender, uid) FROM stdin;
\.


--
-- Data for Name: outbound_sms_recipients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbound_sms_recipients (outbound_sms_id, elt) FROM stdin;
\.


--
-- Data for Name: period; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.period (periodid, periodtypeid, startdate, enddate) FROM stdin;
\.


--
-- Data for Name: periodboundary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periodboundary (periodboundaryid, uid, code, created, lastupdated, lastupdatedby, boundarytarget, analyticsperiodboundarytype, offsetperiods, offsetperiodtypeid, programindicatorid) FROM stdin;
\.


--
-- Data for Name: periodtype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periodtype (periodtypeid, name) FROM stdin;
3	Daily
4	Weekly
5	WeeklyWednesday
6	WeeklyThursday
7	WeeklySaturday
8	WeeklySunday
9	BiWeekly
10	Monthly
11	BiMonthly
12	Quarterly
13	QuarterlyNov
14	SixMonthly
15	SixMonthlyApril
16	SixMonthlyNov
17	Yearly
18	FinancialApril
19	FinancialJuly
20	FinancialOct
21	FinancialNov
\.


--
-- Data for Name: potentialduplicate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.potentialduplicate (potentialduplicateid, uid, created, lastupdated, original, duplicate, status, createdbyusername, lastupdatebyusername) FROM stdin;
\.


--
-- Data for Name: predictor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.predictor (predictorid, uid, code, created, lastupdated, lastupdatedby, name, description, generatorexpressionid, generatoroutput, generatoroutputcombo, skiptestexpressionid, periodtypeid, sequentialsamplecount, annualsamplecount, sequentialskipcount, translations, organisationunitdescendants, shortname) FROM stdin;
\.


--
-- Data for Name: predictorgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.predictorgroup (predictorgroupid, uid, code, created, lastupdated, lastupdatedby, name, description, userid, publicaccess, translations, sharing) FROM stdin;
\.


--
-- Data for Name: predictorgroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.predictorgroupmembers (predictorid, predictorgroupid) FROM stdin;
\.


--
-- Data for Name: predictororgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.predictororgunitlevels (predictorid, orgunitlevelid) FROM stdin;
\.


--
-- Data for Name: previouspasswords; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.previouspasswords (userid, list_index, previouspassword) FROM stdin;
1	0	$2a$10$I9EXLBxXLI9dtxdexllGB.hEjaGqiyTP0RulkZnfuZaVA9XV3fz0a
\.


--
-- Data for Name: program; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program (programid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, version, enrollmentdatelabel, incidentdatelabel, type, displayincidentdate, onlyenrollonce, skipoffline, displayfrontpagelist, usefirststageduringregistration, capturecoordinates, expirydays, completeeventsexpirydays, minattributesrequiredtosearch, maxteicounttoreturn, style, accesslevel, expiryperiodtypeid, ignoreoverdueevents, selectenrollmentdatesinfuture, selectincidentdatesinfuture, relatedprogramid, categorycomboid, trackedentitytypeid, dataentryformid, userid, publicaccess, featuretype, translations, attributevalues, sharing, opendaysaftercoenddate, enrollmentlabel, followuplabel, orgunitlabel, relationshiplabel, notelabel, trackedentityattributelabel, programstagelabel, eventlabel) FROM stdin;
\.


--
-- Data for Name: program_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program_attributes (programtrackedentityattributeid, uid, code, created, lastupdated, lastupdatedby, programid, trackedentityattributeid, displayinlist, mandatory, sort_order, allowfuturedate, renderoptionsasradio, rendertype, searchable) FROM stdin;
\.


--
-- Data for Name: program_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program_organisationunits (organisationunitid, programid) FROM stdin;
\.


--
-- Data for Name: program_userroles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program_userroles (programid, userroleid) FROM stdin;
\.


--
-- Data for Name: programexpression; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programexpression (programexpressionid, description, expression) FROM stdin;
\.


--
-- Data for Name: programindicator; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicator (programindicatorid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, style, programid, expression, filter, aggregationtype, decimals, aggregateexportcategoryoptioncombo, aggregateexportattributeoptioncombo, displayinform, analyticstype, userid, publicaccess, translations, attributevalues, sharing, orgunitfield) FROM stdin;
\.


--
-- Data for Name: programindicatorgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorgroup (programindicatorgroupid, uid, code, created, lastupdated, lastupdatedby, name, description, userid, publicaccess, translations, sharing) FROM stdin;
\.


--
-- Data for Name: programindicatorgroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorgroupmembers (programindicatorid, programindicatorgroupid) FROM stdin;
\.


--
-- Data for Name: programindicatorlegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorlegendsets (programindicatorid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: programmessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programmessage (id, uid, code, created, lastupdated, lastupdatedby, text, subject, processeddate, messagestatus, trackedentityid, organisationunitid, enrollmentid, eventid, translations, notificationtemplate) FROM stdin;
\.


--
-- Data for Name: programmessage_deliverychannels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programmessage_deliverychannels (programmessagedeliverychannelsid, deliverychannel) FROM stdin;
\.


--
-- Data for Name: programmessage_emailaddresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programmessage_emailaddresses (programmessageemailaddressid, email) FROM stdin;
\.


--
-- Data for Name: programmessage_phonenumbers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programmessage_phonenumbers (programmessagephonenumberid, phonenumber) FROM stdin;
\.


--
-- Data for Name: programnotificationinstance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programnotificationinstance (programnotificationinstanceid, uid, code, created, lastupdated, lastupdatedby, name, enrollmentid, eventid, programnotificationtemplateid, scheduledat, sentat, programnotificationtemplatesnapshot) FROM stdin;
\.


--
-- Data for Name: programnotificationtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programnotificationtemplate (programnotificationtemplateid, uid, code, created, lastupdated, lastupdatedby, name, relativescheduleddays, usergroupid, trackedentityattributeid, dataelementid, subjecttemplate, messagetemplate, notifyparentorganisationunitonly, notifyusersinhierarchyonly, notificationtrigger, notificationrecipienttype, programstageid, programid, sendrepeatable, translations) FROM stdin;
\.


--
-- Data for Name: programnotificationtemplate_deliverychannel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programnotificationtemplate_deliverychannel (programnotificationtemplatedeliverychannelid, deliverychannel) FROM stdin;
\.


--
-- Data for Name: programownershiphistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programownershiphistory (programownershiphistoryid, programid, trackedentityid, startdate, enddate, createdby, organisationunitid) FROM stdin;
\.


--
-- Data for Name: programrule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programrule (programruleid, uid, code, created, lastupdated, lastupdatedby, name, description, programid, programstageid, rulecondition, priority, translations) FROM stdin;
\.


--
-- Data for Name: programruleaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programruleaction (programruleactionid, uid, code, created, lastupdated, lastupdatedby, programruleid, actiontype, dataelementid, trackedentityattributeid, programindicatorid, programstagesectionid, programstageid, optionid, optiongroupid, location, content, data, templateuid, evaluationtime, environments, translations) FROM stdin;
\.


--
-- Data for Name: programrulevariable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programrulevariable (programrulevariableid, uid, code, created, lastupdated, lastupdatedby, name, programid, sourcetype, trackedentityattributeid, dataelementid, usecodeforoptionset, programstageid, translations, valuetype) FROM stdin;
\.


--
-- Data for Name: programsection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programsection (programsectionid, uid, code, created, lastupdated, lastupdatedby, name, description, formname, style, rendertype, programid, sortorder, translations) FROM stdin;
\.


--
-- Data for Name: programsection_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programsection_attributes (programsectionid, sort_order, trackedentityattributeid) FROM stdin;
\.


--
-- Data for Name: programstage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstage (programstageid, uid, code, created, lastupdated, lastupdatedby, name, description, formname, mindaysfromstart, programid, repeatable, dataentryformid, standardinterval, executiondatelabel, duedatelabel, autogenerateevent, displaygenerateeventbox, generatedbyenrollmentdate, blockentryform, remindcompleted, allowgeneratenextvisit, openafterenrollment, reportdatetouse, pregenerateuid, style, hideduedate, sort_order, featuretype, periodtypeid, userid, publicaccess, validationstrategy, translations, enableuserassignment, attributevalues, nextscheduledateid, sharing, referral, programstagelabel, eventlabel) FROM stdin;
\.


--
-- Data for Name: programstagedataelement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagedataelement (programstagedataelementid, uid, code, created, lastupdated, lastupdatedby, programstageid, dataelementid, compulsory, allowprovidedelsewhere, sort_order, displayinreports, allowfuturedate, renderoptionsasradio, rendertype, skipsynchronization, skipanalytics) FROM stdin;
\.


--
-- Data for Name: programstagesection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagesection (programstagesectionid, uid, code, created, lastupdated, lastupdatedby, name, description, formname, style, rendertype, programstageid, sortorder, translations) FROM stdin;
\.


--
-- Data for Name: programstagesection_dataelements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagesection_dataelements (programstagesectionid, sort_order, dataelementid) FROM stdin;
\.


--
-- Data for Name: programstagesection_programindicators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagesection_programindicators (programstagesectionid, sort_order, programindicatorid) FROM stdin;
\.


--
-- Data for Name: programstageworkinglist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstageworkinglist (programstageworkinglistid, uid, code, created, createdby, lastupdated, lastupdatedby, name, description, programid, programstageid, programstagequerycriteria, translations, sharing, userid) FROM stdin;
\.


--
-- Data for Name: programtempowner; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programtempowner (programtempownerid, programid, trackedentityid, validtill, userid, reason) FROM stdin;
\.


--
-- Data for Name: programtempownershipaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programtempownershipaudit (programtempownershipauditid, programid, trackedentityid, created, accessedby, reason) FROM stdin;
\.


--
-- Data for Name: pushanalysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pushanalysis (pushanalysisid, uid, code, created, lastupdated, lastupdatedby, name, title, message, enabled, schedulingdayoffrequency, schedulingfrequency, dashboard) FROM stdin;
\.


--
-- Data for Name: pushanalysisrecipientusergroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pushanalysisrecipientusergroups (usergroupid, elt) FROM stdin;
\.


--
-- Data for Name: relationship; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relationship (relationshipid, uid, code, created, lastupdated, lastupdatedby, style, relationshiptypeid, from_relationshipitemid, to_relationshipitemid, key, inverted_key, deleted, createdatclient) FROM stdin;
\.


--
-- Data for Name: relationshipconstraint; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relationshipconstraint (relationshipconstraintid, entity, trackedentitytypeid, programid, programstageid, dataview) FROM stdin;
\.


--
-- Data for Name: relationshipitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relationshipitem (relationshipitemid, relationshipid, trackedentityid, enrollmentid, eventid) FROM stdin;
\.


--
-- Data for Name: relationshiptype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relationshiptype (relationshiptypeid, uid, code, created, lastupdated, lastupdatedby, name, description, from_relationshipconstraintid, to_relationshipconstraintid, userid, publicaccess, translations, bidirectional, fromtoname, tofromname, sharing, attributevalues, referral) FROM stdin;
\.


--
-- Data for Name: relativeperiods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relativeperiods (relativeperiodsid, thisday, yesterday, last3days, last7days, last14days, thismonth, lastmonth, thisbimonth, lastbimonth, thisquarter, lastquarter, thissixmonth, lastsixmonth, weeksthisyear, monthsthisyear, bimonthsthisyear, quartersthisyear, thisyear, monthslastyear, quarterslastyear, lastyear, last5years, last12months, last6months, last3months, last6bimonths, last4quarters, last2sixmonths, thisfinancialyear, lastfinancialyear, last5financialyears, thisweek, lastweek, thisbiweek, lastbiweek, last4weeks, last4biweeks, last12weeks, last52weeks, last30days, last60days, last90days, last180days, last10years, last10financialyears) FROM stdin;
\.


--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report (reportid, uid, code, created, lastupdated, lastupdatedby, name, type, designcontent, relativeperiodsid, paramreportingmonth, paramorganisationunit, cachestrategy, externalaccess, userid, publicaccess, translations, visualizationid, sharing, relativeperiods) FROM stdin;
\.


--
-- Data for Name: reservedvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reservedvalue (reservedvalueid, expirydate, created, ownerobject, owneruid, key, value) FROM stdin;
\.


--
-- Data for Name: route; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.route (routeid, uid, code, created, lastupdated, lastupdatedby, name, description, disabled, url, headers, auth, authorities, userid, translations, sharing, attributevalues, responsetimeoutseconds) FROM stdin;
\.


--
-- Data for Name: section; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.section (sectionid, uid, code, created, lastupdated, lastupdatedby, name, description, datasetid, sortorder, showrowtotals, showcolumntotals, translations, attributevalues, disabledataelementautogroup, displayoptions) FROM stdin;
\.


--
-- Data for Name: sectiondataelements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sectiondataelements (sectionid, sort_order, dataelementid) FROM stdin;
\.


--
-- Data for Name: sectiongreyedfields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sectiongreyedfields (sectionid, dataelementoperandid) FROM stdin;
\.


--
-- Data for Name: sectionindicators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sectionindicators (sectionid, sort_order, indicatorid) FROM stdin;
\.


--
-- Data for Name: sequentialnumbercounter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sequentialnumbercounter (id, owneruid, key, counter) FROM stdin;
\.


--
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.series (seriesid, series, axis) FROM stdin;
\.


--
-- Data for Name: smscodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smscodes (smscodeid, code, formula, compulsory, dataelementid, trackedentityattributeid, optionid) FROM stdin;
\.


--
-- Data for Name: smscommandcodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smscommandcodes (id, codeid) FROM stdin;
\.


--
-- Data for Name: smscommands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smscommands (smscommandid, uid, created, lastupdated, name, parsertype, separatorkey, codeseparator, defaultmessage, receivedmessage, wrongformatmessage, nousermessage, morethanoneorgunitmessage, successmessage, currentperiodusedforreporting, completenessmethod, datasetid, usergroupid, programid, programstageid) FROM stdin;
\.


--
-- Data for Name: smscommandspecialcharacters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smscommandspecialcharacters (smscommandid, specialcharacterid) FROM stdin;
\.


--
-- Data for Name: smsspecialcharacter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smsspecialcharacter (specialcharacterid, name, value) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: sqlview; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sqlview (sqlviewid, uid, code, created, lastupdated, lastupdatedby, name, description, sqlquery, type, cachestrategy, externalaccess, userid, publicaccess, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: systemsetting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.systemsetting (systemsettingid, name, value, translations) FROM stdin;
\.


--
-- Data for Name: tablehook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tablehook (analyticstablehookid, uid, code, created, lastupdated, lastupdatedby, name, analyticstablephase, resourcetabletype, analyticstabletype, sql) FROM stdin;
\.


--
-- Data for Name: trackedentity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentity (trackedentityid, uid, code, created, lastupdated, lastupdatedby, createdatclient, lastupdatedatclient, inactive, deleted, lastsynchronized, featuretype, coordinates, organisationunitid, trackedentitytypeid, geometry, storedby, createdbyuserinfo, lastupdatedbyuserinfo, potentialduplicate) FROM stdin;
\.


--
-- Data for Name: trackedentityattribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattribute (trackedentityattributeid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, valuetype, aggregationtype, optionsetid, inherit, expression, displayonvisitschedule, sortorderinvisitschedule, displayinlistnoprogram, sortorderinlistnoprogram, confidential, uniquefield, generated, pattern, textpattern, style, orgunitscope, skipsynchronization, userid, publicaccess, fieldmask, translations, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: trackedentityattributedimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributedimension (trackedentityattributedimensionid, trackedentityattributeid, legendsetid, filter) FROM stdin;
\.


--
-- Data for Name: trackedentityattributelegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributelegendsets (trackedentityattributeid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: trackedentityattributevalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributevalue (trackedentityid, trackedentityattributeid, created, lastupdated, value, encryptedvalue, storedby) FROM stdin;
\.


--
-- Data for Name: trackedentityattributevalueaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributevalueaudit (trackedentityattributevalueauditid, trackedentityid, trackedentityattributeid, value, encryptedvalue, created, modifiedby, audittype) FROM stdin;
\.


--
-- Data for Name: trackedentityaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityaudit (trackedentityauditid, trackedentity, created, accessedby, audittype, comment) FROM stdin;
\.


--
-- Data for Name: trackedentitydataelementdimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitydataelementdimension (trackedentitydataelementdimensionid, dataelementid, legendsetid, filter, programstageid) FROM stdin;
\.


--
-- Data for Name: trackedentitydatavalueaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitydatavalueaudit (trackedentitydatavalueauditid, eventid, dataelementid, value, created, providedelsewhere, modifiedby, audittype) FROM stdin;
\.


--
-- Data for Name: trackedentityfilter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityfilter (trackedentityfilterid, uid, code, created, lastupdated, lastupdatedby, name, description, sortorder, style, programid, eventfilters, translations, sharing, userid, entityquerycriteria) FROM stdin;
\.


--
-- Data for Name: trackedentityprogramindicatordimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityprogramindicatordimension (trackedentityprogramindicatordimensionid, programindicatorid, legendsetid, filter) FROM stdin;
\.


--
-- Data for Name: trackedentityprogramowner; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityprogramowner (trackedentityprogramownerid, trackedentityid, programid, created, lastupdated, organisationunitid, createdby) FROM stdin;
\.


--
-- Data for Name: trackedentitytype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitytype (trackedentitytypeid, uid, code, created, lastupdated, lastupdatedby, name, description, formname, style, minattributesrequiredtosearch, maxteicounttoreturn, allowauditlog, userid, publicaccess, featuretype, translations, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: trackedentitytypeattribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitytypeattribute (trackedentitytypeattributeid, uid, code, created, lastupdated, lastupdatedby, trackedentitytypeid, trackedentityattributeid, displayinlist, mandatory, searchable, sort_order) FROM stdin;
\.


--
-- Data for Name: userapps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userapps (userinfoid, sort_order, app) FROM stdin;
\.


--
-- Data for Name: userdatavieworgunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userdatavieworgunits (userinfoid, organisationunitid) FROM stdin;
\.


--
-- Data for Name: usergroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroup (usergroupid, uid, code, created, lastupdated, lastupdatedby, name, userid, publicaccess, translations, attributevalues, uuid, sharing) FROM stdin;
\.


--
-- Data for Name: usergroupmanaged; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroupmanaged (managedbygroupid, managedgroupid) FROM stdin;
\.


--
-- Data for Name: usergroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroupmembers (userid, usergroupid) FROM stdin;
\.


--
-- Data for Name: userinfo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userinfo (userinfoid, uid, code, lastupdated, created, surname, firstname, email, phonenumber, jobtitle, introduction, gender, birthday, nationality, employer, education, interests, languages, welcomemessage, lastcheckedinterpretations, whatsapp, skype, facebookmessenger, telegram, twitter, avatar, attributevalues, dataviewmaxorgunitlevel, lastupdatedby, creatoruserid, username, password, secret, externalauth, openid, ldapid, passwordlastupdated, lastlogin, restoretoken, restoreexpiry, selfregistered, invitation, disabled, uuid, accountexpiry, idtoken) FROM stdin;
1	M5zQapPyTZI	admin	2026-04-18 15:35:21.237	2026-04-18 15:34:47.326	admin	admin	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	\N	\N	\N	admin	$2a$10$I9EXLBxXLI9dtxdexllGB.hEjaGqiyTP0RulkZnfuZaVA9XV3fz0a	\N	f	\N	\N	2026-04-18 15:34:47.355	2026-04-18 15:35:21.237	\N	\N	f	f	f	6507f586-f154-4ec1-a25e-d7aa51de5216	\N	\N
\.


--
-- Data for Name: userkeyjsonvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userkeyjsonvalue (userkeyjsonvalueid, uid, code, created, lastupdated, lastupdatedby, userid, namespace, userkey, encrypted_value, encrypted, jbvalue) FROM stdin;
\.


--
-- Data for Name: usermembership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usermembership (organisationunitid, userinfoid) FROM stdin;
\.


--
-- Data for Name: usermessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usermessage (usermessageid, usermessagekey, userid, isread, isfollowup) FROM stdin;
\.


--
-- Data for Name: userrole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userrole (userroleid, uid, code, created, lastupdated, lastupdatedby, name, description, userid, publicaccess, translations, sharing) FROM stdin;
2	yrB6vc5Ip3r	Superuser	2026-04-18 15:34:47.35	2026-04-18 15:34:47.35	\N	Superuser	Superuser	\N	\N	[]	{"users": {}, "external": false, "userGroups": {}}
\.


--
-- Data for Name: userroleauthorities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userroleauthorities (userroleid, authority) FROM stdin;
2	F_TRACKED_ENTITY_INSTANCE_SEARCH_IN_ALL_ORGUNITS
2	ALL
2	F_USER_VIEW
2	F_GENERATE_MIN_MAX_VALUES
2	F_ORGANISATIONUNIT_MOVE
2	F_USER_GROUPS_READ_ONLY_ADD_MEMBERS
2	F_PREDICTOR_RUN
2	F_ORGANISATION_UNIT_SPLIT
2	F_INDICATOR_TYPE_MERGE
2	F_IMPERSONATE_USER
2	F_IGNORE_TRACKER_REQUIRED_VALUE_VALIDATION
2	F_SKIP_DATA_IMPORT_AUDIT
2	F_RUN_VALIDATION
2	F_ORG_UNIT_PROFILE_ADD
2	F_PREVIOUS_IMPERSONATOR_AUTHORITY
2	F_TRACKED_ENTITY_MERGE
2	F_INDICATOR_MERGE
2	F_PERFORM_ANALYTICS_EXPLAIN
2	F_ORGANISATION_UNIT_MERGE
2	F_LOCALE_ADD
2	F_REPLICATE_USER
2	F_SEND_EMAIL
2	F_DATAVALUE_ADD
2	F_INSERT_CUSTOM_JS_CSS
2	F_ENROLLMENT_CASCADE_DELETE
2	F_METADATA_IMPORT
2	F_VIEW_EVENT_ANALYTICS
2	F_VIEW_UNAPPROVED_DATA
2	F_PERFORM_MAINTENANCE
2	F_METADATA_EXPORT
2	F_TEI_CASCADE_DELETE
2	F_CAPTURE_DATASTORE_UPDATE
2	F_EXPORT_DATA
2	F_APPROVE_DATA
2	F_ACCEPT_DATA_LOWER_LEVELS
2	F_EDIT_EXPIRED
2	F_SYSTEM_SETTING
2	F_APPROVE_DATA_LOWER_LEVELS
2	F_VIEW_SERVER_INFO
2	F_UNCOMPLETE_EVENT
\.


--
-- Data for Name: userrolemembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userrolemembers (userroleid, userid) FROM stdin;
2	1
\.


--
-- Data for Name: userrolerestrictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userrolerestrictions (userroleid, restriction) FROM stdin;
\.


--
-- Data for Name: users_catdimensionconstraints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_catdimensionconstraints (userid, dataelementcategoryid) FROM stdin;
\.


--
-- Data for Name: users_cogsdimensionconstraints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_cogsdimensionconstraints (userid, categoryoptiongroupsetid) FROM stdin;
\.


--
-- Data for Name: usersetting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usersetting (userinfoid, name, value) FROM stdin;
\.


--
-- Data for Name: userteisearchorgunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userteisearchorgunits (userinfoid, organisationunitid) FROM stdin;
\.


--
-- Data for Name: validationnotificationtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationnotificationtemplate (validationnotificationtemplateid, uid, code, created, lastupdated, lastupdatedby, name, subjecttemplate, messagetemplate, notifyusersinhierarchyonly, sendstrategy, translations) FROM stdin;
\.


--
-- Data for Name: validationnotificationtemplate_recipientusergroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationnotificationtemplate_recipientusergroups (validationnotificationtemplateid, usergroupid) FROM stdin;
\.


--
-- Data for Name: validationnotificationtemplatevalidationrules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationnotificationtemplatevalidationrules (validationnotificationtemplateid, validationruleid) FROM stdin;
\.


--
-- Data for Name: validationresult; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationresult (validationresultid, created, leftsidevalue, rightsidevalue, validationruleid, periodid, organisationunitid, attributeoptioncomboid, dayinperiod, notificationsent) FROM stdin;
\.


--
-- Data for Name: validationrule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationrule (validationruleid, uid, code, created, lastupdated, lastupdatedby, name, description, instruction, importance, operator, leftexpressionid, rightexpressionid, skipformvalidation, periodtypeid, userid, publicaccess, translations, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: validationrulegroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationrulegroup (validationrulegroupid, uid, code, created, lastupdated, lastupdatedby, name, description, userid, publicaccess, translations, attributevalues, sharing) FROM stdin;
\.


--
-- Data for Name: validationrulegroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationrulegroupmembers (validationgroupid, validationruleid) FROM stdin;
\.


--
-- Data for Name: validationruleorganisationunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationruleorganisationunitlevels (validationruleid, organisationunitlevel) FROM stdin;
\.


--
-- Data for Name: version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.version (versionid, versionkey, versionvalue) FROM stdin;
\.


--
-- Data for Name: visualization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization (visualizationid, uid, name, type, code, title, subtitle, description, created, startdate, enddate, sortorder, toplimit, userid, userorgunittype, publicaccess, displaydensity, fontsize, relativeperiodsid, digitgroupseparator, legendsetid, legenddisplaystyle, legenddisplaystrategy, aggregationtype, regressiontype, targetlinevalue, targetlinelabel, rangeaxislabel, rangeaxismaxvalue, rangeaxissteps, rangeaxisdecimals, rangeaxisminvalue, domainaxislabel, baselinevalue, baselinelabel, numbertype, measurecriteria, hideemptyrowitems, percentstackedvalues, nospacebetweencolumns, regression, externalaccess, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, paramreportingperiod, paramorganisationunit, paramparentorganisationunit, paramgrandparentorganisationunit, rowtotals, coltotals, cumulative, rowsubtotals, colsubtotals, completedonly, skiprounding, showdimensionlabels, hidetitle, hidesubtitle, hidelegend, hideemptycolumns, hideemptyrows, showhierarchy, showdata, lastupdatedby, lastupdated, favorites, subscribers, translations, series, fontstyle, colorset, sharing, outlieranalysis, fixcolumnheaders, fixrowheaders, attributevalues, serieskey, axes, legendshowkey, icons, sorting, relativeperiods) FROM stdin;
\.


--
-- Data for Name: visualization_axis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_axis (visualizationid, sort_order, axisid) FROM stdin;
\.


--
-- Data for Name: visualization_categorydimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_categorydimensions (visualizationid, categorydimensionid, sort_order) FROM stdin;
\.


--
-- Data for Name: visualization_categoryoptiongroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_categoryoptiongroupsetdimensions (visualizationid, sort_order, categoryoptiongroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: visualization_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_columns (visualizationid, dimension, sort_order) FROM stdin;
\.


--
-- Data for Name: visualization_datadimensionitems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_datadimensionitems (visualizationid, datadimensionitemid, sort_order) FROM stdin;
\.


--
-- Data for Name: visualization_dataelementgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_dataelementgroupsetdimensions (visualizationid, sort_order, dataelementgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: visualization_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_filters (visualizationid, dimension, sort_order) FROM stdin;
\.


--
-- Data for Name: visualization_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_itemorgunitgroups (visualizationid, orgunitgroupid, sort_order) FROM stdin;
\.


--
-- Data for Name: visualization_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_organisationunits (visualizationid, organisationunitid, sort_order) FROM stdin;
\.


--
-- Data for Name: visualization_orgunitgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_orgunitgroupsetdimensions (visualizationid, sort_order, orgunitgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: visualization_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_orgunitlevels (visualizationid, orgunitlevel, sort_order) FROM stdin;
\.


--
-- Data for Name: visualization_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_periods (visualizationid, periodid, sort_order) FROM stdin;
\.


--
-- Data for Name: visualization_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_rows (visualizationid, dimension, sort_order) FROM stdin;
\.


--
-- Data for Name: visualization_yearlyseries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visualization_yearlyseries (visualizationid, sort_order, yearlyseries) FROM stdin;
\.


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: -
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: -
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: -
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: -
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: -
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: -
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: audit_auditid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_auditid_seq', 1, false);


--
-- Name: datavalueaudit_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.datavalueaudit_sequence', 1, false);


--
-- Name: deletedobject_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deletedobject_sequence', 1, false);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hibernate_sequence', 417, true);


--
-- Name: message_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_sequence', 1, false);


--
-- Name: messageconversation_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messageconversation_sequence', 1, false);


--
-- Name: potentialduplicatesequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.potentialduplicatesequence', 1, false);


--
-- Name: programinstance_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.programinstance_sequence', 1, false);


--
-- Name: programstageinstance_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.programstageinstance_sequence', 1, false);


--
-- Name: reservedvalue_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reservedvalue_sequence', 1, false);


--
-- Name: trackedentitydatavalueaudit_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trackedentitydatavalueaudit_sequence', 1, false);


--
-- Name: trackedentityinstance_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trackedentityinstance_sequence', 1, false);


--
-- Name: trackedentityinstanceaudit_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trackedentityinstanceaudit_sequence', 1, false);


--
-- Name: usermessage_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usermessage_sequence', 1, false);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: -
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: aggregatedataexchange aggregatedataexchange_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aggregatedataexchange
    ADD CONSTRAINT aggregatedataexchange_code_key UNIQUE (code);


--
-- Name: aggregatedataexchange aggregatedataexchange_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aggregatedataexchange
    ADD CONSTRAINT aggregatedataexchange_name_key UNIQUE (name);


--
-- Name: aggregatedataexchange aggregatedataexchange_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aggregatedataexchange
    ADD CONSTRAINT aggregatedataexchange_pkey PRIMARY KEY (aggregatedataexchangeid);


--
-- Name: aggregatedataexchange aggregatedataexchange_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aggregatedataexchange
    ADD CONSTRAINT aggregatedataexchange_uid_key UNIQUE (uid);


--
-- Name: api_token api_token_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_token
    ADD CONSTRAINT api_token_code_key UNIQUE (code);


--
-- Name: api_token api_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_token
    ADD CONSTRAINT api_token_pkey PRIMARY KEY (apitokenid);


--
-- Name: api_token api_token_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_token
    ADD CONSTRAINT api_token_uid_key UNIQUE (uid);


--
-- Name: attribute attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT attribute_pkey PRIMARY KEY (attributeid);


--
-- Name: attributevalue attributevalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributevalue
    ADD CONSTRAINT attributevalue_pkey PRIMARY KEY (attributevalueid);


--
-- Name: audit audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit
    ADD CONSTRAINT audit_pkey PRIMARY KEY (auditid);


--
-- Name: axis axis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.axis
    ADD CONSTRAINT axis_pkey PRIMARY KEY (axisid);


--
-- Name: categories_categoryoptions categories_categoryoptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_categoryoptions
    ADD CONSTRAINT categories_categoryoptions_pkey PRIMARY KEY (categoryid, sort_order);


--
-- Name: categorycombo categorycombo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT categorycombo_pkey PRIMARY KEY (categorycomboid);


--
-- Name: categorycombos_categories categorycombos_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_categories
    ADD CONSTRAINT categorycombos_categories_pkey PRIMARY KEY (categorycomboid, sort_order);


--
-- Name: categorycombos_optioncombos categorycombos_optioncombos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_optioncombos
    ADD CONSTRAINT categorycombos_optioncombos_pkey PRIMARY KEY (categoryoptioncomboid);


--
-- Name: categorydimension_items categorydimension_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension_items
    ADD CONSTRAINT categorydimension_items_pkey PRIMARY KEY (categorydimensionid, sort_order);


--
-- Name: categorydimension categorydimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension
    ADD CONSTRAINT categorydimension_pkey PRIMARY KEY (categorydimensionid);


--
-- Name: categoryoption_organisationunits categoryoption_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption_organisationunits
    ADD CONSTRAINT categoryoption_organisationunits_pkey PRIMARY KEY (categoryoptionid, organisationunitid);


--
-- Name: categoryoptioncombo categoryoptioncombo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombo
    ADD CONSTRAINT categoryoptioncombo_pkey PRIMARY KEY (categoryoptioncomboid);


--
-- Name: categoryoptioncombos_categoryoptions categoryoptioncombos_categoryoptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombos_categoryoptions
    ADD CONSTRAINT categoryoptioncombos_categoryoptions_pkey PRIMARY KEY (categoryoptioncomboid, categoryoptionid);


--
-- Name: categoryoptiongroup categoryoptiongroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT categoryoptiongroup_pkey PRIMARY KEY (categoryoptiongroupid);


--
-- Name: categoryoptiongroupmembers categoryoptiongroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupmembers
    ADD CONSTRAINT categoryoptiongroupmembers_pkey PRIMARY KEY (categoryoptiongroupid, categoryoptionid);


--
-- Name: categoryoptiongroupset categoryoptiongroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT categoryoptiongroupset_pkey PRIMARY KEY (categoryoptiongroupsetid);


--
-- Name: categoryoptiongroupset categoryoptiongroupset_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT categoryoptiongroupset_unique_shortname UNIQUE (shortname);


--
-- Name: categoryoptiongroupsetdimension_items categoryoptiongroupsetdimension_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension_items
    ADD CONSTRAINT categoryoptiongroupsetdimension_items_pkey PRIMARY KEY (categoryoptiongroupsetdimensionid, sort_order);


--
-- Name: categoryoptiongroupsetdimension categoryoptiongroupsetdimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension
    ADD CONSTRAINT categoryoptiongroupsetdimension_pkey PRIMARY KEY (categoryoptiongroupsetdimensionid);


--
-- Name: categoryoptiongroupsetmembers categoryoptiongroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetmembers
    ADD CONSTRAINT categoryoptiongroupsetmembers_pkey PRIMARY KEY (categoryoptiongroupsetid, sort_order);


--
-- Name: completedatasetregistration completedatasetregistration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT completedatasetregistration_pkey PRIMARY KEY (datasetid, periodid, sourceid, attributeoptioncomboid);


--
-- Name: configuration configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (configurationid);


--
-- Name: constant constant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT constant_pkey PRIMARY KEY (constantid);


--
-- Name: constant constant_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT constant_unique_shortname UNIQUE (shortname);


--
-- Name: dashboard_items dashboard_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_items
    ADD CONSTRAINT dashboard_items_pkey PRIMARY KEY (dashboardid, sort_order);


--
-- Name: dashboard dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_pkey PRIMARY KEY (dashboardid);


--
-- Name: dashboard dashboard_unique_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_unique_code UNIQUE (code);


--
-- Name: dashboarditem dashboarditem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT dashboarditem_pkey PRIMARY KEY (dashboarditemid);


--
-- Name: dashboarditem_reports dashboarditem_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_reports
    ADD CONSTRAINT dashboarditem_reports_pkey PRIMARY KEY (dashboarditemid, sort_order);


--
-- Name: dashboarditem_resources dashboarditem_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_resources
    ADD CONSTRAINT dashboarditem_resources_pkey PRIMARY KEY (dashboarditemid, sort_order);


--
-- Name: dashboarditem_users dashboarditem_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_users
    ADD CONSTRAINT dashboarditem_users_pkey PRIMARY KEY (dashboarditemid, sort_order);


--
-- Name: dataapproval dataapproval_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT dataapproval_pkey PRIMARY KEY (dataapprovalid);


--
-- Name: dataapproval dataapproval_unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT dataapproval_unique_key UNIQUE (dataapprovallevelid, workflowid, periodid, organisationunitid, attributeoptioncomboid);


--
-- Name: dataapprovalaudit dataapprovalaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT dataapprovalaudit_pkey PRIMARY KEY (dataapprovalauditid);


--
-- Name: dataapprovallevel dataapprovallevel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT dataapprovallevel_pkey PRIMARY KEY (dataapprovallevelid);


--
-- Name: dataapprovalworkflow dataapprovalworkflow_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT dataapprovalworkflow_pkey PRIMARY KEY (workflowid);


--
-- Name: dataapprovalworkflowlevels dataapprovalworkflowlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowlevels
    ADD CONSTRAINT dataapprovalworkflowlevels_pkey PRIMARY KEY (workflowid, dataapprovallevelid);


--
-- Name: datadimensionitem datadimensionitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT datadimensionitem_pkey PRIMARY KEY (datadimensionitemid);


--
-- Name: dataelement dataelement_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT dataelement_code_key UNIQUE (code);


--
-- Name: dataelement dataelement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT dataelement_pkey PRIMARY KEY (dataelementid);


--
-- Name: dataelementaggregationlevels dataelementaggregationlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementaggregationlevels
    ADD CONSTRAINT dataelementaggregationlevels_pkey PRIMARY KEY (dataelementid, sort_order);


--
-- Name: category dataelementcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT dataelementcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: category dataelementcategory_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT dataelementcategory_unique_shortname UNIQUE (shortname);


--
-- Name: categoryoption dataelementcategoryoption_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption
    ADD CONSTRAINT dataelementcategoryoption_pkey PRIMARY KEY (categoryoptionid);


--
-- Name: categoryoption dataelementcategoryoption_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption
    ADD CONSTRAINT dataelementcategoryoption_unique_shortname UNIQUE (shortname);


--
-- Name: dataelementgroup dataelementgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT dataelementgroup_pkey PRIMARY KEY (dataelementgroupid);


--
-- Name: dataelementgroup dataelementgroup_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT dataelementgroup_unique_shortname UNIQUE (shortname);


--
-- Name: dataelementgroupmembers dataelementgroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupmembers
    ADD CONSTRAINT dataelementgroupmembers_pkey PRIMARY KEY (dataelementgroupid, dataelementid);


--
-- Name: dataelementgroupset dataelementgroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT dataelementgroupset_pkey PRIMARY KEY (dataelementgroupsetid);


--
-- Name: dataelementgroupset dataelementgroupset_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT dataelementgroupset_unique_shortname UNIQUE (shortname);


--
-- Name: dataelementgroupsetdimension_items dataelementgroupsetdimension_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension_items
    ADD CONSTRAINT dataelementgroupsetdimension_items_pkey PRIMARY KEY (dataelementgroupsetdimensionid, sort_order);


--
-- Name: dataelementgroupsetdimension dataelementgroupsetdimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension
    ADD CONSTRAINT dataelementgroupsetdimension_pkey PRIMARY KEY (dataelementgroupsetdimensionid);


--
-- Name: dataelementgroupsetmembers dataelementgroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetmembers
    ADD CONSTRAINT dataelementgroupsetmembers_pkey PRIMARY KEY (dataelementgroupsetid, sort_order);


--
-- Name: dataelementlegendsets dataelementlegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementlegendsets
    ADD CONSTRAINT dataelementlegendsets_pkey PRIMARY KEY (dataelementid, sort_order);


--
-- Name: dataelementoperand dataelementoperand_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementoperand
    ADD CONSTRAINT dataelementoperand_pkey PRIMARY KEY (dataelementoperandid);


--
-- Name: dataentryform dataentryform_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT dataentryform_pkey PRIMARY KEY (dataentryformid);


--
-- Name: datainputperiod datainputperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datainputperiod
    ADD CONSTRAINT datainputperiod_pkey PRIMARY KEY (datainputperiodid);


--
-- Name: dataset dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT dataset_pkey PRIMARY KEY (datasetid);


--
-- Name: dataset dataset_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT dataset_unique_shortname UNIQUE (shortname);


--
-- Name: datasetelement datasetelement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT datasetelement_pkey PRIMARY KEY (datasetelementid);


--
-- Name: datasetelement datasetelement_unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT datasetelement_unique_key UNIQUE (datasetid, dataelementid);


--
-- Name: datasetindicators datasetindicators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetindicators
    ADD CONSTRAINT datasetindicators_pkey PRIMARY KEY (datasetid, indicatorid);


--
-- Name: datasetlegendsets datasetlegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetlegendsets
    ADD CONSTRAINT datasetlegendsets_pkey PRIMARY KEY (datasetid, sort_order);


--
-- Name: datasetnotification_datasets datasetnotification_datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotification_datasets
    ADD CONSTRAINT datasetnotification_datasets_pkey PRIMARY KEY (datasetnotificationtemplateid, datasetid);


--
-- Name: datasetnotificationtemplate datasetnotificationtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT datasetnotificationtemplate_pkey PRIMARY KEY (datasetnotificationtemplateid);


--
-- Name: datasetoperands datasetoperands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetoperands
    ADD CONSTRAINT datasetoperands_pkey PRIMARY KEY (datasetid, dataelementoperandid);


--
-- Name: datasetsource datasetsource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsource
    ADD CONSTRAINT datasetsource_pkey PRIMARY KEY (datasetid, sourceid);


--
-- Name: datastatistics datastatistics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatistics
    ADD CONSTRAINT datastatistics_pkey PRIMARY KEY (statisticsid);


--
-- Name: datastatisticsevent datastatisticsevent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatisticsevent
    ADD CONSTRAINT datastatisticsevent_pkey PRIMARY KEY (eventid);


--
-- Name: datavalue datavalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT datavalue_pkey PRIMARY KEY (dataelementid, periodid, sourceid, categoryoptioncomboid, attributeoptioncomboid);


--
-- Name: datavalueaudit datavalueaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT datavalueaudit_pkey PRIMARY KEY (datavalueauditid);


--
-- Name: deletedobject deletedobject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deletedobject
    ADD CONSTRAINT deletedobject_pkey PRIMARY KEY (deletedobjectid);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (documentid);


--
-- Name: eventchart_attributedimensions eventchart_attributedimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_attributedimensions
    ADD CONSTRAINT eventchart_attributedimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_categorydimensions eventchart_categorydimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_categorydimensions
    ADD CONSTRAINT eventchart_categorydimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_categoryoptiongroupsetdimensions eventchart_categoryoptiongroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_categoryoptiongroupsetdimensions
    ADD CONSTRAINT eventchart_categoryoptiongroupsetdimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_columns eventchart_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_columns
    ADD CONSTRAINT eventchart_columns_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_dataelementdimensions eventchart_dataelementdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_dataelementdimensions
    ADD CONSTRAINT eventchart_dataelementdimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_filters eventchart_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_filters
    ADD CONSTRAINT eventchart_filters_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_itemorgunitgroups eventchart_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_itemorgunitgroups
    ADD CONSTRAINT eventchart_itemorgunitgroups_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_organisationunits eventchart_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_organisationunits
    ADD CONSTRAINT eventchart_organisationunits_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_orgunitgroupsetdimensions eventchart_orgunitgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_orgunitgroupsetdimensions
    ADD CONSTRAINT eventchart_orgunitgroupsetdimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_orgunitlevels eventchart_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_orgunitlevels
    ADD CONSTRAINT eventchart_orgunitlevels_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_periods eventchart_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_periods
    ADD CONSTRAINT eventchart_periods_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart eventchart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT eventchart_pkey PRIMARY KEY (eventchartid);


--
-- Name: eventchart_programindicatordimensions eventchart_programindicatordimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_programindicatordimensions
    ADD CONSTRAINT eventchart_programindicatordimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_rows eventchart_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_rows
    ADD CONSTRAINT eventchart_rows_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventhook eventhook_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventhook
    ADD CONSTRAINT eventhook_code_key UNIQUE (code);


--
-- Name: eventhook eventhook_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventhook
    ADD CONSTRAINT eventhook_name_key UNIQUE (name);


--
-- Name: eventhook eventhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventhook
    ADD CONSTRAINT eventhook_pkey PRIMARY KEY (eventhookid);


--
-- Name: eventhook eventhook_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventhook
    ADD CONSTRAINT eventhook_uid_key UNIQUE (uid);


--
-- Name: eventreport_attributedimensions eventreport_attributedimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_attributedimensions
    ADD CONSTRAINT eventreport_attributedimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_categorydimensions eventreport_categorydimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_categorydimensions
    ADD CONSTRAINT eventreport_categorydimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_categoryoptiongroupsetdimensions eventreport_categoryoptiongroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_categoryoptiongroupsetdimensions
    ADD CONSTRAINT eventreport_categoryoptiongroupsetdimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_columns eventreport_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_columns
    ADD CONSTRAINT eventreport_columns_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_dataelementdimensions eventreport_dataelementdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_dataelementdimensions
    ADD CONSTRAINT eventreport_dataelementdimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_filters eventreport_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_filters
    ADD CONSTRAINT eventreport_filters_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_itemorgunitgroups eventreport_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_itemorgunitgroups
    ADD CONSTRAINT eventreport_itemorgunitgroups_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_organisationunits eventreport_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_organisationunits
    ADD CONSTRAINT eventreport_organisationunits_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_orgunitgroupsetdimensions eventreport_orgunitgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_orgunitgroupsetdimensions
    ADD CONSTRAINT eventreport_orgunitgroupsetdimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_orgunitlevels eventreport_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_orgunitlevels
    ADD CONSTRAINT eventreport_orgunitlevels_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_periods eventreport_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_periods
    ADD CONSTRAINT eventreport_periods_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport eventreport_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT eventreport_pkey PRIMARY KEY (eventreportid);


--
-- Name: eventreport_programindicatordimensions eventreport_programindicatordimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_programindicatordimensions
    ADD CONSTRAINT eventreport_programindicatordimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_rows eventreport_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_rows
    ADD CONSTRAINT eventreport_rows_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventvisualization_attributedimensions eventvisualization_attributedimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_attributedimensions
    ADD CONSTRAINT eventvisualization_attributedimensions_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_categorydimensions eventvisualization_categorydimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_categorydimensions
    ADD CONSTRAINT eventvisualization_categorydimensions_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_categoryoptiongroupsetdimensions eventvisualization_categoryoptiongroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_categoryoptiongroupsetdimensions
    ADD CONSTRAINT eventvisualization_categoryoptiongroupsetdimensions_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_columns eventvisualization_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_columns
    ADD CONSTRAINT eventvisualization_columns_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_dataelementdimensions eventvisualization_dataelementdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_dataelementdimensions
    ADD CONSTRAINT eventvisualization_dataelementdimensions_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_filters eventvisualization_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_filters
    ADD CONSTRAINT eventvisualization_filters_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_itemorgunitgroups eventvisualization_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_itemorgunitgroups
    ADD CONSTRAINT eventvisualization_itemorgunitgroups_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_organisationunits eventvisualization_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_organisationunits
    ADD CONSTRAINT eventvisualization_organisationunits_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_orgunitgroupsetdimensions eventvisualization_orgunitgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_orgunitgroupsetdimensions
    ADD CONSTRAINT eventvisualization_orgunitgroupsetdimensions_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_orgunitlevels eventvisualization_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_orgunitlevels
    ADD CONSTRAINT eventvisualization_orgunitlevels_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_periods eventvisualization_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_periods
    ADD CONSTRAINT eventvisualization_periods_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization eventvisualization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT eventvisualization_pkey PRIMARY KEY (eventvisualizationid);


--
-- Name: eventvisualization_programindicatordimensions eventvisualization_programindicatordimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_programindicatordimensions
    ADD CONSTRAINT eventvisualization_programindicatordimensions_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: eventvisualization_rows eventvisualization_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_rows
    ADD CONSTRAINT eventvisualization_rows_pkey PRIMARY KEY (eventvisualizationid, sort_order);


--
-- Name: expression expression_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expression
    ADD CONSTRAINT expression_pkey PRIMARY KEY (expressionid);


--
-- Name: expressiondimensionitem expressiondimensionitem_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expressiondimensionitem
    ADD CONSTRAINT expressiondimensionitem_code_key UNIQUE (code);


--
-- Name: expressiondimensionitem expressiondimensionitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expressiondimensionitem
    ADD CONSTRAINT expressiondimensionitem_pkey PRIMARY KEY (expressiondimensionitemid);


--
-- Name: expressiondimensionitem expressiondimensionitem_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expressiondimensionitem
    ADD CONSTRAINT expressiondimensionitem_uid_key UNIQUE (uid);


--
-- Name: externalfileresource externalfileresource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT externalfileresource_pkey PRIMARY KEY (externalfileresourceid);


--
-- Name: externalmaplayer externalmaplayer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT externalmaplayer_pkey PRIMARY KEY (externalmaplayerid);


--
-- Name: externalnotificationlogentry externalnotificationlogentry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalnotificationlogentry
    ADD CONSTRAINT externalnotificationlogentry_pkey PRIMARY KEY (externalnotificationlogentryid);


--
-- Name: fileresource fileresource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT fileresource_pkey PRIMARY KEY (fileresourceid);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: i18nlocale i18nlocale_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT i18nlocale_pkey PRIMARY KEY (i18nlocaleid);


--
-- Name: icon icon_fileresource_ukey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icon
    ADD CONSTRAINT icon_fileresource_ukey UNIQUE (fileresourceid);


--
-- Name: icon icon_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icon
    ADD CONSTRAINT icon_pkey PRIMARY KEY (iconkey);


--
-- Name: incomingsms incomingsms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incomingsms
    ADD CONSTRAINT incomingsms_pkey PRIMARY KEY (id);


--
-- Name: indicator indicator_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT indicator_code_key UNIQUE (code);


--
-- Name: indicator indicator_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT indicator_pkey PRIMARY KEY (indicatorid);


--
-- Name: indicatorgroup indicatorgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT indicatorgroup_pkey PRIMARY KEY (indicatorgroupid);


--
-- Name: indicatorgroupmembers indicatorgroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupmembers
    ADD CONSTRAINT indicatorgroupmembers_pkey PRIMARY KEY (indicatorgroupid, indicatorid);


--
-- Name: indicatorgroupset indicatorgroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT indicatorgroupset_pkey PRIMARY KEY (indicatorgroupsetid);


--
-- Name: indicatorgroupset indicatorgroupset_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT indicatorgroupset_unique_shortname UNIQUE (shortname);


--
-- Name: indicatorgroupsetmembers indicatorgroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetmembers
    ADD CONSTRAINT indicatorgroupsetmembers_pkey PRIMARY KEY (indicatorgroupsetid, sort_order);


--
-- Name: indicatorlegendsets indicatorlegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorlegendsets
    ADD CONSTRAINT indicatorlegendsets_pkey PRIMARY KEY (indicatorid, sort_order);


--
-- Name: indicatortype indicatortype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT indicatortype_pkey PRIMARY KEY (indicatortypeid);


--
-- Name: intepretation_likedby intepretation_likedby_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.intepretation_likedby
    ADD CONSTRAINT intepretation_likedby_pkey PRIMARY KEY (interpretationid, userid);


--
-- Name: interpretation_comments interpretation_comments_interpretationcommentid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation_comments
    ADD CONSTRAINT interpretation_comments_interpretationcommentid_key UNIQUE (interpretationcommentid) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: interpretation_comments interpretation_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation_comments
    ADD CONSTRAINT interpretation_comments_pkey PRIMARY KEY (interpretationid, sort_order);


--
-- Name: interpretation interpretation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT interpretation_pkey PRIMARY KEY (interpretationid);


--
-- Name: interpretationcomment interpretationcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationcomment
    ADD CONSTRAINT interpretationcomment_pkey PRIMARY KEY (interpretationcommentid);


--
-- Name: jobconfiguration jobconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT jobconfiguration_pkey PRIMARY KEY (jobconfigurationid);


--
-- Name: deletedobject key_deleted_object_klass_uid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deletedobject
    ADD CONSTRAINT key_deleted_object_klass_uid UNIQUE (klass, uid);


--
-- Name: section key_sectionnamedataset; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT key_sectionnamedataset UNIQUE (name, datasetid);


--
-- Name: keyjsonvalue keyjsonvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT keyjsonvalue_pkey PRIMARY KEY (keyjsonvalueid);


--
-- Name: keyjsonvalue keyjsonvalue_unique_key_in_namespace; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT keyjsonvalue_unique_key_in_namespace UNIQUE (namespace, namespacekey);


--
-- Name: lockexception lockexception_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lockexception
    ADD CONSTRAINT lockexception_pkey PRIMARY KEY (lockexceptionid);


--
-- Name: map map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT map_pkey PRIMARY KEY (mapid);


--
-- Name: maplegend maplegend_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT maplegend_pkey PRIMARY KEY (maplegendid);


--
-- Name: maplegendset maplegendset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT maplegendset_pkey PRIMARY KEY (maplegendsetid);


--
-- Name: mapmapviews mapmapviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapmapviews
    ADD CONSTRAINT mapmapviews_pkey PRIMARY KEY (mapid, sort_order);


--
-- Name: mapview_attributedimensions mapview_attributedimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_attributedimensions
    ADD CONSTRAINT mapview_attributedimensions_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_categorydimensions mapview_categorydimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_categorydimensions
    ADD CONSTRAINT mapview_categorydimensions_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_categoryoptiongroupsetdimensions mapview_categoryoptiongroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_categoryoptiongroupsetdimensions
    ADD CONSTRAINT mapview_categoryoptiongroupsetdimensions_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_columns mapview_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_columns
    ADD CONSTRAINT mapview_columns_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_datadimensionitems mapview_datadimensionitems_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_datadimensionitems
    ADD CONSTRAINT mapview_datadimensionitems_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_dataelementdimensions mapview_dataelementdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_dataelementdimensions
    ADD CONSTRAINT mapview_dataelementdimensions_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_filters mapview_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_filters
    ADD CONSTRAINT mapview_filters_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_itemorgunitgroups mapview_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_itemorgunitgroups
    ADD CONSTRAINT mapview_itemorgunitgroups_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_organisationunits mapview_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_organisationunits
    ADD CONSTRAINT mapview_organisationunits_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_orgunitgroupsetdimensions mapview_orgunitgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_orgunitgroupsetdimensions
    ADD CONSTRAINT mapview_orgunitgroupsetdimensions_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_orgunitlevels mapview_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_orgunitlevels
    ADD CONSTRAINT mapview_orgunitlevels_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_periods mapview_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_periods
    ADD CONSTRAINT mapview_periods_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview mapview_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT mapview_pkey PRIMARY KEY (mapviewid);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (messageid);


--
-- Name: messageattachments messageattachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageattachments
    ADD CONSTRAINT messageattachments_pkey PRIMARY KEY (messageid, fileresourceid);


--
-- Name: messageconversation_messages messageconversation_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_messages
    ADD CONSTRAINT messageconversation_messages_pkey PRIMARY KEY (messageconversationid, sort_order);


--
-- Name: messageconversation messageconversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation
    ADD CONSTRAINT messageconversation_pkey PRIMARY KEY (messageconversationid);


--
-- Name: messageconversation_usermessages messageconversation_usermessages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_usermessages
    ADD CONSTRAINT messageconversation_usermessages_pkey PRIMARY KEY (messageconversationid, usermessageid);


--
-- Name: metadataproposal metadataproposal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataproposal
    ADD CONSTRAINT metadataproposal_pkey PRIMARY KEY (proposalid);


--
-- Name: metadataproposal metadataproposal_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataproposal
    ADD CONSTRAINT metadataproposal_uid_key UNIQUE (uid);


--
-- Name: metadataversion metadataversion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT metadataversion_pkey PRIMARY KEY (versionid);


--
-- Name: minmaxdataelement minmaxdataelement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minmaxdataelement
    ADD CONSTRAINT minmaxdataelement_pkey PRIMARY KEY (sourceid, dataelementid, categoryoptioncomboid);


--
-- Name: oauth2client oauth2client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT oauth2client_pkey PRIMARY KEY (oauth2clientid);


--
-- Name: oauth2clientgranttypes oauth2clientgranttypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2clientgranttypes
    ADD CONSTRAINT oauth2clientgranttypes_pkey PRIMARY KEY (oauth2clientid, sort_order);


--
-- Name: oauth2clientredirecturis oauth2clientredirecturis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2clientredirecturis
    ADD CONSTRAINT oauth2clientredirecturis_pkey PRIMARY KEY (oauth2clientid, sort_order);


--
-- Name: oauth_access_token oauth_access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_pkey PRIMARY KEY (authentication_id);


--
-- Name: optiongroup optiongroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT optiongroup_pkey PRIMARY KEY (optiongroupid);


--
-- Name: optiongroupmembers optiongroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupmembers
    ADD CONSTRAINT optiongroupmembers_pkey PRIMARY KEY (optiongroupid, optionid);


--
-- Name: optiongroupset optiongroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT optiongroupset_pkey PRIMARY KEY (optiongroupsetid);


--
-- Name: optiongroupsetmembers optiongroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetmembers
    ADD CONSTRAINT optiongroupsetmembers_pkey PRIMARY KEY (optiongroupsetid, sort_order);


--
-- Name: optionset optionset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT optionset_pkey PRIMARY KEY (optionsetid);


--
-- Name: optionvalue optionvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvalue
    ADD CONSTRAINT optionvalue_pkey PRIMARY KEY (optionvalueid);


--
-- Name: optionvalue optionvalue_unique_optionsetid_and_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvalue
    ADD CONSTRAINT optionvalue_unique_optionsetid_and_code UNIQUE (optionsetid, code);


--
-- Name: organisationunit organisationunit_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT organisationunit_code_key UNIQUE (code);


--
-- Name: organisationunit organisationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT organisationunit_pkey PRIMARY KEY (organisationunitid);


--
-- Name: orgunitgroup orgunitgroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT orgunitgroup_name_key UNIQUE (name);


--
-- Name: orgunitgroup orgunitgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT orgunitgroup_pkey PRIMARY KEY (orgunitgroupid);


--
-- Name: orgunitgroup orgunitgroup_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT orgunitgroup_unique_shortname UNIQUE (shortname);


--
-- Name: orgunitgroupmembers orgunitgroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupmembers
    ADD CONSTRAINT orgunitgroupmembers_pkey PRIMARY KEY (orgunitgroupid, organisationunitid);


--
-- Name: orgunitgroupset orgunitgroupset_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT orgunitgroupset_name_key UNIQUE (name);


--
-- Name: orgunitgroupset orgunitgroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT orgunitgroupset_pkey PRIMARY KEY (orgunitgroupsetid);


--
-- Name: orgunitgroupset orgunitgroupset_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT orgunitgroupset_unique_shortname UNIQUE (shortname);


--
-- Name: orgunitgroupsetdimension_items orgunitgroupsetdimension_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension_items
    ADD CONSTRAINT orgunitgroupsetdimension_items_pkey PRIMARY KEY (orgunitgroupsetdimensionid, sort_order);


--
-- Name: orgunitgroupsetdimension orgunitgroupsetdimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension
    ADD CONSTRAINT orgunitgroupsetdimension_pkey PRIMARY KEY (orgunitgroupsetdimensionid);


--
-- Name: orgunitgroupsetmembers orgunitgroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetmembers
    ADD CONSTRAINT orgunitgroupsetmembers_pkey PRIMARY KEY (orgunitgroupsetid, orgunitgroupid);


--
-- Name: orgunitlevel orgunitlevel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT orgunitlevel_pkey PRIMARY KEY (orgunitlevelid);


--
-- Name: outbound_sms outbound_sms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbound_sms
    ADD CONSTRAINT outbound_sms_pkey PRIMARY KEY (id);


--
-- Name: period period_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period
    ADD CONSTRAINT period_pkey PRIMARY KEY (periodid);


--
-- Name: periodboundary periodboundary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodboundary
    ADD CONSTRAINT periodboundary_pkey PRIMARY KEY (periodboundaryid);


--
-- Name: periodtype periodtype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodtype
    ADD CONSTRAINT periodtype_pkey PRIMARY KEY (periodtypeid);


--
-- Name: potentialduplicate potentialduplicate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.potentialduplicate
    ADD CONSTRAINT potentialduplicate_pkey PRIMARY KEY (potentialduplicateid);


--
-- Name: potentialduplicate potentialduplicate_teia_teib; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.potentialduplicate
    ADD CONSTRAINT potentialduplicate_teia_teib UNIQUE (original, duplicate);


--
-- Name: potentialduplicate potentialduplicate_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.potentialduplicate
    ADD CONSTRAINT potentialduplicate_uid_key UNIQUE (uid);


--
-- Name: predictor predictor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT predictor_pkey PRIMARY KEY (predictorid);


--
-- Name: predictor predictor_unique_shortname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT predictor_unique_shortname UNIQUE (shortname);


--
-- Name: predictorgroup predictorgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictorgroup
    ADD CONSTRAINT predictorgroup_pkey PRIMARY KEY (predictorgroupid);


--
-- Name: predictorgroupmembers predictorgroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictorgroupmembers
    ADD CONSTRAINT predictorgroupmembers_pkey PRIMARY KEY (predictorgroupid, predictorid);


--
-- Name: predictororgunitlevels predictororgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictororgunitlevels
    ADD CONSTRAINT predictororgunitlevels_pkey PRIMARY KEY (predictorid, orgunitlevelid);


--
-- Name: previouspasswords previouspasswords_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.previouspasswords
    ADD CONSTRAINT previouspasswords_pkey PRIMARY KEY (userid, list_index);


--
-- Name: program_attributes program_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT program_attributes_pkey PRIMARY KEY (programtrackedentityattributeid);


--
-- Name: program_organisationunits program_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_organisationunits
    ADD CONSTRAINT program_organisationunits_pkey PRIMARY KEY (programid, organisationunitid);


--
-- Name: program program_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT program_pkey PRIMARY KEY (programid);


--
-- Name: programexpression programexpression_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programexpression
    ADD CONSTRAINT programexpression_pkey PRIMARY KEY (programexpressionid);


--
-- Name: programindicator programindicator_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT programindicator_pkey PRIMARY KEY (programindicatorid);


--
-- Name: programindicatorgroup programindicatorgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT programindicatorgroup_pkey PRIMARY KEY (programindicatorgroupid);


--
-- Name: programindicatorgroupmembers programindicatorgroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupmembers
    ADD CONSTRAINT programindicatorgroupmembers_pkey PRIMARY KEY (programindicatorgroupid, programindicatorid);


--
-- Name: programindicatorlegendsets programindicatorlegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorlegendsets
    ADD CONSTRAINT programindicatorlegendsets_pkey PRIMARY KEY (programindicatorid, sort_order);


--
-- Name: enrollment programinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT programinstance_pkey PRIMARY KEY (enrollmentid);


--
-- Name: enrollment_notes programinstancecomments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment_notes
    ADD CONSTRAINT programinstancecomments_pkey PRIMARY KEY (enrollmentid, sort_order);


--
-- Name: programmessage programmessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT programmessage_pkey PRIMARY KEY (id);


--
-- Name: programnotificationinstance programnotificationinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationinstance
    ADD CONSTRAINT programnotificationinstance_pkey PRIMARY KEY (programnotificationinstanceid);


--
-- Name: programnotificationtemplate programnotificationtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT programnotificationtemplate_pkey PRIMARY KEY (programnotificationtemplateid);


--
-- Name: programownershiphistory programownershiphistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programownershiphistory
    ADD CONSTRAINT programownershiphistory_pkey PRIMARY KEY (programownershiphistoryid);


--
-- Name: programrule programrule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT programrule_pkey PRIMARY KEY (programruleid);


--
-- Name: programruleaction programruleaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT programruleaction_pkey PRIMARY KEY (programruleactionid);


--
-- Name: programrulevariable programrulevariable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT programrulevariable_pkey PRIMARY KEY (programrulevariableid);


--
-- Name: programsection_attributes programsection_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection_attributes
    ADD CONSTRAINT programsection_attributes_pkey PRIMARY KEY (programsectionid, sort_order);


--
-- Name: programsection programsection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT programsection_pkey PRIMARY KEY (programsectionid);


--
-- Name: programstage programstage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT programstage_pkey PRIMARY KEY (programstageid);


--
-- Name: programstagedataelement programstagedataelement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT programstagedataelement_pkey PRIMARY KEY (programstagedataelementid);


--
-- Name: programstagedataelement programstagedataelement_unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT programstagedataelement_unique_key UNIQUE (programstageid, dataelementid);


--
-- Name: event programstageinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT programstageinstance_pkey PRIMARY KEY (eventid);


--
-- Name: event_notes programstageinstancecomments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_notes
    ADD CONSTRAINT programstageinstancecomments_pkey PRIMARY KEY (eventid, sort_order);


--
-- Name: eventfilter programstageinstancefilter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventfilter
    ADD CONSTRAINT programstageinstancefilter_pkey PRIMARY KEY (eventfilterid);


--
-- Name: programstagesection_dataelements programstagesection_dataelements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_dataelements
    ADD CONSTRAINT programstagesection_dataelements_pkey PRIMARY KEY (programstagesectionid, sort_order);


--
-- Name: programstagesection programstagesection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT programstagesection_pkey PRIMARY KEY (programstagesectionid);


--
-- Name: programstagesection_programindicators programstagesection_programindicators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_programindicators
    ADD CONSTRAINT programstagesection_programindicators_pkey PRIMARY KEY (programstagesectionid, sort_order);


--
-- Name: programstageworkinglist programstageworkinglist_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageworkinglist
    ADD CONSTRAINT programstageworkinglist_code_key UNIQUE (code);


--
-- Name: programstageworkinglist programstageworkinglist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageworkinglist
    ADD CONSTRAINT programstageworkinglist_pkey PRIMARY KEY (programstageworkinglistid);


--
-- Name: programstageworkinglist programstageworkinglist_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageworkinglist
    ADD CONSTRAINT programstageworkinglist_uid_key UNIQUE (uid);


--
-- Name: programtempowner programtempowner_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtempowner
    ADD CONSTRAINT programtempowner_pkey PRIMARY KEY (programtempownerid);


--
-- Name: programtempownershipaudit programtempownershipaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtempownershipaudit
    ADD CONSTRAINT programtempownershipaudit_pkey PRIMARY KEY (programtempownershipauditid);


--
-- Name: program_attributes programtrackedentityattribute_unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT programtrackedentityattribute_unique_key UNIQUE (programid, trackedentityattributeid);


--
-- Name: pushanalysis pushanalysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT pushanalysis_pkey PRIMARY KEY (pushanalysisid);


--
-- Name: pushanalysisrecipientusergroups pushanalysisrecipientusergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysisrecipientusergroups
    ADD CONSTRAINT pushanalysisrecipientusergroups_pkey PRIMARY KEY (usergroupid, elt);


--
-- Name: relationship relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT relationship_pkey PRIMARY KEY (relationshipid);


--
-- Name: relationshipconstraint relationshipconstraint_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshipconstraint
    ADD CONSTRAINT relationshipconstraint_pkey PRIMARY KEY (relationshipconstraintid);


--
-- Name: relationshipitem relationshipitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshipitem
    ADD CONSTRAINT relationshipitem_pkey PRIMARY KEY (relationshipitemid);


--
-- Name: relationshiptype relationshiptype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT relationshiptype_pkey PRIMARY KEY (relationshiptypeid);


--
-- Name: relativeperiods relativeperiods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relativeperiods
    ADD CONSTRAINT relativeperiods_pkey PRIMARY KEY (relativeperiodsid);


--
-- Name: report report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_pkey PRIMARY KEY (reportid);


--
-- Name: reservedvalue reservedvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservedvalue
    ADD CONSTRAINT reservedvalue_pkey PRIMARY KEY (reservedvalueid);


--
-- Name: route route_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT route_code_key UNIQUE (code);


--
-- Name: route route_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT route_name_key UNIQUE (name);


--
-- Name: route route_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT route_pkey PRIMARY KEY (routeid);


--
-- Name: route route_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT route_uid_key UNIQUE (uid);


--
-- Name: section section_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_pkey PRIMARY KEY (sectionid);


--
-- Name: sectiondataelements sectiondataelements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiondataelements
    ADD CONSTRAINT sectiondataelements_pkey PRIMARY KEY (sectionid, sort_order);


--
-- Name: sectiongreyedfields sectiongreyedfields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiongreyedfields
    ADD CONSTRAINT sectiongreyedfields_pkey PRIMARY KEY (sectionid, dataelementoperandid);


--
-- Name: sectionindicators sectionindicators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionindicators
    ADD CONSTRAINT sectionindicators_pkey PRIMARY KEY (sectionid, sort_order);


--
-- Name: sequentialnumbercounter seqnumcount_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequentialnumbercounter
    ADD CONSTRAINT seqnumcount_pkey PRIMARY KEY (owneruid, key);


--
-- Name: series series_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_pkey PRIMARY KEY (seriesid);


--
-- Name: smscodes smscodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscodes
    ADD CONSTRAINT smscodes_pkey PRIMARY KEY (smscodeid);


--
-- Name: smscommandcodes smscommandcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandcodes
    ADD CONSTRAINT smscommandcodes_pkey PRIMARY KEY (id, codeid);


--
-- Name: smscommands smscommands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT smscommands_pkey PRIMARY KEY (smscommandid);


--
-- Name: smscommandspecialcharacters smscommandspecialcharacters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandspecialcharacters
    ADD CONSTRAINT smscommandspecialcharacters_pkey PRIMARY KEY (smscommandid, specialcharacterid);


--
-- Name: smsspecialcharacter smsspecialcharacter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smsspecialcharacter
    ADD CONSTRAINT smsspecialcharacter_pkey PRIMARY KEY (specialcharacterid);


--
-- Name: sqlview sqlview_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT sqlview_pkey PRIMARY KEY (sqlviewid);


--
-- Name: systemsetting systemsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.systemsetting
    ADD CONSTRAINT systemsetting_pkey PRIMARY KEY (systemsettingid);


--
-- Name: tablehook tablehook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT tablehook_pkey PRIMARY KEY (analyticstablehookid);


--
-- Name: trackedentityattribute trackedentityattribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT trackedentityattribute_pkey PRIMARY KEY (trackedentityattributeid);


--
-- Name: trackedentityattributedimension trackedentityattributedimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributedimension
    ADD CONSTRAINT trackedentityattributedimension_pkey PRIMARY KEY (trackedentityattributedimensionid);


--
-- Name: trackedentityattributelegendsets trackedentityattributelegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributelegendsets
    ADD CONSTRAINT trackedentityattributelegendsets_pkey PRIMARY KEY (trackedentityattributeid, sort_order);


--
-- Name: trackedentityattributevalue trackedentityattributevalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalue
    ADD CONSTRAINT trackedentityattributevalue_pkey PRIMARY KEY (trackedentityid, trackedentityattributeid);


--
-- Name: trackedentityattributevalueaudit trackedentityattributevalueaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalueaudit
    ADD CONSTRAINT trackedentityattributevalueaudit_pkey PRIMARY KEY (trackedentityattributevalueauditid);


--
-- Name: note trackedentitycomment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT trackedentitycomment_pkey PRIMARY KEY (noteid);


--
-- Name: trackedentitydataelementdimension trackedentitydataelementdimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydataelementdimension
    ADD CONSTRAINT trackedentitydataelementdimension_pkey PRIMARY KEY (trackedentitydataelementdimensionid);


--
-- Name: trackedentitydatavalueaudit trackedentitydatavalueaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydatavalueaudit
    ADD CONSTRAINT trackedentitydatavalueaudit_pkey PRIMARY KEY (trackedentitydatavalueauditid);


--
-- Name: trackedentity trackedentityinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentity
    ADD CONSTRAINT trackedentityinstance_pkey PRIMARY KEY (trackedentityid);


--
-- Name: trackedentityaudit trackedentityinstanceaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityaudit
    ADD CONSTRAINT trackedentityinstanceaudit_pkey PRIMARY KEY (trackedentityauditid);


--
-- Name: trackedentityfilter trackedentityinstancefilter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityfilter
    ADD CONSTRAINT trackedentityinstancefilter_pkey PRIMARY KEY (trackedentityfilterid);


--
-- Name: trackedentityprogramindicatordimension trackedentityprogramindicatordimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramindicatordimension
    ADD CONSTRAINT trackedentityprogramindicatordimension_pkey PRIMARY KEY (trackedentityprogramindicatordimensionid);


--
-- Name: trackedentityprogramowner trackedentityprogramowner_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramowner
    ADD CONSTRAINT trackedentityprogramowner_pkey PRIMARY KEY (trackedentityprogramownerid);


--
-- Name: trackedentitytype trackedentitytype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT trackedentitytype_pkey PRIMARY KEY (trackedentitytypeid);


--
-- Name: trackedentitytypeattribute trackedentitytypeattribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT trackedentitytypeattribute_pkey PRIMARY KEY (trackedentitytypeattributeid);


--
-- Name: trackedentitytypeattribute uk_10sblshxcb7dd4qi3s879u35h; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT uk_10sblshxcb7dd4qi3s879u35h UNIQUE (uid);


--
-- Name: validationrule uk_13x63e3skbl5qj4mc1qgq2xex; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT uk_13x63e3skbl5qj4mc1qgq2xex UNIQUE (code);


--
-- Name: attribute uk_1774shfid1uaopl9tu8am19fq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT uk_1774shfid1uaopl9tu8am19fq UNIQUE (code);


--
-- Name: optionvalue uk_18b68rcofdwt1sbr6rf55poog; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvalue
    ADD CONSTRAINT uk_18b68rcofdwt1sbr6rf55poog UNIQUE (uid);


--
-- Name: mapview uk_1dw8gju4leg7iud4gpsr5r1ng; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT uk_1dw8gju4leg7iud4gpsr5r1ng UNIQUE (uid);


--
-- Name: category uk_1ev6xqtcsfr4wv6rel0lkg44n; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT uk_1ev6xqtcsfr4wv6rel0lkg44n UNIQUE (uid);


--
-- Name: optiongroupsetmembers uk_1film7lsn5m1wyeku7yh5anfa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetmembers
    ADD CONSTRAINT uk_1film7lsn5m1wyeku7yh5anfa UNIQUE (optiongroupid);


--
-- Name: report uk_1ie06vhy3begtwuuvrv0f71se; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT uk_1ie06vhy3begtwuuvrv0f71se UNIQUE (uid);


--
-- Name: validationrulegroup uk_1lvk8ftq028jrr28qouou9q3c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT uk_1lvk8ftq028jrr28qouou9q3c UNIQUE (code);


--
-- Name: event_notes uk_1n7xvxj0jupob5f2v86cv8qer; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_notes
    ADD CONSTRAINT uk_1n7xvxj0jupob5f2v86cv8qer UNIQUE (noteid);


--
-- Name: programmessage uk_1qlw3rts2pog96ye7r6fqd122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT uk_1qlw3rts2pog96ye7r6fqd122 UNIQUE (uid);


--
-- Name: dataelementgroupset uk_1xk8j7j0a3li8o0ukblanosky; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT uk_1xk8j7j0a3li8o0ukblanosky UNIQUE (name);


--
-- Name: programstagesection uk_22wt9yk9idujmywno44v9qf66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT uk_22wt9yk9idujmywno44v9qf66 UNIQUE (code);


--
-- Name: optiongroupset uk_2boebaetgus89t1k8nn4dac65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT uk_2boebaetgus89t1k8nn4dac65 UNIQUE (uid);


--
-- Name: programstagedataelement uk_2ejl9l5vm4rhtqj8eit31g0u6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT uk_2ejl9l5vm4rhtqj8eit31g0u6 UNIQUE (code);


--
-- Name: relationship uk_2gbm9ji77snuoll07yvpgj3o5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT uk_2gbm9ji77snuoll07yvpgj3o5 UNIQUE (to_relationshipitemid);


--
-- Name: i18nlocale uk_2l0ovv74pjtairmeyiwy4i2ui; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT uk_2l0ovv74pjtairmeyiwy4i2ui UNIQUE (uid);


--
-- Name: dataelement uk_2nhc265rlfu3dlc3qouvjdprl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT uk_2nhc265rlfu3dlc3qouvjdprl UNIQUE (name);


--
-- Name: programindicatorgroup uk_2p9x16ryxtek0g6bqwd49et0c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT uk_2p9x16ryxtek0g6bqwd49et0c UNIQUE (uid);


--
-- Name: programnotificationtemplate uk_2pimmculf9ttu2dxquomb9ram; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT uk_2pimmculf9ttu2dxquomb9ram UNIQUE (uid);


--
-- Name: dataapprovallevel uk_2r18tvmbtksk69j35uxpwej44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT uk_2r18tvmbtksk69j35uxpwej44 UNIQUE (code);


--
-- Name: userkeyjsonvalue uk_2ubxwwtgyqd0h2mvy46u3prfq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT uk_2ubxwwtgyqd0h2mvy46u3prfq UNIQUE (code);


--
-- Name: map uk_37l2m3o1xfuagpki90gfh5kqb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT uk_37l2m3o1xfuagpki90gfh5kqb UNIQUE (code);


--
-- Name: categorycombo uk_3a4ee92kxafw85hsopq4qle47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT uk_3a4ee92kxafw85hsopq4qle47 UNIQUE (code);


--
-- Name: programruleaction uk_3c2n8db21er764e4skh3qg57w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT uk_3c2n8db21er764e4skh3qg57w UNIQUE (uid);


--
-- Name: validationrulegroup uk_3cl2o6ha8naw5w6my3q4el6gk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT uk_3cl2o6ha8naw5w6my3q4el6gk UNIQUE (name);


--
-- Name: dashboarditem uk_3idqsvkpmxpehxqv615s952vd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT uk_3idqsvkpmxpehxqv615s952vd UNIQUE (uid);


--
-- Name: orgunitgroup uk_3phvecdmy2msmcpitqifpcy3c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT uk_3phvecdmy2msmcpitqifpcy3c UNIQUE (code);


--
-- Name: dataelement uk_3r6dr8m9qwa89afngtr43x9jh; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT uk_3r6dr8m9qwa89afngtr43x9jh UNIQUE (uid);


--
-- Name: dataapprovalworkflow uk_3svwn20y9qda34bmatesg5c0j; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT uk_3svwn20y9qda34bmatesg5c0j UNIQUE (code);


--
-- Name: programmessage uk_3vgkycs0lsgpxaqtytfijr1ji; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT uk_3vgkycs0lsgpxaqtytfijr1ji UNIQUE (code);


--
-- Name: programindicator uk_4372w9f7asbu1ybpduj2xqjmt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT uk_4372w9f7asbu1ybpduj2xqjmt UNIQUE (shortname);


--
-- Name: report uk_478bg522jkn8460hkeshlw1j1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT uk_478bg522jkn8460hkeshlw1j1 UNIQUE (relativeperiodsid);


--
-- Name: predictor uk_4b97sdsm2p477cc05eody10lm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT uk_4b97sdsm2p477cc05eody10lm UNIQUE (name);


--
-- Name: tablehook uk_4bcigh7ivtiraxnhqrg72tldo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT uk_4bcigh7ivtiraxnhqrg72tldo UNIQUE (code);


--
-- Name: fileresource uk_4dlqoc6s8ilws9yhacy5qkddb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT uk_4dlqoc6s8ilws9yhacy5qkddb UNIQUE (code);


--
-- Name: periodboundary uk_4e9t02lypy6ynejqfegixx36k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodboundary
    ADD CONSTRAINT uk_4e9t02lypy6ynejqfegixx36k UNIQUE (uid);


--
-- Name: trackedentitytype uk_4iylxmooa7ca562qvw4tjq5ys; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT uk_4iylxmooa7ca562qvw4tjq5ys UNIQUE (uid);


--
-- Name: userkeyjsonvalue uk_4k3a3mf7dgr4b2btftg5jkmt7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT uk_4k3a3mf7dgr4b2btftg5jkmt7 UNIQUE (uid);


--
-- Name: programnotificationinstance uk_4mi7q6tbreuo0hspppxyodibk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationinstance
    ADD CONSTRAINT uk_4mi7q6tbreuo0hspppxyodibk UNIQUE (code);


--
-- Name: categoryoption uk_4pi5lfmisrt8un89dnb17xrdy; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption
    ADD CONSTRAINT uk_4pi5lfmisrt8un89dnb17xrdy UNIQUE (uid);


--
-- Name: sqlview uk_50aqn6tun6lt4u3ablvdxgoi6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT uk_50aqn6tun6lt4u3ablvdxgoi6 UNIQUE (code);


--
-- Name: externalmaplayer uk_581ayy658kxytmijcfd2rxnq0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT uk_581ayy658kxytmijcfd2rxnq0 UNIQUE (name);


--
-- Name: programindicator uk_59abitsfd3u0jx4ntrrblven0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT uk_59abitsfd3u0jx4ntrrblven0 UNIQUE (uid);


--
-- Name: orgunitlevel uk_5km0xiwk0dg7pnoru5yfvqsdo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT uk_5km0xiwk0dg7pnoru5yfvqsdo UNIQUE (uid);


--
-- Name: dataapprovallevel uk_5mq4bmpyevmr1ddkkopweted1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT uk_5mq4bmpyevmr1ddkkopweted1 UNIQUE (name);


--
-- Name: eventchart uk_5w429v9hdlvivan4a69x3ntx5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT uk_5w429v9hdlvivan4a69x3ntx5 UNIQUE (relativeperiodsid);


--
-- Name: categoryoptioncombo uk_60p9gh2un0pb7l9tctfd4o3b3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombo
    ADD CONSTRAINT uk_60p9gh2un0pb7l9tctfd4o3b3 UNIQUE (code);


--
-- Name: externalmaplayer uk_64w4wa4oc3hkxo86hjo63cd1x; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT uk_64w4wa4oc3hkxo86hjo63cd1x UNIQUE (uid);


--
-- Name: tablehook uk_668dyd20363ufr44a805inegm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT uk_668dyd20363ufr44a805inegm UNIQUE (name);


--
-- Name: eventchart uk_679r4uoqpust6h694bed8nrh9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT uk_679r4uoqpust6h694bed8nrh9 UNIQUE (uid);


--
-- Name: eventchart uk_6dyim42vl218i9e9waqrvw36k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT uk_6dyim42vl218i9e9waqrvw36k UNIQUE (code);


--
-- Name: categoryoptiongroupset uk_6itpx2frqt3msln8p32rk7qta; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT uk_6itpx2frqt3msln8p32rk7qta UNIQUE (uid);


--
-- Name: trackedentitytypeattribute uk_6lycqfymeu4sdi4t3cdh6ul1k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT uk_6lycqfymeu4sdi4t3cdh6ul1k UNIQUE (code);


--
-- Name: optiongroup uk_6ni8qsiimdcy626hwls002flo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT uk_6ni8qsiimdcy626hwls002flo UNIQUE (name);


--
-- Name: mapview uk_6nm3ynkrtuj01bpo1uwcryq06; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT uk_6nm3ynkrtuj01bpo1uwcryq06 UNIQUE (code);


--
-- Name: dataelementgroup uk_6x37lph70r5mh15a71pf1tj17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT uk_6x37lph70r5mh15a71pf1tj17 UNIQUE (shortname);


--
-- Name: relationship uk_74iy11sx99wxaut3skkphkvgi; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT uk_74iy11sx99wxaut3skkphkvgi UNIQUE (uid);


--
-- Name: tablehook uk_78x5lua91w1j6upu02wh8pfx9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT uk_78x5lua91w1j6upu02wh8pfx9 UNIQUE (uid);


--
-- Name: relationship uk_799tkjg7am2injr1dypaidt4p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT uk_799tkjg7am2injr1dypaidt4p UNIQUE (code);


--
-- Name: programindicatorgroup uk_7carnwjb5dtsk6i5dn43wy9ck; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT uk_7carnwjb5dtsk6i5dn43wy9ck UNIQUE (name);


--
-- Name: programrule uk_7odx4uo6s5bg55kt1fxky4a8v; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT uk_7odx4uo6s5bg55kt1fxky4a8v UNIQUE (code);


--
-- Name: relationshiptype uk_7rnfvkitq6l0kr5ju2slxopfi; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT uk_7rnfvkitq6l0kr5ju2slxopfi UNIQUE (uid);


--
-- Name: programindicator uk_7udjng39j4ddafjn57r58v7oq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT uk_7udjng39j4ddafjn57r58v7oq UNIQUE (name);


--
-- Name: optionset uk_81gfx3yt7ngwmkk0t8qgcovhi; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT uk_81gfx3yt7ngwmkk0t8qgcovhi UNIQUE (uid);


--
-- Name: maplegendset uk_842ips1xb81udqc3dw5uax7u5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT uk_842ips1xb81udqc3dw5uax7u5 UNIQUE (name);


--
-- Name: programsection uk_84abcabq3so8ktgt726o5du9d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT uk_84abcabq3so8ktgt726o5du9d UNIQUE (uid);


--
-- Name: validationnotificationtemplate uk_87wso1e1xtxsl34nxey6nr922; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate
    ADD CONSTRAINT uk_87wso1e1xtxsl34nxey6nr922 UNIQUE (code);


--
-- Name: validationrulegroup uk_8alvmsgu0onl4i0a0sqb6mqx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT uk_8alvmsgu0onl4i0a0sqb6mqx UNIQUE (uid);


--
-- Name: relationshiptype uk_8d4xrx2gygb4aivpcwrp613hj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT uk_8d4xrx2gygb4aivpcwrp613hj UNIQUE (name);


--
-- Name: indicatortype uk_8dcmrupnoi7hiiom466aoa2y; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT uk_8dcmrupnoi7hiiom466aoa2y UNIQUE (code);


--
-- Name: mapview uk_8eyremdx683wcd9owh1t5jufs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT uk_8eyremdx683wcd9owh1t5jufs UNIQUE (relativeperiodsid);


--
-- Name: note uk_8ul0w6gi3mdnr0kficn5syigg; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT uk_8ul0w6gi3mdnr0kficn5syigg UNIQUE (code);


--
-- Name: externalfileresource uk_8v1lxgqdnnocvm9ah6clxmjf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT uk_8v1lxgqdnnocvm9ah6clxmjf UNIQUE (code);


--
-- Name: dataelement uk_94srnunkibylfaxt4knxfn58e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT uk_94srnunkibylfaxt4knxfn58e UNIQUE (code);


--
-- Name: maplegend uk_9csrw908a1fvfwbhjwm0jfl4e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT uk_9csrw908a1fvfwbhjwm0jfl4e UNIQUE (uid);


--
-- Name: section uk_9hvlbsw019hscf35xb5behfx9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT uk_9hvlbsw019hscf35xb5behfx9 UNIQUE (code);


--
-- Name: i18nlocale uk_9j6xjgegveyc0uqs506yy2wrp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT uk_9j6xjgegveyc0uqs506yy2wrp UNIQUE (locale);


--
-- Name: metadataversion uk_9k7bv5o2ut4t0unxcwfyf1ay0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT uk_9k7bv5o2ut4t0unxcwfyf1ay0 UNIQUE (code);


--
-- Name: attribute uk_9mqbhximifdn1n8ru52lan3fw; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT uk_9mqbhximifdn1n8ru52lan3fw UNIQUE (uid);


--
-- Name: validationrule uk_9ut6k8m3216v5kjcryy7d2y9w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT uk_9ut6k8m3216v5kjcryy7d2y9w UNIQUE (name);


--
-- Name: event uk_9ydk6ypaj0xdjoyo1d5asap3m; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT uk_9ydk6ypaj0xdjoyo1d5asap3m UNIQUE (code);


--
-- Name: section uk_a50otc0l2chm0heii6scpit4k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT uk_a50otc0l2chm0heii6scpit4k UNIQUE (uid);


--
-- Name: indicatorgroupset uk_actuoxkkqulslxjpj5hagib9r; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT uk_actuoxkkqulslxjpj5hagib9r UNIQUE (code);


--
-- Name: trackedentityfilter uk_acvg948kspicwqw3gmg4ehu8i; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityfilter
    ADD CONSTRAINT uk_acvg948kspicwqw3gmg4ehu8i UNIQUE (code);


--
-- Name: optiongroupset uk_aee54nmg1ci2cpitnpiwa845p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT uk_aee54nmg1ci2cpitnpiwa845p UNIQUE (name);


--
-- Name: dataelementgroup uk_aqbaj76r9qxmnylr6p8kj9g37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT uk_aqbaj76r9qxmnylr6p8kj9g37 UNIQUE (name);


--
-- Name: constant uk_aygjfui3fpgrsxbj6qj782h6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT uk_aygjfui3fpgrsxbj6qj782h6f UNIQUE (shortname);


--
-- Name: dataset uk_ayk5ey2r1fh1akknxtpcpyp9r; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT uk_ayk5ey2r1fh1akknxtpcpyp9r UNIQUE (uid);


--
-- Name: relationshiptype uk_aypbls80uca5qu23w4fbqns2f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT uk_aypbls80uca5qu23w4fbqns2f UNIQUE (to_relationshipconstraintid);


--
-- Name: category uk_b0ii4jdfy88pffbapohsr2lor; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT uk_b0ii4jdfy88pffbapohsr2lor UNIQUE (name);


--
-- Name: programstage uk_b3oan3noe4cj9dvyi0amofndv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT uk_b3oan3noe4cj9dvyi0amofndv UNIQUE (uid);


--
-- Name: predictorgroup uk_biaq93npnr9ho37lxo51sbt3b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictorgroup
    ADD CONSTRAINT uk_biaq93npnr9ho37lxo51sbt3b UNIQUE (code);


--
-- Name: categoryoptiongroupset uk_bjs0n874pj6eoag98jmeidy9a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT uk_bjs0n874pj6eoag98jmeidy9a UNIQUE (code);


--
-- Name: maplegendset uk_bv71u83esume24hp4gsaj5p4f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT uk_bv71u83esume24hp4gsaj5p4f UNIQUE (code);


--
-- Name: dataapprovalworkflow uk_by4pqq1ans00ffmrgqqh9ehog; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT uk_by4pqq1ans00ffmrgqqh9ehog UNIQUE (uid);


--
-- Name: dashboarditem uk_c8bnosb06cchme5sig7b54uot; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT uk_c8bnosb06cchme5sig7b54uot UNIQUE (code);


--
-- Name: externalfileresource uk_ccwoighljmk4fy165ipnwl5n4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT uk_ccwoighljmk4fy165ipnwl5n4 UNIQUE (uid);


--
-- Name: datastatistics uk_cswvqawieb2sfq5qsy5wpqp1k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatistics
    ADD CONSTRAINT uk_cswvqawieb2sfq5qsy5wpqp1k UNIQUE (code);


--
-- Name: programrulevariable uk_cto4jvd9q49voite13v0egy3i; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT uk_cto4jvd9q49voite13v0egy3i UNIQUE (code);


--
-- Name: enrollment uk_d3lsa2h8me94ksyp53l6rpe3g; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT uk_d3lsa2h8me94ksyp53l6rpe3g UNIQUE (uid);


--
-- Name: metadataversion uk_d3qpxp187x8t4c1rsn64crgqu; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT uk_d3qpxp187x8t4c1rsn64crgqu UNIQUE (hashcode);


--
-- Name: externalfileresource uk_d4gp8a84gn643g0r28hdnn4so; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT uk_d4gp8a84gn643g0r28hdnn4so UNIQUE (fileresourceid);


--
-- Name: dataentryform uk_dhl0qt8y7hht7krbiym1e9x3n; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT uk_dhl0qt8y7hht7krbiym1e9x3n UNIQUE (code);


--
-- Name: categorycombo uk_dlhi39gmt2e0dun73f04w7w7u; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT uk_dlhi39gmt2e0dun73f04w7w7u UNIQUE (uid);


--
-- Name: programindicator uk_do17h5nk71uvc3xjry6kgevj9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT uk_do17h5nk71uvc3xjry6kgevj9 UNIQUE (code);


--
-- Name: systemsetting uk_do99wgsyk5wflbhb937u5av8m; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.systemsetting
    ADD CONSTRAINT uk_do99wgsyk5wflbhb937u5av8m UNIQUE (name);


--
-- Name: optiongroup uk_dt8m81o2pw5p9ttid369e92bg; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT uk_dt8m81o2pw5p9ttid369e92bg UNIQUE (code);


--
-- Name: programrulevariable uk_e5mhmtj1h7xdfiio2panhapgg; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT uk_e5mhmtj1h7xdfiio2panhapgg UNIQUE (uid);


--
-- Name: programstage uk_e6s6o9jau6tx04m62t7ey4i81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT uk_e6s6o9jau6tx04m62t7ey4i81 UNIQUE (code);


--
-- Name: maplegendset uk_ec7ehyocpresxxhm7yjstdnwt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT uk_ec7ehyocpresxxhm7yjstdnwt UNIQUE (uid);


--
-- Name: constant uk_edy7cktu2fqg01r3n0fjyk1kk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT uk_edy7cktu2fqg01r3n0fjyk1kk UNIQUE (code);


--
-- Name: fileresource uk_eh2epuhchf9mci86ihl06i31g; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT uk_eh2epuhchf9mci86ihl06i31g UNIQUE (uid);


--
-- Name: trackedentityattribute uk_eh4c3whbwi94nhh772q6l5t7m; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT uk_eh4c3whbwi94nhh772q6l5t7m UNIQUE (code);


--
-- Name: organisationunit uk_ehl4v33tq7hlkmc28vbno1b4n; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT uk_ehl4v33tq7hlkmc28vbno1b4n UNIQUE (code);


--
-- Name: usergroup uk_ekb018cvmpvll5dgtn97leerj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT uk_ekb018cvmpvll5dgtn97leerj UNIQUE (uid);


--
-- Name: document uk_elt3kiqdmmm5fwqfxsxk9lvh0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT uk_elt3kiqdmmm5fwqfxsxk9lvh0 UNIQUE (code);


--
-- Name: keyjsonvalue uk_em6b7qxcas7dn6y506i3nd2x6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT uk_em6b7qxcas7dn6y506i3nd2x6 UNIQUE (uid);


--
-- Name: version uk_emoyyyy114ofh6cwo6do8xsi0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT uk_emoyyyy114ofh6cwo6do8xsi0 UNIQUE (versionkey);


--
-- Name: dashboard uk_emyh4fed0f1kknqhimmrhnek8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT uk_emyh4fed0f1kknqhimmrhnek8 UNIQUE (code);


--
-- Name: predictor uk_enhquk04unrpri78inaske3jq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT uk_enhquk04unrpri78inaske3jq UNIQUE (uid);


--
-- Name: eventreport uk_eqd95mucf5pd856dqlwe6y36c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT uk_eqd95mucf5pd856dqlwe6y36c UNIQUE (code);


--
-- Name: smscommandspecialcharacters uk_etm1elt7pbwyia8e0kfnrvqo3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandspecialcharacters
    ADD CONSTRAINT uk_etm1elt7pbwyia8e0kfnrvqo3 UNIQUE (specialcharacterid);


--
-- Name: trackedentityattribute uk_evp7d8obarxt3kewepigkwahc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT uk_evp7d8obarxt3kewepigkwahc UNIQUE (name);


--
-- Name: programindicatorgroup uk_f7wfef3jx1yl73stqs7b45ewb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT uk_f7wfef3jx1yl73stqs7b45ewb UNIQUE (code);


--
-- Name: metadataversion uk_f93o7l4afmkassm3t4f2op9ps; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT uk_f93o7l4afmkassm3t4f2op9ps UNIQUE (name);


--
-- Name: programruleaction uk_fbferisvig2o4f5owb5lnygf3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT uk_fbferisvig2o4f5owb5lnygf3 UNIQUE (code);


--
-- Name: userrole uk_ff1da38in40mg91rlgqhw02ff; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT uk_ff1da38in40mg91rlgqhw02ff UNIQUE (uid);


--
-- Name: sqlview uk_fps2ja521pudngaitlp0805du; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT uk_fps2ja521pudngaitlp0805du UNIQUE (uid);


--
-- Name: orgunitgroupset uk_fuentbuhbbr0ix49td9jqlfe5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT uk_fuentbuhbbr0ix49td9jqlfe5 UNIQUE (uid);


--
-- Name: program uk_fuq6kda6folarp19oggaf02vb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT uk_fuq6kda6folarp19oggaf02vb UNIQUE (code);


--
-- Name: orgunitlevel uk_fvgc7isaflcan55g51ysm9df2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT uk_fvgc7isaflcan55g51ysm9df2 UNIQUE (code);


--
-- Name: oauth2client uk_fx3xx9xe0xpurjt6v5p7rv8da; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT uk_fx3xx9xe0xpurjt6v5p7rv8da UNIQUE (uid);


--
-- Name: organisationunit uk_g1nrfjv5x04ap1ceohiwah380; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT uk_g1nrfjv5x04ap1ceohiwah380 UNIQUE (uid);


--
-- Name: oauth2client uk_gdfuf3j66jxnvwwnksjxqysac; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT uk_gdfuf3j66jxnvwwnksjxqysac UNIQUE (code);


--
-- Name: categoryoptiongroup uk_ge3y4pf6qlne9p7rfmhlvg941; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT uk_ge3y4pf6qlne9p7rfmhlvg941 UNIQUE (code);


--
-- Name: trackedentityattribute uk_gg9gc0pyaqjuxi8mr4y93i03w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT uk_gg9gc0pyaqjuxi8mr4y93i03w UNIQUE (shortname);


--
-- Name: relationshiptype uk_gio4nn8l23jikmebud3jwql43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT uk_gio4nn8l23jikmebud3jwql43 UNIQUE (code);


--
-- Name: userinfo uk_gky85ptfkcumyuqhr5yvjxwsa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userinfo
    ADD CONSTRAINT uk_gky85ptfkcumyuqhr5yvjxwsa UNIQUE (code);


--
-- Name: map uk_grp9b5jne53f806pc92sfd5s8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT uk_grp9b5jne53f806pc92sfd5s8 UNIQUE (uid);


--
-- Name: relationship uk_gsvll3t3tsda7kx38waqnegkw; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT uk_gsvll3t3tsda7kx38waqnegkw UNIQUE (from_relationshipitemid);


--
-- Name: event uk_gy44hufdeduoma7eeh3j6abm7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT uk_gy44hufdeduoma7eeh3j6abm7 UNIQUE (uid);


--
-- Name: program uk_h4omjcs2ktifdrf2m36u886ae; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT uk_h4omjcs2ktifdrf2m36u886ae UNIQUE (uid);


--
-- Name: categorycombo uk_h97pko7n41oky8pfptkflp8l6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT uk_h97pko7n41oky8pfptkflp8l6 UNIQUE (name);


--
-- Name: userrole uk_hebhkhm8gpwg9xsp8q4f7wlx1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT uk_hebhkhm8gpwg9xsp8q4f7wlx1 UNIQUE (code);


--
-- Name: userrole uk_hjocbvo9fla04bgj7ku32vwsn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT uk_hjocbvo9fla04bgj7ku32vwsn UNIQUE (name);


--
-- Name: attribute uk_hpwum0iq12fs4ej5d0tgy6wsn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT uk_hpwum0iq12fs4ej5d0tgy6wsn UNIQUE (name);


--
-- Name: dataapprovallevel uk_hqekpuhjg3g4k4t7xdnu10jy4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT uk_hqekpuhjg3g4k4t7xdnu10jy4 UNIQUE (orgunitlevel, categoryoptiongroupsetid);


--
-- Name: orgunitgroupset uk_hs57i9hma97ps6jpsrbb24lm9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT uk_hs57i9hma97ps6jpsrbb24lm9 UNIQUE (code);


--
-- Name: dataapprovallevel uk_i1uhc0c8jgxkhlswl9fujsicf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT uk_i1uhc0c8jgxkhlswl9fujsicf UNIQUE (uid);


--
-- Name: predictorgroup uk_i4dix5cj64521ivv59c0wgvfq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictorgroup
    ADD CONSTRAINT uk_i4dix5cj64521ivv59c0wgvfq UNIQUE (uid);


--
-- Name: maplegend uk_id4stsb5slq35axmjeojnjnoa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT uk_id4stsb5slq35axmjeojnjnoa UNIQUE (code);


--
-- Name: sqlview uk_iedy6hh42wl3gr3m87ntd6so8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT uk_iedy6hh42wl3gr3m87ntd6so8 UNIQUE (name);


--
-- Name: jobconfiguration uk_igo4gx1d74k7m93vxnn4n77jf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT uk_igo4gx1d74k7m93vxnn4n77jf UNIQUE (code);


--
-- Name: messageconversation_usermessages uk_j5pi1qwi2m228qrsxql48o61s; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_usermessages
    ADD CONSTRAINT uk_j5pi1qwi2m228qrsxql48o61s UNIQUE (usermessageid);


--
-- Name: categoryoptiongroup uk_j9oya1t1tvj8yn5h8fega4ltr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT uk_j9oya1t1tvj8yn5h8fega4ltr UNIQUE (name);


--
-- Name: dataelement uk_jc27pe1xeptws5xprct7mgxrj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT uk_jc27pe1xeptws5xprct7mgxrj UNIQUE (shortname);


--
-- Name: datasetnotificationtemplate uk_jjt6ctp2xi4d7vtv4pwkkdhh0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT uk_jjt6ctp2xi4d7vtv4pwkkdhh0 UNIQUE (uid);


--
-- Name: dataelementgroup uk_jo65jc3wyrxfekiu3upk80mtr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT uk_jo65jc3wyrxfekiu3upk80mtr UNIQUE (code);


--
-- Name: document uk_jxodv1lvot26euasttk021jio; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT uk_jxodv1lvot26euasttk021jio UNIQUE (uid);


--
-- Name: fileresource uk_jxqj907hbrng860p6mypvl63k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT uk_jxqj907hbrng860p6mypvl63k UNIQUE (storagekey);


--
-- Name: interpretation_comments uk_k48tayhxu52jiq782pikev9d9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation_comments
    ADD CONSTRAINT uk_k48tayhxu52jiq782pikev9d9 UNIQUE (interpretationcommentid);


--
-- Name: trackedentityattribute uk_kbqnrdakcjfooofmti30d4p8x; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT uk_kbqnrdakcjfooofmti30d4p8x UNIQUE (uid);


--
-- Name: report uk_kc1wmcky1ooleovi36oqcqmqe; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT uk_kc1wmcky1ooleovi36oqcqmqe UNIQUE (code);


--
-- Name: categoryoptiongroupset uk_ke8p30sy68dl7fggednkimdb6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT uk_ke8p30sy68dl7fggednkimdb6 UNIQUE (name);


--
-- Name: indicator uk_kmpefoaw81v4bxpoey6y1y3xl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT uk_kmpefoaw81v4bxpoey6y1y3xl UNIQUE (code);


--
-- Name: indicatorgroup uk_kqbwxccoqctky1kdkimjya03s; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT uk_kqbwxccoqctky1kdkimjya03s UNIQUE (uid);


--
-- Name: i18nlocale uk_krm9w69donjqsejkmfw17jbcx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT uk_krm9w69donjqsejkmfw17jbcx UNIQUE (code);


--
-- Name: metadataversion uk_ktwf16f728hce9ahtpmm7w5lx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT uk_ktwf16f728hce9ahtpmm7w5lx UNIQUE (uid);


--
-- Name: program_attributes uk_lgju00pi2jk7y6sl4dkhaykux; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT uk_lgju00pi2jk7y6sl4dkhaykux UNIQUE (uid);


--
-- Name: externalnotificationlogentry uk_lner1ovmrqr5qrwn8gwfuhhhn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalnotificationlogentry
    ADD CONSTRAINT uk_lner1ovmrqr5qrwn8gwfuhhhn UNIQUE (uid);


--
-- Name: eventreport uk_lnnx8vmalkhkmneryv1ytjq68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT uk_lnnx8vmalkhkmneryv1ytjq68 UNIQUE (uid);


--
-- Name: categoryoptiongroup uk_lrnagoy2wi83nwmataolh7t6d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT uk_lrnagoy2wi83nwmataolh7t6d UNIQUE (shortname);


--
-- Name: orgunitgroup uk_lswbn93sime7vmdqqe9lks7ge; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT uk_lswbn93sime7vmdqqe9lks7ge UNIQUE (uid);


--
-- Name: orgunitlevel uk_ltwhby0s0iwayxrcdu6yefeqt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT uk_ltwhby0s0iwayxrcdu6yefeqt UNIQUE (level);


--
-- Name: dataelementgroupset uk_lu295rc1y01c7p7t76y6ajaas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT uk_lu295rc1y01c7p7t76y6ajaas UNIQUE (uid);


--
-- Name: enrollment_notes uk_lwep604j10w1ey7vunqdmotx2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment_notes
    ADD CONSTRAINT uk_lwep604j10w1ey7vunqdmotx2 UNIQUE (noteid);


--
-- Name: programstagesection uk_lycal9jdw3cs0wwebxciswwgr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT uk_lycal9jdw3cs0wwebxciswwgr UNIQUE (uid);


--
-- Name: trackedentityfilter uk_m5k30j5e93n1no82gye7jgf25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityfilter
    ADD CONSTRAINT uk_m5k30j5e93n1no82gye7jgf25 UNIQUE (uid);


--
-- Name: validationnotificationtemplate uk_mbt1vxa5exs9cbqqs5px2mopx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate
    ADD CONSTRAINT uk_mbt1vxa5exs9cbqqs5px2mopx UNIQUE (uid);


--
-- Name: externalnotificationlogentry uk_mcn0op3hsf5ajqg5k4oli4xkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalnotificationlogentry
    ADD CONSTRAINT uk_mcn0op3hsf5ajqg5k4oli4xkc UNIQUE (key);


--
-- Name: categoryoption uk_mlop2afk26fwowa69lr9a138y; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption
    ADD CONSTRAINT uk_mlop2afk26fwowa69lr9a138y UNIQUE (code);


--
-- Name: datasetnotificationtemplate uk_mq0y6uuq2erprg2siebo2mk1o; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT uk_mq0y6uuq2erprg2siebo2mk1o UNIQUE (code);


--
-- Name: dashboard uk_myox13mr8r27oxl7ts33ntpd5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT uk_myox13mr8r27oxl7ts33ntpd5 UNIQUE (uid);


--
-- Name: dataapprovalworkflow uk_n18s4feicujvngv2ajoesdgio; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT uk_n18s4feicujvngv2ajoesdgio UNIQUE (name);


--
-- Name: indicatorgroupset uk_n4xputyk31femiaxls6lbl2rw; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT uk_n4xputyk31femiaxls6lbl2rw UNIQUE (uid);


--
-- Name: pushanalysis uk_n5ax669vkj63nx3rrvlushqdm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT uk_n5ax669vkj63nx3rrvlushqdm UNIQUE (code);


--
-- Name: indicatortype uk_n8mbmryeksa80ucyxj0vg6p9b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT uk_n8mbmryeksa80ucyxj0vg6p9b UNIQUE (name);


--
-- Name: oauth2client uk_ni7epmbxtn4jcax3ya324ff9w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT uk_ni7epmbxtn4jcax3ya324ff9w UNIQUE (cid);


--
-- Name: optiongroup uk_nipo7t010a80osh7okxswav2g; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT uk_nipo7t010a80osh7okxswav2g UNIQUE (uid);


--
-- Name: messageconversation_messages uk_nqdtggpr548q0tnbu919puw0p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_messages
    ADD CONSTRAINT uk_nqdtggpr548q0tnbu919puw0p UNIQUE (messageid);


--
-- Name: oauth2client uk_nwgvrevv2slj1bvc9m01p89lf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT uk_nwgvrevv2slj1bvc9m01p89lf UNIQUE (name);


--
-- Name: optiongroup uk_nwq3y4xqct21tdl0l77bvmpoe; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT uk_nwq3y4xqct21tdl0l77bvmpoe UNIQUE (shortname);


--
-- Name: constant uk_nywvip5682tuvxrnwjomeyg6y; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT uk_nywvip5682tuvxrnwjomeyg6y UNIQUE (uid);


--
-- Name: predictor uk_o0v1fdqiyte40ffm9q3nhcj4v; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT uk_o0v1fdqiyte40ffm9q3nhcj4v UNIQUE (code);


--
-- Name: constant uk_o2xbcli806eba6dkdfco0o3kc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT uk_o2xbcli806eba6dkdfco0o3kc UNIQUE (name);


--
-- Name: dataset uk_oeni5ndit5g033f1s1j08bdry; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT uk_oeni5ndit5g033f1s1j08bdry UNIQUE (code);


--
-- Name: categoryoptiongroup uk_ol8n7oq6clgxvqjedlpn85aqo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT uk_ol8n7oq6clgxvqjedlpn85aqo UNIQUE (uid);


--
-- Name: trackedentity uk_orq3pwtro2yu9yydh046bn40j; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentity
    ADD CONSTRAINT uk_orq3pwtro2yu9yydh046bn40j UNIQUE (code);


--
-- Name: programstagedataelement uk_os4r1umsvtmbuqm2bo25s5ej0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT uk_os4r1umsvtmbuqm2bo25s5ej0 UNIQUE (uid);


--
-- Name: programnotificationtemplate uk_ot8a05g9d4k5l67xi062xx5w6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT uk_ot8a05g9d4k5l67xi062xx5w6 UNIQUE (code);


--
-- Name: dataelementgroup uk_otvwcgv4bxjtqfj3flhrnmgf7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT uk_otvwcgv4bxjtqfj3flhrnmgf7 UNIQUE (uid);


--
-- Name: indicatortype uk_p0p3bwhgbsdemu14v23p47qne; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT uk_p0p3bwhgbsdemu14v23p47qne UNIQUE (uid);


--
-- Name: optionset uk_p0rvldurcmk0x3mx39lt5uvsd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT uk_p0rvldurcmk0x3mx39lt5uvsd UNIQUE (name);


--
-- Name: programrule uk_p7arcbl58mmcrj2didtr0ruqh; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT uk_p7arcbl58mmcrj2didtr0ruqh UNIQUE (uid);


--
-- Name: dataelementgroupset uk_p7egnv3sj4ugyl23mk4vga40k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT uk_p7egnv3sj4ugyl23mk4vga40k UNIQUE (code);


--
-- Name: dataentryform uk_p8tvo9tqrdn5tb45d0g5cko5o; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT uk_p8tvo9tqrdn5tb45d0g5cko5o UNIQUE (name);


--
-- Name: categoryoption uk_pbj3u1nk9vnuof8f47utvowmv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption
    ADD CONSTRAINT uk_pbj3u1nk9vnuof8f47utvowmv UNIQUE (name);


--
-- Name: datastatistics uk_ppi146eky8fodu97t1o21vkd8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatistics
    ADD CONSTRAINT uk_ppi146eky8fodu97t1o21vkd8 UNIQUE (uid);


--
-- Name: eventfilter uk_programstageinstancefilter_uid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventfilter
    ADD CONSTRAINT uk_programstageinstancefilter_uid UNIQUE (uid);


--
-- Name: organisationunit uk_pw2bgc9ykjad2obefeqha28t4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT uk_pw2bgc9ykjad2obefeqha28t4 UNIQUE (path);


--
-- Name: category uk_pw87bi64e3ev11k7dwrmljo78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT uk_pw87bi64e3ev11k7dwrmljo78 UNIQUE (code);


--
-- Name: predictorgroup uk_pxnxtb4ywoh2m74vosk2httc3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictorgroup
    ADD CONSTRAINT uk_pxnxtb4ywoh2m74vosk2httc3 UNIQUE (name);


--
-- Name: dataentryform uk_q0obvr5rvxhlnjs367y1f0bav; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT uk_q0obvr5rvxhlnjs367y1f0bav UNIQUE (uid);


--
-- Name: eventreport uk_q0oyainj1lis9c8kkh5sky2ri; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT uk_q0oyainj1lis9c8kkh5sky2ri UNIQUE (relativeperiodsid);


--
-- Name: usergroup uk_q20sh82vk885ooi7fekwtboej; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT uk_q20sh82vk885ooi7fekwtboej UNIQUE (code);


--
-- Name: optiongroupset uk_q9jv2e3fy49hc1havuwnr0res; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT uk_q9jv2e3fy49hc1havuwnr0res UNIQUE (code);


--
-- Name: categoryoptioncombo uk_qki43s9vdndg15c9tyv718u1j; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombo
    ADD CONSTRAINT uk_qki43s9vdndg15c9tyv718u1j UNIQUE (uid);


--
-- Name: i18nlocale uk_qogg9a7yy4qconomxt4j4upql; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT uk_qogg9a7yy4qconomxt4j4upql UNIQUE (name);


--
-- Name: categoryoption uk_qp9201a4m6jl53sei0huh4l6s; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption
    ADD CONSTRAINT uk_qp9201a4m6jl53sei0huh4l6s UNIQUE (shortname);


--
-- Name: relationshiptype uk_qq5b8o288bhpe59e5ks3op8jy; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT uk_qq5b8o288bhpe59e5ks3op8jy UNIQUE (from_relationshipconstraintid);


--
-- Name: pushanalysis uk_qunv1hucv9wi5pt92tur929mr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT uk_qunv1hucv9wi5pt92tur929mr UNIQUE (uid);


--
-- Name: orgunitgroup uk_qwk9qdapql867enp5r7fa0uic; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT uk_qwk9qdapql867enp5r7fa0uic UNIQUE (name);


--
-- Name: program_attributes uk_r2f9o8i6th2w8vqdexdfo72ui; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT uk_r2f9o8i6th2w8vqdexdfo72ui UNIQUE (code);


--
-- Name: externalmaplayer uk_r3ugbbibdsyn234isip3346v4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT uk_r3ugbbibdsyn234isip3346v4 UNIQUE (code);


--
-- Name: validationresult uk_r6ebedjcac8c49c53aa1mpa8e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT uk_r6ebedjcac8c49c53aa1mpa8e UNIQUE (validationruleid, periodid, organisationunitid, attributeoptioncomboid, dayinperiod);


--
-- Name: trackedentity uk_rbr4kyuk4s0kb4jo1r77cuaq9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentity
    ADD CONSTRAINT uk_rbr4kyuk4s0kb4jo1r77cuaq9 UNIQUE (uid);


--
-- Name: jobconfiguration uk_rqkhk3ebvk1kflf7qigbaxeyp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT uk_rqkhk3ebvk1kflf7qigbaxeyp UNIQUE (name);


--
-- Name: optionset uk_rvfiukug5ui7qidoiln3el3aa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT uk_rvfiukug5ui7qidoiln3el3aa UNIQUE (code);


--
-- Name: periodboundary uk_sbipy5btkgy542bdbx7mxppdd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodboundary
    ADD CONSTRAINT uk_sbipy5btkgy542bdbx7mxppdd UNIQUE (code);


--
-- Name: jobconfiguration uk_sdng31h9qjawcikcllry8a8a5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT uk_sdng31h9qjawcikcllry8a8a5 UNIQUE (uid);


--
-- Name: indicatorgroup uk_sspviu4m0l0lf7ef3t3cagfxd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT uk_sspviu4m0l0lf7ef3t3cagfxd UNIQUE (code);


--
-- Name: validationrule uk_t0dg39dopew9f6y64ucsx7194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT uk_t0dg39dopew9f6y64ucsx7194 UNIQUE (uid);


--
-- Name: orgunitgroup uk_t0srkng3akwg3pcp5qlwcx06n; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT uk_t0srkng3akwg3pcp5qlwcx06n UNIQUE (shortname);


--
-- Name: orgunitgroupset uk_t5lxvc1km3ylon5st1fuabsgl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT uk_t5lxvc1km3ylon5st1fuabsgl UNIQUE (name);


--
-- Name: note uk_t94h9p111tcydbm6je22tla52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT uk_t94h9p111tcydbm6je22tla52 UNIQUE (uid);


--
-- Name: smscommandcodes uk_t9e1mnpydje0rsvinxq68q1i6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandcodes
    ADD CONSTRAINT uk_t9e1mnpydje0rsvinxq68q1i6 UNIQUE (codeid);


--
-- Name: indicator uk_ta80keoi67443tkvvmx8l872x; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT uk_ta80keoi67443tkvvmx8l872x UNIQUE (uid);


--
-- Name: programnotificationinstance uk_takpuhb2893t7bbbak9ym3kq9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationinstance
    ADD CONSTRAINT uk_takpuhb2893t7bbbak9ym3kq9 UNIQUE (uid);


--
-- Name: period uk_tbkbjga8h4j5u33d7hbcuk66t; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period
    ADD CONSTRAINT uk_tbkbjga8h4j5u33d7hbcuk66t UNIQUE (periodtypeid, startdate, enddate);


--
-- Name: trackedentityprogramowner uk_tei_program; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramowner
    ADD CONSTRAINT uk_tei_program UNIQUE (trackedentityid, programid);


--
-- Name: programsection uk_tglbwfy1e3ubt5x5hab46qbh6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT uk_tglbwfy1e3ubt5x5hab46qbh6 UNIQUE (code);


--
-- Name: trackedentitytype uk_thb8irn2kmm7jay3vcogqxy3x; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT uk_thb8irn2kmm7jay3vcogqxy3x UNIQUE (name);


--
-- Name: keyjsonvalue uk_tikknlgl0im3w68yvlb0swrgd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT uk_tikknlgl0im3w68yvlb0swrgd UNIQUE (code);


--
-- Name: trackedentitytype uk_to3d8d23u9behgh9acdu2wjvl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT uk_to3d8d23u9behgh9acdu2wjvl UNIQUE (code);


--
-- Name: userinfo uk_userinfo_username; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userinfo
    ADD CONSTRAINT uk_userinfo_username UNIQUE (username);


--
-- Name: predictor unique_generator_expression; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT unique_generator_expression UNIQUE (generatorexpressionid);


--
-- Name: validationrule unique_left_expression; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT unique_left_expression UNIQUE (leftexpressionid);


--
-- Name: validationrule unique_right_expression; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT unique_right_expression UNIQUE (rightexpressionid);


--
-- Name: predictor unique_skip_test_expression; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT unique_skip_test_expression UNIQUE (skiptestexpressionid);


--
-- Name: userapps userapps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userapps
    ADD CONSTRAINT userapps_pkey PRIMARY KEY (userinfoid, sort_order);


--
-- Name: userdatavieworgunits userdatavieworgunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userdatavieworgunits
    ADD CONSTRAINT userdatavieworgunits_pkey PRIMARY KEY (userinfoid, organisationunitid);


--
-- Name: usergroup usergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT usergroup_pkey PRIMARY KEY (usergroupid);


--
-- Name: usergroupmanaged usergroupmanaged_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmanaged
    ADD CONSTRAINT usergroupmanaged_pkey PRIMARY KEY (managedbygroupid, managedgroupid);


--
-- Name: usergroupmembers usergroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmembers
    ADD CONSTRAINT usergroupmembers_pkey PRIMARY KEY (usergroupid, userid);


--
-- Name: userinfo userinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userinfo
    ADD CONSTRAINT userinfo_pkey PRIMARY KEY (userinfoid);


--
-- Name: userkeyjsonvalue userkeyjsonvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT userkeyjsonvalue_pkey PRIMARY KEY (userkeyjsonvalueid);


--
-- Name: userkeyjsonvalue userkeyjsonvalue_unique_key_on_user_and_namespace; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT userkeyjsonvalue_unique_key_on_user_and_namespace UNIQUE (userid, namespace, userkey);


--
-- Name: usermembership usermembership_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermembership
    ADD CONSTRAINT usermembership_pkey PRIMARY KEY (userinfoid, organisationunitid);


--
-- Name: usermessage usermessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermessage
    ADD CONSTRAINT usermessage_pkey PRIMARY KEY (usermessageid);


--
-- Name: userrole userrole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT userrole_pkey PRIMARY KEY (userroleid);


--
-- Name: userrolemembers userrolemembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrolemembers
    ADD CONSTRAINT userrolemembers_pkey PRIMARY KEY (userid, userroleid);


--
-- Name: users_catdimensionconstraints users_catdimensionconstraints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_catdimensionconstraints
    ADD CONSTRAINT users_catdimensionconstraints_pkey PRIMARY KEY (userid, dataelementcategoryid);


--
-- Name: users_cogsdimensionconstraints users_cogsdimensionconstraints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_cogsdimensionconstraints
    ADD CONSTRAINT users_cogsdimensionconstraints_pkey PRIMARY KEY (userid, categoryoptiongroupsetid);


--
-- Name: usersetting usersetting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usersetting
    ADD CONSTRAINT usersetting_pkey PRIMARY KEY (userinfoid, name);


--
-- Name: userteisearchorgunits userteisearchorgunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userteisearchorgunits
    ADD CONSTRAINT userteisearchorgunits_pkey PRIMARY KEY (userinfoid, organisationunitid);


--
-- Name: validationnotificationtemplate validationnotificationtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate
    ADD CONSTRAINT validationnotificationtemplate_pkey PRIMARY KEY (validationnotificationtemplateid);


--
-- Name: validationnotificationtemplate_recipientusergroups validationnotificationtemplate_recipientusergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate_recipientusergroups
    ADD CONSTRAINT validationnotificationtemplate_recipientusergroups_pkey PRIMARY KEY (validationnotificationtemplateid, usergroupid);


--
-- Name: validationnotificationtemplatevalidationrules validationnotificationtemplatevalidationrules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplatevalidationrules
    ADD CONSTRAINT validationnotificationtemplatevalidationrules_pkey PRIMARY KEY (validationnotificationtemplateid, validationruleid);


--
-- Name: validationresult validationresult_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT validationresult_pkey PRIMARY KEY (validationresultid);


--
-- Name: validationrule validationrule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT validationrule_pkey PRIMARY KEY (validationruleid);


--
-- Name: validationrulegroup validationrulegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT validationrulegroup_pkey PRIMARY KEY (validationrulegroupid);


--
-- Name: validationrulegroupmembers validationrulegroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupmembers
    ADD CONSTRAINT validationrulegroupmembers_pkey PRIMARY KEY (validationgroupid, validationruleid);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (versionid);


--
-- Name: version version_versionkey_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT version_versionkey_key UNIQUE (versionkey);


--
-- Name: visualization_axis visualization_axis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_axis
    ADD CONSTRAINT visualization_axis_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_categorydimensions visualization_categorydimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_categorydimensions
    ADD CONSTRAINT visualization_categorydimensions_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_categoryoptiongroupsetdimensions visualization_categoryoptiongroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_categoryoptiongroupsetdimensions
    ADD CONSTRAINT visualization_categoryoptiongroupsetdimensions_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization visualization_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization
    ADD CONSTRAINT visualization_code_key UNIQUE (code);


--
-- Name: visualization_columns visualization_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_columns
    ADD CONSTRAINT visualization_columns_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_datadimensionitems visualization_datadimensionitems_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_datadimensionitems
    ADD CONSTRAINT visualization_datadimensionitems_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_dataelementgroupsetdimensions visualization_dataelementgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_dataelementgroupsetdimensions
    ADD CONSTRAINT visualization_dataelementgroupsetdimensions_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_filters visualization_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_filters
    ADD CONSTRAINT visualization_filters_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_itemorgunitgroups visualization_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_itemorgunitgroups
    ADD CONSTRAINT visualization_itemorgunitgroups_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_organisationunits visualization_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_organisationunits
    ADD CONSTRAINT visualization_organisationunits_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_orgunitgroupsetdimensions visualization_orgunitgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_orgunitgroupsetdimensions
    ADD CONSTRAINT visualization_orgunitgroupsetdimensions_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_orgunitlevels visualization_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_orgunitlevels
    ADD CONSTRAINT visualization_orgunitlevels_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization_periods visualization_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_periods
    ADD CONSTRAINT visualization_periods_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization visualization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization
    ADD CONSTRAINT visualization_pkey PRIMARY KEY (visualizationid);


--
-- Name: visualization visualization_relativeperiodsid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization
    ADD CONSTRAINT visualization_relativeperiodsid_key UNIQUE (relativeperiodsid);


--
-- Name: visualization_rows visualization_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_rows
    ADD CONSTRAINT visualization_rows_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: visualization visualization_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization
    ADD CONSTRAINT visualization_uid_key UNIQUE (uid);


--
-- Name: visualization_yearlyseries visualization_yearlyseries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_yearlyseries
    ADD CONSTRAINT visualization_yearlyseries_pkey PRIMARY KEY (visualizationid, sort_order);


--
-- Name: create index in_userinfo_openid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "create index in_userinfo_openid" ON public.userinfo USING btree (openid);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: id_datavalueaudit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX id_datavalueaudit_created ON public.datavalueaudit USING btree (created);


--
-- Name: in_categories_categoryoptions_coid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_categories_categoryoptions_coid ON public.categories_categoryoptions USING btree (categoryoptionid, categoryid);


--
-- Name: in_categoryoptioncombo_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_categoryoptioncombo_name ON public.categoryoptioncombo USING btree (name);


--
-- Name: in_dataapprovallevel_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_dataapprovallevel_level ON public.dataapprovallevel USING btree (level);


--
-- Name: in_datasetsource_sourceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_datasetsource_sourceid ON public.datasetsource USING btree (sourceid);


--
-- Name: in_datavalue_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_datavalue_deleted ON public.datavalue USING btree (deleted);


--
-- Name: in_datavalue_lastupdated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_datavalue_lastupdated ON public.datavalue USING btree (lastupdated);


--
-- Name: in_datavalueaudit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_datavalueaudit ON public.datavalueaudit USING btree (dataelementid, periodid, organisationunitid, categoryoptioncomboid, attributeoptioncomboid);


--
-- Name: in_enrollment_lastupdated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_enrollment_lastupdated ON public.enrollment USING btree (lastupdated);


--
-- Name: in_event_lastupdated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_event_lastupdated ON public.event USING btree (lastupdated);


--
-- Name: in_interpretation_mentions_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_interpretation_mentions_username ON public.interpretation USING gin (((mentions -> 'username'::text)) jsonb_path_ops);


--
-- Name: in_interpretationcomment_mentions_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_interpretationcomment_mentions_username ON public.interpretationcomment USING gin (((mentions -> 'username'::text)) jsonb_path_ops);


--
-- Name: in_messageconversation_extmessageid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_messageconversation_extmessageid ON public.messageconversation USING hash (extmessageid);


--
-- Name: in_organisationunit_hierarchylevel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_organisationunit_hierarchylevel ON public.organisationunit USING btree (hierarchylevel);


--
-- Name: in_organisationunit_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_organisationunit_path ON public.organisationunit USING btree (path varchar_pattern_ops);


--
-- Name: in_parentid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_parentid ON public.organisationunit USING btree (parentid);


--
-- Name: in_programinstance_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_programinstance_deleted ON public.enrollment USING btree (deleted);


--
-- Name: in_programinstance_programid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_programinstance_programid ON public.enrollment USING btree (programid);


--
-- Name: in_programinstance_trackedentityinstanceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_programinstance_trackedentityinstanceid ON public.enrollment USING btree (trackedentityid);


--
-- Name: in_programstageinstance_status_executiondate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_programstageinstance_status_executiondate ON public.event USING btree (status, occurreddate);


--
-- Name: in_programtempowner_validtill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_programtempowner_validtill ON public.programtempowner USING btree (EXTRACT(epoch FROM validtill));


--
-- Name: in_psi_deleted_assigneduserid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_psi_deleted_assigneduserid ON public.event USING btree (deleted, assigneduserid);


--
-- Name: in_relationship_inverted_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_relationship_inverted_key ON public.relationship USING btree (inverted_key);


--
-- Name: in_relationship_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_relationship_key ON public.relationship USING btree (key);


--
-- Name: in_relationshipitem_programinstanceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_relationshipitem_programinstanceid ON public.relationshipitem USING btree (enrollmentid);


--
-- Name: in_relationshipitem_programstageinstanceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_relationshipitem_programstageinstanceid ON public.relationshipitem USING btree (eventid);


--
-- Name: in_relationshipitem_trackedentityinstanceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_relationshipitem_trackedentityinstanceid ON public.relationshipitem USING btree (trackedentityid);


--
-- Name: in_reservedvalue_value_generation; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX in_reservedvalue_value_generation ON public.reservedvalue USING btree (ownerobject, owneruid, key, lower((value)::text));


--
-- Name: in_trackedentity_attribute_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_trackedentity_attribute_value ON public.trackedentityattributevalue USING btree (trackedentityattributeid, lower((value)::text));


--
-- Name: in_trackedentityattributevalue_attributeid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_trackedentityattributevalue_attributeid ON public.trackedentityattributevalue USING btree (trackedentityattributeid);


--
-- Name: in_trackedentityinstance_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_trackedentityinstance_created ON public.trackedentity USING btree (created);


--
-- Name: in_trackedentityinstance_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_trackedentityinstance_deleted ON public.trackedentity USING btree (deleted);


--
-- Name: in_trackedentityinstance_organisationunitid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_trackedentityinstance_organisationunitid ON public.trackedentity USING btree (organisationunitid);


--
-- Name: in_trackedentityinstance_trackedentityattribute_value; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX in_trackedentityinstance_trackedentityattribute_value ON public.trackedentityattributevalue USING btree (trackedentityid, trackedentityattributeid, lower((value)::text));


--
-- Name: in_trackedentityprogramowner_program_orgunit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_trackedentityprogramowner_program_orgunit ON public.trackedentityprogramowner USING btree (programid, organisationunitid);


--
-- Name: in_unique_trackedentityprogramowner_teiid_programid_ouid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX in_unique_trackedentityprogramowner_teiid_programid_ouid ON public.trackedentityprogramowner USING btree (trackedentityid, programid, organisationunitid);


--
-- Name: in_userinfo_ldapid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX in_userinfo_ldapid ON public.userinfo USING btree (ldapid);


--
-- Name: in_userinfo_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX in_userinfo_username ON public.userinfo USING btree (username);


--
-- Name: in_userinfo_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX in_userinfo_uuid ON public.userinfo USING btree (uuid);


--
-- Name: index_programinstance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_programinstance ON public.enrollment USING btree (enrollmentid);


--
-- Name: index_trackedentitydatavalueaudit_programstageinstanceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_trackedentitydatavalueaudit_programstageinstanceid ON public.trackedentitydatavalueaudit USING btree (eventid);


--
-- Name: interpretation_lastupdated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interpretation_lastupdated ON public.interpretation USING btree (lastupdated);


--
-- Name: maplegend_endvalue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maplegend_endvalue ON public.maplegend USING btree (endvalue);


--
-- Name: maplegend_startvalue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maplegend_startvalue ON public.maplegend USING btree (startvalue);


--
-- Name: messageconversation_lastmessage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messageconversation_lastmessage ON public.messageconversation USING btree (lastmessage);


--
-- Name: outbound_sms_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX outbound_sms_status_index ON public.outbound_sms USING btree (status);


--
-- Name: program_rule_program; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX program_rule_program ON public.programrule USING btree (programid);


--
-- Name: program_rule_variable_program; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX program_rule_variable_program ON public.programrulevariable USING btree (programid);


--
-- Name: programstageinstance_executiondate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programstageinstance_executiondate ON public.event USING btree (occurreddate);


--
-- Name: programstageinstance_organisationunitid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programstageinstance_organisationunitid ON public.event USING btree (organisationunitid);


--
-- Name: programstageinstance_programinstanceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programstageinstance_programinstanceid ON public.event USING btree (enrollmentid);


--
-- Name: sms_originator_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_originator_index ON public.incomingsms USING btree (originator);


--
-- Name: sms_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_status_index ON public.incomingsms USING btree (status);


--
-- Name: uk_deletedobject_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_deletedobject_uid ON public.deletedobject USING btree (uid);


--
-- Name: uk_eventvisualization_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_eventvisualization_uid ON public.eventvisualization USING btree (uid);


--
-- Name: uk_incomingsms_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_incomingsms_uid ON public.incomingsms USING btree (uid);


--
-- Name: uk_interpretation_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_interpretation_uid ON public.interpretation USING btree (uid);


--
-- Name: uk_interpretationcomment_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_interpretationcomment_uid ON public.interpretationcomment USING btree (uid);


--
-- Name: uk_message_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_message_uid ON public.message USING btree (uid);


--
-- Name: uk_messageconversation_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_messageconversation_uid ON public.messageconversation USING btree (uid);


--
-- Name: uk_outbound_sms_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_outbound_sms_uid ON public.outbound_sms USING btree (uid);


--
-- Name: uk_smscommands_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_smscommands_uid ON public.smscommands USING btree (uid);


--
-- Name: uk_userinfo_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_userinfo_uid ON public.userinfo USING btree (uid);


--
-- Name: userkeyjsonvalue_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX userkeyjsonvalue_user ON public.userkeyjsonvalue USING btree (userid);


--
-- Name: usermessage_isread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usermessage_isread ON public.usermessage USING btree (isread);


--
-- Name: usermessage_userid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usermessage_userid ON public.usermessage USING btree (userid);


--
-- Name: uuid_usergroup_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uuid_usergroup_idx ON public.usergroup USING btree (uuid);


--
-- Name: indicatorlegendsets fk1ps7mt73qi3wnt6f5g6w6flga; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorlegendsets
    ADD CONSTRAINT fk1ps7mt73qi3wnt6f5g6w6flga FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: programmessage_phonenumbers fk3408hwfswvwfqyfngk1tf5ju8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage_phonenumbers
    ADD CONSTRAINT fk3408hwfswvwfqyfngk1tf5ju8 FOREIGN KEY (programmessagephonenumberid) REFERENCES public.programmessage(id);


--
-- Name: programnotificationtemplate_deliverychannel fk45uc7wfpi4u5gunpl127ehkn2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate_deliverychannel
    ADD CONSTRAINT fk45uc7wfpi4u5gunpl127ehkn2 FOREIGN KEY (programnotificationtemplatedeliverychannelid) REFERENCES public.programnotificationtemplate(programnotificationtemplateid);


--
-- Name: programnotificationtemplate fk4uq2bl31hdu2s4e07rltemk3d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk4uq2bl31hdu2s4e07rltemk3d FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: validationnotificationtemplatevalidationrules fk6oepnl7prbw10034c5vot1jii; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplatevalidationrules
    ADD CONSTRAINT fk6oepnl7prbw10034c5vot1jii FOREIGN KEY (validationnotificationtemplateid) REFERENCES public.validationnotificationtemplate(validationnotificationtemplateid);


--
-- Name: validationnotificationtemplate_recipientusergroups fk804hp0os62rpdtroxhrrio76v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate_recipientusergroups
    ADD CONSTRAINT fk804hp0os62rpdtroxhrrio76v FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: datasetlegendsets fk9f6ich22mw6be835i07khg9ld; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetlegendsets
    ADD CONSTRAINT fk9f6ich22mw6be835i07khg9ld FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: programnotificationtemplate fk9whlsdwfojxbp8yclqolqwm9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk9whlsdwfojxbp8yclqolqwm9 FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: aggregatedataexchange fk_aggregatedataexchange_lastupdateby_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aggregatedataexchange
    ADD CONSTRAINT fk_aggregatedataexchange_lastupdateby_userinfoid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: aggregatedataexchange fk_aggregatedataexchange_userid_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aggregatedataexchange
    ADD CONSTRAINT fk_aggregatedataexchange_userid_userinfoid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: attribute fk_attribute_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT fk_attribute_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: attribute fk_attribute_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT fk_attribute_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: attributevalue fk_attributevalue_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributevalue
    ADD CONSTRAINT fk_attributevalue_attributeid FOREIGN KEY (attributeid) REFERENCES public.attribute(attributeid);


--
-- Name: trackedentityattributevalue fk_attributevalue_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalue
    ADD CONSTRAINT fk_attributevalue_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: trackedentityattributevalue fk_attributevalue_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalue
    ADD CONSTRAINT fk_attributevalue_trackedentityinstanceid FOREIGN KEY (trackedentityid) REFERENCES public.trackedentity(trackedentityid);


--
-- Name: trackedentityattributevalueaudit fk_attributevalueaudit_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalueaudit
    ADD CONSTRAINT fk_attributevalueaudit_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: trackedentityattributevalueaudit fk_attributevalueaudit_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalueaudit
    ADD CONSTRAINT fk_attributevalueaudit_trackedentityinstanceid FOREIGN KEY (trackedentityid) REFERENCES public.trackedentity(trackedentityid);


--
-- Name: categories_categoryoptions fk_categories_categoryoptions_categoryid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_categoryoptions
    ADD CONSTRAINT fk_categories_categoryoptions_categoryid FOREIGN KEY (categoryid) REFERENCES public.category(categoryid);


--
-- Name: categories_categoryoptions fk_category_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_categoryoptions
    ADD CONSTRAINT fk_category_categoryoptionid FOREIGN KEY (categoryoptionid) REFERENCES public.categoryoption(categoryoptionid);


--
-- Name: categorycombos_categories fk_categorycombo_categoryid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_categories
    ADD CONSTRAINT fk_categorycombo_categoryid FOREIGN KEY (categoryid) REFERENCES public.category(categoryid);


--
-- Name: categorycombos_optioncombos fk_categorycombo_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_optioncombos
    ADD CONSTRAINT fk_categorycombo_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: categorycombo fk_categorycombo_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT fk_categorycombo_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: categorycombos_categories fk_categorycombos_categories_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_categories
    ADD CONSTRAINT fk_categorycombos_categories_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: categorycombos_optioncombos fk_categorycombos_optioncombos_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_optioncombos
    ADD CONSTRAINT fk_categorycombos_optioncombos_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: categorydimension fk_categorydimension_category; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension
    ADD CONSTRAINT fk_categorydimension_category FOREIGN KEY (categoryid) REFERENCES public.category(categoryid);


--
-- Name: categorydimension_items fk_categorydimension_items_categorydimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension_items
    ADD CONSTRAINT fk_categorydimension_items_categorydimensionid FOREIGN KEY (categorydimensionid) REFERENCES public.categorydimension(categorydimensionid);


--
-- Name: categorydimension_items fk_categorydimension_items_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension_items
    ADD CONSTRAINT fk_categorydimension_items_categoryoptionid FOREIGN KEY (categoryoptionid) REFERENCES public.categoryoption(categoryoptionid);


--
-- Name: categoryoptioncombos_categoryoptions fk_categoryoption_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombos_categoryoptions
    ADD CONSTRAINT fk_categoryoption_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: categoryoption_organisationunits fk_categoryoption_organisationunits_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption_organisationunits
    ADD CONSTRAINT fk_categoryoption_organisationunits_categoryoptionid FOREIGN KEY (categoryoptionid) REFERENCES public.categoryoption(categoryoptionid);


--
-- Name: categoryoption_organisationunits fk_categoryoption_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption_organisationunits
    ADD CONSTRAINT fk_categoryoption_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: smscodes fk_categoryoptioncombo_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscodes
    ADD CONSTRAINT fk_categoryoptioncombo_categoryoptioncomboid FOREIGN KEY (optionid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: categoryoptioncombos_categoryoptions fk_categoryoptioncombos_categoryoptions_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombos_categoryoptions
    ADD CONSTRAINT fk_categoryoptioncombos_categoryoptions_categoryoptionid FOREIGN KEY (categoryoptionid) REFERENCES public.categoryoption(categoryoptionid);


--
-- Name: categoryoptiongroup fk_categoryoptiongroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT fk_categoryoptiongroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: categoryoptiongroupmembers fk_categoryoptiongroupmembers_categoryoptiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupmembers
    ADD CONSTRAINT fk_categoryoptiongroupmembers_categoryoptiongroupid FOREIGN KEY (categoryoptionid) REFERENCES public.categoryoption(categoryoptionid);


--
-- Name: categoryoptiongroupmembers fk_categoryoptiongroupmembers_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupmembers
    ADD CONSTRAINT fk_categoryoptiongroupmembers_categoryoptionid FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: categoryoptiongroupset fk_categoryoptiongroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT fk_categoryoptiongroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: categoryoptiongroupsetmembers fk_categoryoptiongroupsetmembers_categoryoptiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetmembers
    ADD CONSTRAINT fk_categoryoptiongroupsetmembers_categoryoptiongroupid FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: categoryoptiongroupsetmembers fk_categoryoptiongroupsetmembers_categoryoptiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetmembers
    ADD CONSTRAINT fk_categoryoptiongroupsetmembers_categoryoptiongroupsetid FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: completedatasetregistration fk_completedatasetregistration_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT fk_completedatasetregistration_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: completedatasetregistration fk_completedatasetregistration_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT fk_completedatasetregistration_organisationunitid FOREIGN KEY (sourceid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: configuration_corswhitelist fk_configuration_corswhitelist; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration_corswhitelist
    ADD CONSTRAINT fk_configuration_corswhitelist FOREIGN KEY (configurationid) REFERENCES public.configuration(configurationid);


--
-- Name: configuration fk_configuration_facilityorgunitgroupset; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_facilityorgunitgroupset FOREIGN KEY (facilityorgunitgroupset) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: configuration fk_configuration_facilityorgunitlevel; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_facilityorgunitlevel FOREIGN KEY (facilityorgunitlevel) REFERENCES public.orgunitlevel(orgunitlevelid);


--
-- Name: configuration fk_configuration_feedback_recipients; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_feedback_recipients FOREIGN KEY (feedbackrecipientsid) REFERENCES public.usergroup(usergroupid);


--
-- Name: configuration fk_configuration_infrastructural_dataelements; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_infrastructural_dataelements FOREIGN KEY (infrastructuraldataelementsid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: configuration fk_configuration_infrastructural_indicators; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_infrastructural_indicators FOREIGN KEY (infrastructuralindicatorsid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: configuration fk_configuration_infrastructural_periodtype; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_infrastructural_periodtype FOREIGN KEY (infrastructuralperiodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: configuration fk_configuration_offline_orgunit_level; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_offline_orgunit_level FOREIGN KEY (offlineorgunitlevelid) REFERENCES public.orgunitlevel(orgunitlevelid);


--
-- Name: configuration fk_configuration_selfregistrationorgunit; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_selfregistrationorgunit FOREIGN KEY (selfregistrationorgunit) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: configuration fk_configuration_selfregistrationrole; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_selfregistrationrole FOREIGN KEY (selfregistrationrole) REFERENCES public.userrole(userroleid);


--
-- Name: configuration fk_configuration_systemupdatenotification_recipients; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_systemupdatenotification_recipients FOREIGN KEY (systemupdatenotificationrecipientsid) REFERENCES public.usergroup(usergroupid);


--
-- Name: constant fk_constant_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT fk_constant_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: icon fk_createdby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icon
    ADD CONSTRAINT fk_createdby_userid FOREIGN KEY (createdby) REFERENCES public.userinfo(userinfoid);


--
-- Name: metadataproposal fk_createdby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataproposal
    ADD CONSTRAINT fk_createdby_userid FOREIGN KEY (createdby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dashboard_items fk_dashboard_items_dashboardid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_items
    ADD CONSTRAINT fk_dashboard_items_dashboardid FOREIGN KEY (dashboardid) REFERENCES public.dashboard(dashboardid);


--
-- Name: dashboard_items fk_dashboard_items_dashboarditemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_items
    ADD CONSTRAINT fk_dashboard_items_dashboarditemid FOREIGN KEY (dashboarditemid) REFERENCES public.dashboarditem(dashboarditemid);


--
-- Name: dashboard fk_dashboard_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT fk_dashboard_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: dashboarditem fk_dashboarditem_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: dashboarditem fk_dashboarditem_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_eventreportid FOREIGN KEY (eventreport) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: dashboarditem fk_dashboarditem_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: dashboarditem fk_dashboarditem_mapid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_mapid FOREIGN KEY (mapid) REFERENCES public.map(mapid);


--
-- Name: dashboarditem_reports fk_dashboarditem_reports_dashboardid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_reports
    ADD CONSTRAINT fk_dashboarditem_reports_dashboardid FOREIGN KEY (dashboarditemid) REFERENCES public.dashboarditem(dashboarditemid);


--
-- Name: dashboarditem_reports fk_dashboarditem_reports_reportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_reports
    ADD CONSTRAINT fk_dashboarditem_reports_reportid FOREIGN KEY (reportid) REFERENCES public.report(reportid);


--
-- Name: dashboarditem_resources fk_dashboarditem_resources_dashboardid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_resources
    ADD CONSTRAINT fk_dashboarditem_resources_dashboardid FOREIGN KEY (dashboarditemid) REFERENCES public.dashboarditem(dashboarditemid);


--
-- Name: dashboarditem_resources fk_dashboarditem_resources_resourceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_resources
    ADD CONSTRAINT fk_dashboarditem_resources_resourceid FOREIGN KEY (resourceid) REFERENCES public.document(documentid);


--
-- Name: dashboarditem_users fk_dashboarditem_users_dashboardid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_users
    ADD CONSTRAINT fk_dashboarditem_users_dashboardid FOREIGN KEY (dashboarditemid) REFERENCES public.dashboarditem(dashboarditemid);


--
-- Name: dashboarditem_users fk_dashboarditem_users_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_users
    ADD CONSTRAINT fk_dashboarditem_users_userinfoid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: dashboarditem fk_dashboarditem_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: dataapproval fk_dataapproval_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: dataapproval fk_dataapproval_creator; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_creator FOREIGN KEY (creator) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataapprovalaudit fk_dataapproval_creator; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapproval_creator FOREIGN KEY (creator) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataapproval fk_dataapproval_dataapprovallevel; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_dataapprovallevel FOREIGN KEY (dataapprovallevelid) REFERENCES public.dataapprovallevel(dataapprovallevelid);


--
-- Name: dataapproval fk_dataapproval_lastupdateby; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_lastupdateby FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataapproval fk_dataapproval_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: dataapproval fk_dataapproval_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: dataapproval fk_dataapproval_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: dataapprovalaudit fk_dataapprovalaudit_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: dataapprovalaudit fk_dataapprovalaudit_levelid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_levelid FOREIGN KEY (levelid) REFERENCES public.dataapprovallevel(dataapprovallevelid);


--
-- Name: dataapprovalaudit fk_dataapprovalaudit_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: dataapprovalaudit fk_dataapprovalaudit_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: dataapprovalaudit fk_dataapprovalaudit_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: dataapprovallevel fk_dataapprovallevel_categoryoptiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT fk_dataapprovallevel_categoryoptiongroupsetid FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: dataapprovallevel fk_dataapprovallevel_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT fk_dataapprovallevel_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataapprovalworkflow fk_dataapprovalworkflow_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT fk_dataapprovalworkflow_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: dataapprovalworkflow fk_dataapprovalworkflow_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT fk_dataapprovalworkflow_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: dataapprovalworkflow fk_dataapprovalworkflow_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT fk_dataapprovalworkflow_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataapprovalworkflowlevels fk_dataapprovalworkflowlevels_levelid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowlevels
    ADD CONSTRAINT fk_dataapprovalworkflowlevels_levelid FOREIGN KEY (dataapprovallevelid) REFERENCES public.dataapprovallevel(dataapprovallevelid);


--
-- Name: dataapprovalworkflowlevels fk_dataapprovalworkflowlevels_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowlevels
    ADD CONSTRAINT fk_dataapprovalworkflowlevels_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: datadimensionitem fk_datadimensionitem_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: datadimensionitem fk_datadimensionitem_dataelementoperand_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_dataelementoperand_categoryoptioncomboid FOREIGN KEY (dataelementoperand_categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: datadimensionitem fk_datadimensionitem_dataelementoperand_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_dataelementoperand_dataelementid FOREIGN KEY (dataelementoperand_dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: datadimensionitem fk_datadimensionitem_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: datadimensionitem fk_datadimensionitem_expressiondimensionitemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_expressiondimensionitemid FOREIGN KEY (expressiondimensionitemid) REFERENCES public.expressiondimensionitem(expressiondimensionitemid);


--
-- Name: datadimensionitem fk_datadimensionitem_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_indicatorid FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: datadimensionitem fk_datadimensionitem_programattribute_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programattribute_attributeid FOREIGN KEY (programattribute_attributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: datadimensionitem fk_datadimensionitem_programattribute_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programattribute_programid FOREIGN KEY (programattribute_programid) REFERENCES public.program(programid);


--
-- Name: datadimensionitem fk_datadimensionitem_programdataelement_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programdataelement_dataelementid FOREIGN KEY (programdataelement_dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: datadimensionitem fk_datadimensionitem_programdataelement_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programdataelement_programid FOREIGN KEY (programdataelement_programid) REFERENCES public.program(programid);


--
-- Name: datadimensionitem fk_datadimensionitem_programindicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programindicatorid FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: dataelement fk_dataelement_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_dataelement_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: dataelement fk_dataelement_commentoptionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_dataelement_commentoptionsetid FOREIGN KEY (commentoptionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: smscodes fk_dataelement_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscodes
    ADD CONSTRAINT fk_dataelement_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: dataelementlegendsets fk_dataelement_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementlegendsets
    ADD CONSTRAINT fk_dataelement_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: dataelement fk_dataelement_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_dataelement_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: dataelement fk_dataelement_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_dataelement_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataelementaggregationlevels fk_dataelementaggregationlevels_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementaggregationlevels
    ADD CONSTRAINT fk_dataelementaggregationlevels_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: category fk_dataelementcategory_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT fk_dataelementcategory_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: categoryoption fk_dataelementcategoryoption_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption
    ADD CONSTRAINT fk_dataelementcategoryoption_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataelementgroupmembers fk_dataelementgroup_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupmembers
    ADD CONSTRAINT fk_dataelementgroup_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: dataelementgroup fk_dataelementgroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT fk_dataelementgroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataelementgroupmembers fk_dataelementgroupmembers_dataelementgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupmembers
    ADD CONSTRAINT fk_dataelementgroupmembers_dataelementgroupid FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: dataelementgroupsetmembers fk_dataelementgroupset_dataelementgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetmembers
    ADD CONSTRAINT fk_dataelementgroupset_dataelementgroupid FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: dataelementgroupset fk_dataelementgroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT fk_dataelementgroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataelementgroupsetmembers fk_dataelementgroupsetmembers_dataelementgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetmembers
    ADD CONSTRAINT fk_dataelementgroupsetmembers_dataelementgroupsetid FOREIGN KEY (dataelementgroupsetid) REFERENCES public.dataelementgroupset(dataelementgroupsetid);


--
-- Name: dataelementoperand fk_dataelementoperand_dataelement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementoperand
    ADD CONSTRAINT fk_dataelementoperand_dataelement FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: dataelementoperand fk_dataelementoperand_dataelementcategoryoptioncombo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementoperand
    ADD CONSTRAINT fk_dataelementoperand_dataelementcategoryoptioncombo FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: datainputperiod fk_datainputperiod_period; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datainputperiod
    ADD CONSTRAINT fk_datainputperiod_period FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: dataset fk_dataset_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: datasetoperands fk_dataset_dataelementoperandid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetoperands
    ADD CONSTRAINT fk_dataset_dataelementoperandid FOREIGN KEY (dataelementoperandid) REFERENCES public.dataelementoperand(dataelementoperandid);


--
-- Name: dataset fk_dataset_dataentryform; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_dataentryform FOREIGN KEY (dataentryform) REFERENCES public.dataentryform(dataentryformid);


--
-- Name: smscommands fk_dataset_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT fk_dataset_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: datasetindicators fk_dataset_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetindicators
    ADD CONSTRAINT fk_dataset_indicatorid FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: datasetlegendsets fk_dataset_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetlegendsets
    ADD CONSTRAINT fk_dataset_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: dataset fk_dataset_notificationrecipients; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_notificationrecipients FOREIGN KEY (notificationrecipients) REFERENCES public.usergroup(usergroupid);


--
-- Name: datasetsource fk_dataset_organisationunit; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsource
    ADD CONSTRAINT fk_dataset_organisationunit FOREIGN KEY (sourceid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: dataset fk_dataset_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: dataset fk_dataset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataset fk_dataset_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: completedatasetregistration fk_datasetcompleteregistration_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT fk_datasetcompleteregistration_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: completedatasetregistration fk_datasetcompleteregistration_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT fk_datasetcompleteregistration_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: datainputperiod fk_datasetdatainputperiods_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datainputperiod
    ADD CONSTRAINT fk_datasetdatainputperiods_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: datasetelement fk_datasetelement_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT fk_datasetelement_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: datasetindicators fk_datasetindicators_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetindicators
    ADD CONSTRAINT fk_datasetindicators_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: datasetelement fk_datasetmembers_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT fk_datasetmembers_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: datasetelement fk_datasetmembers_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT fk_datasetmembers_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: datasetnotificationtemplate fk_datasetnotification_usergroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT fk_datasetnotification_usergroup FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: datasetoperands fk_datasetoperands_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetoperands
    ADD CONSTRAINT fk_datasetoperands_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: datasetnotification_datasets fk_datasets_datasetnotificationtemplateid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotification_datasets
    ADD CONSTRAINT fk_datasets_datasetnotificationtemplateid FOREIGN KEY (datasetnotificationtemplateid) REFERENCES public.datasetnotificationtemplate(datasetnotificationtemplateid);


--
-- Name: datasetsource fk_datasetsource_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsource
    ADD CONSTRAINT fk_datasetsource_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: datavalue fk_datavalue_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: datavalue fk_datavalue_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: datavalue fk_datavalue_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: datavalue fk_datavalue_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_organisationunitid FOREIGN KEY (sourceid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: datavalue fk_datavalue_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: datavalueaudit fk_datavalueaudit_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: datavalueaudit fk_datavalueaudit_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: datavalueaudit fk_datavalueaudit_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: datavalueaudit fk_datavalueaudit_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: datavalueaudit fk_datavalueaudit_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: categoryoptiongroupsetdimension fk_dimension_categoryoptiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension
    ADD CONSTRAINT fk_dimension_categoryoptiongroupsetid FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: dataelementgroupsetdimension fk_dimension_dataelementgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension
    ADD CONSTRAINT fk_dimension_dataelementgroupsetid FOREIGN KEY (dataelementgroupsetid) REFERENCES public.dataelementgroupset(dataelementgroupsetid);


--
-- Name: categoryoptiongroupsetdimension_items fk_dimension_items_categoryoptiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_categoryoptiongroupid FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: categoryoptiongroupsetdimension_items fk_dimension_items_categoryoptiongroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_categoryoptiongroupsetdimensionid FOREIGN KEY (categoryoptiongroupsetdimensionid) REFERENCES public.categoryoptiongroupsetdimension(categoryoptiongroupsetdimensionid);


--
-- Name: dataelementgroupsetdimension_items fk_dimension_items_dataelementgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_dataelementgroupid FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: dataelementgroupsetdimension_items fk_dimension_items_dataelementgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_dataelementgroupsetdimensionid FOREIGN KEY (dataelementgroupsetdimensionid) REFERENCES public.dataelementgroupsetdimension(dataelementgroupsetdimensionid);


--
-- Name: orgunitgroupsetdimension_items fk_dimension_items_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: orgunitgroupsetdimension_items fk_dimension_items_orgunitgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_orgunitgroupsetdimensionid FOREIGN KEY (orgunitgroupsetdimensionid) REFERENCES public.orgunitgroupsetdimension(orgunitgroupsetdimensionid);


--
-- Name: orgunitgroupsetdimension fk_dimension_orgunitgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension
    ADD CONSTRAINT fk_dimension_orgunitgroupsetid FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: document fk_document_fileresourceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT fk_document_fileresourceid FOREIGN KEY (fileresource) REFERENCES public.fileresource(fileresourceid);


--
-- Name: document fk_document_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT fk_document_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentitydatavalueaudit fk_entityinstancedatavalueaudit_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydatavalueaudit
    ADD CONSTRAINT fk_entityinstancedatavalueaudit_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: trackedentitydatavalueaudit fk_entityinstancedatavalueaudit_programstageinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydatavalueaudit
    ADD CONSTRAINT fk_entityinstancedatavalueaudit_programstageinstanceid FOREIGN KEY (eventid) REFERENCES public.event(eventid);


--
-- Name: eventhook fk_eventhook_lastupdateby_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventhook
    ADD CONSTRAINT fk_eventhook_lastupdateby_userinfoid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: eventhook fk_eventhook_userid_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventhook
    ADD CONSTRAINT fk_eventhook_userid_userinfoid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: eventvisualization_attributedimensions fk_evisualization_attributedimensions_attributedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_attributedimensions
    ADD CONSTRAINT fk_evisualization_attributedimensions_attributedimensionid FOREIGN KEY (trackedentityattributedimensionid) REFERENCES public.trackedentityattributedimension(trackedentityattributedimensionid);


--
-- Name: eventvisualization_attributedimensions fk_evisualization_attributedimensions_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_attributedimensions
    ADD CONSTRAINT fk_evisualization_attributedimensions_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization fk_evisualization_attributevaluedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_attributevaluedimensionid FOREIGN KEY (attributevaluedimensionid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: eventvisualization_categorydimensions fk_evisualization_categorydimensions_categorydimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_categorydimensions
    ADD CONSTRAINT fk_evisualization_categorydimensions_categorydimensionid FOREIGN KEY (categorydimensionid) REFERENCES public.categorydimension(categorydimensionid);


--
-- Name: eventvisualization_categorydimensions fk_evisualization_categorydimensions_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_categorydimensions
    ADD CONSTRAINT fk_evisualization_categorydimensions_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization_categoryoptiongroupsetdimensions fk_evisualization_catoptiongroupsetdimensions_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_evisualization_catoptiongroupsetdimensions_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization_columns fk_evisualization_columns_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_columns
    ADD CONSTRAINT fk_evisualization_columns_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization_dataelementdimensions fk_evisualization_dataelementdimensions_dataelementdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_dataelementdimensions
    ADD CONSTRAINT fk_evisualization_dataelementdimensions_dataelementdimensionid FOREIGN KEY (trackedentitydataelementdimensionid) REFERENCES public.trackedentitydataelementdimension(trackedentitydataelementdimensionid);


--
-- Name: eventvisualization_dataelementdimensions fk_evisualization_dataelementdimensions_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_dataelementdimensions
    ADD CONSTRAINT fk_evisualization_dataelementdimensions_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization fk_evisualization_dataelementvaluedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_dataelementvaluedimensionid FOREIGN KEY (dataelementvaluedimensionid) REFERENCES public.dataelement(dataelementid);


--
-- Name: eventvisualization_categoryoptiongroupsetdimensions fk_evisualization_dimensions_catoptiongroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_evisualization_dimensions_catoptiongroupsetdimensionid FOREIGN KEY (categoryoptiongroupsetdimensionid) REFERENCES public.categoryoptiongroupsetdimension(categoryoptiongroupsetdimensionid);


--
-- Name: eventvisualization_orgunitgroupsetdimensions fk_evisualization_dimensions_ogunitgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_evisualization_dimensions_ogunitgroupsetdimensionid FOREIGN KEY (orgunitgroupsetdimensionid) REFERENCES public.orgunitgroupsetdimension(orgunitgroupsetdimensionid);


--
-- Name: eventvisualization_filters fk_evisualization_filters_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_filters
    ADD CONSTRAINT fk_evisualization_filters_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization_itemorgunitgroups fk_evisualization_itemorgunitgroups_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_itemorgunitgroups
    ADD CONSTRAINT fk_evisualization_itemorgunitgroups_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: eventvisualization_itemorgunitgroups fk_evisualization_itemorgunitunitgroups_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_itemorgunitgroups
    ADD CONSTRAINT fk_evisualization_itemorgunitunitgroups_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization fk_evisualization_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: eventvisualization fk_evisualization_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: eventvisualization_organisationunits fk_evisualization_organisationunits_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_organisationunits
    ADD CONSTRAINT fk_evisualization_organisationunits_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization_organisationunits fk_evisualization_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_organisationunits
    ADD CONSTRAINT fk_evisualization_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: eventvisualization_orgunitgroupsetdimensions fk_evisualization_orgunitgroupsetdimensions_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_evisualization_orgunitgroupsetdimensions_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization_orgunitlevels fk_evisualization_orgunitlevels_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_orgunitlevels
    ADD CONSTRAINT fk_evisualization_orgunitlevels_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization_periods fk_evisualization_periods_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_periods
    ADD CONSTRAINT fk_evisualization_periods_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization_periods fk_evisualization_periods_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_periods
    ADD CONSTRAINT fk_evisualization_periods_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: eventvisualization_programindicatordimensions fk_evisualization_prindicatordimensions_prindicatordimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_programindicatordimensions
    ADD CONSTRAINT fk_evisualization_prindicatordimensions_prindicatordimensionid FOREIGN KEY (trackedentityprogramindicatordimensionid) REFERENCES public.trackedentityprogramindicatordimension(trackedentityprogramindicatordimensionid);


--
-- Name: eventvisualization fk_evisualization_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: eventvisualization_programindicatordimensions fk_evisualization_programindicatordim_programindicatordimid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_programindicatordimensions
    ADD CONSTRAINT fk_evisualization_programindicatordim_programindicatordimid FOREIGN KEY (trackedentityprogramindicatordimensionid) REFERENCES public.trackedentityprogramindicatordimension(trackedentityprogramindicatordimensionid);


--
-- Name: eventvisualization_programindicatordimensions fk_evisualization_programindicatordimensions_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_programindicatordimensions
    ADD CONSTRAINT fk_evisualization_programindicatordimensions_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization fk_evisualization_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: eventvisualization fk_evisualization_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: eventvisualization fk_evisualization_report_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_report_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: eventvisualization_rows fk_evisualization_rows_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization_rows
    ADD CONSTRAINT fk_evisualization_rows_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: eventvisualization fk_evisualization_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: eventvisualization fk_evisualization_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventvisualization
    ADD CONSTRAINT fk_evisualization_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: expressiondimensionitem fk_expressiondimensionitem_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expressiondimensionitem
    ADD CONSTRAINT fk_expressiondimensionitem_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: externalmaplayer fk_externalmaplayer_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT fk_externalmaplayer_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: externalmaplayer fk_externalmaplayer_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT fk_externalmaplayer_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: externalfileresource fk_fileresource_externalfileresource; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT fk_fileresource_externalfileresource FOREIGN KEY (fileresourceid) REFERENCES public.fileresource(fileresourceid);


--
-- Name: fileresource fk_fileresource_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT fk_fileresource_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: metadataproposal fk_finalisedby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataproposal
    ADD CONSTRAINT fk_finalisedby_userid FOREIGN KEY (finalisedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: users_catdimensionconstraints fk_fk_users_catconstraints_dataelementcategoryid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_catdimensionconstraints
    ADD CONSTRAINT fk_fk_users_catconstraints_dataelementcategoryid FOREIGN KEY (dataelementcategoryid) REFERENCES public.category(categoryid);


--
-- Name: users_cogsdimensionconstraints fk_fk_users_cogsconstraints_categoryoptiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_cogsdimensionconstraints
    ADD CONSTRAINT fk_fk_users_cogsconstraints_categoryoptiongroupsetid FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: icon fk_icon_fileresource; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icon
    ADD CONSTRAINT fk_icon_fileresource FOREIGN KEY (fileresourceid) REFERENCES public.fileresource(fileresourceid) ON DELETE CASCADE;


--
-- Name: incomingsms fk_incomingsms_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incomingsms
    ADD CONSTRAINT fk_incomingsms_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: indicator fk_indicator_indicatortypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT fk_indicator_indicatortypeid FOREIGN KEY (indicatortypeid) REFERENCES public.indicatortype(indicatortypeid);


--
-- Name: indicatorlegendsets fk_indicator_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorlegendsets
    ADD CONSTRAINT fk_indicator_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: indicator fk_indicator_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT fk_indicator_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: indicatorgroupmembers fk_indicatorgroup_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupmembers
    ADD CONSTRAINT fk_indicatorgroup_indicatorid FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: indicatorgroup fk_indicatorgroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT fk_indicatorgroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: indicatorgroupmembers fk_indicatorgroupmembers_indicatorgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupmembers
    ADD CONSTRAINT fk_indicatorgroupmembers_indicatorgroupid FOREIGN KEY (indicatorgroupid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: indicatorgroupsetmembers fk_indicatorgroupset_indicatorgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetmembers
    ADD CONSTRAINT fk_indicatorgroupset_indicatorgroupid FOREIGN KEY (indicatorgroupid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: indicatorgroupset fk_indicatorgroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT fk_indicatorgroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: indicatorgroupsetmembers fk_indicatorgroupsetmembers_indicatorgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetmembers
    ADD CONSTRAINT fk_indicatorgroupsetmembers_indicatorgroupsetid FOREIGN KEY (indicatorgroupsetid) REFERENCES public.indicatorgroupset(indicatorgroupsetid);


--
-- Name: intepretation_likedby fk_intepretation_likedby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.intepretation_likedby
    ADD CONSTRAINT fk_intepretation_likedby_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: interpretation_comments fk_interpretation_comments_interpretationcommentid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation_comments
    ADD CONSTRAINT fk_interpretation_comments_interpretationcommentid FOREIGN KEY (interpretationcommentid) REFERENCES public.interpretationcomment(interpretationcommentid);


--
-- Name: interpretation_comments fk_interpretation_comments_interpretationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation_comments
    ADD CONSTRAINT fk_interpretation_comments_interpretationid FOREIGN KEY (interpretationid) REFERENCES public.interpretation(interpretationid);


--
-- Name: interpretation fk_interpretation_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: interpretation fk_interpretation_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_eventchartid FOREIGN KEY (eventreportid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: interpretation fk_interpretation_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_eventreportid FOREIGN KEY (eventchartid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: interpretation fk_interpretation_evisualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_evisualizationid FOREIGN KEY (eventvisualizationid) REFERENCES public.eventvisualization(eventvisualizationid);


--
-- Name: intepretation_likedby fk_interpretation_likedby_interpretationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.intepretation_likedby
    ADD CONSTRAINT fk_interpretation_likedby_interpretationid FOREIGN KEY (interpretationid) REFERENCES public.interpretation(interpretationid);


--
-- Name: interpretation fk_interpretation_mapid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_mapid FOREIGN KEY (mapid) REFERENCES public.map(mapid);


--
-- Name: interpretation fk_interpretation_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: interpretation fk_interpretation_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: interpretation fk_interpretation_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: interpretation fk_interpretation_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: interpretationcomment fk_interpretationcomment_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationcomment
    ADD CONSTRAINT fk_interpretationcomment_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: keyjsonvalue fk_keyjsonvalue_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT fk_keyjsonvalue_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: attribute fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: category fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: categorycombo fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: categoryoption fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: categoryoptioncombo fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombo
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: categoryoptiongroup fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: categoryoptiongroupset fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: constant fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dashboard fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dashboarditem fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataapprovallevel fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataapprovalworkflow fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataelement fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataelementgroup fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataelementgroupset fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataentryform fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: dataset fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: datasetnotificationtemplate fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: datastatistics fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatistics
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: document fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: expressiondimensionitem fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expressiondimensionitem
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: externalfileresource fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: externalmaplayer fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fileresource fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: i18nlocale fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: indicator fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: indicatorgroup fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: indicatorgroupset fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: indicatortype fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: jobconfiguration fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: keyjsonvalue fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: map fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: maplegend fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: maplegendset fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: mapview fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: metadataversion fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: note fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: oauth2client fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: optiongroup fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: optiongroupset fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: optionset fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: organisationunit fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: orgunitgroup fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: orgunitgroupset fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: orgunitlevel fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: periodboundary fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodboundary
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: predictor fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: predictorgroup fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictorgroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: program fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: program_attributes fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programindicator fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programindicatorgroup fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programmessage fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programnotificationinstance fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationinstance
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programnotificationtemplate fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programrule fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programruleaction fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programrulevariable fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programsection fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programstage fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programstagedataelement fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: programstagesection fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: pushanalysis fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: relationship fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: relationshiptype fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: report fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: section fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: sqlview fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: tablehook fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentity fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentity
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentityattribute fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentityfilter fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityfilter
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentitytype fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentitytypeattribute fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: usergroup fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: userkeyjsonvalue fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: userrole fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: validationnotificationtemplate fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: validationrule fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: validationrulegroup fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: eventfilter fk_lastupdatedby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventfilter
    ADD CONSTRAINT fk_lastupdatedby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: maplegendset fk_legendset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT fk_legendset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: lockexception fk_lockexception_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lockexception
    ADD CONSTRAINT fk_lockexception_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: lockexception fk_lockexception_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lockexception
    ADD CONSTRAINT fk_lockexception_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: lockexception fk_lockexception_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lockexception
    ADD CONSTRAINT fk_lockexception_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: maplegend fk_maplegend_maplegendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT fk_maplegend_maplegendsetid FOREIGN KEY (maplegendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: mapmapviews fk_mapmapview_mapid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapmapviews
    ADD CONSTRAINT fk_mapmapview_mapid FOREIGN KEY (mapid) REFERENCES public.map(mapid);


--
-- Name: mapmapviews fk_mapmapview_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapmapviews
    ADD CONSTRAINT fk_mapmapview_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_attributedimensions fk_mapview_attributedimensions_attributedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_attributedimensions
    ADD CONSTRAINT fk_mapview_attributedimensions_attributedimensionid FOREIGN KEY (trackedentityattributedimensionid) REFERENCES public.trackedentityattributedimension(trackedentityattributedimensionid);


--
-- Name: mapview_attributedimensions fk_mapview_attributedimensions_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_attributedimensions
    ADD CONSTRAINT fk_mapview_attributedimensions_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_categorydimensions fk_mapview_categorydimensions_categorydimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_categorydimensions
    ADD CONSTRAINT fk_mapview_categorydimensions_categorydimensionid FOREIGN KEY (categorydimensionid) REFERENCES public.categorydimension(categorydimensionid);


--
-- Name: mapview_categorydimensions fk_mapview_categorydimensions_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_categorydimensions
    ADD CONSTRAINT fk_mapview_categorydimensions_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_categoryoptiongroupsetdimensions fk_mapview_catoptiongroupsetdimensions_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_mapview_catoptiongroupsetdimensions_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_columns fk_mapview_columns_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_columns
    ADD CONSTRAINT fk_mapview_columns_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_datadimensionitems fk_mapview_datadimensionitems_datadimensionitemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_datadimensionitems
    ADD CONSTRAINT fk_mapview_datadimensionitems_datadimensionitemid FOREIGN KEY (datadimensionitemid) REFERENCES public.datadimensionitem(datadimensionitemid);


--
-- Name: mapview_datadimensionitems fk_mapview_datadimensionitems_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_datadimensionitems
    ADD CONSTRAINT fk_mapview_datadimensionitems_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_dataelementdimensions fk_mapview_dataelementdimensions_dataelementdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_dataelementdimensions
    ADD CONSTRAINT fk_mapview_dataelementdimensions_dataelementdimensionid FOREIGN KEY (trackedentitydataelementdimensionid) REFERENCES public.trackedentitydataelementdimension(trackedentitydataelementdimensionid);


--
-- Name: mapview_dataelementdimensions fk_mapview_dataelementdimensions_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_dataelementdimensions
    ADD CONSTRAINT fk_mapview_dataelementdimensions_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_categoryoptiongroupsetdimensions fk_mapview_dimensions_catoptiongroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_mapview_dimensions_catoptiongroupsetdimensionid FOREIGN KEY (categoryoptiongroupsetdimensionid) REFERENCES public.categoryoptiongroupsetdimension(categoryoptiongroupsetdimensionid);


--
-- Name: mapview_orgunitgroupsetdimensions fk_mapview_dimensions_orgunitgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_mapview_dimensions_orgunitgroupsetdimensionid FOREIGN KEY (orgunitgroupsetdimensionid) REFERENCES public.orgunitgroupsetdimension(orgunitgroupsetdimensionid);


--
-- Name: mapview_filters fk_mapview_filters_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_filters
    ADD CONSTRAINT fk_mapview_filters_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_itemorgunitgroups fk_mapview_itemorgunitgroups_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_itemorgunitgroups
    ADD CONSTRAINT fk_mapview_itemorgunitgroups_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: mapview_itemorgunitgroups fk_mapview_itemorgunitunitgroups_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_itemorgunitgroups
    ADD CONSTRAINT fk_mapview_itemorgunitunitgroups_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview fk_mapview_maplegendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_maplegendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: mapview_organisationunits fk_mapview_organisationunits_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_organisationunits
    ADD CONSTRAINT fk_mapview_organisationunits_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_organisationunits fk_mapview_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_organisationunits
    ADD CONSTRAINT fk_mapview_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: mapview_orgunitgroupsetdimensions fk_mapview_orgunitgroupsetdimensions_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_mapview_orgunitgroupsetdimensions_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview fk_mapview_orgunitgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_orgunitgroupsetid FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: mapview_orgunitlevels fk_mapview_orgunitlevels_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_orgunitlevels
    ADD CONSTRAINT fk_mapview_orgunitlevels_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_periods fk_mapview_periods_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_periods
    ADD CONSTRAINT fk_mapview_periods_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: mapview_periods fk_mapview_periods_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_periods
    ADD CONSTRAINT fk_mapview_periods_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: mapview fk_mapview_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: mapview fk_mapview_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: mapview fk_mapview_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: mapview fk_mapview_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: map fk_mapview_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT fk_mapview_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: message fk_message_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT fk_message_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: messageattachments fk_messageattachments_fileresourceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageattachments
    ADD CONSTRAINT fk_messageattachments_fileresourceid FOREIGN KEY (fileresourceid) REFERENCES public.fileresource(fileresourceid);


--
-- Name: messageconversation fk_messageconversation_lastsender_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation
    ADD CONSTRAINT fk_messageconversation_lastsender_userid FOREIGN KEY (lastsenderid) REFERENCES public.userinfo(userinfoid);


--
-- Name: messageconversation_messages fk_messageconversation_messages_messageconversationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_messages
    ADD CONSTRAINT fk_messageconversation_messages_messageconversationid FOREIGN KEY (messageconversationid) REFERENCES public.messageconversation(messageconversationid);


--
-- Name: messageconversation_messages fk_messageconversation_messages_messageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_messages
    ADD CONSTRAINT fk_messageconversation_messages_messageid FOREIGN KEY (messageid) REFERENCES public.message(messageid);


--
-- Name: messageconversation fk_messageconversation_user_user_assigned; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation
    ADD CONSTRAINT fk_messageconversation_user_user_assigned FOREIGN KEY (user_assigned) REFERENCES public.userinfo(userinfoid);


--
-- Name: messageconversation fk_messageconversation_user_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation
    ADD CONSTRAINT fk_messageconversation_user_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: messageconversation_usermessages fk_messageconversation_usermessages_messageconversationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_usermessages
    ADD CONSTRAINT fk_messageconversation_usermessages_messageconversationid FOREIGN KEY (messageconversationid) REFERENCES public.messageconversation(messageconversationid);


--
-- Name: messageconversation_usermessages fk_messageconversation_usermessages_usermessageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_usermessages
    ADD CONSTRAINT fk_messageconversation_usermessages_usermessageid FOREIGN KEY (usermessageid) REFERENCES public.usermessage(usermessageid);


--
-- Name: minmaxdataelement fk_minmaxdataelement_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minmaxdataelement
    ADD CONSTRAINT fk_minmaxdataelement_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: minmaxdataelement fk_minmaxdataelement_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minmaxdataelement
    ADD CONSTRAINT fk_minmaxdataelement_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: minmaxdataelement fk_minmaxdataelement_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minmaxdataelement
    ADD CONSTRAINT fk_minmaxdataelement_organisationunitid FOREIGN KEY (sourceid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: oauth2clientgranttypes fk_oauth2clientgranttypes_oauth2clientid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2clientgranttypes
    ADD CONSTRAINT fk_oauth2clientgranttypes_oauth2clientid FOREIGN KEY (oauth2clientid) REFERENCES public.oauth2client(oauth2clientid);


--
-- Name: oauth2clientredirecturis fk_oauth2clientredirecturis_oauth2clientid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2clientredirecturis
    ADD CONSTRAINT fk_oauth2clientredirecturis_oauth2clientid FOREIGN KEY (oauth2clientid) REFERENCES public.oauth2client(oauth2clientid);


--
-- Name: optiongroup fk_optiongroup_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT fk_optiongroup_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: optiongroup fk_optiongroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT fk_optiongroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: optiongroupmembers fk_optiongroupmembers_optiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupmembers
    ADD CONSTRAINT fk_optiongroupmembers_optiongroupid FOREIGN KEY (optionid) REFERENCES public.optionvalue(optionvalueid);


--
-- Name: optiongroupmembers fk_optiongroupmembers_optionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupmembers
    ADD CONSTRAINT fk_optiongroupmembers_optionid FOREIGN KEY (optiongroupid) REFERENCES public.optiongroup(optiongroupid);


--
-- Name: optiongroupset fk_optiongroupset_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT fk_optiongroupset_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: optiongroupset fk_optiongroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT fk_optiongroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: optiongroupsetmembers fk_optiongroupsetmembers_optiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetmembers
    ADD CONSTRAINT fk_optiongroupsetmembers_optiongroupid FOREIGN KEY (optiongroupid) REFERENCES public.optiongroup(optiongroupid);


--
-- Name: optiongroupsetmembers fk_optiongroupsetmembers_optiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetmembers
    ADD CONSTRAINT fk_optiongroupsetmembers_optiongroupsetid FOREIGN KEY (optiongroupsetid) REFERENCES public.optiongroupset(optiongroupsetid);


--
-- Name: optionset fk_optionset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT fk_optionset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: optionvalue fk_optionsetmembers_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvalue
    ADD CONSTRAINT fk_optionsetmembers_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: organisationunit fk_organisationunit_fileresourceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT fk_organisationunit_fileresourceid FOREIGN KEY (image) REFERENCES public.fileresource(fileresourceid);


--
-- Name: organisationunit fk_organisationunit_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT fk_organisationunit_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: validationruleorganisationunitlevels fk_organisationunitlevel_validationtuleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleorganisationunitlevels
    ADD CONSTRAINT fk_organisationunitlevel_validationtuleid FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: orgunitgroupmembers fk_orgunitgroup_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupmembers
    ADD CONSTRAINT fk_orgunitgroup_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: orgunitgroup fk_orgunitgroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT fk_orgunitgroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: orgunitgroupmembers fk_orgunitgroupmembers_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupmembers
    ADD CONSTRAINT fk_orgunitgroupmembers_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: orgunitgroupsetmembers fk_orgunitgroupset_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetmembers
    ADD CONSTRAINT fk_orgunitgroupset_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: orgunitgroupset fk_orgunitgroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT fk_orgunitgroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: orgunitgroupsetmembers fk_orgunitgroupsetmembers_orgunitgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetmembers
    ADD CONSTRAINT fk_orgunitgroupsetmembers_orgunitgroupsetid FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: organisationunit fk_parentid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT fk_parentid FOREIGN KEY (parentid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: period fk_period_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period
    ADD CONSTRAINT fk_period_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: periodboundary fk_periodboundary_periodtype; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodboundary
    ADD CONSTRAINT fk_periodboundary_periodtype FOREIGN KEY (offsetperiodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: periodboundary fk_periodboundary_programindicator; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodboundary
    ADD CONSTRAINT fk_periodboundary_programindicator FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: predictor fk_predictor_generatorexpressionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_predictor_generatorexpressionid FOREIGN KEY (generatorexpressionid) REFERENCES public.expression(expressionid);


--
-- Name: predictor fk_predictor_outputcomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_predictor_outputcomboid FOREIGN KEY (generatoroutputcombo) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: predictor fk_predictor_outputdataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_predictor_outputdataelementid FOREIGN KEY (generatoroutput) REFERENCES public.dataelement(dataelementid);


--
-- Name: predictorgroupmembers fk_predictorgroup_predictorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictorgroupmembers
    ADD CONSTRAINT fk_predictorgroup_predictorid FOREIGN KEY (predictorid) REFERENCES public.predictor(predictorid);


--
-- Name: predictorgroup fk_predictorgroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictorgroup
    ADD CONSTRAINT fk_predictorgroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: predictorgroupmembers fk_predictorgroupmembers_predictorgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictorgroupmembers
    ADD CONSTRAINT fk_predictorgroupmembers_predictorgroupid FOREIGN KEY (predictorgroupid) REFERENCES public.predictorgroup(predictorgroupid);


--
-- Name: predictororgunitlevels fk_predictororgunitlevels_orgunitlevelid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictororgunitlevels
    ADD CONSTRAINT fk_predictororgunitlevels_orgunitlevelid FOREIGN KEY (orgunitlevelid) REFERENCES public.orgunitlevel(orgunitlevelid);


--
-- Name: predictororgunitlevels fk_predictororgunitlevels_predictorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictororgunitlevels
    ADD CONSTRAINT fk_predictororgunitlevels_predictorid FOREIGN KEY (predictorid) REFERENCES public.predictor(predictorid);


--
-- Name: program_attributes fk_program_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT fk_program_attributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: program fk_program_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: program fk_program_dataentryformid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_dataentryformid FOREIGN KEY (dataentryformid) REFERENCES public.dataentryform(dataentryformid);


--
-- Name: program fk_program_expiryperiodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_expiryperiodtypeid FOREIGN KEY (expiryperiodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: program_organisationunits fk_program_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_organisationunits
    ADD CONSTRAINT fk_program_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: program_organisationunits fk_program_organisationunits_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_organisationunits
    ADD CONSTRAINT fk_program_organisationunits_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: programsection fk_program_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT fk_program_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: programstagesection fk_program_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT fk_program_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: program fk_program_relatedprogram; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_relatedprogram FOREIGN KEY (relatedprogramid) REFERENCES public.program(programid);


--
-- Name: program fk_program_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: program fk_program_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: programindicatorlegendsets fk_programindicator_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorlegendsets
    ADD CONSTRAINT fk_programindicator_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: programindicator fk_programindicator_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT fk_programindicator_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: programindicator fk_programindicator_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT fk_programindicator_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: programindicatorgroupmembers fk_programindicatorgroup_programindicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupmembers
    ADD CONSTRAINT fk_programindicatorgroup_programindicatorid FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: programindicatorgroup fk_programindicatorgroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT fk_programindicatorgroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: programindicatorgroupmembers fk_programindicatorgroupmembers_programindicatorgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupmembers
    ADD CONSTRAINT fk_programindicatorgroupmembers_programindicatorgroupid FOREIGN KEY (programindicatorgroupid) REFERENCES public.programindicatorgroup(programindicatorgroupid);


--
-- Name: enrollment fk_programinstance_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT fk_programinstance_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: enrollment fk_programinstance_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT fk_programinstance_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: enrollment fk_programinstance_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT fk_programinstance_trackedentityinstanceid FOREIGN KEY (trackedentityid) REFERENCES public.trackedentity(trackedentityid);


--
-- Name: enrollment_notes fk_programinstancecomments_programinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment_notes
    ADD CONSTRAINT fk_programinstancecomments_programinstanceid FOREIGN KEY (enrollmentid) REFERENCES public.enrollment(enrollmentid);


--
-- Name: enrollment_notes fk_programinstancecomments_trackedentitycommentid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment_notes
    ADD CONSTRAINT fk_programinstancecomments_trackedentitycommentid FOREIGN KEY (noteid) REFERENCES public.note(noteid);


--
-- Name: programmessage fk_programmessage_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_programmessage_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: programmessage fk_programmessage_programinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_programmessage_programinstanceid FOREIGN KEY (enrollmentid) REFERENCES public.enrollment(enrollmentid);


--
-- Name: programmessage fk_programmessage_programstageinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_programmessage_programstageinstanceid FOREIGN KEY (eventid) REFERENCES public.event(eventid);


--
-- Name: programmessage fk_programmessage_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_programmessage_trackedentityinstanceid FOREIGN KEY (trackedentityid) REFERENCES public.trackedentity(trackedentityid);


--
-- Name: programownershiphistory fk_programownershiphistory_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programownershiphistory
    ADD CONSTRAINT fk_programownershiphistory_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: programownershiphistory fk_programownershiphistory_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programownershiphistory
    ADD CONSTRAINT fk_programownershiphistory_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: programownershiphistory fk_programownershiphistory_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programownershiphistory
    ADD CONSTRAINT fk_programownershiphistory_trackedentityinstanceid FOREIGN KEY (trackedentityid) REFERENCES public.trackedentity(trackedentityid);


--
-- Name: programrule fk_programrule_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT fk_programrule_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: programrule fk_programrule_programstage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT fk_programrule_programstage FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: programruleaction fk_programruleaction_dataelement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_dataelement FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: programruleaction fk_programruleaction_option; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_option FOREIGN KEY (optionid) REFERENCES public.optionvalue(optionvalueid);


--
-- Name: programruleaction fk_programruleaction_optiongroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_optiongroup FOREIGN KEY (optiongroupid) REFERENCES public.optiongroup(optiongroupid);


--
-- Name: programruleaction fk_programruleaction_programindicator; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_programindicator FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: programruleaction fk_programruleaction_programrule; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_programrule FOREIGN KEY (programruleid) REFERENCES public.programrule(programruleid);


--
-- Name: programruleaction fk_programruleaction_programstage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_programstage FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: programruleaction fk_programruleaction_programstagesection; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_programstagesection FOREIGN KEY (programstagesectionid) REFERENCES public.programstagesection(programstagesectionid);


--
-- Name: programruleaction fk_programruleaction_trackedentityattribute; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_trackedentityattribute FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: programrulevariable fk_programrulevariable_dataelement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_programrulevariable_dataelement FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: programrulevariable fk_programrulevariable_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_programrulevariable_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: programrulevariable fk_programrulevariable_programstage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_programrulevariable_programstage FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: programrulevariable fk_programrulevariable_trackedentityattribute; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_programrulevariable_trackedentityattribute FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: programsection_attributes fk_programsection_attributes_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection_attributes
    ADD CONSTRAINT fk_programsection_attributes_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: programsection_attributes fk_programsections_attributes_programsectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection_attributes
    ADD CONSTRAINT fk_programsections_attributes_programsectionid FOREIGN KEY (programsectionid) REFERENCES public.programsection(programsectionid);


--
-- Name: programstage fk_programstage_dataentryform; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_programstage_dataentryform FOREIGN KEY (dataentryformid) REFERENCES public.dataentryform(dataentryformid);


--
-- Name: programstage fk_programstage_nextscheduledateid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_programstage_nextscheduledateid FOREIGN KEY (nextscheduledateid) REFERENCES public.dataelement(dataelementid);


--
-- Name: programstage fk_programstage_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_programstage_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: programstage fk_programstage_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_programstage_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: programstage fk_programstage_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_programstage_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: programstagedataelement fk_programstagedataelement_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT fk_programstagedataelement_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: programstagedataelement fk_programstagedataelement_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT fk_programstagedataelement_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: event fk_programstageinstance_assigneduserid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT fk_programstageinstance_assigneduserid FOREIGN KEY (assigneduserid) REFERENCES public.userinfo(userinfoid);


--
-- Name: event fk_programstageinstance_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT fk_programstageinstance_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: event fk_programstageinstance_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT fk_programstageinstance_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: event fk_programstageinstance_programinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT fk_programstageinstance_programinstanceid FOREIGN KEY (enrollmentid) REFERENCES public.enrollment(enrollmentid);


--
-- Name: event fk_programstageinstance_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT fk_programstageinstance_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: event_notes fk_programstageinstancecomments_programstageinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_notes
    ADD CONSTRAINT fk_programstageinstancecomments_programstageinstanceid FOREIGN KEY (eventid) REFERENCES public.event(eventid);


--
-- Name: event_notes fk_programstageinstancecomments_trackedentitycommentid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_notes
    ADD CONSTRAINT fk_programstageinstancecomments_trackedentitycommentid FOREIGN KEY (noteid) REFERENCES public.note(noteid);


--
-- Name: eventfilter fk_programstageinstancefilter_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventfilter
    ADD CONSTRAINT fk_programstageinstancefilter_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: programnotificationtemplate fk_programstagenotification_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk_programstagenotification_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: programnotificationinstance fk_programstagenotification_pi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationinstance
    ADD CONSTRAINT fk_programstagenotification_pi FOREIGN KEY (enrollmentid) REFERENCES public.enrollment(enrollmentid);


--
-- Name: programnotificationinstance fk_programstagenotification_psi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationinstance
    ADD CONSTRAINT fk_programstagenotification_psi FOREIGN KEY (eventid) REFERENCES public.event(eventid);


--
-- Name: programnotificationtemplate fk_programstagenotification_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk_programstagenotification_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: programnotificationtemplate fk_programstagenotification_usergroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk_programstagenotification_usergroup FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: programstagesection_dataelements fk_programstagesection_dataelements_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_dataelements
    ADD CONSTRAINT fk_programstagesection_dataelements_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: programstagesection_dataelements fk_programstagesection_dataelements_programstagesectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_dataelements
    ADD CONSTRAINT fk_programstagesection_dataelements_programstagesectionid FOREIGN KEY (programstagesectionid) REFERENCES public.programstagesection(programstagesectionid);


--
-- Name: programstagesection_programindicators fk_programstagesection_programindicators_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_programindicators
    ADD CONSTRAINT fk_programstagesection_programindicators_indicatorid FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: programstagesection_programindicators fk_programstagesection_programindicators_sectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_programindicators
    ADD CONSTRAINT fk_programstagesection_programindicators_sectionid FOREIGN KEY (programstagesectionid) REFERENCES public.programstagesection(programstagesectionid);


--
-- Name: programstageworkinglist fk_programstageworkinglist_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageworkinglist
    ADD CONSTRAINT fk_programstageworkinglist_programid FOREIGN KEY (programid) REFERENCES public.program(programid) ON DELETE CASCADE;


--
-- Name: programstageworkinglist fk_programstageworkinglist_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageworkinglist
    ADD CONSTRAINT fk_programstageworkinglist_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid) ON DELETE CASCADE;


--
-- Name: programtempowner fk_programtempowner_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtempowner
    ADD CONSTRAINT fk_programtempowner_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: programtempowner fk_programtempowner_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtempowner
    ADD CONSTRAINT fk_programtempowner_trackedentityinstanceid FOREIGN KEY (trackedentityid) REFERENCES public.trackedentity(trackedentityid);


--
-- Name: programtempowner fk_programtempowner_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtempowner
    ADD CONSTRAINT fk_programtempowner_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: programtempownershipaudit fk_programtempownershipaudit_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtempownershipaudit
    ADD CONSTRAINT fk_programtempownershipaudit_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: programtempownershipaudit fk_programtempownershipaudit_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtempownershipaudit
    ADD CONSTRAINT fk_programtempownershipaudit_trackedentityinstanceid FOREIGN KEY (trackedentityid) REFERENCES public.trackedentity(trackedentityid);


--
-- Name: program_attributes fk_programtrackedentityattribute_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT fk_programtrackedentityattribute_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: pushanalysisrecipientusergroups fk_pushanalysis_recipientusergroups; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysisrecipientusergroups
    ADD CONSTRAINT fk_pushanalysis_recipientusergroups FOREIGN KEY (elt) REFERENCES public.usergroup(usergroupid);


--
-- Name: relationship fk_relationship_from_relationshipitemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT fk_relationship_from_relationshipitemid FOREIGN KEY (from_relationshipitemid) REFERENCES public.relationshipitem(relationshipitemid) ON DELETE CASCADE;


--
-- Name: relationship fk_relationship_relationshiptypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT fk_relationship_relationshiptypeid FOREIGN KEY (relationshiptypeid) REFERENCES public.relationshiptype(relationshiptypeid);


--
-- Name: relationship fk_relationship_to_relationshipitemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT fk_relationship_to_relationshipitemid FOREIGN KEY (to_relationshipitemid) REFERENCES public.relationshipitem(relationshipitemid) ON DELETE CASCADE;


--
-- Name: relationshipconstraint fk_relationshipconstraint_program_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshipconstraint
    ADD CONSTRAINT fk_relationshipconstraint_program_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: relationshipconstraint fk_relationshipconstraint_programstage_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshipconstraint
    ADD CONSTRAINT fk_relationshipconstraint_programstage_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: relationshipconstraint fk_relationshipconstraint_trackedentitytype_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshipconstraint
    ADD CONSTRAINT fk_relationshipconstraint_trackedentitytype_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: relationshipitem fk_relationshipitem_programinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshipitem
    ADD CONSTRAINT fk_relationshipitem_programinstanceid FOREIGN KEY (enrollmentid) REFERENCES public.enrollment(enrollmentid);


--
-- Name: relationshipitem fk_relationshipitem_programstageinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshipitem
    ADD CONSTRAINT fk_relationshipitem_programstageinstanceid FOREIGN KEY (eventid) REFERENCES public.event(eventid);


--
-- Name: relationshipitem fk_relationshipitem_relationshipid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshipitem
    ADD CONSTRAINT fk_relationshipitem_relationshipid FOREIGN KEY (relationshipid) REFERENCES public.relationship(relationshipid) ON DELETE CASCADE;


--
-- Name: relationshipitem fk_relationshipitem_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshipitem
    ADD CONSTRAINT fk_relationshipitem_trackedentityinstanceid FOREIGN KEY (trackedentityid) REFERENCES public.trackedentity(trackedentityid);


--
-- Name: relationshiptype fk_relationshiptype_from_relationshipconstraintid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT fk_relationshiptype_from_relationshipconstraintid FOREIGN KEY (from_relationshipconstraintid) REFERENCES public.relationshipconstraint(relationshipconstraintid);


--
-- Name: relationshiptype fk_relationshiptype_to_relationshipconstraintid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT fk_relationshiptype_to_relationshipconstraintid FOREIGN KEY (to_relationshipconstraintid) REFERENCES public.relationshipconstraint(relationshipconstraintid);


--
-- Name: relationshiptype fk_relationshiptype_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT fk_relationshiptype_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: report fk_report_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fk_report_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: report fk_report_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fk_report_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: report fk_report_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fk_report_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: route fk_route_lastupdateby_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT fk_route_lastupdateby_userinfoid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: route fk_route_userid_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT fk_route_userid_userinfoid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: sectiondataelements fk_section_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiondataelements
    ADD CONSTRAINT fk_section_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: sectiongreyedfields fk_section_dataelementoperandid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiongreyedfields
    ADD CONSTRAINT fk_section_dataelementoperandid FOREIGN KEY (dataelementoperandid) REFERENCES public.dataelementoperand(dataelementoperandid);


--
-- Name: section fk_section_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT fk_section_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: sectionindicators fk_section_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionindicators
    ADD CONSTRAINT fk_section_indicatorid FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: sectiondataelements fk_sectiondataelements_sectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiondataelements
    ADD CONSTRAINT fk_sectiondataelements_sectionid FOREIGN KEY (sectionid) REFERENCES public.section(sectionid);


--
-- Name: sectiongreyedfields fk_sectiongreyedfields_sectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiongreyedfields
    ADD CONSTRAINT fk_sectiongreyedfields_sectionid FOREIGN KEY (sectionid) REFERENCES public.section(sectionid);


--
-- Name: sectionindicators fk_sectionindicators_sectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionindicators
    ADD CONSTRAINT fk_sectionindicators_sectionid FOREIGN KEY (sectionid) REFERENCES public.section(sectionid);


--
-- Name: smscommands fk_smscommand_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT fk_smscommand_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: smscommands fk_smscommand_programstage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT fk_smscommand_programstage FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: smscommands fk_smscommand_usergroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT fk_smscommand_usergroup FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: sqlview fk_sqlview_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT fk_sqlview_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentityattributedimension fk_teattributedimension_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributedimension
    ADD CONSTRAINT fk_teattributedimension_attributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: trackedentityattributedimension fk_teattributedimension_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributedimension
    ADD CONSTRAINT fk_teattributedimension_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: trackedentitydataelementdimension fk_tedataelementdimension_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydataelementdimension
    ADD CONSTRAINT fk_tedataelementdimension_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: trackedentitydataelementdimension fk_tedataelementdimension_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydataelementdimension
    ADD CONSTRAINT fk_tedataelementdimension_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: trackedentitydataelementdimension fk_tedataelementdimension_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydataelementdimension
    ADD CONSTRAINT fk_tedataelementdimension_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: trackedentityprogramindicatordimension fk_teprogramindicatordimension_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramindicatordimension
    ADD CONSTRAINT fk_teprogramindicatordimension_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: trackedentityprogramindicatordimension fk_teprogramindicatordimension_programindicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramindicatordimension
    ADD CONSTRAINT fk_teprogramindicatordimension_programindicatorid FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: trackedentityattributelegendsets fk_trackedentityattribute_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributelegendsets
    ADD CONSTRAINT fk_trackedentityattribute_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: trackedentityattribute fk_trackedentityattribute_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT fk_trackedentityattribute_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: smscodes fk_trackedentityattribute_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscodes
    ADD CONSTRAINT fk_trackedentityattribute_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: trackedentityattribute fk_trackedentityattribute_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT fk_trackedentityattribute_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentity fk_trackedentityinstance_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentity
    ADD CONSTRAINT fk_trackedentityinstance_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: trackedentity fk_trackedentityinstance_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentity
    ADD CONSTRAINT fk_trackedentityinstance_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: trackedentityfilter fk_trackedentityinstancefilter_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityfilter
    ADD CONSTRAINT fk_trackedentityinstancefilter_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: trackedentityfilter fk_trackedentityinstancefilter_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityfilter
    ADD CONSTRAINT fk_trackedentityinstancefilter_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentityprogramowner fk_trackedentityprogramowner_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramowner
    ADD CONSTRAINT fk_trackedentityprogramowner_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: trackedentityprogramowner fk_trackedentityprogramowner_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramowner
    ADD CONSTRAINT fk_trackedentityprogramowner_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: trackedentityprogramowner fk_trackedentityprogramowner_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramowner
    ADD CONSTRAINT fk_trackedentityprogramowner_trackedentityinstanceid FOREIGN KEY (trackedentityid) REFERENCES public.trackedentity(trackedentityid);


--
-- Name: trackedentitytype fk_trackedentitytype_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT fk_trackedentitytype_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: trackedentitytypeattribute fk_trackedentitytypeattribute_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT fk_trackedentitytypeattribute_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: trackedentitytypeattribute fk_trackedentitytypeattribute_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT fk_trackedentitytypeattribute_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: userinfo fk_user_fileresourceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userinfo
    ADD CONSTRAINT fk_user_fileresourceid FOREIGN KEY (avatar) REFERENCES public.fileresource(fileresourceid);


--
-- Name: userapps fk_userapps_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userapps
    ADD CONSTRAINT fk_userapps_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: userdatavieworgunits fk_userdatavieworgunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userdatavieworgunits
    ADD CONSTRAINT fk_userdatavieworgunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: userdatavieworgunits fk_userdatavieworgunits_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userdatavieworgunits
    ADD CONSTRAINT fk_userdatavieworgunits_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: usergroup fk_usergroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT fk_usergroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: usergroupmanaged fk_usergroupmanaging_managedbygroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmanaged
    ADD CONSTRAINT fk_usergroupmanaging_managedbygroupid FOREIGN KEY (managedbygroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: usergroupmanaged fk_usergroupmanaging_managedgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmanaged
    ADD CONSTRAINT fk_usergroupmanaging_managedgroupid FOREIGN KEY (managedgroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: usergroupmembers fk_usergroupmembers_usergroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmembers
    ADD CONSTRAINT fk_usergroupmembers_usergroupid FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: usergroupmembers fk_usergroupmembers_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmembers
    ADD CONSTRAINT fk_usergroupmembers_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: usermembership fk_userinfo_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermembership
    ADD CONSTRAINT fk_userinfo_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: userkeyjsonvalue fk_userkeyjsonvalue_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT fk_userkeyjsonvalue_user FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: usermembership fk_usermembership_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermembership
    ADD CONSTRAINT fk_usermembership_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: usermessage fk_usermessage_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermessage
    ADD CONSTRAINT fk_usermessage_user FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: userrole fk_userrole_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT fk_userrole_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: userroleauthorities fk_userroleauthorities_userroleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleauthorities
    ADD CONSTRAINT fk_userroleauthorities_userroleid FOREIGN KEY (userroleid) REFERENCES public.userrole(userroleid);


--
-- Name: userrolemembers fk_userrolemembers_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrolemembers
    ADD CONSTRAINT fk_userrolemembers_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: userrolemembers fk_userrolemembers_userroleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrolemembers
    ADD CONSTRAINT fk_userrolemembers_userroleid FOREIGN KEY (userroleid) REFERENCES public.userrole(userroleid);


--
-- Name: userrolerestrictions fk_userrolerestrictions_userroleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrolerestrictions
    ADD CONSTRAINT fk_userrolerestrictions_userroleid FOREIGN KEY (userroleid) REFERENCES public.userrole(userroleid);


--
-- Name: users_catdimensionconstraints fk_users_catconstraints_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_catdimensionconstraints
    ADD CONSTRAINT fk_users_catconstraints_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: users_cogsdimensionconstraints fk_users_cogsconstraints_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_cogsdimensionconstraints
    ADD CONSTRAINT fk_users_cogsconstraints_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: usersetting fk_usersetting_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usersetting
    ADD CONSTRAINT fk_usersetting_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: userteisearchorgunits fk_userteisearchorgunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userteisearchorgunits
    ADD CONSTRAINT fk_userteisearchorgunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: userteisearchorgunits fk_userteisearchorgunits_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userteisearchorgunits
    ADD CONSTRAINT fk_userteisearchorgunits_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: validationnotificationtemplate_recipientusergroups fk_validationnotificationtemplate_usergroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate_recipientusergroups
    ADD CONSTRAINT fk_validationnotificationtemplate_usergroup FOREIGN KEY (validationnotificationtemplateid) REFERENCES public.validationnotificationtemplate(validationnotificationtemplateid);


--
-- Name: validationresult fk_validationresult_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT fk_validationresult_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: validationresult fk_validationresult_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT fk_validationresult_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: validationresult fk_validationresult_period; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT fk_validationresult_period FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: validationresult fk_validationresult_validationruleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT fk_validationresult_validationruleid FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: validationrule fk_validationrule_leftexpressionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_validationrule_leftexpressionid FOREIGN KEY (leftexpressionid) REFERENCES public.expression(expressionid);


--
-- Name: predictor fk_validationrule_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_validationrule_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: validationrule fk_validationrule_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_validationrule_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: validationrule fk_validationrule_rightexpressionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_validationrule_rightexpressionid FOREIGN KEY (rightexpressionid) REFERENCES public.expression(expressionid);


--
-- Name: predictor fk_validationrule_skiptestexpressionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_validationrule_skiptestexpressionid FOREIGN KEY (skiptestexpressionid) REFERENCES public.expression(expressionid);


--
-- Name: validationrule fk_validationrule_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_validationrule_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: validationnotificationtemplatevalidationrules fk_validationrule_validationnotificationtemplateid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplatevalidationrules
    ADD CONSTRAINT fk_validationrule_validationnotificationtemplateid FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: validationrulegroup fk_validationrulegroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT fk_validationrulegroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: validationrulegroupmembers fk_validationrulegroup_validationruleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupmembers
    ADD CONSTRAINT fk_validationrulegroup_validationruleid FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: validationrulegroupmembers fk_validationrulegroupmembers_validationrulegroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupmembers
    ADD CONSTRAINT fk_validationrulegroupmembers_validationrulegroupid FOREIGN KEY (validationgroupid) REFERENCES public.validationrulegroup(validationrulegroupid);


--
-- Name: visualization_axis fk_visualization_axis_axisid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_axis
    ADD CONSTRAINT fk_visualization_axis_axisid FOREIGN KEY (axisid) REFERENCES public.axis(axisid);


--
-- Name: visualization_axis fk_visualization_axis_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_axis
    ADD CONSTRAINT fk_visualization_axis_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_categorydimensions fk_visualization_categorydimensions_categorydimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_categorydimensions
    ADD CONSTRAINT fk_visualization_categorydimensions_categorydimensionid FOREIGN KEY (categorydimensionid) REFERENCES public.categorydimension(categorydimensionid);


--
-- Name: visualization_categorydimensions fk_visualization_categorydimensions_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_categorydimensions
    ADD CONSTRAINT fk_visualization_categorydimensions_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_categoryoptiongroupsetdimensions fk_visualization_catoptiongroupsetdimensions_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_visualization_catoptiongroupsetdimensions_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_columns fk_visualization_columns_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_columns
    ADD CONSTRAINT fk_visualization_columns_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_datadimensionitems fk_visualization_datadimensionitems_datadimensionitemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_datadimensionitems
    ADD CONSTRAINT fk_visualization_datadimensionitems_datadimensionitemid FOREIGN KEY (datadimensionitemid) REFERENCES public.datadimensionitem(datadimensionitemid);


--
-- Name: visualization_datadimensionitems fk_visualization_datadimensionitems_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_datadimensionitems
    ADD CONSTRAINT fk_visualization_datadimensionitems_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_dataelementgroupsetdimensions fk_visualization_dataelementgroupsetdimensions_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_dataelementgroupsetdimensions
    ADD CONSTRAINT fk_visualization_dataelementgroupsetdimensions_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_categoryoptiongroupsetdimensions fk_visualization_dimensions_catoptiongroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_visualization_dimensions_catoptiongroupsetdimensionid FOREIGN KEY (categoryoptiongroupsetdimensionid) REFERENCES public.categoryoptiongroupsetdimension(categoryoptiongroupsetdimensionid);


--
-- Name: visualization_dataelementgroupsetdimensions fk_visualization_dimensions_dataelementgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_dataelementgroupsetdimensions
    ADD CONSTRAINT fk_visualization_dimensions_dataelementgroupsetdimensionid FOREIGN KEY (dataelementgroupsetdimensionid) REFERENCES public.dataelementgroupsetdimension(dataelementgroupsetdimensionid);


--
-- Name: visualization_orgunitgroupsetdimensions fk_visualization_dimensions_orgunitgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_visualization_dimensions_orgunitgroupsetdimensionid FOREIGN KEY (orgunitgroupsetdimensionid) REFERENCES public.orgunitgroupsetdimension(orgunitgroupsetdimensionid);


--
-- Name: visualization_filters fk_visualization_filters_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_filters
    ADD CONSTRAINT fk_visualization_filters_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_itemorgunitgroups fk_visualization_itemorgunitgroups_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_itemorgunitgroups
    ADD CONSTRAINT fk_visualization_itemorgunitgroups_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: visualization_itemorgunitgroups fk_visualization_itemorgunitunitgroups_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_itemorgunitgroups
    ADD CONSTRAINT fk_visualization_itemorgunitunitgroups_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization fk_visualization_lastupdateby; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization
    ADD CONSTRAINT fk_visualization_lastupdateby FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: visualization fk_visualization_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization
    ADD CONSTRAINT fk_visualization_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: visualization_organisationunits fk_visualization_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_organisationunits
    ADD CONSTRAINT fk_visualization_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: visualization_organisationunits fk_visualization_organisationunits_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_organisationunits
    ADD CONSTRAINT fk_visualization_organisationunits_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_orgunitgroupsetdimensions fk_visualization_orgunitgroupsetdimensions_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_visualization_orgunitgroupsetdimensions_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_orgunitlevels fk_visualization_orgunitlevels_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_orgunitlevels
    ADD CONSTRAINT fk_visualization_orgunitlevels_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization_periods fk_visualization_periods_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_periods
    ADD CONSTRAINT fk_visualization_periods_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: visualization_periods fk_visualization_periods_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_periods
    ADD CONSTRAINT fk_visualization_periods_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization fk_visualization_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization
    ADD CONSTRAINT fk_visualization_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: visualization_rows fk_visualization_rows_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_rows
    ADD CONSTRAINT fk_visualization_rows_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: visualization fk_visualization_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization
    ADD CONSTRAINT fk_visualization_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: visualization_yearlyseries fk_visualization_yearlyseries_visualizationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visualization_yearlyseries
    ADD CONSTRAINT fk_visualization_yearlyseries_visualizationid FOREIGN KEY (visualizationid) REFERENCES public.visualization(visualizationid);


--
-- Name: dataelementlegendsets fkbrsplevygf9yr4hvydhix39ug; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementlegendsets
    ADD CONSTRAINT fkbrsplevygf9yr4hvydhix39ug FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: programmessage_emailaddresses fkbyaw75hj8du8w14hpuhxj762w; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage_emailaddresses
    ADD CONSTRAINT fkbyaw75hj8du8w14hpuhxj762w FOREIGN KEY (programmessageemailaddressid) REFERENCES public.programmessage(id);


--
-- Name: smscommandcodes fkc6ibwny8jp0hq6l6w0w2untt4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandcodes
    ADD CONSTRAINT fkc6ibwny8jp0hq6l6w0w2untt4 FOREIGN KEY (id) REFERENCES public.smscommands(smscommandid);


--
-- Name: trackedentityattributelegendsets fkcdkajbb0rpnpwuo57i894s0dg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributelegendsets
    ADD CONSTRAINT fkcdkajbb0rpnpwuo57i894s0dg FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: smscommandspecialcharacters fkch98ncn24f71dft102f7of537; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandspecialcharacters
    ADD CONSTRAINT fkch98ncn24f71dft102f7of537 FOREIGN KEY (smscommandid) REFERENCES public.smscommands(smscommandid);


--
-- Name: smscommandcodes fke1eymlpayuhawlo8pfuwue654; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandcodes
    ADD CONSTRAINT fke1eymlpayuhawlo8pfuwue654 FOREIGN KEY (codeid) REFERENCES public.smscodes(smscodeid);


--
-- Name: datasetnotification_datasets fken6g44y648k1fembweltcao3e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotification_datasets
    ADD CONSTRAINT fken6g44y648k1fembweltcao3e FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: previouspasswords fkg6n5kwuhypwdvkn15ke824kpb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.previouspasswords
    ADD CONSTRAINT fkg6n5kwuhypwdvkn15ke824kpb FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: program_userroles fkgb55kdvtf92qykh2840inyhst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_userroles
    ADD CONSTRAINT fkgb55kdvtf92qykh2840inyhst FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: pushanalysis fkibpy72i2p9nfkdtqqe6my34nr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT fkibpy72i2p9nfkdtqqe6my34nr FOREIGN KEY (dashboard) REFERENCES public.dashboard(dashboardid);


--
-- Name: programindicatorlegendsets fkkbd9rqv83w4nwogj5fchtxj9y; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorlegendsets
    ADD CONSTRAINT fkkbd9rqv83w4nwogj5fchtxj9y FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: outbound_sms_recipients fkktmkxjuo5b3v1q2jqk7lymh0p; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbound_sms_recipients
    ADD CONSTRAINT fkktmkxjuo5b3v1q2jqk7lymh0p FOREIGN KEY (outbound_sms_id) REFERENCES public.outbound_sms(id);


--
-- Name: programmessage_deliverychannels fkljv6vp4ro5l6stx7dclnkenen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage_deliverychannels
    ADD CONSTRAINT fkljv6vp4ro5l6stx7dclnkenen FOREIGN KEY (programmessagedeliverychannelsid) REFERENCES public.programmessage(id);


--
-- Name: pushanalysisrecipientusergroups fklllvhilfsouycft98q82ph66q; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysisrecipientusergroups
    ADD CONSTRAINT fklllvhilfsouycft98q82ph66q FOREIGN KEY (usergroupid) REFERENCES public.pushanalysis(pushanalysisid);


--
-- Name: datasetnotificationtemplate_deliverychannel fkpmebskggkjfjfwxw7u43twmg2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate_deliverychannel
    ADD CONSTRAINT fkpmebskggkjfjfwxw7u43twmg2 FOREIGN KEY (datasetnotificationtemplateid) REFERENCES public.datasetnotificationtemplate(datasetnotificationtemplateid);


--
-- Name: smscommandspecialcharacters fktl0s6blarqvbvjhnoa94drtb2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandspecialcharacters
    ADD CONSTRAINT fktl0s6blarqvbvjhnoa94drtb2 FOREIGN KEY (specialcharacterid) REFERENCES public.smsspecialcharacter(specialcharacterid);


--
-- Name: potentialduplicate potentialduplicate_lastupdatedby_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.potentialduplicate
    ADD CONSTRAINT potentialduplicate_lastupdatedby_user FOREIGN KEY (lastupdatebyusername) REFERENCES public.userinfo(username);


--
-- PostgreSQL database dump complete
--

\unrestrict bariPagwfIa45BR4nvpqwP5XoTf6iysnCssZVFNXqGEEVaXHAG9ygRfrkdVWugI

